-- RBAC tables and seed policies for test endpoints
-- Create tables
CREATE TABLE IF NOT EXISTS rbac_policy (
  id            VARCHAR(12) PRIMARY KEY,
  http_method   VARCHAR(10) NOT NULL,
  pattern       VARCHAR(255) NOT NULL,
  effect        VARCHAR(10)  NOT NULL,
  scope         VARCHAR(20)  NOT NULL,
  conditions    JSONB        NULL,
  priority      INT          NOT NULL,
  enabled       BOOLEAN      NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS rbac_policy_role (
  id          VARCHAR(12) PRIMARY KEY,
  policy_id   VARCHAR(12) NOT NULL REFERENCES rbac_policy(id) ON DELETE CASCADE,
  role_name   VARCHAR(100) NOT NULL,
  created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  CONSTRAINT uk_rbac_policy_role UNIQUE(policy_id, role_name)
);

-- Seed policies for RBAC test controller
INSERT INTO rbac_policy (id, http_method, pattern, effect, scope, conditions, priority, enabled)
VALUES
  ('RBAC00000001', 'GET', '/api/rbac-test/public', 'ALLOW', 'Application', NULL, 10, TRUE)
ON CONFLICT (id) DO NOTHING;

INSERT INTO rbac_policy (id, http_method, pattern, effect, scope, conditions, priority, enabled)
VALUES
  ('RBAC00000002', 'GET', '/api/rbac-test/user', 'ALLOW', 'Application', NULL, 10, TRUE)
ON CONFLICT (id) DO NOTHING;

INSERT INTO rbac_policy (id, http_method, pattern, effect, scope, conditions, priority, enabled)
VALUES
  ('RBAC00000003', 'GET', '/api/rbac-test/admin', 'ALLOW', 'Application', NULL, 10, TRUE)
ON CONFLICT (id) DO NOTHING;

-- Bind roles
INSERT INTO rbac_policy_role (id, policy_id, role_name)
VALUES ('RPR00000001', 'RBAC00000002', 'USER')
ON CONFLICT (id) DO NOTHING;

INSERT INTO rbac_policy_role (id, policy_id, role_name)
VALUES ('RPR00000002', 'RBAC00000003', 'ADMIN')
ON CONFLICT (id) DO NOTHING;
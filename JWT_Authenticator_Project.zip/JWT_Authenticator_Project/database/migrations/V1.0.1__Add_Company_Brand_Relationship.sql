-- Migration: Add Company-Brand Relationship
-- Version: V1.0.1
-- Description: Add company_id foreign key to brands table to establish Company -> Brand relationship

-- Add company_id column to brands table
ALTER TABLE brands 
ADD COLUMN company_id INTEGER;

-- Add foreign key constraint
ALTER TABLE brands 
ADD CONSTRAINT fk_brands_company 
FOREIGN KEY (company_id) REFERENCES company(companyid) 
ON DELETE SET NULL ON UPDATE CASCADE;

-- Add index for performance
CREATE INDEX idx_brand_company ON brands(company_id);

-- Add comment for documentation
COMMENT ON COLUMN brands.company_id IS 'Foreign key reference to company table - links brand to owning company';

-- Optional: Update existing brands to link with companies based on domain matching
-- This is a one-time data migration for existing records
UPDATE brands b 
SET company_id = (
    SELECT c.companyid 
    FROM company c 
    WHERE c.domainname = LOWER(
        CASE 
            WHEN b.website LIKE 'https://%' THEN SUBSTRING(b.website FROM 9)
            WHEN b.website LIKE 'http://%' THEN SUBSTRING(b.website FROM 8)
            ELSE b.website
        END
    )
    LIMIT 1
)
WHERE b.company_id IS NULL 
AND EXISTS (
    SELECT 1 FROM company c 
    WHERE c.domainname = LOWER(
        CASE 
            WHEN b.website LIKE 'https://%' THEN SUBSTRING(b.website FROM 9)
            WHEN b.website LIKE 'http://%' THEN SUBSTRING(b.website FROM 8)
            ELSE b.website
        END
    )
);

-- Log migration completion
INSERT INTO migration_log (version, description, executed_at) 
VALUES ('V1.0.1', 'Added Company-Brand relationship with company_id foreign key', NOW())
ON CONFLICT (version) DO NOTHING;
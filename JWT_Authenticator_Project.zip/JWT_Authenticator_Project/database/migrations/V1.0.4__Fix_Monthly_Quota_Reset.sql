-- Migration: Fix Monthly Quota Reset Issues
-- Version: V1.0.4
-- Description: Fix critical bugs preventing monthly quota reset from working
-- 
-- Issues Fixed:
-- 1. Make last_reset_date column nullable to allow NULL checks in queries
-- 2. Reset existing data with proper logic for next reset cycle
-- 
-- Date: 2025-01-09

-- Step 1: Make last_reset_date column nullable
ALTER TABLE api_key_monthly_usage 
ALTER COLUMN last_reset_date DROP NOT NULL;

-- Step 2: Add index for better performance on reset queries
CREATE INDEX IF NOT EXISTS idx_api_key_monthly_usage_reset_date 
ON api_key_monthly_usage(last_reset_date);

-- Step 3: Add comment for documentation
COMMENT ON COLUMN api_key_monthly_usage.last_reset_date IS 
'Date when this usage record was last reset. NULL indicates never reset. Used by monthly quota reset scheduler.';

-- Step 4: Fix any existing data - set records from December 2024 or earlier to need reset
-- This ensures they get picked up by the next reset cycle
UPDATE api_key_monthly_usage 
SET last_reset_date = '2024-12-31'::date
WHERE last_reset_date >= '2025-01-01'::date
  AND month_year <= '2024-12';

-- Step 5: Log migration completion
INSERT INTO migration_log (version, description, executed_at) 
VALUES ('V1.0.4', 'Fixed monthly quota reset bugs - nullable last_reset_date and proper date logic', NOW())
ON CONFLICT (version) DO NOTHING;

-- Optional: Create migration_log table if it doesn't exist
CREATE TABLE IF NOT EXISTS migration_log (
  version VARCHAR(20) PRIMARY KEY,
  description TEXT,
  executed_at TIMESTAMPTZ DEFAULT NOW()
);
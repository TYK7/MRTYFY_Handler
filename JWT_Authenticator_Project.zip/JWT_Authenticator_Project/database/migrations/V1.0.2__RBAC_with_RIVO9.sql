-- ============================================================
-- RBAC with per-table RIVO9 ID generators
-- Each table starts at: RIVO90000001
-- ID format: 'RIVO9' + 7 digits (varchar(12))
-- ============================================================

-- ============================================================
-- Per-table sequences and ID helper functions
-- Ensures first ID in EACH table is RIVO90000001
-- ============================================================

-- rbac_policy
CREATE SEQUENCE IF NOT EXISTS rivo9_rbac_policy_seq START 1 INCREMENT 1;
-- NOTE: If this sequence is already in use with data present, comment next line
ALTER SEQUENCE rivo9_rbac_policy_seq RESTART WITH 1;

CREATE OR REPLACE FUNCTION next_rivo9_rbac_policy_id()
RETURNS varchar AS $$
  SELECT 'RIVO9' || lpad(nextval('rivo9_rbac_policy_seq')::text, 7, '0');
$$ LANGUAGE sql;

-- rbac_policy_role
CREATE SEQUENCE IF NOT EXISTS rivo9_rbac_policy_role_seq START 1 INCREMENT 1;
-- NOTE: If this sequence is already in use with data present, comment next line
ALTER SEQUENCE rivo9_rbac_policy_role_seq RESTART WITH 1;

CREATE OR REPLACE FUNCTION next_rivo9_rbac_policy_role_id()
RETURNS varchar AS $$
  SELECT 'RIVO9' || lpad(nextval('rivo9_rbac_policy_role_seq')::text, 7, '0');
$$ LANGUAGE sql;


-- ============================================================
-- RBAC tables using per-table RIVO9 primary keys
-- ============================================================

-- rbac_policy: rules for endpoint access
CREATE TABLE IF NOT EXISTS rbac_policy (
  id                    varchar(12) PRIMARY KEY DEFAULT next_rivo9_rbac_policy_id(),
  http_method           varchar(10) NOT NULL CHECK (http_method IN ('GET','POST','PUT','PATCH','DELETE','*')),
  pattern               varchar(255) NOT NULL,
  effect                varchar(10)  NOT NULL DEFAULT 'ALLOW' CHECK (effect IN ('ALLOW','DENY')),
  scope                 varchar(20)  NOT NULL DEFAULT 'Application' CHECK (scope IN ('Application','Global')),
  conditions            jsonb,
  priority              int          NOT NULL DEFAULT 100,
  enabled               bool         NOT NULL DEFAULT true,
  created_at            timestamp    NOT NULL DEFAULT now(),
  updated_at            timestamp    NOT NULL DEFAULT now(),

  -- Optional audit — matches users.id (varchar(11))
  created_by_user_fk_id varchar(11) NULL REFERENCES public.users(id) ON DELETE SET NULL,
  updated_by_user_fk_id varchar(11) NULL REFERENCES public.users(id) ON DELETE SET NULL
);

-- Enforce default even if table already existed
ALTER TABLE rbac_policy ALTER COLUMN id SET DEFAULT next_rivo9_rbac_policy_id();

-- rbac_policy_role: role bindings per policy
CREATE TABLE IF NOT EXISTS rbac_policy_role (
  id         varchar(12) PRIMARY KEY DEFAULT next_rivo9_rbac_policy_role_id(),
  policy_id  varchar(12) NOT NULL REFERENCES rbac_policy(id) ON DELETE CASCADE,
  role_name  varchar(100) NOT NULL,  -- e.g., 'USER' | 'ADMIN'
  created_at timestamp NOT NULL DEFAULT now(),
  CONSTRAINT uk_rbac_policy_role UNIQUE (policy_id, role_name)
);

-- Enforce default even if table already existed
ALTER TABLE rbac_policy_role ALTER COLUMN id SET DEFAULT next_rivo9_rbac_policy_role_id();


-- ============================================================
-- Indexes
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_rbac_policy_pattern   ON rbac_policy(pattern);
CREATE INDEX IF NOT EXISTS idx_rbac_policy_method    ON rbac_policy(http_method);
CREATE INDEX IF NOT EXISTS idx_rbac_policy_enabled   ON rbac_policy(enabled);
CREATE INDEX IF NOT EXISTS idx_rbac_policy_priority  ON rbac_policy(priority);
CREATE INDEX IF NOT EXISTS idx_rbac_policy_role_pol  ON rbac_policy_role(policy_id);


-- ============================================================
-- Auto-maintain updated_at on updates
-- ============================================================
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_rbac_policy_updated_at ON rbac_policy;
CREATE TRIGGER trg_rbac_policy_updated_at
BEFORE UPDATE ON rbac_policy
FOR EACH ROW EXECUTE FUNCTION set_updated_at();


-- ============================================================
-- Minimal seed data
-- Public endpoints (no role binding)
-- API-key–based endpoints (bypass JWT RBAC; enforced by your API-key filters)
-- User/Admin rules for self-service and reference/statistics (no Super Admin in users table)
-- ============================================================

-- Public endpoints
INSERT INTO rbac_policy (http_method, pattern, effect, scope, priority, enabled)
VALUES
('*','/auth/**','ALLOW','Application',1,true),
('*','/v3/api-docs/**','ALLOW','Application',1,true),
('*','/swagger-ui/**','ALLOW','Application',1,true),
('GET','/swagger-ui.html','ALLOW','Application',1,true),
('GET','/actuator/health','ALLOW','Application',1,true)
ON CONFLICT DO NOTHING;

-- API-key–protected endpoints (bypass)
INSERT INTO rbac_policy (http_method, pattern, effect, scope, conditions, priority, enabled)
VALUES
('*','/api/external/**','ALLOW','Application','{"bypassFor":["API_KEY"]}',5,true),
('*','/api/secure/**','ALLOW','Application','{"bypassFor":["API_KEY"]}',5,true)
ON CONFLICT DO NOTHING;

-- User/Admin: API key self-service
WITH p1 AS (
  INSERT INTO rbac_policy (http_method, pattern, effect, scope, conditions, priority, enabled)
  VALUES ('*','/api/v1/api-keys/**','ALLOW','Application','{"ownership":"self"}',10,true)
  ON CONFLICT DO NOTHING
  RETURNING id
), p1f AS (
  SELECT COALESCE((SELECT id FROM p1),
                  (SELECT id FROM rbac_policy WHERE http_method='*' AND pattern='/api/v1/api-keys/**' LIMIT 1)) AS id
)
INSERT INTO rbac_policy_role (policy_id, role_name)
SELECT id, role_name FROM p1f CROSS JOIN (VALUES ('USER'),('ADMIN')) r(role_name)
ON CONFLICT DO NOTHING;

-- User/Admin: reference data
WITH p2 AS (
  INSERT INTO rbac_policy (http_method, pattern, effect, scope, conditions, priority, enabled)
  VALUES ('*','/api/v1/reference/**','ALLOW','Application','{}',10,true)
  ON CONFLICT DO NOTHING
  RETURNING id
), p2f AS (
  SELECT COALESCE((SELECT id FROM p2),
                  (SELECT id FROM rbac_policy WHERE http_method='*' AND pattern='/api/v1/reference/**' LIMIT 1)) AS id
)
INSERT INTO rbac_policy_role (policy_id, role_name)
SELECT id, role_name FROM p2f CROSS JOIN (VALUES ('USER'),('ADMIN')) r(role_name)
ON CONFLICT DO NOTHING;

-- User/Admin: add-ons (self)
WITH p3 AS (
  INSERT INTO rbac_policy (http_method, pattern, effect, scope, conditions, priority, enabled)
  VALUES ('*','/api/v1/api-keys/addons/**','ALLOW','Application','{"ownership":"self"}',10,true)
  ON CONFLICT DO NOTHING
  RETURNING id
), p3f AS (
  SELECT COALESCE((SELECT id FROM p3),
                  (SELECT id FROM rbac_policy WHERE http_method='*' AND pattern='/api/v1/api-keys/addons/**' LIMIT 1)) AS id
)
INSERT INTO rbac_policy_role (policy_id, role_name)
SELECT id, role_name FROM p3f CROSS JOIN (VALUES ('USER'),('ADMIN')) r(role_name)
ON CONFLICT DO NOTHING;

-- User/Admin: analytics/statistics (self)
WITH p4 AS (
  INSERT INTO rbac_policy (http_method, pattern, effect, scope, conditions, priority, enabled)
  VALUES
    ('GET','/api/v1/api-keys/analytics/**','ALLOW','Application','{"ownership":"self"}',12,true),
    ('GET','/api/v1/api-keys/statistics/*','ALLOW','Application','{"ownership":"self"}',12,true),
    ('GET','/api/v1/api-keys/statistics/*/analytics','ALLOW','Application','{"ownership":"self"}',12,true)
  ON CONFLICT DO NOTHING
  RETURNING id, pattern
)
INSERT INTO rbac_policy_role (policy_id, role_name)
SELECT p4.id, r.role_name
FROM p4
CROSS JOIN (VALUES ('USER'),('ADMIN')) AS r(role_name)
ON CONFLICT DO NOTHING;

-- Admin-only operations
WITH p5 AS (
  INSERT INTO rbac_policy (http_method, pattern, effect, scope, conditions, priority, enabled)
  VALUES
    ('GET','/api/v1/api-keys/statistics/system','ALLOW','Application','{}',20,true),
    ('GET','/api/v1/api-keys/statistics/realtime','ALLOW','Application','{}',20,true),
    ('POST','/api/v1/api-keys/statistics/cleanup','ALLOW','Application','{}',20,true),
    ('GET','/api/v1/api-keys/addons/expiring','ALLOW','Application','{}',20,true),
    ('GET','/api/v1/api-keys/addons/nearly-exhausted','ALLOW','Application','{}',20,true),
    ('POST','/api/v1/api-keys/addons/process-auto-renewals','ALLOW','Application','{}',20,true),
    ('POST','/api/v1/api-keys/addons/cleanup-expired','ALLOW','Application','{}',20,true)
  ON CONFLICT DO NOTHING
  RETURNING id
)
INSERT INTO rbac_policy_role (policy_id, role_name)
SELECT id, 'ADMIN' FROM p5
ON CONFLICT DO NOTHING;

-- ============================================================
-- End of file
-- ============================================================
package com.example.jwtauthenticator.service;

import com.example.jwtauthenticator.dto.RegisterResponse;
import com.example.jwtauthenticator.entity.Company;
import com.example.jwtauthenticator.entity.User;
import com.example.jwtauthenticator.model.RegisterRequest;
import com.example.jwtauthenticator.repository.CompanyRepository;
import com.example.jwtauthenticator.repository.UserRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import static org.assertj.core.api.Assertions.*;

/**
 * 🧪 Integration Test for Enhanced User Registration
 * 
 * Tests the complete registration flow with email validation and company resolution
 * using the existing AuthService with enhanced capabilities.
 */
@SpringBootTest
@ActiveProfiles("test")
@Transactional
@DisplayName("Enhanced Registration Integration Tests")
class EnhancedRegistrationIntegrationTest {

    @Autowired
    private AuthService authService;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private CompanyRepository companyRepository;

    @Test
    @DisplayName("🟢 Gmail user registration - creates Gmail company and user")
    void testGmailUserRegistration() {
        // Given
        RegisterRequest gmailRequest = new RegisterRequest(
            "testuser_gmail",
            "password123",
            "testuser@gmail.com",
            "Test",
            "User",
            "+1234567890",
            "Test Location",
            null, // brandId - will be auto-generated
            null, // roleId - will use default
            null  // companyId - will be resolved from email
        );

        // When
        RegisterResponse response = authService.registerUser(gmailRequest);

        // Then
        assertThat(response.success()).isTrue();
        assertThat(response.message()).contains("registered successfully");
        
        // Verify user was created
        User createdUser = userRepository.findByEmail("testuser@gmail.com").orElse(null);
        assertThat(createdUser).isNotNull();
        assertThat(createdUser.getUsername()).isEqualTo("testuser_gmail");
        
        // Verify Gmail company was created
        Company gmailCompany = createdUser.getCompany();
        assertThat(gmailCompany).isNotNull();
        assertThat(gmailCompany.getCompanyName()).isEqualTo("Gmail");
        assertThat(gmailCompany.getDomainName()).isEqualTo("gmail.com");
        assertThat(gmailCompany.getStatus()).isEqualTo("Email Provider");
        
        // Verify company has correct email domains
        assertThat(gmailCompany.getEmailDomains()).contains("gmail.com", "googlemail.com");
    }

    @Test
    @DisplayName("🟢 Second Gmail user - reuses existing Gmail company")
    void testSecondGmailUserReusesCompany() {
        // Given - First user creates Gmail company
        RegisterRequest firstGmailRequest = new RegisterRequest(
            "first_gmail_user",
            "password123",
            "first@gmail.com",
            "First",
            "User",
            "+1234567890",
            "Test Location",
            null, // brandId
            null, // roleId
            null  // companyId
        );
        
        authService.registerUser(firstGmailRequest);
        long initialCompanyCount = companyRepository.count();
        
        // When - Second user registers
        RegisterRequest secondGmailRequest = new RegisterRequest(
            "second_gmail_user",
            "password123",
            "second@gmail.com",
            "Second",
            "User",
            "+1234567890",
            "Test Location",
            null, // brandId
            null, // roleId
            null  // companyId
        );
        
        RegisterResponse response = authService.registerUser(secondGmailRequest);

        // Then
        assertThat(response.success()).isTrue();
        
        // Verify no new company was created
        assertThat(companyRepository.count()).isEqualTo(initialCompanyCount);
        
        // Verify both users have the same Gmail company
        User firstUser = userRepository.findByEmail("first@gmail.com").orElseThrow();
        User secondUser = userRepository.findByEmail("second@gmail.com").orElseThrow();
        
        assertThat(firstUser.getCompany().getCompanyId())
            .isEqualTo(secondUser.getCompany().getCompanyId());
        assertThat(secondUser.getCompany().getCompanyName()).isEqualTo("Gmail");
    }

    @Test
    @DisplayName("🟢 Googlemail.com user - uses Gmail company (domain mapping)")
    void testGooglemailUserUsesGmailCompany() {
        // Given - Gmail company already exists
        RegisterRequest gmailRequest = new RegisterRequest(
            "gmail_user",
            "password123",
            "user@gmail.com",
            "Gmail",
            "User",
            "+1234567890",
            "Test Location",
            null, // brandId
            null, // roleId
            null  // companyId
        );
        authService.registerUser(gmailRequest);
        
        // When - Googlemail user registers
        RegisterRequest googlemailRequest = new RegisterRequest(
            "googlemail_user",
            "password123",
            "user@googlemail.com",
            "Googlemail",
            "User",
            "+1234567890",
            "Test Location",
            null, // brandId
            null, // roleId
            null  // companyId
        );
        
        RegisterResponse response = authService.registerUser(googlemailRequest);

        // Then
        assertThat(response.success()).isTrue();
        
        // Verify both users have the same Gmail company
        User gmailUser = userRepository.findByEmail("user@gmail.com").orElseThrow();
        User googlemailUser = userRepository.findByEmail("user@googlemail.com").orElseThrow();
        
        assertThat(gmailUser.getCompany().getCompanyId())
            .isEqualTo(googlemailUser.getCompany().getCompanyId());
        assertThat(googlemailUser.getCompany().getCompanyName()).isEqualTo("Gmail");
        assertThat(googlemailUser.getCompany().getDomainName()).isEqualTo("gmail.com");
    }

    @Test
    @DisplayName("🟢 Multiple email providers - creates separate companies")
    void testMultipleEmailProviders() {
        // Given
        RegisterRequest gmailRequest = new RegisterRequest(
            "gmail_user", "password123", "user@gmail.com",
            "Gmail", "User", "+1234567890", "Test Location", null, null, null
        );
        
        RegisterRequest yahooRequest = new RegisterRequest(
            "yahoo_user", "password123", "user@yahoo.com",
            "Yahoo", "User", "+1234567890", "Test Location", null, null, null
        );
        
        RegisterRequest outlookRequest = new RegisterRequest(
            "outlook_user", "password123", "user@outlook.com",
            "Outlook", "User", "+1234567890", "Test Location", null, null, null
        );

        // When
        authService.registerUser(gmailRequest);
        authService.registerUser(yahooRequest);
        authService.registerUser(outlookRequest);

        // Then
        User gmailUser = userRepository.findByEmail("user@gmail.com").orElseThrow();
        User yahooUser = userRepository.findByEmail("user@yahoo.com").orElseThrow();
        User outlookUser = userRepository.findByEmail("user@outlook.com").orElseThrow();
        
        // Verify separate companies were created
        assertThat(gmailUser.getCompany().getCompanyName()).isEqualTo("Gmail");
        assertThat(yahooUser.getCompany().getCompanyName()).isEqualTo("Yahoo");
        assertThat(outlookUser.getCompany().getCompanyName()).isEqualTo("Outlook");
        
        // Verify they have different company IDs
        assertThat(gmailUser.getCompany().getCompanyId())
            .isNotEqualTo(yahooUser.getCompany().getCompanyId());
        assertThat(yahooUser.getCompany().getCompanyId())
            .isNotEqualTo(outlookUser.getCompany().getCompanyId());
        
        // Verify all are email providers
        assertThat(gmailUser.getCompany().getStatus()).isEqualTo("Email Provider");
        assertThat(yahooUser.getCompany().getStatus()).isEqualTo("Email Provider");
        assertThat(outlookUser.getCompany().getStatus()).isEqualTo("Email Provider");
    }

    @Test
    @DisplayName("🔴 Duplicate username - registration fails")
    void testDuplicateUsernameRegistrationFails() {
        // Given - First user registered
        RegisterRequest firstRequest = new RegisterRequest(
            "duplicate_user", "password123", "first@gmail.com",
            "First", "User", "+1234567890", "Test Location", null, null, null
        );
        authService.registerUser(firstRequest);
        
        // When - Second user with same username
        RegisterRequest duplicateRequest = new RegisterRequest(
            "duplicate_user", "password123", "second@yahoo.com",
            "Second", "User", "+1234567890", "Test Location", null, null, null
        );

        // Then
        assertThatThrownBy(() -> authService.registerUser(duplicateRequest))
            .isInstanceOf(RuntimeException.class)
            .hasMessageContaining("Username already exists");
    }

    @Test
    @DisplayName("🔴 Duplicate email - registration fails")
    void testDuplicateEmailRegistrationFails() {
        // Given - First user registered
        RegisterRequest firstRequest = new RegisterRequest(
            "first_user", "password123", "duplicate@gmail.com",
            "First", "User", "+1234567890", "Test Location", null, null, null
        );
        authService.registerUser(firstRequest);
        
        // When - Second user with same email
        RegisterRequest duplicateRequest = new RegisterRequest(
            "second_user", "password123", "duplicate@gmail.com",
            "Second", "User", "+1234567890", "Test Location", null, null, null
        );

        // Then
        assertThatThrownBy(() -> authService.registerUser(duplicateRequest))
            .isInstanceOf(RuntimeException.class)
            .hasMessageContaining("Email already exists");
    }
}
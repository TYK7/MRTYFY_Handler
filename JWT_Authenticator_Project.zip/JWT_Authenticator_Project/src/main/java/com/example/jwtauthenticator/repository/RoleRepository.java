package com.example.jwtauthenticator.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.jwtauthenticator.entity.Role;

@Repository
public interface RoleRepository extends JpaRepository<Role, Integer> {
    
    Optional<Role> findByRoleName(String roleName);
    
    Optional<Role> findByRoleNumber(Integer roleNumber);
    
    boolean existsByRoleName(String roleName);
    
    boolean existsByRoleNumber(Integer roleNumber);
    
    @Query("SELECT r FROM Role r WHERE r.roleName = :roleName AND r.scope = :scope")
    Optional<Role> findByRoleNameAndScope(@Param("roleName") String roleName, @Param("scope") String scope);
    
    // Find default user role (role name 'User' with role number 100)
    @Query("SELECT r FROM Role r WHERE r.roleName = 'User' OR r.roleNumber = 100 ORDER BY r.roleNumber ASC")
    Optional<Role> findDefaultUserRole();
}
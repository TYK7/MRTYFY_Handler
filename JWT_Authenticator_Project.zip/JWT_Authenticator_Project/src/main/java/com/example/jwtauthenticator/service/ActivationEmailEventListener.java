package com.example.jwtauthenticator.service;

import com.example.jwtauthenticator.event.ActivationSuccessEvent;
import com.example.jwtauthenticator.entity.User;
import com.example.jwtauthenticator.dto.ApiKeyGeneratedResponseDTO;
import com.example.jwtauthenticator.entity.ApiKey;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.transaction.event.TransactionPhase;

import java.util.HashMap;
import java.util.Map;

/**
 * Event listener that handles sending activation success emails
 * after the user activation transaction has been successfully committed.
 * This ensures email is sent only if activation was successful.
 */
@Service
@Slf4j
public class ActivationEmailEventListener {
    
    @Autowired
    private EmailService emailService;

    /**
     * Handles activation success events after transaction commits.
     * Sends activation success email with API key preview (secure).
     */
    @SuppressWarnings("unused")
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void handleActivationSuccessEvent(ActivationSuccessEvent event) {
        try {
            User user = event.getUser();
            ApiKeyGeneratedResponseDTO apiKey = event.getApiKey();
            
            log.info("📧 Processing activation success email for user: {} (post-transaction)", user.getUsername());
            
            // Validate required data
            if (user == null) {
                log.error("Cannot send activation email: user is null in event");
                return;
            }
            if (apiKey == null) {
                log.error("Cannot send activation email: apiKey is null for user {} in event", user.getUsername());
                return;
            }
            
            // ✅ SECURITY FIX: Create secure API key data for email (preview only)
            Map<String, Object> secureApiKeyData = new HashMap<>();
            secureApiKeyData.put("name", apiKey.getName());
            secureApiKeyData.put("keyPreview", ApiKey.generateKeyPreview(apiKey.getKeyValue())); // Only preview - matches template variable
            secureApiKeyData.put("environment", "Testing"); // Default environment
            secureApiKeyData.put("tier", "FREE_TIER");
            
            Map<String, Object> model = new HashMap<>();
            model.put("user", user);
            model.put("apiKey", secureApiKeyData);  // ✅ SECURE: Only preview data, NOT full key!
            model.put("userPlan", user.getPlan() != null ? user.getPlan() : com.example.jwtauthenticator.enums.UserPlan.FREE);
            
            // ✅ FRONTEND URL FIX: Use correct frontend URLs
            String loginUrl = "http://202.65.155.117/auth/login";  // ✅ FIXED: Frontend login URL
            String dashboardUrl = "http://202.65.155.117/dashboard/api-keys";  // ✅ FIXED: Frontend dashboard URL
            String apiDocsUrl = "http://202.65.155.117/auth/login";  // ✅ FIXED: Redirect to login since no API docs yet
            
            model.put("loginUrl", loginUrl);
            model.put("dashboardUrl", dashboardUrl);
            model.put("apiDocsUrl", apiDocsUrl);
            
            log.info("📧 EMAIL URLS for {}: Login={}, Dashboard={}, Docs={}", 
                    user.getUsername(), loginUrl, dashboardUrl, apiDocsUrl);
            
            emailService.sendActivationSuccessEmail(
                user.getEmail(), 
                user.getUsername(), 
                model
            );
            
            log.info("✅ Activation success email sent to user: {} (post-transaction)", user.getUsername());
        } catch (Exception e) {
            log.error("❌ Failed to send activation success email (post-transaction) to {}: {}", 
                     event.getUser() != null ? event.getUser().getUsername() : "unknown", 
                     e.getMessage(), e);
            // Don't re-throw exception - this is a background email process
            // User activation has already succeeded, email failure shouldn't affect that
        }
    }
}
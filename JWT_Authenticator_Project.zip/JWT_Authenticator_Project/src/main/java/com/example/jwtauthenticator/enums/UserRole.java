package com.example.jwtauthenticator.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

/**
 * Hierarchical User Role Enum
 * 
 * Defines the role hierarchy where higher roles inherit lower role permissions:
 * SUPER_ADMIN (Level 3) → ADMIN (Level 2) → USER (Level 1)
 * 
 * This ensures hierarchical access control where:
 * - USER can access USER endpoints only
 * - ADMIN can access USER + ADMIN endpoints  
 * - SUPER_ADMIN can access USER + ADMIN + SUPER_ADMIN endpoints
 */
@Getter
@RequiredArgsConstructor
public enum UserRole {
    
    /**
     * Standard application user - Level 1 (Base level)
     * Permissions: Own profile, own API keys, brand data consumption
     */
    USER(100, "User", "Application", List.of()),
    
    /**
     * Administrative user - Level 2 (Inherits USER permissions)
     * Permissions: USER + User management, system monitoring, analytics
     */
    ADMIN(200, "Admin", "Application", List.of(USER)),
    
    /**
     * Super administrator - Level 3 (Inherits USER + ADMIN permissions)  
     * Permissions: USER + ADMIN + System configuration, global operations
     */
    SUPER_ADMIN(300, "Super Admin", "Global", List.of(USER, ADMIN));

    private final int roleNumber;
    private final String displayName;
    private final String scope;
    private final List<UserRole> inheritsFrom;

    /**
     * Get the Spring Security role name with ROLE_ prefix
     */
    public String getRoleName() {
        return "ROLE_" + this.name();
    }

    /**
     * Get the database role name (without ROLE_ prefix)
     * Returns the exact role name format used in the database
     */
    public String getDatabaseRoleName() {
        return switch (this) {
            case USER -> "User";
            case ADMIN -> "Admin";
            case SUPER_ADMIN -> "Super Admin";
        };
    }

    /**
     * Check if this role can access resources that require the specified role
     * Implements hierarchical role checking
     * 
     * @param requiredRole The role required to access a resource
     * @return true if this role can access resources requiring the specified role
     */
    public boolean hasAccess(UserRole requiredRole) {
        if (this == requiredRole) {
            return true; // Direct role match
        }
        
        // Check if this role inherits the required role
        return getAllInheritedRoles().contains(requiredRole);
    }

    /**
     * Get all roles this role inherits from (including itself)
     */
    public Set<UserRole> getAllInheritedRoles() {
        Set<UserRole> allRoles = new java.util.HashSet<>();
        allRoles.add(this); // Add self
        
        // Recursively add inherited roles
        for (UserRole inheritedRole : inheritsFrom) {
            allRoles.addAll(inheritedRole.getAllInheritedRoles());
        }
        
        return allRoles;
    }

    /**
     * Get Spring Security authorities for this role (including inherited roles)
     */
    public List<String> getAuthorities() {
        return getAllInheritedRoles().stream()
            .map(UserRole::getRoleName)
            .toList();
    }

    /**
     * Find role by role name (supports both with and without ROLE_ prefix, and database format)
     */
    public static UserRole fromRoleName(String roleName) {
        if (roleName == null || roleName.trim().isEmpty()) {
            return USER; // Default role
        }
        
        // Remove ROLE_ prefix if present
        String cleanRoleName = roleName.startsWith("ROLE_") 
            ? roleName.substring(5) 
            : roleName;
        
        // Handle database format names
        return switch (cleanRoleName) {
            case "User" -> USER;
            case "Admin" -> ADMIN;
            case "Super Admin" -> SUPER_ADMIN;
            // Also handle uppercase enum names for backward compatibility
            case "USER" -> USER;
            case "ADMIN" -> ADMIN;
            case "SUPER_ADMIN" -> SUPER_ADMIN;
            default -> USER; // Default to USER if role not found
        };
    }

    /**
     * Find role by role number
     */
    public static UserRole fromRoleNumber(int roleNumber) {
        return Arrays.stream(values())
            .filter(role -> role.roleNumber == roleNumber)
            .findFirst()
            .orElse(USER); // Default to USER
    }

    /**
     * Check if a role name is valid
     */
    public static boolean isValidRoleName(String roleName) {
        try {
            fromRoleName(roleName);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Get all available role names with ROLE_ prefix
     */
    public static List<String> getAllRoleNames() {
        return Arrays.stream(values())
            .map(UserRole::getRoleName)
            .toList();
    }

    /**
     * Get role hierarchy as string for debugging
     */
    public String getHierarchyString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.getRoleName()).append(" (Level ").append(this.roleNumber).append(")");
        
        if (!inheritsFrom.isEmpty()) {
            sb.append(" -> inherits from: ");
            sb.append(inheritsFrom.stream()
                .map(UserRole::getRoleName)
                .reduce((a, b) -> a + ", " + b)
                .orElse("none"));
        }
        
        return sb.toString();
    }

    /**
     * Get role permissions description for documentation
     */
    public String getPermissionsDescription() {
        return switch (this) {
            case USER -> """
                - Own profile management (/api/users/**)
                - Own API key management (/api/v1/api-keys/**)
                - Own dashboard access (/api/dashboard/user/**)
                - Brand data consumption (/api/external/**, /api/secure/**)
                """;
                
            case ADMIN -> """
                - All USER permissions +
                - User management (/api/admin/users/**)
                - System API keys management (/api/admin/api-keys/**)
                - Role management (/api/roles/**)
                - System monitoring (/api/dashboard/admin/**)
                - Company & brand management (/api/companies/**, /api/brands/admin/**)
                """;
                
            case SUPER_ADMIN -> """
                - All USER and ADMIN permissions +
                - System configuration (/api/super/**)
                - ID generation management (/api/id-generator/**)
                - Global analytics (/api/super/analytics/**)
                - Critical system operations (backup, maintenance)
                """;
        };
    }

    @Override
    public String toString() {
        return String.format("%s (%d) - %s [%s]", 
            getRoleName(), roleNumber, displayName, scope);
    }
}
package com.example.jwtauthenticator.config;

import com.example.jwtauthenticator.security.JwtRequestFilter;
import com.example.jwtauthenticator.security.JwtUserDetailsService;
import com.example.jwtauthenticator.security.ApiKeyAuthenticationFilter;
import com.example.jwtauthenticator.security.ExternalApiSecurityFilter;
import com.example.jwtauthenticator.security.CustomAuthenticationEntryPoint;
import com.example.jwtauthenticator.security.CustomAccessDeniedHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    private final JwtUserDetailsService jwtUserDetailsService;
    private final PasswordEncoder passwordEncoder;
    private final JwtRequestFilter jwtRequestFilter;
    private final ApiKeyAuthenticationFilter apiKeyAuthenticationFilter;
    private final ExternalApiSecurityFilter externalApiSecurityFilter;
    private final CustomAuthenticationEntryPoint customAuthenticationEntryPoint;
    private final CustomAccessDeniedHandler customAccessDeniedHandler;
    private final RoleHierarchy roleHierarchy;
    
    @Autowired
    private AppConfig appConfig;

    public SecurityConfig(JwtUserDetailsService jwtUserDetailsService, PasswordEncoder passwordEncoder, 
                         JwtRequestFilter jwtRequestFilter, ApiKeyAuthenticationFilter apiKeyAuthenticationFilter,
                         ExternalApiSecurityFilter externalApiSecurityFilter,
                         CustomAuthenticationEntryPoint customAuthenticationEntryPoint,
                         CustomAccessDeniedHandler customAccessDeniedHandler,
                         RoleHierarchy roleHierarchy) {
        this.jwtUserDetailsService = jwtUserDetailsService;
        this.passwordEncoder = passwordEncoder;
        this.jwtRequestFilter = jwtRequestFilter;
        this.apiKeyAuthenticationFilter = apiKeyAuthenticationFilter;
        this.externalApiSecurityFilter = externalApiSecurityFilter;
        this.customAuthenticationEntryPoint = customAuthenticationEntryPoint;
        this.customAccessDeniedHandler = customAccessDeniedHandler;
        this.roleHierarchy = roleHierarchy;
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(jwtUserDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder);
        return authProvider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable())
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .headers(headers -> headers
                    .frameOptions(frameOptions -> frameOptions.deny())
                    .httpStrictTransportSecurity(hstsConfig -> hstsConfig
                        .includeSubDomains(true)
                        .maxAgeInSeconds(31536000))
                )
                .authorizeHttpRequests(authz -> authz
                    // 🔓 PUBLIC ENDPOINTS - No authentication required
                    .requestMatchers(
                        // Authentication & Registration
                        "/auth/register", "/auth/token", "/auth/login", "/auth/login/**",
                        "/auth/forward", "/auth/forgot-password*", "/auth/reset-password", 
                        "/auth/refresh", "/auth/verify-email", "/auth/google", 
                        "/auth/check-*", "/auth/username-exists", "/auth/brand-info",
                        "/auth/tfa/**", "/auth/public-forward",
                        
                        // Public Data & Assets
                        "/api/brands/assets/**", "/api/brands/images/**", 
                        "/api/brands/all", "/api/category/hierarchy",
                        
                        // External API (Protected by API Key + Domain validation)
                        "/api/external/**", "/api/secure/**",
                        
                        // Documentation & Health
                        "/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html",
                        "/actuator/health",
                        
                        // Development (Remove in production)
                        "/test/**", "/api/id-generator/user-id/init-sequence"
                    ).permitAll()
                    
                    // 🔧 SUPER_ADMIN Level Endpoints (ROLE_SUPER_ADMIN only)
                    .requestMatchers("/api/super/**", "/api/id-generator/**")
                       .hasRole("SUPER_ADMIN")
                     
                    // 🛠️ ADMIN Level Endpoints (ROLE_ADMIN+ due to hierarchy)  
                    .requestMatchers("/api/admin/**", "/api/roles/**", "/api/companies/**", 
                                   "/api/dashboard/admin/**", "/api/brands/admin/**")
                        .hasRole("ADMIN")
                    
                   // 👤 USER Level Endpoints (ROLE_USER+ due to hierarchy)
                    .requestMatchers("/api/users/**", "/api/v1/api-keys/**", 
                                    "/api/v1/dashboard/**")
                        .hasRole("USER")
                    
                    // 🧪 TESTING Endpoints (Authenticated users only - Remove in production)
                    .requestMatchers("/api/test/**").authenticated()
                    
                    // Default: All other endpoints require authentication
                    .anyRequest().authenticated()
                )
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authenticationProvider(authenticationProvider())
                
                // 🔐 Custom Exception Handlers for Role-Based Security
                .exceptionHandling(exceptions -> exceptions
                    .authenticationEntryPoint(customAuthenticationEntryPoint)
                    .accessDeniedHandler(customAccessDeniedHandler)
                )
                
                // 🚨 Security Filters Chain (Order is important!)
                .addFilterBefore(apiKeyAuthenticationFilter, UsernamePasswordAuthenticationFilter.class)
                .addFilterAfter(jwtRequestFilter, ApiKeyAuthenticationFilter.class)
                .addFilterAfter(externalApiSecurityFilter, JwtRequestFilter.class);

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        // Allow all origins since JWT authentication handles security
        configuration.setAllowedOrigins(Arrays.asList("*"));
        configuration.setAllowedMethods(Arrays.asList("*"));
        configuration.setAllowedHeaders(Arrays.asList("*"));
        configuration.setExposedHeaders(Arrays.asList(
            "Authorization", 
            "X-RateLimit-Limit", 
            "X-RateLimit-Remaining", 
            "X-RateLimit-Reset",
            "X-RateLimit-Tier",
            "X-RateLimit-Additional-Available",
            "X-RateLimit-Total-Remaining",
            "X-RateLimit-Used-AddOn"
        ));
        configuration.setAllowCredentials(false); // Must be false when using wildcard origins
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}

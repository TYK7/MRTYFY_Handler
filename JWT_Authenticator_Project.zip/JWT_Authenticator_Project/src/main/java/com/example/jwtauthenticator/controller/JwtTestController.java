package com.example.jwtauthenticator.controller;

import com.example.jwtauthenticator.util.JwtUtil;
import com.example.jwtauthenticator.entity.User;
import com.example.jwtauthenticator.repository.UserRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jakarta.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * JWT Test Controller - For testing and debugging JWT token structure
 * This controller helps verify that JWT tokens contain proper role claims
 * 
 * ⚠️ NOTE: This is a testing controller. Remove in production!
 */
@RestController
@RequestMapping("/api/test/jwt")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "JWT Testing", description = "Testing endpoints for JWT token validation (Remove in production)")
public class JwtTestController {

    private final JwtUtil jwtUtil;
    private final UserRepository userRepository;

    /**
     * Debug JWT Token Contents
     * Shows what information is stored in the current JWT token
     */
    @GetMapping("/debug")
    @Operation(
        summary = "Debug JWT Token Contents", 
        description = "Extract and display JWT token claims including user ID, role, username, etc. Useful for testing role-based authentication.",
        security = { @SecurityRequirement(name = "Bearer Authentication") }
    )
    public ResponseEntity<Map<String, Object>> debugJwtToken(
            @AuthenticationPrincipal UserDetails userDetails,
            Authentication authentication) {
        
        try {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            String authHeader = request.getHeader("Authorization");
            
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "No valid JWT token found in Authorization header"
                ));
            }
            
            String jwt = authHeader.substring(7);
            
            // Extract claims from JWT
            String username = jwtUtil.extractUsername(jwt);
            String userId = jwtUtil.extractUserId(jwt); 
            String role = jwtUtil.extractRole(jwt);
            boolean isExpired = jwtUtil.isTokenExpired(jwt);
            
            // Get user details from database
            Optional<User> userOpt = userRepository.findById(userId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "JWT Token Debug Information");
            
            // JWT Claims
            Map<String, Object> jwtClaims = new HashMap<>();
            jwtClaims.put("username", username);
            jwtClaims.put("userId", userId);
            jwtClaims.put("role", role);
            jwtClaims.put("isExpired", isExpired);
            response.put("jwtClaims", jwtClaims);
            
            // Spring Security Context
            Map<String, Object> securityContext = new HashMap<>();
            securityContext.put("authenticatedUsername", userDetails.getUsername());
            securityContext.put("authorities", authentication.getAuthorities());
            securityContext.put("isAuthenticated", authentication.isAuthenticated());
            response.put("securityContext", securityContext);
            
            // Database User Info
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                Map<String, Object> dbUser = new HashMap<>();
                dbUser.put("id", user.getId());
                dbUser.put("userId", user.getUserId());
                dbUser.put("username", user.getUsername());
                dbUser.put("email", user.getEmail());
                dbUser.put("brandId", user.getBrandId());
                dbUser.put("roleName", user.getRole() != null ? user.getRole().getRoleName() : "No role");
                dbUser.put("roleNumber", user.getRole() != null ? user.getRole().getRoleNumber() : "No role");
                response.put("databaseUser", dbUser);
            } else {
                response.put("databaseUser", Map.of("error", "User not found in database"));
            }
            
            log.info("🔍 JWT Debug - User: {}, Role: {}, Authorities: {}", 
                username, role, authentication.getAuthorities());
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("❌ JWT Debug failed: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().body(Map.of(
                "error", "JWT debug failed: " + e.getMessage()
            ));
        }
    }

    /**
     * Test Role-Based Access
     * Simple endpoint to test if role extraction works
     */
    @GetMapping("/role-test")
    @Operation(
        summary = "Test Role Extraction",
        description = "Simple test to verify role extraction from JWT tokens works correctly.",
        security = { @SecurityRequirement(name = "Bearer Authentication") }
    )
    public ResponseEntity<Map<String, Object>> testRoleExtraction(Authentication authentication) {
        try {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            String authHeader = request.getHeader("Authorization");
            
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "No JWT token found"
                ));
            }
            
            String jwt = authHeader.substring(7);
            String role = jwtUtil.extractRole(jwt);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("extractedRole", role);
            response.put("springSecurityAuthorities", authentication.getAuthorities());
            response.put("message", "Role extraction successful");
            
            // Role hierarchy check
            boolean isUser = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_USER"));
            boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));
            boolean isSuperAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_SUPER_ADMIN"));
                
            response.put("roleChecks", Map.of(
                "isUser", isUser,
                "isAdmin", isAdmin,
                "isSuperAdmin", isSuperAdmin
            ));
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of(
                "error", "Role test failed: " + e.getMessage()
            ));
        }
    }
}
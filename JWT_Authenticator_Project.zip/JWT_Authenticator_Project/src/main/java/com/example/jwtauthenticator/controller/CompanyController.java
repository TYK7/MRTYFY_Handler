package com.example.jwtauthenticator.controller;

import com.example.jwtauthenticator.dto.CompanyDTO;
import com.example.jwtauthenticator.service.CompanyService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/companies")
@Tag(name = "Company Management", description = "APIs for managing companies")
@Slf4j
public class CompanyController {

    @Autowired
    private CompanyService companyService;

    @Operation(summary = "Get all companies", description = "Retrieve all companies in the system")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Companies retrieved successfully")
    })
    @GetMapping
    public ResponseEntity<List<CompanyDTO>> getAllCompanies() {
        List<CompanyDTO> companies = companyService.getAllCompanies();
        return ResponseEntity.ok(companies);
    }

    @Operation(summary = "Get active companies", description = "Retrieve all active companies")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Active companies retrieved successfully")
    })
    @GetMapping("/active")
    public ResponseEntity<List<CompanyDTO>> getActiveCompanies() {
        List<CompanyDTO> companies = companyService.getActiveCompanies();
        return ResponseEntity.ok(companies);
    }

    @Operation(summary = "Get company by ID", description = "Retrieve a specific company by its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Company found"),
            @ApiResponse(responseCode = "404", description = "Company not found")
    })
    @GetMapping("/{companyId}")
    public ResponseEntity<CompanyDTO> getCompanyById(@PathVariable Integer companyId) {
        return companyService.getCompanyById(companyId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Get company by name", description = "Retrieve a specific company by its name")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Company found"),
            @ApiResponse(responseCode = "404", description = "Company not found")
    })
    @GetMapping("/name/{companyName}")
    public ResponseEntity<CompanyDTO> getCompanyByName(@PathVariable String companyName) {
        return companyService.getCompanyByName(companyName)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Get company by domain", description = "Retrieve a specific company by its domain name")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Company found"),
            @ApiResponse(responseCode = "404", description = "Company not found")
    })
    @GetMapping("/domain/{domainName}")
    public ResponseEntity<CompanyDTO> getCompanyByDomain(@PathVariable String domainName) {
        return companyService.getCompanyByDomain(domainName)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
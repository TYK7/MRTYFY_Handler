package com.example.jwtauthenticator.config;

import com.example.jwtauthenticator.enums.UserRole;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
import org.springframework.security.access.hierarchicalroles.RoleHierarchyImpl;

/**
 * Role Hierarchy Configuration
 * 
 * Defines the hierarchical relationship between roles for Spring Security.
 * Higher roles automatically inherit permissions of lower roles.
 * 
 * Hierarchy: ROLE_SUPER_ADMIN > ROLE_ADMIN > ROLE_USER
 */
@Configuration
@Slf4j
public class RoleHierarchyConfig {

    /**
     * Configure Spring Security role hierarchy
     * Format: HIGHER_ROLE > LOWER_ROLE
     * 
     * This ensures:
     * - SUPER_ADMIN can access ADMIN and USER endpoints
     * - ADMIN can access USER endpoints  
     * - USER can access only USER endpoints
     */
    @Bean
    public RoleHierarchy roleHierarchy() {
        RoleHierarchyImpl roleHierarchy = new RoleHierarchyImpl();
        
        // Build hierarchy string based on UserRole enum
        StringBuilder hierarchy = new StringBuilder();
        
        // SUPER_ADMIN inherits ADMIN and USER
        hierarchy.append(UserRole.SUPER_ADMIN.getRoleName())
                 .append(" > ")
                 .append(UserRole.ADMIN.getRoleName())
                 .append(" > ")
                 .append(UserRole.USER.getRoleName());
        
        String hierarchyString = hierarchy.toString();
        roleHierarchy.setHierarchy(hierarchyString);
        
        log.info("🏗️ Role hierarchy configured: {}", hierarchyString);
        
        return roleHierarchy;
    }

    /**
     * Get role hierarchy as string for debugging and documentation
     */
    public static String getHierarchyDescription() {
        return """
            Role Hierarchy Configuration:
            
            ROLE_SUPER_ADMIN (Level 3)
            ├── Can access: SUPER_ADMIN + ADMIN + USER endpoints
            ├── Permissions: All system operations, global analytics, critical system functions
            │
            └── ROLE_ADMIN (Level 2)
                ├── Can access: ADMIN + USER endpoints  
                ├── Permissions: User management, system monitoring, role administration
                │
                └── ROLE_USER (Level 1)
                    ├── Can access: USER endpoints only
                    └── Permissions: Own profile, own API keys, personal dashboard
            
            Examples:
            - USER with ROLE_USER → Can access /api/users/**, /api/v1/api-keys/**
            - ADMIN with ROLE_ADMIN → Can access USER endpoints + /api/admin/**, /api/roles/**
            - SUPER_ADMIN with ROLE_SUPER_ADMIN → Can access all endpoints
            """;
    }
}
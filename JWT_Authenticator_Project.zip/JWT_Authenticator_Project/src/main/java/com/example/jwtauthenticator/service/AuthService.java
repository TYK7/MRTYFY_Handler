package com.example.jwtauthenticator.service;

import com.example.jwtauthenticator.dto.*;
import com.example.jwtauthenticator.dto.RegisterResponse;
import com.example.jwtauthenticator.dto.ApiKeyCreateRequestDTO;
import com.example.jwtauthenticator.dto.ApiKeyGeneratedResponseDTO;
import com.example.jwtauthenticator.entity.ApiKey;
import com.example.jwtauthenticator.entity.LoginLog;
import com.example.jwtauthenticator.entity.PasswordResetCode;
import com.example.jwtauthenticator.entity.User;
import com.example.jwtauthenticator.entity.User.AuthProvider;
import com.example.jwtauthenticator.entity.Role;
import com.example.jwtauthenticator.entity.Company;
import com.example.jwtauthenticator.enums.UserPlan;
import com.example.jwtauthenticator.model.AuthRequest;
import com.example.jwtauthenticator.model.AuthResponse;
import com.example.jwtauthenticator.model.RegisterRequest;
import com.example.jwtauthenticator.repository.ApiKeyRepository;
import com.example.jwtauthenticator.repository.CompanyRepository;
import com.example.jwtauthenticator.repository.LoginLogRepository;
import com.example.jwtauthenticator.repository.PasswordResetCodeRepository;
import com.example.jwtauthenticator.repository.RoleRepository;
import com.example.jwtauthenticator.repository.UserRepository;
import com.example.jwtauthenticator.security.JwtUserDetailsService;
import com.example.jwtauthenticator.util.JwtUtil;
import com.example.jwtauthenticator.dto.BrandExtractionResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class AuthService {

    // ==================== GENERIC EMAIL PROVIDERS ====================
    
    /**
     * 📧 COMPREHENSIVE: Generic email providers with their primary domains for company mapping
     * ✅ UPDATED: Added modern providers, missing variants, and temporary email detection
     * Using Map.ofEntries() for more than 10 pairs (Java 21 compatible)
     */
    private static final Map<String, String> GENERIC_EMAIL_PROVIDERS = Map.ofEntries(
        // Google Services
        Map.entry("gmail.com", "gmail.com"),
        Map.entry("googlemail.com", "gmail.com"),
        
        // Microsoft Services
        Map.entry("outlook.com", "outlook.com"),
        Map.entry("hotmail.com", "outlook.com"),
        Map.entry("live.com", "outlook.com"),
        Map.entry("msn.com", "outlook.com"),
        
        // Yahoo Services
        Map.entry("yahoo.com", "yahoo.com"),
        Map.entry("yahoo.co.uk", "yahoo.com"),
        Map.entry("yahoo.ca", "yahoo.com"),
        Map.entry("yahoo.in", "yahoo.com"),
        Map.entry("yahoo.de", "yahoo.com"),
        Map.entry("ymail.com", "yahoo.com"),
        
        // Apple Services
        Map.entry("icloud.com", "icloud.com"),
        Map.entry("me.com", "icloud.com"),
        Map.entry("mac.com", "icloud.com"),
        
        // Privacy-Focused Providers
        Map.entry("protonmail.com", "protonmail.com"),
        Map.entry("proton.me", "protonmail.com"),
        Map.entry("tutanota.com", "tutanota.com"),
        Map.entry("duck.com", "duck.com"),
        
        // Business Email Providers
        Map.entry("zoho.com", "zoho.com"),
        Map.entry("fastmail.com", "fastmail.com"),
        
        // Legacy Providers
        Map.entry("aol.com", "aol.com"),
        Map.entry("mail.com", "mail.com"),
        
        // Modern Providers
        Map.entry("hey.com", "hey.com"),
        Map.entry("superhuman.com", "superhuman.com"),
        
        // ⚠️ TEMPORARY/DISPOSABLE EMAIL (flagged as generic to prevent corporate enrichment)
        Map.entry("temp-mail.org", "temp-mail.org"),
        Map.entry("10minutemail.com", "10minutemail.com"),
        Map.entry("guerrillamail.com", "guerrillamail.com"),
        Map.entry("mailinator.com", "mailinator.com")
    );
    
    /**
     * 📧 UPDATED: Provider display names for company creation
     * ✅ Added new providers and temporary email flagging
     */
    private static final Map<String, String> PROVIDER_DISPLAY_NAMES = Map.ofEntries(
        // Major Providers
        Map.entry("gmail.com", "Gmail"),
        Map.entry("outlook.com", "Outlook"), 
        Map.entry("yahoo.com", "Yahoo"),
        Map.entry("icloud.com", "iCloud"),
        Map.entry("aol.com", "AOL"),
        
        // Privacy & Security Focused
        Map.entry("protonmail.com", "ProtonMail"),
        Map.entry("tutanota.com", "Tutanota"),
        Map.entry("duck.com", "DuckDuckGo Email"),
        
        // Business Email
        Map.entry("zoho.com", "Zoho Mail"),
        Map.entry("fastmail.com", "FastMail"),
        
        // Modern Providers
        Map.entry("hey.com", "HEY Email"),
        Map.entry("superhuman.com", "Superhuman"),
        Map.entry("mail.com", "Mail.com"),
        
        // ⚠️ TEMPORARY/DISPOSABLE (flagged for security)
        Map.entry("temp-mail.org", "⚠️ Temporary Email"),
        Map.entry("10minutemail.com", "⚠️ Disposable Email"),
        Map.entry("guerrillamail.com", "⚠️ Temporary Email"),
        Map.entry("mailinator.com", "⚠️ Disposable Email")
    );


    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private JwtUserDetailsService userDetailsService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EmailService emailService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private GoogleTokenVerificationService googleTokenVerificationService;

    @Autowired
    private LoginLogRepository loginLogRepository;

    @Autowired
    private PasswordResetCodeRepository passwordResetCodeRepository;

    @Autowired
    private IdGeneratorService idGeneratorService;
    
    @Autowired
    private EnhancedApiKeyService enhancedApiKeyService;
    
    @Autowired
    private ApiKeyRepository apiKeyRepository;
    
    @Autowired
    private RoleRepository roleRepository;
    
    @Autowired
    private CompanyRepository companyRepository;
    
    @Autowired
    private ApplicationEventPublisher applicationEventPublisher;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    @Autowired
    private AsyncEnrichmentService asyncEnrichmentService;

    @Transactional
    public RegisterResponse registerUser(RegisterRequest request) {
        // ===================== PHASE 1: FAST SYNC VALIDATION (< 100ms) =====================
        log.info("🚀 Starting fast registration for: {}", request.email());
        
        // Basic input validation - FAST
        if (!isValidEmailFormat(request.email())) {
            throw new RuntimeException("Invalid email format. Please provide a valid email address.");
        }
        
        // Database existence checks - FAST (indexed queries)
        if (userRepository.existsByUsername(request.username())) {
            throw new RuntimeException("Username already exists. Please choose a different username.");
        }
        if (userRepository.existsByEmail(request.email())) {
            throw new RuntimeException("Email already exists. Please use a different email address.");
        }
        
        // Auto-generate brandId if not provided - FAST
        String brandId = request.brandId();
        if (brandId == null || brandId.trim().isEmpty()) {
            try {
                brandId = idGeneratorService.generateNextId();
            } catch (Exception e) {
                log.error("Error generating brand ID, using fallback", e);
                brandId = "MRTFY" + String.format("%06d", System.currentTimeMillis() % 10000);
            }
        }
        
        // Additional brand-specific checks - FAST
        if (userRepository.existsByUsernameAndBrandId(request.username(), brandId)) {
            throw new RuntimeException("Username already exists for this brand");
        }
        if (userRepository.existsByEmailAndBrandId(request.email(), brandId)) {
            throw new RuntimeException("Email already exists for this brand");
        }
        
        // Get role - FAST (cached/indexed lookup)
        Role userRole = getRoleForUser(request.roleId());
        
        // ===================== PHASE 2: FAST COMPANY ASSIGNMENT (< 50ms) =====================
        Company userCompany = resolveFastCompanyForRegistration(request, brandId);
        
        // ===================== PHASE 3: USER CREATION WITH ASYNC TRACKING (< 50ms) =====================
        User newUser = createUserRecordWithAsyncTracking(request, brandId, userRole, userCompany);
        
        // ===================== PHASE 4: ASYNC ENRICHMENT (Non-blocking) =====================
        scheduleAsyncEmailAndCompanyEnrichment(newUser.getId(), request.email());
        
        // ===================== RESPONSE: SUB-SECOND REGISTRATION =====================
        log.info("✅ Fast registration completed for: {} in brandId: {}", request.email(), brandId);
        return new RegisterResponse(
            "User registered successfully. Email verification and profile enrichment in progress.",
            brandId,
            newUser.getUsername(),
            newUser.getEmail(),
            true
        );
    }
    
    /**
     * ⚡ FAST: Basic email format validation without network calls
     */
    private boolean isValidEmailFormat(String email) {
        return email != null && 
               email.matches("^[\\w\\.-]+@([\\w\\-]+\\.)+[\\w\\-]{2,4}$") && 
               email.length() <= 255;
    }
    
    /**
     * ⚡ FAST: Get role with fallback to default
     */
    private Role getRoleForUser(Integer roleId) {
        if (roleId != null) {
            return roleRepository.findById(roleId)
                    .orElseThrow(() -> new RuntimeException("Role with ID " + roleId + " not found."));
        }
        return roleRepository.findDefaultUserRole()
                .orElseThrow(() -> new RuntimeException("Default user role not found. Please ensure role data is properly initialized."));
    }
    
    /**
     * ⚡ FAST: Immediate company assignment with placeholder for corporate domains
     */
    private Company resolveFastCompanyForRegistration(RegisterRequest request, String brandId) {
        // Use provided companyId if available - FAST DB lookup
        if (request.companyId() != null) {
            Company company = companyRepository.findById(request.companyId())
                    .orElseThrow(() -> new RuntimeException("Company with ID " + request.companyId() + " not found."));
            log.info("📋 Using provided company: {} (ID: {})", company.getCompanyName(), company.getCompanyId());
            return company;
        }
        
        String domain = this.asyncEnrichmentService.extractDomainFromEmail(request.email());
        
        // Handle generic email providers - FAST (cached)
        if (isGenericEmailProvider(domain)) {
            return resolveGenericEmailProviderCompany(domain);
        }
        
        // Corporate domain: Create immediate placeholder - FAST
        return createImmediatePlaceholderCompany(domain);
    }
    
    /**
     * ⚡ FAST: Create user record with async tracking using existing future columns
     */
    private User createUserRecordWithAsyncTracking(RegisterRequest request, String brandId, Role userRole, Company userCompany) {
        User newUser = User.builder()
                .id(brandId)
                .username(request.username())
                .password(passwordEncoder.encode(request.password()))
                .email(request.email())
                .firstName(request.firstName())
                .lastName(request.lastName())
                .phoneNumber(request.phoneNumber())
                .location(request.location())
                .role(userRole)
                .company(userCompany)
                .brandId("default")
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .emailVerified(false)
                // ✅ Use existing AVAILABLE future columns for async tracking
                .futureV5("EMAIL_VALIDATION_PENDING")  // Email validation status (V5 available)
                .futureI2("COMPANY_ENRICHMENT_PENDING") // Company enrichment status (I2 available)
                .futureI3(null) // Will store validated domain URL (I3 available)
                .futureI4(null) // Will store error messages if any (I4 available)
                .build();

        String verificationToken = UUID.randomUUID().toString();
        newUser.setVerificationToken(verificationToken);
        
        return userRepository.save(newUser);
    }
    
    /**
     * ⚡ FAST: Create immediate placeholder company (no external calls)
     */
    private Company createImmediatePlaceholderCompany(String domain) {
        // Check if already exists - FAST
        Optional<Company> existing = companyRepository.findByDomainName(domain);
        if (existing.isPresent()) {
            log.info("✅ Found existing company for domain: {}", domain);
            return existing.get();
        }
        
        // Create minimal placeholder - FAST
        Company placeholder = Company.builder()
            .companyName(this.asyncEnrichmentService.generateCompanyNameFromDomain(domain))
            .domainName(domain)
            .status("Pending Validation") // ✅ Use existing status column
            .companyDescription("Domain verification in progress...")
            .websiteUrl("https://" + domain)
            .emailDomains("@" + domain)
            .createdAt(LocalDateTime.now())
            .updatedAt(LocalDateTime.now())
            .build();
            
        Company saved = companyRepository.save(placeholder);
        log.info("🏗️ Created placeholder company: {} (ID: {}) - enrichment scheduled", 
                saved.getCompanyName(), saved.getCompanyId());
        return saved;
    }
    
    /**
     * 🔄 HYBRID APPROACH: Direct @Async call - cleaner and faster
     * ✅ OPTIMIZED: Removed CompletableFuture wrapper (redundant with @Async)
     */
    private void scheduleAsyncEmailAndCompanyEnrichment(String userId, String email) {
        log.info("🔄 Scheduling async enrichment for user: {} with email: {}", userId, email);
        
        try {
            // Direct @Async call - Spring handles the async execution
            asyncEnrichmentService.performUserEnrichment(userId, email);
            log.info("✅ Async enrichment scheduled for user: {}", userId);
            
        } catch (Exception e) {
            log.error("💥 Failed to schedule async enrichment for user: {} with email: {}", userId, email, e);
            // Handle failure with fallback
            handleAsyncEnrichmentFailure(userId, email, e.getMessage());
        }
    }
    

    /**
     * ⚠️ HYBRID: Handle async enrichment failure with fallback
     */
    private void handleAsyncEnrichmentFailure(String userId, String email, String errorMessage) {
        try {
            // Use AsyncEnrichmentService failure handler for consistency
            asyncEnrichmentService.handleEnrichmentFailure(userId, email, errorMessage);
            
        } catch (Exception failEx) {
            log.error("💥 Failed to handle async enrichment failure for user: {}", userId, failEx);
           // Last resort: mark user with basic error status
             try {
                Optional<User> userOpt = userRepository.findById(userId);
                if (userOpt.isPresent()) {
                    User user = userOpt.get();
                    user.setFutureV5("EMAIL_VALIDATION_FAILED");
                    user.setFutureI2("COMPANY_ENRICHMENT_FAILED");
                    user.setFutureI4("Async enrichment failed - will retry later");
                    userRepository.save(user);
                    log.info("⚠️ Marked enrichment as failed for user: {}", userId);
                }
            } catch (Exception e) {
                log.error("💥 Failed to mark enrichment as failed for user: {}", userId, e);
            }
        }
    }


    public AuthResponse createAuthenticationToken(AuthRequest authenticationRequest) throws Exception {
        try {
            authenticate(authenticationRequest.username(), authenticationRequest.password(), authenticationRequest.brandId());
            final UserDetails userDetails = userDetailsService
                    .loadUserByUsernameAndBrandId(authenticationRequest.username(), authenticationRequest.brandId());
            User user = userRepository.findByUsernameAndBrandId(authenticationRequest.username(), authenticationRequest.brandId())
                    .orElseThrow(() -> new RuntimeException("User not found"));
    
            if (!user.isEmailVerified()) {
                // Log failure due to unverified email
                logLogin(user, "PASSWORD", "FAILURE", "Login failed: Email not verified");
                throw new RuntimeException("Email not verified. Please verify your email to login.");
            }
    
            String roleName = getUserRoleName(user);
            final String token = jwtUtil.generateToken(userDetails, user.getId(), roleName); // Use primary key with role
            final String refreshToken = jwtUtil.generateRefreshToken(userDetails, user.getId(), roleName); // Use primary key with role
    
            user.setRefreshToken(refreshToken);
            userRepository.save(user);
    
            // Log successful password login
            logLogin(user, "PASSWORD", "SUCCESS", "Password login successful");
    
            return new AuthResponse(token, refreshToken, user.getBrandId(), jwtUtil.getAccessTokenExpirationTimeInSeconds());
        } catch (Exception e) {
            // If the exception wasn't already logged in the authenticate method, log it here
            if (!(e.getCause() instanceof BadCredentialsException)) {
                // Create a temporary user object just for logging if needed
                User tempUser = new User();
                tempUser.setUsername(authenticationRequest.username());
                tempUser.setBrandId(authenticationRequest.brandId());
                tempUser.setUserId(UUID.randomUUID()); // Generate a temporary UUID
                logLogin(tempUser, "PASSWORD", "FAILURE", "Authentication failed: " + e.getMessage());
            }
            throw e;
        }
    }

    public AuthResponse loginUser(AuthRequest authenticationRequest) throws Exception {
        return createAuthenticationToken(authenticationRequest);
    }
    
    public AuthResponse loginUserWithNameOrEmail(String usernameOrEmail, String password) throws Exception {
        log.info("Login attempt with identifier: {}", usernameOrEmail); 
        try {
            // Check if the input is an email (contains @ symbol)
            if (usernameOrEmail.contains("@")) {
                log.debug("Detected email format, attempting email-based login");
                // Find user by email
                User user = userRepository.findByEmail(usernameOrEmail)
                        .orElseThrow(() -> new RuntimeException("Invalid email or password"));
                
                log.info("Email found, proceeding with authentication for user: {}", user.getUsername());
                // Authenticate with the found user's username and brandId
                return authenticateAndGenerateToken(user.getUsername(), password, user.getEmail());
            } else {
                log.debug("Username format detected, attempting username-based login");
                // Find user by username across all brands
                User user = userRepository.findByUsername(usernameOrEmail)
                        .orElseThrow(() -> new RuntimeException("Invalid username or password"));
                
                log.info("Username found, proceeding with authentication with brand ID: {}", user.getBrandId());
                // Authenticate with the found user's brandId
                return authenticateAndGenerateToken(usernameOrEmail, password, user.getEmail());
            }
        } catch (Exception e) {
            log.error("Login failed for identifier: {}, reason: {}", usernameOrEmail, e.getMessage());
            
            // Create a temporary user object for logging if needed
            User tempUser = new User();
            tempUser.setUsername(usernameOrEmail);
            if (usernameOrEmail.contains("@")) {
                tempUser.setEmail(usernameOrEmail);
            }
            tempUser.setBrandId("unknown");
            tempUser.setUserId(UUID.randomUUID()); // Generate a temporary UUID
            
            logLogin(tempUser, "PASSWORD", "FAILURE", "Login failed: " + e.getMessage());
            throw e;
        }
    }
    
    public AuthResponse loginWithUsername(String username, String password) throws Exception {
        try {
            // Find user by username (across all brands)
            User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new RuntimeException("Invalid username or password"));
            
            // Authenticate with the found user's brandId
            return authenticateAndGenerateToken(username, password, user.getEmail());
        } catch (Exception e) {
            // Log failed login attempt
            Optional<User> userOpt = userRepository.findByUsername(username);
            if (userOpt.isPresent()) {
                logLogin(userOpt.get(), "PASSWORD", "FAILURE", "Username login failed: " + e.getMessage());
            } else {
                // User not found, create a temporary user object just for logging
                User tempUser = new User();
                tempUser.setUsername(username);
                tempUser.setUserId(UUID.randomUUID()); // Generate a temporary UUID
                logLogin(tempUser, "PASSWORD", "FAILURE", "User not found with provided username");
            }
            throw e;
        }
    }
    
    public AuthResponse loginWithEmail(String email, String password) throws Exception {
        try {
            // Find user by email (across all brands)
            User user = userRepository.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("Invalid email or password"));
            
            // Authenticate with the found user's brandId
            return authenticateAndGenerateToken(user.getUsername(), password, user.getEmail());
        } catch (Exception e) {
            // Log failed login attempt
            Optional<User> userOpt = userRepository.findByEmail(email);
            if (userOpt.isPresent()) {
                logLogin(userOpt.get(), "PASSWORD", "FAILURE", "Email login failed: " + e.getMessage());
            } else {
                // User not found, create a temporary user object just for logging
                User tempUser = new User();
                tempUser.setEmail(email);
                tempUser.setUsername(email.split("@")[0]); // Use part before @ as username
                tempUser.setUserId(UUID.randomUUID()); // Generate a temporary UUID
                logLogin(tempUser, "PASSWORD", "FAILURE", "User not found with provided email");
            }
            throw e;
        }
    }
    
    private AuthResponse authenticateAndGenerateToken(String username, String password, String email) throws Exception {
        authenticate(username, password, email);
        
        
        final UserDetails userDetails = userDetailsService.loadUserByUsernameAndEmail(username, email);
        User user = userRepository.findByUsernameAndEmail(username, email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!user.isEmailVerified()) {
            throw new RuntimeException("Email not verified. Please verify your email to login.");
        }

        String roleName = getUserRoleName(user);
        final String token = jwtUtil.generateToken(userDetails, user.getId(), roleName); // Use primary key with role
        final String refreshToken = jwtUtil.generateRefreshToken(userDetails, user.getId(), roleName); // Use primary key with role

        user.setRefreshToken(refreshToken);
        userRepository.save(user);

        // Log successful password login
        logLogin(user, "PASSWORD", "SUCCESS", "Password login successful");

        return new AuthResponse(token, refreshToken, user.getId(), jwtUtil.getAccessTokenExpirationTimeInSeconds());
    }

    public AuthResponse refreshToken(String oldRefreshToken) throws Exception {
        String username = jwtUtil.extractUsername(oldRefreshToken);
        String userId = jwtUtil.extractUserId(oldRefreshToken); // Now contains primary key (MRTFY000001)
        
        // Find user by primary key instead of UUID
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!user.getRefreshToken().equals(oldRefreshToken) || jwtUtil.isTokenExpired(oldRefreshToken)) {
            throw new RuntimeException("Invalid or expired refresh token");
        }

        final UserDetails userDetails = userDetailsService.loadUserByUsernameAndBrandId(username, user.getBrandId());
        String roleName = getUserRoleName(user);
        final String newToken = jwtUtil.generateToken(userDetails, user.getId(), roleName); // Use primary key with role
        final String newRefreshToken = jwtUtil.generateRefreshToken(userDetails, user.getId(), roleName); // Use primary key with role

        user.setRefreshToken(newRefreshToken);
        userRepository.save(user);

        return new AuthResponse(newToken, newRefreshToken, user.getBrandId(), jwtUtil.getAccessTokenExpirationTimeInSeconds());
    }

    @Transactional
    public String verifyEmail(String token) {
        log.info("🔐 Starting email verification for token: {}", token);
        
        User user = userRepository.findByVerificationToken(token)
                .orElseThrow(() -> {
                    log.error("❌ Invalid verification token: {}", token);
                    return new RuntimeException("Invalid verification token");
                });

        log.info("✅ Found user for verification: {} ({})", user.getUsername(), user.getId());
        
        // Activate user account
        user.setEmailVerified(true);
        user.setVerificationToken(null); // Clear the token after verification
        user.setPlan(UserPlan.FREE); // Ensure FREE plan is set
        user.setPlanStartedAt(LocalDateTime.now());
        
        User savedUser = userRepository.save(user);
        log.info("✅ User account activated: {} - Email verified: {}, Plan: {}", 
            savedUser.getUsername(), savedUser.isEmailVerified(), savedUser.getPlan());

        try {
            // AUTO-GENERATE FREE TIER API KEY with rivo9 prefix and unique domain
            log.info("🔧 Creating default API key for verified user...");
            ApiKeyGeneratedResponseDTO apiKey = createDefaultApiKeyForUser(savedUser);
            
            // ✅ FIX: Publish event for email sending AFTER transaction commits
            log.info("📧 Publishing activation success event for post-transaction email...");
            applicationEventPublisher.publishEvent(new com.example.jwtauthenticator.event.ActivationSuccessEvent(savedUser, apiKey));
            
            log.info("🎉 Email verification process completed successfully for user: {}", savedUser.getUsername());
            return "Account activated successfully! Check your email for your API key and next steps.";
        } catch (Exception e) {
            log.error("❌ Failed to complete activation process for user {}: {}", user.getUsername(), e.getMessage(), e);
            throw new RuntimeException("Account activated but failed to create API key: " + e.getMessage());
        }
    }

    private ApiKeyGeneratedResponseDTO createDefaultApiKeyForUser(User user) {
        try {
            // ✅ FIX: Generate unique MAIN domain per user (not subdomain) to avoid constraint violations
            String uniqueDomain = user.getUsername() + "-brandsnap.com";
            
            // ✅ CRITICAL FIX: Use proper scopes that match ApiKeyScope enum
            List<String> defaultFreeScopes = Arrays.asList(
                "READ_BASIC",      // Basic read access to public data
                "DOMAIN_HEALTH",   // Access domain health monitoring  
                "READ_BRANDS"      // Read brand information and assets
            );
            
            // Create unique API key name to avoid duplicates
            String uniqueKeyName = "Default Free API Key - " + user.getUsername();
            
            log.info("🔧 Creating default API key for user: {} (ID: {}) with unique domain: {}", 
                user.getUsername(), user.getId(), uniqueDomain);
            log.info("📋 Request details - Name: {}, Prefix: {}, Tier: {}, Scopes: {}", 
                uniqueKeyName, "rivo9_", "FREE_TIER", defaultFreeScopes);
            
            ApiKeyCreateRequestDTO request = ApiKeyCreateRequestDTO.builder()
                .name(uniqueKeyName)
                .description("Auto-generated API key for Free tier access - 100 calls/month")
                .registeredDomain(uniqueDomain) // ✅ FIX: Use unique domain per user
                .prefix("rivo9_")
                .rateLimitTier("FREE_TIER")
                .scopes(defaultFreeScopes)  // ✅ FIXED: Valid ApiKeyScope enum values
                .build();
            
            log.info("✅ Calling enhancedApiKeyService.createApiKeyWithPlanValidation for complete field population");
            EnhancedApiKeyService.ApiKeyCreateResult result = enhancedApiKeyService.createApiKeyWithPlanValidation(
                request, 
                user.getId(), 
                com.example.jwtauthenticator.enums.ApiKeyEnvironment.TESTING
            );
            
            if (!result.isSuccess()) {
                log.error("❌ Enhanced API key creation failed: {} (Code: {})", result.getErrorMessage(), result.getErrorCode());
                throw new RuntimeException("Enhanced API key creation failed: " + result.getErrorMessage());
            }
            
            // ✅ STEP 3: Mark the auto-created API key as default for /myapp/forward endpoint
            try {
                ApiKey createdApiKey = result.getApiKey();
                createdApiKey.setIsDefaultKey(true);
                apiKeyRepository.save(createdApiKey);
                log.info("✅ Marked API key {} as default for user: {}", createdApiKey.getId(), user.getUsername());
            } catch (Exception e) {
                log.error("⚠️ Failed to mark API key as default for user {}: {}", user.getUsername(), e.getMessage());
                // Don't throw exception - API key was created successfully, just not marked as default
            }
            
            // Convert to expected response format
            ApiKeyGeneratedResponseDTO response = ApiKeyGeneratedResponseDTO.builder()
                .id(result.getApiKey().getId())
                .name(result.getApiKey().getName())
                .description(result.getApiKey().getDescription())
                .prefix(result.getApiKey().getPrefix())
                .keyValue(result.getRawApiKey())
                .registeredDomain(result.getApiKey().getRegisteredDomain())
                .isDefaultKey(result.getApiKey().getIsDefaultKey())
                .build();
            
            log.info("🎉 Successfully created enhanced API key with all fields populated: {}", response.getPrefix());
            return response;
        } catch (IllegalArgumentException e) {
            log.error("❌ Validation error creating API key for user {}: {}", user.getUsername(), e.getMessage());
            throw new RuntimeException("Validation failed during API key creation: " + e.getMessage());
        } catch (Exception e) {
            log.error("❌ Unexpected error creating API key for user {}: {}", user.getUsername(), e.getMessage(), e);
            throw new RuntimeException("Failed to create API key during activation: " + e.getMessage());
        }
    }

    private void authenticate(String username, String password, String email) throws Exception {
        try {
            // Manual authentication for multi-brand setup
            User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new BadCredentialsException("Invalid credentials"));
            
            if (!passwordEncoder.matches(password, user.getPassword())) {
                // Log failed login attempt due to wrong password
                logLogin(user, "PASSWORD", "FAILURE", "Invalid password provided");
                throw new BadCredentialsException("Invalid credentials");
            }
            
            // Additional checks can be added here (e.g., account enabled, not locked, etc.)
            
        } catch (BadCredentialsException e) {
            // Try to find user just for logging purposes
            Optional<User> userOpt = userRepository.findByUsername(username);
            if (userOpt.isPresent()) {
                // We found the user, so log the failure
                logLogin(userOpt.get(), "PASSWORD", "FAILURE", "Authentication failed: " + e.getMessage());
            } else {
                // User not found, create a temporary user object just for logging
                User tempUser = new User();
                tempUser.setUsername(username);
                tempUser.setBrandId("default");
                tempUser.setUserId(UUID.randomUUID()); // Generate a temporary UUID
                logLogin(tempUser, "PASSWORD", "FAILURE", "User not found with provided credentials");
            }
            throw new Exception("INVALID_CREDENTIALS", e);
        }
    }

    public AuthResponse googleSignIn(GoogleSignInRequest request) throws Exception {
        try {
            // Verify Google ID token and extract user info
            GoogleUserInfo googleUserInfo = googleTokenVerificationService.verifyToken(request.idToken());
            
            // Check if user already exists
            Optional<User> existingUserOpt = userRepository.findByEmail(googleUserInfo.getEmail());
            User existingUser = existingUserOpt.orElse(null);
            
            if (existingUser != null) {
                // User exists - update profile picture and email verification if needed
                boolean needsUpdate = false;
                
                if (googleUserInfo.getPicture() != null && 
                    !googleUserInfo.getPicture().equals(existingUser.getProfilePictureUrl())) {
                    existingUser.setProfilePictureUrl(googleUserInfo.getPicture());
                    needsUpdate = true;
                }
                
                // Ensure email is verified for Google users
                if (!existingUser.isEmailVerified()) {
                    existingUser.setEmailVerified(true);
                    needsUpdate = true;
                }
                
                if (needsUpdate) {
                    userRepository.save(existingUser);
                }
                
                // Log successful Google login for existing user
                logLogin(existingUser, "GOOGLE", "SUCCESS", "Google Sign-In successful for existing user");
                
                // Generate JWT token for existing user
                return generateJwtResponse(existingUser);
            } else {
                // User doesn't exist - create new user
                User newUser = createGoogleUser(googleUserInfo);
                userRepository.save(newUser);
                
                // Log successful Google registration and login for new user
                logLogin(newUser, "GOOGLE", "SUCCESS", "Google Sign-In successful - new user created");
                
                // Generate JWT token for new user
                return generateJwtResponse(newUser);
            }
            
        } catch (Exception e) {
            // Create a temporary user for logging the failure
            // Since we don't have the email from the request directly, we'll just log with a generic user
            User tempUser = new User();
            tempUser.setUsername("google_signin_attempt");
            tempUser.setUserId(UUID.randomUUID()); // Generate a temporary UUID
            logLogin(tempUser, "GOOGLE", "FAILURE", "Google Sign-In failed: " + e.getMessage());
            
            throw new Exception("Google Sign-In failed: " + e.getMessage(), e);
        }
    }

    private User createGoogleUser(GoogleUserInfo googleUserInfo) {
        // Generate a unique username from email
        String baseUsername = googleUserInfo.getEmail().split("@")[0];
        String username = generateUniqueUsername(baseUsername);
        
        // Extract first and last name from Google's name field
        String firstName = null;
        String lastName = null;
        if (googleUserInfo.getName() != null && !googleUserInfo.getName().trim().isEmpty()) {
            String[] nameParts = googleUserInfo.getName().trim().split("\\s+");
            firstName = nameParts[0];
            if (nameParts.length > 1) {
                lastName = String.join(" ", java.util.Arrays.copyOfRange(nameParts, 1, nameParts.length));
            }
        }
        
        // Generate the sequential user ID
        String dombrId;
        try {
            // Try to use the database sequence
            dombrId = idGeneratorService.generateDombrUserId();
            log.info("Generated sequential user ID for Google user: {}", dombrId);
        } catch (Exception e) {
            // If that fails, use the simple method
            log.error("Failed to generate ID using sequence for Google user: {}", e.getMessage());
            dombrId = idGeneratorService.generateSimpleDombrUserId();
            log.info("Generated simple sequential user ID for Google user: {}", dombrId);
        }
        
        // If we still don't have an ID, use a hardcoded one as last resort
        if (dombrId == null) {
            dombrId = "DOMBR" + String.format("%06d", System.currentTimeMillis() % 1000000);
            log.warn("Using timestamp-based ID as last resort for Google user: {}", dombrId);
        }
        String brandId;
         try {
                brandId = idGeneratorService.generateNextId(); // Uses default prefix from application.properties
            } catch (Exception e) {
                log.error("Error generating brand ID, using default", e);
                brandId = "MRTFY" + String.format("%06d", System.currentTimeMillis() % 10000);
            }
        // Get default role for Google users
        Role defaultRole = roleRepository.findDefaultUserRole()
                .orElseThrow(() -> new RuntimeException("Default user role not found. Please ensure role data is properly initialized."));
        return User.builder()
                .id(brandId) // Set the DOMBR ID as primary key
                .username(username)
                .email(googleUserInfo.getEmail())
                .firstName(firstName)
                .lastName(lastName)
                .password(UUID.randomUUID().toString()) // Random password for Google users, will be encoded by JwtUserDetailsService.save()
                .role(defaultRole) // Use role entity instead of enum
                .company(null) // Set company to null for Google users
                .authProvider(AuthProvider.GOOGLE)
                .emailVerified(true) // Always true for Google users since Google has already verified the email
                .profilePictureUrl(googleUserInfo.getPicture())
                .brandId("default") // You can modify this based on your brand logic
                .userId(UUID.randomUUID()) // Set UUID
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    private String generateUniqueUsername(String baseUsername) {
        String username = baseUsername;
        int counter = 1;
        
        while (userRepository.existsByUsername(username)) {
            username = baseUsername + counter;
            counter++;
        }
        
        return username;
    }

    private AuthResponse generateJwtResponse(User user) {
        UserDetails userDetails = userDetailsService.loadUserByUsernameAndBrandId(user.getUsername(), user.getBrandId());
        String roleName = getUserRoleName(user);
        String accessToken = jwtUtil.generateToken(userDetails, user.getId(), roleName); // Use primary key with role
        String refreshToken = jwtUtil.generateRefreshToken(userDetails, user.getId(), roleName); // Use primary key with role
        
        // Save refresh token
        user.setRefreshToken(refreshToken);
        userRepository.save(user);
        
        return new AuthResponse(accessToken, refreshToken, user.getBrandId(), jwtUtil.getAccessTokenExpirationTimeInSeconds());
    }

    /**
     * Logs a login event, maintaining only the most recent success and failure records for each user.
     * For each user, the system keeps only two records:
     * 1. The most recent successful login
     * 2. The most recent failed login
     * 
     * @param user The user who attempted to log in
     * @param loginMethod The login method used (PASSWORD, GOOGLE, etc.)
     * @param loginStatus The login status (SUCCESS or FAILURE)
     * @param details Additional details about the login attempt
     */
    private void logLogin(User user, String loginMethod, String loginStatus, String details) {
        try {
            if (user == null || user.getUserId() == null) {
                log.warn("Cannot log login event: User or user ID is null");
                return;
            }
            
            // Check if there's an existing record for this user with the same login status
            Optional<LoginLog> existingLogOpt = loginLogRepository
                .findTopByUserIdAndLoginStatusOrderByLoginTimeDesc(user.getUserId(), loginStatus);
            
            LoginLog loginLog;
            
            if (existingLogOpt.isPresent()) {
                // Update the existing record with new timestamp and details
                loginLog = existingLogOpt.get();
                loginLog.setLoginTime(LocalDateTime.now());
                loginLog.setLoginMethod(loginMethod);
                loginLog.setDetails(details);
            } else {
                // Create a new record
                loginLog = LoginLog.builder()
                        .userId(user.getUserId())
                        .username(user.getUsername())
                        .loginMethod(loginMethod)
                        .loginStatus(loginStatus)
                        .details(details)
                        .build();
            }
            
            // Save the record
            loginLogRepository.save(loginLog);
            log.info("LOGIN_LOG: {} - {} - {}", user.getUsername(), loginMethod, loginStatus);
        } catch (Exception e) {
            log.error("Failed to log login event: {}", e.getMessage());
        }
    }

    // Profile Update Method
    @Transactional
    public String updateProfile(String username, String brandId, ProfileUpdateRequest request) {
        User user = userRepository.findByUsernameAndBrandId(username, brandId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Update fields if provided
        if (request.firstName() != null) {
            user.setFirstName(request.firstName());
        }
        if (request.lastName() != null) {
            user.setLastName(request.lastName());
        }
        if (request.phoneNumber() != null) {
            user.setPhoneNumber(request.phoneNumber());
        }
        if (request.location() != null) {
            user.setLocation(request.location());
        }
        if (request.email() != null && !request.email().equals(user.getEmail())) {
            // Check if new email already exists
            if (userRepository.existsByEmailAndBrandId(request.email(), brandId)) {
                throw new RuntimeException("Email already exists for this brand");
            }
            user.setEmail(request.email());
            user.setEmailVerified(false); // Need to verify new email
        }

        user.setUpdatedAt(LocalDateTime.now());
        userRepository.save(user);

        return "Profile updated successfully";
    }

    // Check Email Existence Method
    public boolean checkEmailExists(CheckEmailRequest request) {
        return userRepository.existsByEmailAndBrandId(request.email(), request.brandId());
    }
    
    // Check Username Existence Method
    public boolean checkUsernameExists(CheckUsernameRequest request) {
        return userRepository.existsByUsernameAndBrandId(request.username(), request.brandId());
    }
    
    // Simple Check Username Existence Method (without brand ID)
    public boolean checkUsernameExists(SimpleCheckUsernameRequest request) {
        return userRepository.existsByUsername(request.username());
    }
    
    // Check Username Existence by username string
    public boolean checkUsernameExists(String username) {
        return userRepository.existsByUsername(username);
    }

    // Enhanced Forgot Password with Verification Code
    @Transactional
    public String sendPasswordResetCode(ForgotPasswordRequest request) {
        try {
            // Validate user ID format (should match MRTFY000001 pattern)
//            if (!request.userId().matches("MRTFY\\d{6}")) {
//                throw new RuntimeException("Invalid user ID format. Expected format: MRTFY000001");
//            }
            
            // Find user by userId and email to confirm they match
            User user = userRepository.findByEmail(request.email())
                    .orElseThrow(() -> new RuntimeException("email not found"));
            
            // Validate that the email matches the user's email
            if (!user.getEmail().equals(request.email())) {
                throw new RuntimeException("User ID and email do not match");
            }
    
            // Clean up any existing codes for this user
            passwordResetCodeRepository.deleteByEmailAndUserId(request.email(), user.getId());
    
            // Generate 6-digit verification code
            String code = generateVerificationCode();
    
            // Save the code
            PasswordResetCode resetCode = PasswordResetCode.builder()
                    .email(request.email())
                    .userId(user.getId())
                    .code(code)
                    .build();
    
            passwordResetCodeRepository.save(resetCode);
    
            // Send email with verification code
            try {
                emailService.sendPasswordResetCode(request.email(), user.getUsername(), code);
                log.info("Password reset code sent to: {}", request.email());
            } catch (Exception e) {
                log.error("Failed to send password reset email: {}", e.getMessage());
                throw new RuntimeException("Failed to send verification code email");
            }
    
            return "Verification code sent successfully.";
        } catch (Exception e) {
            log.error("Error in sendPasswordResetCode: {}", e.getMessage());
            throw e;
        }
    }

    // Verify Reset Code Method - Only verify, don't mark as used yet
    public Map<String, Object> verifyResetCode(VerifyCodeRequest request) {
        try {
//            // Validate user ID format
//            if (!request.userId().matches("MRTFY\\d{6}")) {
//                throw new RuntimeException("Invalid user ID format. Expected format: MRTFY000001");
//            }
            
            Optional<PasswordResetCode> resetCodeOpt = passwordResetCodeRepository
                    .findByEmailAndCodeAndUsedFalse(request.email(), request.code());
    
            if (resetCodeOpt.isEmpty()) {
                throw new RuntimeException("Invalid verification code");
            }
    
            PasswordResetCode resetCode = resetCodeOpt.get();
            if (resetCode.isExpired()) {
                // Delete expired code
                passwordResetCodeRepository.delete(resetCode);
                throw new RuntimeException("Verification code has expired. Please request a new code.");
            }
    
            // Don't mark as used here - just verify it's valid
            return Map.of(
                    "message", "Code verified successfully. Proceed to set a new password.",
                    "verified", true,
                    "userId", resetCode.getUserId(),
                    "email", request.email(),
                    "nextStep", "You can now call /auth/set-new-password with the same code to reset your password"
                );
//            return "Code verified successfully. Proceed to set a new password.";
        } catch (Exception e) {
            log.error("Error in verifyResetCode: {}", e.getMessage());
            throw e;
        }
    }

    // Set New Password Method - Only works after code verification
    @Transactional
    public String setNewPassword(SetNewPasswordRequest request) {
        try {
            // Validate user ID format
//            if (!request.userId().matches("MRTFY\\d{6}")) {
//                throw new RuntimeException("Invalid user ID format. Expected format: MRTFY000001");
//            }
            
            // Verify the code again before allowing password reset
            Optional<PasswordResetCode> resetCodeOpt = passwordResetCodeRepository
                    .findByEmailAndCodeAndUsedFalse(request.email(), request.code());
    
            if (resetCodeOpt.isEmpty()) {
                throw new RuntimeException("Invalid verification code or code already used");
            }
    
            PasswordResetCode resetCode = resetCodeOpt.get();
            if (resetCode.isExpired()) {
                // Delete expired code
                passwordResetCodeRepository.delete(resetCode);
                throw new RuntimeException("Verification code has expired. Please request a new one.");
            }
    
            // Find and update user password
            User user = userRepository.findByEmail(request.email())
                    .orElseThrow(() -> new RuntimeException("User not found"));
                    
            // Verify email matches
            if (!user.getEmail().equals(request.email())) {
                throw new RuntimeException("User ID and email do not match");
            }
    
            // Validate password complexity
            if (request.newPassword().length() < 8) {
                throw new RuntimeException("Password must be at least 8 characters long");
            }
    
            user.setPassword(request.newPassword()); // Will be encoded by userDetailsService.save()
            user.setUpdatedAt(LocalDateTime.now());
            userDetailsService.save(user);
    
            // Mark the code as used - now it can't be used again
            resetCode.setUsed(true);
            passwordResetCodeRepository.save(resetCode);
    
            return "Password has been reset successfully";
        } catch (Exception e) {
            log.error("Error in setNewPassword: {}", e.getMessage());
            throw e;
        }
    }

    // Helper method to generate 6-digit verification code
    private String generateVerificationCode() {
        SecureRandom random = new SecureRandom();
        int code = 100000 + random.nextInt(900000); // Generates 6-digit number
        return String.valueOf(code);
    }

    // Cleanup expired codes (can be called by a scheduled task)
    @Transactional
    public void cleanupExpiredCodes() {
        passwordResetCodeRepository.deleteExpiredCodes(LocalDateTime.now());
    }
    

    /**
     * Check if domain is a generic email provider
     */
    private boolean isGenericEmailProvider(String domain) {
        return GENERIC_EMAIL_PROVIDERS.containsKey(domain.toLowerCase());
    }
    
    /**
     * Resolve company for generic email providers (Gmail, Yahoo, etc.)
     */
    private Company resolveGenericEmailProviderCompany(String domain) {
        String primaryDomain = GENERIC_EMAIL_PROVIDERS.get(domain.toLowerCase());
        String displayName = PROVIDER_DISPLAY_NAMES.get(primaryDomain);
        
        log.info("📧 Resolving generic email provider: {} -> {} ({})", domain, primaryDomain, displayName);
        
        // Check if provider company already exists
        Optional<Company> existingCompany = companyRepository.findByDomainName(primaryDomain);
        
        if (existingCompany.isPresent()) {
            log.info("✅ Found existing provider company: {}", existingCompany.get().getCompanyName());
            return existingCompany.get();
        }
        
        // Create new provider company
        return createGenericProviderCompany(primaryDomain, displayName);
    }
    
    /**
     * Create company for generic email provider
     */
    private Company createGenericProviderCompany(String primaryDomain, String displayName) {
        log.info("🏗️ Creating new provider company: {}", displayName);
        
        // Get all domains for this provider and format with @ prefix
        String emailDomains = GENERIC_EMAIL_PROVIDERS.entrySet().stream()
            .filter(entry -> entry.getValue().equals(primaryDomain))
            .map(entry -> "@" + entry.getKey()) // ✅ FIXED: Add @ prefix to each domain
            .collect(java.util.stream.Collectors.joining(", ")); // Join multiple domains with comma
        
        Company providerCompany = Company.builder()
            .companyName(displayName)
            .domainName(primaryDomain)
            .status("Email Provider")
            .companyDescription(String.format("%s email service provider", displayName))
            .websiteUrl("https://" + primaryDomain)
            .emailDomains(emailDomains) // ✅ FIXED: Single string with comma-separated @ domains
            .createdAt(LocalDateTime.now())
            .updatedAt(LocalDateTime.now())
            .build();
        
        Company savedCompany = companyRepository.save(providerCompany);
        log.info("✅ Created provider company: {} (ID: {})", savedCompany.getCompanyName(), savedCompany.getCompanyId());
        
        return savedCompany;
    }
    
    /**
     * Enrich existing company with ForwardService data (ASYNC with proper transaction)
     */
    @Transactional
    private void enrichCompanyWithForwardServiceDataAsync(Integer companyId, String companyName, String responseBody) {
        try {
            log.info("🔄 [ASYNC] Enriching company: {} with ForwardService data", companyName);
            
            // ✅ FIX: Fetch company fresh from database in new transaction
            Optional<Company> companyOpt = companyRepository.findById(companyId);
            if (companyOpt.isEmpty()) {
                log.warn("⚠️ [ASYNC] Company not found with ID: {}", companyId);
                return;
            }
            
            Company company = companyOpt.get();
            
            // Parse the response as BrandExtractionResponse
            BrandExtractionResponse brandResponse = objectMapper.readValue(
                responseBody, BrandExtractionResponse.class);
            
            BrandExtractionResponse.CompanyData companyData = brandResponse.getCompany();
            
            if (companyData == null) {
                log.warn("⚠️ [ASYNC] No company data in ForwardService response for: {}", company.getDomainName());
                markCompanyEnrichmentFailedAsync(companyId, companyName);
                return;
            }
            
            // Update company with enriched data
            if (StringUtils.hasText(companyData.getName())) {
                company.setCompanyName(companyData.getName());
            }
            if (StringUtils.hasText(companyData.getDescription())) {
                company.setCompanyDescription(companyData.getDescription());
            }
            if (StringUtils.hasText(companyData.getWebsite())) {
                company.setWebsiteUrl(companyData.getWebsite());
            }
            if (StringUtils.hasText(companyData.getLocation())) {
                company.setAddressLine1(companyData.getLocation());
            }
            if (StringUtils.hasText(companyData.getHeadquarters())) {
                company.setCity(companyData.getHeadquarters());  // ✅ Use full headquarters data
                company.setCountry(companyData.getHeadquarters());  // ✅ Use full headquarters data
            }
            
            // Set logo URL
            String logoUrl = this.asyncEnrichmentService.extractLogoUrl(brandResponse);
            if (StringUtils.hasText(logoUrl)) {
                company.setCompanyLogoUrl(logoUrl);
            }
            
            // Mark as enriched
            company.setStatus("Active");
            company.setUpdatedAt(LocalDateTime.now());
            
            companyRepository.save(company);
            log.info("✅ [ASYNC] Successfully enriched company: {} (ID: {})", 
                company.getCompanyName(), company.getCompanyId());
            
        } catch (Exception e) {
            log.error("💥 [ASYNC] Error enriching company: {}", companyName, e);
            markCompanyEnrichmentFailedAsync(companyId, companyName);
        }
    }
    /**
     * Mark company enrichment as failed (ASYNC with proper transaction)
     */
    @Transactional
    private void markCompanyEnrichmentFailedAsync(Integer companyId, String companyName) {
        try {
            Optional<Company> companyOpt = companyRepository.findById(companyId);
            if (companyOpt.isEmpty()) {
                log.warn("⚠️ [ASYNC] Company not found with ID: {} for failure marking", companyId);
                return;
            }
            
            Company company = companyOpt.get();
            company.setStatus("Enrichment Failed");
            company.setCompanyDescription("Company profile could not be automatically enriched");
            company.setUpdatedAt(LocalDateTime.now());
            companyRepository.save(company);
            
            log.warn("⚠️ [ASYNC] Marked company enrichment as failed: {} (ID: {})", 
                companyName, companyId);
        } catch (Exception e) {
            log.error("💥 [ASYNC] Error marking company enrichment as failed: {}", companyName, e);
        }
    }
    
    /**
     * Helper method to extract role name from User entity
     * Ensures ROLE_ prefix for Spring Security compatibility
     */
    private String getUserRoleName(User user) {
        if (user == null || user.getRole() == null) {
            return "ROLE_USER"; // Default role
        }
        
        String roleName = user.getRole().getRoleName();
        if (roleName == null || roleName.trim().isEmpty()) {
            return "ROLE_USER"; // Default role
        }
        
        // Ensure ROLE_ prefix for Spring Security
        if (!roleName.startsWith("ROLE_")) {
            roleName = "ROLE_" + roleName.toUpperCase();
        }
        
        return roleName;
    }
}



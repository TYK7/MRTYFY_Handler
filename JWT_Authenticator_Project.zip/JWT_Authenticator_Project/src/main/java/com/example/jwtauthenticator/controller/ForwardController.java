package com.example.jwtauthenticator.controller;

import com.example.jwtauthenticator.dto.ForwardRequest;
import com.example.jwtauthenticator.entity.ApiKey;
import com.example.jwtauthenticator.entity.User;
import com.example.jwtauthenticator.dto.BrandExtractionResponse;
import com.example.jwtauthenticator.enums.UserPlan;
import com.example.jwtauthenticator.repository.ApiKeyRepository;
import com.example.jwtauthenticator.repository.UserRepository;
import com.example.jwtauthenticator.service.ApiKeyAuthenticationService;
import com.example.jwtauthenticator.service.ForwardService;
import com.example.jwtauthenticator.service.ForwardUsageValidationService;
import com.example.jwtauthenticator.service.ForwardJwtUsageTrackingService;
import com.example.jwtauthenticator.service.RateLimiterService;
import com.example.jwtauthenticator.service.ProfessionalRateLimitService;
import com.example.jwtauthenticator.service.StreamlinedUsageTracker;
import com.example.jwtauthenticator.util.JwtUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.bucket4j.ConsumptionProbe;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/forward")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Request Forwarding", description = "Endpoints for forwarding authenticated requests to external APIs")
public class ForwardController {

    private final ForwardService forwardService;
    private final ProfessionalRateLimitService professionalRateLimitService;
    private final JwtUtil jwtUtil;
    private final ObjectMapper objectMapper;
    private final ApiKeyAuthenticationService apiKeyAuthenticationService;
    private final ForwardUsageValidationService forwardUsageValidationService;
    private final ForwardJwtUsageTrackingService forwardJwtUsageTrackingService;
    private final StreamlinedUsageTracker streamlinedUsageTracker;
    private final UserRepository userRepository;
    private final ApiKeyRepository apiKeyRepository;

    @PostMapping
    @Operation(
        summary = "Forward authenticated request", 
        description = "Forwards an authenticated request to an external API with rate limiting",
        security = { @SecurityRequirement(name = "Bearer Authentication") },
        parameters = {
            @Parameter(
                name = "Authorization", 
                description = "JWT Bearer token OR API Key", 
                required = true, 
                in = ParameterIn.HEADER,
                example = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9... OR sk-1234567890abcdef..."
            ),
            @Parameter(
                name = "X-API-Key", 
                description = "Alternative API Key authentication (if not using Authorization header)", 
                required = false, 
                in = ParameterIn.HEADER,
                example = "sk-1234567890abcdef..."
            )
        }
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200", 
            description = "Request forwarded successfully",
            content = @Content(schema = @Schema(implementation = BrandExtractionResponse.class))
        ),
        @ApiResponse(responseCode = "400", description = "Bad Request - Invalid URL or missing required headers"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing JWT token or API key"),
        @ApiResponse(responseCode = "429", description = "Too Many Requests - Rate limit exceeded"),
        @ApiResponse(responseCode = "500", description = "Internal Server Error"),
        @ApiResponse(responseCode = "504", description = "Gateway Timeout - External API timed out")
    })
    public ResponseEntity<?> forward(
            @Parameter(description = "Forward request details", required = true)
            @Valid @RequestBody ForwardRequest request, 
            HttpServletRequest httpRequest,
            HttpServletResponse httpResponse) {
        long start = System.currentTimeMillis();
        String userId = null;
        
        try {
            // ✅ STEP 1: Extract user ID from JWT (ONLY JWT authentication for /myapp/forward)
            String authHeader = httpRequest.getHeader(HttpHeaders.AUTHORIZATION);
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return buildError("JWT Bearer token required for /myapp/forward endpoint", HttpStatus.UNAUTHORIZED);
            }
            
            String token = authHeader.substring(7);
            
            // ✅ STEP 1A: Extract business ID from JWT token (MRTFY format)
            String userIdFromJWT = jwtUtil.extractUserId(token);
            log.debug("✅ Extracted user ID from JWT: {}", userIdFromJWT);
            
            // ✅ STEP 1B: JWT contains business ID directly (MRTFY000005 format)
            if (!userIdFromJWT.startsWith("MRTFY")) {
                log.error("❌ Invalid business ID format in JWT: {}", userIdFromJWT);
                return buildError("JWT must contain valid business ID (MRTFY format)", HttpStatus.UNAUTHORIZED);
            }
            
            userId = userIdFromJWT;
            log.debug("✅ Using business ID from JWT: {}", userId);
            
            // ✅ STEP 2: Find user's default API key for quota management
            Optional<ApiKey> defaultApiKeyOpt = apiKeyRepository.findDefaultApiKeyByUserId(userId);
            if (defaultApiKeyOpt.isEmpty()) {
                log.warn("❌ No default API key found for user: {} (business ID)", userId);
                return buildError("No default API key found. Please contact support.", HttpStatus.FORBIDDEN);
            }
            
            ApiKey defaultApiKey = defaultApiKeyOpt.get();
            log.debug("✅ Found default API key for user {}: {}", userId, defaultApiKey.getId());
            
            // ✅ STEP 3: Use SAME rate limiting as /api/secure/rivofetch with default API key
            ProfessionalRateLimitService.RateLimitResult rateLimitResult = 
                professionalRateLimitService.checkRateLimit(defaultApiKey.getId());
            
            if (!rateLimitResult.isAllowed()) {
                HttpHeaders headers = new HttpHeaders();
                headers.add("X-RateLimit-Limit", String.valueOf(rateLimitResult.getTier() != null ? rateLimitResult.getTier().getRequestLimit() : 0));
                headers.add("X-RateLimit-Remaining", String.valueOf(rateLimitResult.getRemainingRequests() != null ? rateLimitResult.getRemainingRequests() : 0));
                headers.add("X-RateLimit-Reset", String.valueOf(rateLimitResult.getResetInSeconds() != null ? rateLimitResult.getResetInSeconds() : 0));
                headers.add("X-RateLimit-Tier", rateLimitResult.getTier() != null ? rateLimitResult.getTier().name() : "UNKNOWN");
                
                log.warn("❌ Rate limit exceeded for default API key {}: {}", defaultApiKey.getId(), rateLimitResult.getReason());
                return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS)
                        .headers(headers)
                        .body(buildErrorMap(rateLimitResult.getReason(), HttpStatus.TOO_MANY_REQUESTS));
            }
            
            log.debug("✅ Rate limit check passed for default API key: {}", defaultApiKey.getId());
            
            // ✅ STEP 4: Process the forward request (same as before)
            CompletableFuture<ResponseEntity<String>> future = 
                forwardService.forwardWithPublicLogging(request.url(), httpRequest, httpResponse);
            
            ResponseEntity<String> extResponse = future.get();
            long duration = System.currentTimeMillis() - start;
            
            log.info("userId={} | defaultApiKey={} | url={} | status={} | duration={}ms", 
                    userId, defaultApiKey.getId(), request.url(), 
                    extResponse.getStatusCode().value(), duration);
            
            // ✅ STEP 5: Track usage with default API key (SAME as /api/secure/rivofetch)
            if (extResponse.getStatusCode().is2xxSuccessful()) {
                streamlinedUsageTracker.trackForwardCallSync(
                    defaultApiKey.getId(),
                    userId,
                    getClientIpAddress(httpRequest),
                    extractDomainFromRequest(httpRequest),
                    httpRequest.getHeader("User-Agent"),
                    extResponse.getStatusCode().value(),
                    duration,
                    null
                );
                
                // Parse the response into BrandExtractionResponse object
                try {
                    BrandExtractionResponse brandResponse = objectMapper.readValue(extResponse.getBody(), BrandExtractionResponse.class);
                    return ResponseEntity.ok(brandResponse);
                } catch (Exception parseException) {
                    log.error("Failed to parse external API response as BrandExtractionResponse for URL: {}", request.url(), parseException);
                    
                    // Track the parsing error with default API key
                    streamlinedUsageTracker.trackForwardCallSync(
                        defaultApiKey.getId(),
                        userId,
                        getClientIpAddress(httpRequest),
                        extractDomainFromRequest(httpRequest),
                        httpRequest.getHeader("User-Agent"),
                        500,
                        duration,
                        "Failed to parse external API response"
                    );
                    
                    return buildError("Failed to parse external API response", HttpStatus.INTERNAL_SERVER_ERROR);
                }
            } else {
                // Track failed response with default API key
                streamlinedUsageTracker.trackForwardCallSync(
                    defaultApiKey.getId(),
                    userId,
                    getClientIpAddress(httpRequest),
                    extractDomainFromRequest(httpRequest),
                    httpRequest.getHeader("User-Agent"),
                    extResponse.getStatusCode().value(),
                    duration,
                    "External API error: " + extResponse.getBody()
                );
            }
            
            return ResponseEntity.status(extResponse.getStatusCode())
                    .body(buildErrorMap("External API error: " + extResponse.getBody(), extResponse.getStatusCode()));
        } catch (Exception e) {
            long duration = System.currentTimeMillis() - start;
            log.error("userId={} | url={} | error={}", userId, request.url(), e.getMessage());
            
            // Track the error with default API key (if available)
            String errorMessage = e.getMessage();
            int errorStatus = 500;
            if (e.getCause() instanceof java.util.concurrent.TimeoutException) {
                errorMessage = "External API timed out after " + forwardService.getForwardConfig().getTimeoutSeconds() + " seconds";
                errorStatus = 504;
            }
            
            // Only track if we have the default API key (user authentication succeeded)
            try {
                if (userId != null) {
                    Optional<ApiKey> defaultApiKeyOpt = apiKeyRepository.findDefaultApiKeyByUserId(userId);
                    if (defaultApiKeyOpt.isPresent()) {
                        streamlinedUsageTracker.trackForwardCallSync(
                            defaultApiKeyOpt.get().getId(),
                            userId,
                            getClientIpAddress(httpRequest),
                            extractDomainFromRequest(httpRequest),
                            httpRequest.getHeader("User-Agent"),
                            errorStatus,
                            duration,
                            errorMessage
                        );
                    }
                }
            } catch (Exception trackingException) {
                log.error("Failed to track error for user {}: {}", userId, trackingException.getMessage());
            }
            
            if (e.getCause() instanceof java.util.concurrent.TimeoutException) {
                return buildError(errorMessage, HttpStatus.GATEWAY_TIMEOUT);
            }
            return buildError("External API error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



    private ResponseEntity<Map<String, Object>> buildError(String message, HttpStatus status) {
        return ResponseEntity.status(status).body(buildErrorMap(message, status));
    }

    private Map<String, Object> buildErrorMap(String message, HttpStatusCode status) {
        Map<String, Object> body = new HashMap<>();
        body.put("error", message);
        body.put("status", status.value());
        body.put("timestamp", Instant.now().toString());
        return body;
    }

    /**
     * Extract client IP address from request
     */
    private String getClientIpAddress(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }
        
        String xRealIp = request.getHeader("X-Real-IP");
        if (xRealIp != null && !xRealIp.isEmpty()) {
            return xRealIp;
        }
        
        return request.getRemoteAddr();
    }

    /**
     * Extract domain from request headers
     */
    private String extractDomainFromRequest(HttpServletRequest request) {
        String origin = request.getHeader("Origin");
        if (origin != null && !origin.isEmpty()) {
            return origin.replaceAll("https?://", "");
        }
        
        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isEmpty()) {
            return referer.replaceAll("https?://", "").split("/")[0];
        }
        
        return request.getServerName();
    }

}

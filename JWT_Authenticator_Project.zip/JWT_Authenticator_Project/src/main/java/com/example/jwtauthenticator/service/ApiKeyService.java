package com.example.jwtauthenticator.service;

import com.example.jwtauthenticator.dto.ApiKeyCreateRequestDTO;
import com.example.jwtauthenticator.dto.ApiKeyGeneratedResponseDTO;
import com.example.jwtauthenticator.dto.ApiKeyResponseDTO;
import com.example.jwtauthenticator.dto.ApiKeyUpdateRequestDTO;
import com.example.jwtauthenticator.entity.ApiKey;
import com.example.jwtauthenticator.entity.User; // Import User entity
import com.example.jwtauthenticator.enums.ApiKeyScope;
import com.example.jwtauthenticator.enums.RateLimitTier;
import com.example.jwtauthenticator.repository.ApiKeyRepository;
import com.example.jwtauthenticator.repository.UserRepository; // Import UserRepository
import com.example.jwtauthenticator.util.ApiKeyHashUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ApiKeyService {

    private final ApiKeyRepository apiKeyRepository;
    private final UserRepository userRepository; // Inject UserRepository to fetch User by String ID
    private final ApiKeyHashUtil apiKeyHashUtil;
    private final com.example.jwtauthenticator.util.DomainExtractionUtil domainExtractionUtil; // ✅ Use existing service

    @Autowired
    public ApiKeyService(ApiKeyRepository apiKeyRepository, UserRepository userRepository, 
                        ApiKeyHashUtil apiKeyHashUtil, 
                        com.example.jwtauthenticator.util.DomainExtractionUtil domainExtractionUtil) {
        this.apiKeyRepository = apiKeyRepository;
        this.userRepository = userRepository; // Initialize UserRepository
        this.apiKeyHashUtil = apiKeyHashUtil;
        this.domainExtractionUtil = domainExtractionUtil; // ✅ Initialize existing service
    }

    private String generateSecureApiKey(String prefix) {
        return this.apiKeyHashUtil.generateSecureApiKey(prefix);
    }

    @Transactional
    public ApiKeyGeneratedResponseDTO createApiKey(String userFkId, ApiKeyCreateRequestDTO request) {
        // Input validation
        if (userFkId == null || userFkId.trim().isEmpty()) {
            throw new IllegalArgumentException("User ID cannot be null or empty");
        }
        if (request == null) {
            throw new IllegalArgumentException("API key request cannot be null");
        }
        if (request.getName() == null || request.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("API key name cannot be null or empty");
        }
        
        // // Validate if the userFkId exists in the User table's 'id' column
        // User user = userRepository.findById(userFkId) // Use findById for the primary key lookup
        //               .orElseThrow(() -> new IllegalArgumentException("User with ID " + userFkId + " not found."));
      
        // Check for duplicate API key names for this user
        if (apiKeyRepository.existsByNameAndUserFkId(request.getName().trim(), userFkId)) {
            throw new IllegalArgumentException("API key with name '" + request.getName() + "' already exists for this user");
        }
        
        // Check API key limit per user (configurable limit)
        List<ApiKey> userApiKeys = apiKeyRepository.findByUserFkId(userFkId);
        int maxApiKeysPerUser = 10; // This could be made configurable
        if (userApiKeys.size() >= maxApiKeysPerUser) {
            throw new IllegalArgumentException("Maximum number of API keys (" + maxApiKeysPerUser + ") reached for this user");
        }
        
        // Validate rate limit tier if provided
        if (request.getRateLimitTier() != null && !request.getRateLimitTier().trim().isEmpty()) {
            try {
                RateLimitTier.valueOf(request.getRateLimitTier().toUpperCase());
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("Invalid rate limit tier: " + request.getRateLimitTier() + 
                    ". Valid values are: FREE_TIER, PRO_TIER, BUSINESS_TIER");
            }
        }
        
        // Validate scopes if provided
        if (request.getScopes() != null && !request.getScopes().isEmpty()) {
            for (String scope : request.getScopes()) {
                if (scope == null || scope.trim().isEmpty()) {
                    throw new IllegalArgumentException("Scope cannot be null or empty");
                }
                try {
                    ApiKeyScope.valueOf(scope.trim().toUpperCase());
                } catch (IllegalArgumentException e) {
                    throw new IllegalArgumentException("Invalid scope: " + scope + 
                        ". Please check available scopes in ApiKeyScope enum");
                }
            }
        }

        String generatedKeyValue = generateSecureApiKey(request.getPrefix());
        String keyHash = apiKeyHashUtil.hashApiKey(generatedKeyValue); // Hash the key for storage

        // Handle expiration date: if null, set to 1 year from now
        LocalDateTime expirationDate = request.getExpiresAt();
        if (expirationDate == null) {
            expirationDate = LocalDateTime.now().plusYears(1);
            log.info("No expiration date provided for API key '{}', setting default expiration to: {}", 
                    request.getName(), expirationDate);
        }

        // Generate key preview for security
        String keyPreview = ApiKey.generateKeyPreview(generatedKeyValue);
        
        // ✅ Extract main domain using EXISTING service
        String mainDomain = null;
        String subdomainPattern = null;
        if (request.getRegisteredDomain() != null && !request.getRegisteredDomain().trim().isEmpty()) {
            try {
                mainDomain = domainExtractionUtil.extractMainDomain(request.getRegisteredDomain());
                // Generate subdomain pattern: *.xamplyfy.com
                subdomainPattern = "*." + mainDomain;
            } catch (Exception e) {
                log.warn("Failed to extract main domain from {}: {}", request.getRegisteredDomain(), e.getMessage());
            }
        }
        
        // ✅ Placeholder encryption - Base64 encode for now (TODO: proper AES encryption)
        String encryptedKey = null;
        try {
            encryptedKey = java.util.Base64.getEncoder().encodeToString(generatedKeyValue.getBytes());
        } catch (Exception e) {
            log.warn("Failed to encode API key for user {}: {}", userFkId, e.getMessage());
        }
        
        log.info("🔧 Creating API key with missing fields - Preview: {}, MainDomain: {}, SubdomainPattern: {}", 
                keyPreview, mainDomain, subdomainPattern);
        
        ApiKey apiKey = ApiKey.builder()
                .userFkId(userFkId) // Set the String user ID
                .keyHash(keyHash) // Store the hash instead of plain key
                .name(request.getName().trim())
                .description(request.getDescription())
                .prefix(request.getPrefix())
                .registeredDomain(request.getRegisteredDomain()) // Add the missing registeredDomain field
                .isActive(true)
                .isDefaultKey(false) // Regular API keys are not default keys
                .expiresAt(expirationDate) // Use the processed expiration date
                .allowedIps(request.getAllowedIps() != null ? String.join(",", request.getAllowedIps()) : null)
                .allowedDomains(request.getAllowedDomains() != null ? String.join(",", request.getAllowedDomains()) : null)
                .rateLimitTier(request.getRateLimitTier() != null && !request.getRateLimitTier().trim().isEmpty() ? 
                              RateLimitTier.valueOf(request.getRateLimitTier().toUpperCase().trim()) : RateLimitTier.FREE_TIER)
                .scopes(request.getScopes() != null ? String.join(",", request.getScopes()) : null)
                .keyPreview(keyPreview) // Masked preview for display
                .environment(com.example.jwtauthenticator.enums.ApiKeyEnvironment.TESTING) // ✅ DEFAULT TO TESTING
                .mainDomain(mainDomain) // Extracted main domain
                .subdomainPattern(subdomainPattern) // Generated subdomain pattern
                .encryptedKeyValue(encryptedKey) // Encrypted key for secure retrieval
                .build();

        try {
            ApiKey savedKey = apiKeyRepository.save(apiKey);
            
            log.info("API key '{}' created successfully for user '{}' with ID: {}", 
                    savedKey.getName(), userFkId, savedKey.getId());
            
            return ApiKeyGeneratedResponseDTO.builder()
                    .id(savedKey.getId())
                    .name(savedKey.getName())
                    .keyValue(generatedKeyValue)
                    .isDefaultKey(savedKey.getIsDefaultKey())
                    .build();
        } catch (Exception e) {
            log.error("Failed to create API key '{}' for user '{}': {}", 
                     request.getName(), userFkId, e.getMessage(), e);
            throw new RuntimeException("Failed to create API key: " + e.getMessage(), e);
        }
    }

    @Transactional(readOnly = true)
    public List<ApiKeyResponseDTO> getApiKeysForUser(String userFkId) {
        return apiKeyRepository.findByUserFkId(userFkId) // Use the updated repository method
                .stream()
                .map(ApiKeyResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Optional<ApiKeyResponseDTO> getApiKeyByIdForUser(UUID keyId, String userFkId) {
        return apiKeyRepository.findByIdAndUserFkId(keyId, userFkId) // Use the updated repository method
                .map(ApiKeyResponseDTO::fromEntity);
    }

    @Transactional
    public Optional<ApiKeyResponseDTO> updateApiKey(UUID keyId, String userFkId, ApiKeyUpdateRequestDTO request) {
        return apiKeyRepository.findByIdAndUserFkId(keyId, userFkId).map(existingKey -> { // Use updated method
            if (request.getName() != null) {
                existingKey.setName(request.getName());
            }
            if (request.getDescription() != null) {
                existingKey.setDescription(request.getDescription());
            }
            if (request.getIsActive() != null) {
                existingKey.setActive(request.getIsActive());
            }
            if (request.getExpiresAt() != null) {
                existingKey.setExpiresAt(request.getExpiresAt());
            }
            if (request.getAllowedIps() != null) {
                existingKey.setAllowedIps(String.join(",", request.getAllowedIps()));
            }
            if (request.getAllowedDomains() != null) {
                existingKey.setAllowedDomains(String.join(",", request.getAllowedDomains()));
            }
            if (request.getRateLimitTier() != null) {
                existingKey.setRateLimitTier(RateLimitTier.valueOf(request.getRateLimitTier()));
            }
            
            // Handle default key logic - only one default key per user
            if (request.getIsDefaultKey() != null) {
                if (request.getIsDefaultKey()) {
                    // ✅ ENHANCED FIX: Use atomic operation to clear all defaults first
                    try {
                        // Method 1: Atomic clear operation (most robust)
                        int clearedCount = apiKeyRepository.clearAllDefaultKeysForUser(userFkId);
                        if (clearedCount > 0) {
                            log.info("Cleared {} existing default API keys for user {}", clearedCount, userFkId);
                        }
                    } catch (Exception atomicException) {
                        // Method 2: Fallback to individual updates with flush (original fix)
                        log.warn("Atomic clear failed, using fallback method for user {}", userFkId);
                        apiKeyRepository.findDefaultApiKeyByUserId(userFkId).ifPresent(currentDefault -> {
                            if (!currentDefault.getId().equals(existingKey.getId())) {
                                currentDefault.setIsDefaultKey(false);
                                // ✅ CRITICAL FIX: Force immediate save to avoid batch constraint violation
                                apiKeyRepository.saveAndFlush(currentDefault);
                                log.info("Unset previous default API key {} for user {}", currentDefault.getId(), userFkId);
                            }
                        });
                    }
                    
                    existingKey.setIsDefaultKey(true);
                    log.info("Set API key {} as new default for user {}", existingKey.getId(), userFkId);
                } else {
                    // ⚠️ CRITICAL: Cannot unset auto-generated default keys
                    if (isAutoGeneratedApiKey(existingKey)) {
                        log.warn("❌ Attempted to unset auto-generated default API key {} for user {}", existingKey.getId(), userFkId);
                        throw new IllegalArgumentException("Cannot unset auto-generated default API key. This key is required for /myapp/forward endpoint functionality.");
                    }
                    
                    // For user-created default keys, transfer default status first
                    if (!transferDefaultToAnotherKey(userFkId, existingKey.getId())) {
                        log.warn("❌ Cannot unset default API key {} - no other active API key available for user {}", existingKey.getId(), userFkId);
                        throw new IllegalArgumentException("Cannot unset default API key. You must have at least one active API key. Please create another API key first.");
                    }
                    
                    existingKey.setIsDefaultKey(false);
                    log.info("Unset API key {} as default for user {}", existingKey.getId(), userFkId);
                }
            }
            
            return ApiKeyResponseDTO.fromEntity(apiKeyRepository.save(existingKey));
        });
    }

    @Transactional
    public boolean revokeApiKey(UUID keyId, String userFkId) {
        return apiKeyRepository.findByIdAndUserFkId(keyId, userFkId).map(key -> {
            // Check if this is a default API key
            if (key.getIsDefaultKey() != null && key.getIsDefaultKey()) {
                // Cannot revoke auto-generated default API keys
                if (isAutoGeneratedApiKey(key)) {
                    log.warn("❌ Attempted to revoke auto-generated default API key {} for user {}", keyId, userFkId);
                    throw new IllegalArgumentException("Cannot revoke auto-generated default API key. This key is required for /myapp/forward endpoint functionality.");
                }
                
                // For user-created default keys, transfer default status first
                if (!transferDefaultToAnotherKey(userFkId, keyId)) {
                    log.warn("❌ Cannot revoke default API key {} - no other active API key available for user {}", keyId, userFkId);
                    throw new IllegalArgumentException("Cannot revoke default API key. You must have at least one active API key. Please create another API key first.");
                }
            }
            
            // Proceed with revocation
            key.setActive(false);
            key.setRevokedAt(LocalDateTime.now());
            apiKeyRepository.save(key);
            log.info("✅ Successfully revoked API key {} for user {}", keyId, userFkId);
            return true;
        }).orElse(false);
    }

    /**
     * Enhanced revoke method that returns API key information before revoking
     */
    @Transactional
    public Optional<ApiKey> revokeApiKeyWithDetails(UUID keyId, String userFkId) {
        return apiKeyRepository.findByIdAndUserFkId(keyId, userFkId).map(key -> {
            // Check if this is a default API key
            if (key.getIsDefaultKey() != null && key.getIsDefaultKey()) {
                // Cannot revoke auto-generated default API keys
                if (isAutoGeneratedApiKey(key)) {
                    log.warn("❌ Attempted to revoke auto-generated default API key {} for user {}", keyId, userFkId);
                    throw new IllegalArgumentException("Cannot revoke auto-generated default API key. This key is required for /myapp/forward endpoint functionality.");
                }
                
                // For user-created default keys, transfer default status first
                if (!transferDefaultToAnotherKey(userFkId, keyId)) {
                    log.warn("❌ Cannot revoke default API key {} - no other active API key available for user {}", keyId, userFkId);
                    throw new IllegalArgumentException("Cannot revoke default API key. You must have at least one active API key. Please create another API key first.");
                }
            }
            
            // Create a copy of the key data before modification
            ApiKey keyInfo = new ApiKey();
            keyInfo.setId(key.getId());
            keyInfo.setName(key.getName());
            keyInfo.setPrefix(key.getPrefix());
            keyInfo.setActive(key.isActive());
            keyInfo.setIsDefaultKey(key.getIsDefaultKey());
            
            // Now perform the revocation
            key.setActive(false);
            key.setRevokedAt(LocalDateTime.now());
            apiKeyRepository.save(key);
            log.info("✅ Successfully revoked API key {} for user {}", keyId, userFkId);
            
            return keyInfo;
        });
    }

    @Transactional
    public boolean deleteApiKey(UUID keyId, String userFkId) {
        Optional<ApiKey> apiKey = apiKeyRepository.findByIdAndUserFkId(keyId, userFkId);
        if (apiKey.isPresent()) {
            ApiKey key = apiKey.get();
            
            // Check if this is a default API key
            if (key.getIsDefaultKey() != null && key.getIsDefaultKey()) {
                // Cannot delete auto-generated default API keys
                if (isAutoGeneratedApiKey(key)) {
                    log.warn("❌ Attempted to delete auto-generated default API key {} for user {}", keyId, userFkId);
                    throw new IllegalArgumentException("Cannot delete auto-generated default API key. This key is required for /myapp/forward endpoint functionality.");
                }
                
                // For user-created default keys, transfer default status first
                if (!transferDefaultToAnotherKey(userFkId, keyId)) {
                    log.warn("❌ Cannot delete default API key {} - no other active API key available for user {}", keyId, userFkId);
                    throw new IllegalArgumentException("Cannot delete default API key. You must have at least one active API key. Please create another API key first.");
                }
            }
            
            // Proceed with deletion
            apiKeyRepository.delete(key);
            log.info("✅ Successfully deleted API key {} for user {}", keyId, userFkId);
            return true;
        }
        return false;
    }

    /**
     * Enhanced delete method that returns API key information before deleting
     */
    @Transactional
    public Optional<ApiKey> deleteApiKeyWithDetails(UUID keyId, String userFkId) {
        Optional<ApiKey> apiKey = apiKeyRepository.findByIdAndUserFkId(keyId, userFkId);
        if (apiKey.isPresent()) {
            ApiKey key = apiKey.get();
            
            // Check if this is a default API key
            if (key.getIsDefaultKey() != null && key.getIsDefaultKey()) {
                // Cannot delete auto-generated default API keys
                if (isAutoGeneratedApiKey(key)) {
                    log.warn("❌ Attempted to delete auto-generated default API key {} for user {}", keyId, userFkId);
                    throw new IllegalArgumentException("Cannot delete auto-generated default API key. This key is required for /myapp/forward endpoint functionality.");
                }
                
                // For user-created default keys, transfer default status first
                if (!transferDefaultToAnotherKey(userFkId, keyId)) {
                    log.warn("❌ Cannot delete default API key {} - no other active API key available for user {}", keyId, userFkId);
                    throw new IllegalArgumentException("Cannot delete default API key. You must have at least one active API key. Please create another API key first.");
                }
            }
            
            // Create a copy of the key data before deletion
            ApiKey keyInfo = new ApiKey();
            keyInfo.setId(key.getId());
            keyInfo.setName(key.getName());
            keyInfo.setPrefix(key.getPrefix());
            keyInfo.setActive(key.isActive());
            keyInfo.setIsDefaultKey(key.getIsDefaultKey());
            
            // Now perform the deletion
            apiKeyRepository.delete(key);
            log.info("✅ Successfully deleted API key {} for user {}", keyId, userFkId);
            
            return Optional.of(keyInfo);
        }
        return Optional.empty();
    }

    /**
     * Core validation method for incoming API calls using key hash.
     * This will be used in your API key authentication filter.
     */
    @Transactional(readOnly = true)
    public Optional<ApiKey> validateApiKey(String plainTextKey) {
        if (!apiKeyHashUtil.isValidApiKeyFormat(plainTextKey)) {
            return Optional.empty();
        }
        
        String keyHash = apiKeyHashUtil.hashApiKey(plainTextKey);
        return apiKeyRepository.findByKeyHash(keyHash)
                .filter(ApiKey::isActive)
                .filter(key -> key.getRevokedAt() == null)
                .filter(key -> key.getExpiresAt() == null || key.getExpiresAt().isAfter(LocalDateTime.now()));
    }
    
    /**
     * Find API key by key hash.
     */
    @Transactional(readOnly = true)
    public Optional<ApiKey> findByKeyHash(String keyHash) {
        return apiKeyRepository.findByKeyHash(keyHash);
    }
    
    /**
     * Update last used timestamp for an API key.
     */
    @Transactional
    public void updateLastUsed(UUID keyId) {
        apiKeyRepository.findById(keyId).ifPresent(key -> {
            key.setLastUsedAt(LocalDateTime.now());
            apiKeyRepository.save(key);
        });
    }

    /**
     * Check if an API key belongs to a specific user.
     */
    @Transactional(readOnly = true)
    public boolean apiKeyBelongsToUser(UUID keyId, String userFkId) {
        return apiKeyRepository.findById(keyId)
                .map(apiKey -> apiKey.getUserFkId().equals(userFkId))
                .orElse(false);
    }

    /**
     * Fetches the User entity associated with a given API key's userFkId.
     * This is useful in the API key authentication filter to get the User principal.
     */
    @Transactional(readOnly = true)
    public Optional<User> getUserByApiKey(ApiKey apiKey) {
        return userRepository.findById(apiKey.getUserFkId()); // Use findById (which uses String PK)
    }

    // ==================== DEFAULT API KEY PROTECTION METHODS ====================

    /**
     * Check if an API key is auto-generated during user activation
     * Auto-generated keys have specific naming pattern and prefix
     */
    private boolean isAutoGeneratedApiKey(ApiKey apiKey) {
        if (apiKey.getName() == null || apiKey.getPrefix() == null) {
            return false;
        }
        
        // Auto-generated API keys have this exact pattern
        return apiKey.getName().startsWith("Default Free API Key - ") && 
               "rivo9_".equals(apiKey.getPrefix());
    }

    /**
     * Transfer default API key status to another active API key for the same user
     * This is called before deleting/revoking a user-created default API key
     * 
     * @param userFkId The user ID
     * @param currentDefaultKeyId The current default key being deleted/revoked
     * @return true if transfer was successful, false if no other active key available
     */
    private boolean transferDefaultToAnotherKey(String userFkId, UUID currentDefaultKeyId) {
        log.info("🔄 Attempting to transfer default API key status for user {} from key {}", userFkId, currentDefaultKeyId);
        
        // Find another active API key for this user (excluding the current default)
        List<ApiKey> userApiKeys = apiKeyRepository.findByUserFkId(userFkId);
        
        Optional<ApiKey> newDefaultCandidate = userApiKeys.stream()
            .filter(key -> !key.getId().equals(currentDefaultKeyId)) // Not the current default
            .filter(ApiKey::isActive) // Must be active
            .filter(key -> key.getRevokedAt() == null) // Must not be revoked
            .filter(key -> key.getExpiresAt() == null || key.getExpiresAt().isAfter(LocalDateTime.now())) // Must not be expired
            .findFirst(); // Take the first available one
        
        if (newDefaultCandidate.isPresent()) {
            // ✅ ENHANCED FIX: Use atomic operation first, fallback to individual save
            try {
                // Method 1: Atomic clear + set (most robust)
                int clearedCount = apiKeyRepository.clearAllDefaultKeysForUser(userFkId);
                log.info("Cleared {} existing default API keys for user {} during transfer", clearedCount, userFkId);
                
                ApiKey newDefault = newDefaultCandidate.get();
                newDefault.setIsDefaultKey(true);
                apiKeyRepository.saveAndFlush(newDefault);
                
            } catch (Exception atomicException) {
                // Method 2: Fallback to individual save (existing fix)
                log.warn("Atomic transfer failed, using fallback method for user {}", userFkId);
                ApiKey newDefault = newDefaultCandidate.get();
                newDefault.setIsDefaultKey(true);
                // ✅ CRITICAL FIX: Force immediate save to avoid batch constraint violation
                apiKeyRepository.saveAndFlush(newDefault);
            }
            
            log.info("✅ Successfully transferred default status to API key {} ({}) for user {}", 
                    newDefaultCandidate.get().getId(), newDefaultCandidate.get().getName(), userFkId);
            return true;
        }
        
        log.warn("❌ No other active API key available to transfer default status for user {}", userFkId);
        return false;
    }
}
package com.example.jwtauthenticator.service;

public class GeminiService {

}

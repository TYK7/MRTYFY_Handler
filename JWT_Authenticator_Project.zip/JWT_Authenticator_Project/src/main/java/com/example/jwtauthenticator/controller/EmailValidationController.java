package com.example.jwtauthenticator.controller;

import com.example.jwtauthenticator.service.EmailDomainService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 📧 EMAIL VALIDATION CONTROLLER
 * 
 * Provides endpoints for validating email domains during user registration
 * Performs comprehensive checks including DNS, MX records, SMTP, and website accessibility
 */
@RestController
@RequestMapping("/api/v1/email")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Email Validation", description = "Email domain validation for user registration")
public class EmailValidationController {

    private final EmailDomainService emailDomainService;

    /**
     * Validate email domain for registration
     * 
     * @param email Email address to validate
     * @return Validation results with detailed information
     */
    @PostMapping("/validate-domain")
    @Operation(
        summary = "Validate Email Domain",
        description = "Validates an email domain for user registration by checking DNS resolution, MX records, SMTP connectivity, and website accessibility"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Email validation completed successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid email format or validation failed"),
        @ApiResponse(responseCode = "429", description = "Rate limit exceeded"),
        @ApiResponse(responseCode = "500", description = "Internal server error during validation")
    })
    public ResponseEntity<?> validateEmailDomain(
            @Parameter(description = "Email address to validate", example = "user@example.com", required = true)
            @RequestParam String email) {
        
        log.info("📧 Email domain validation request for: {}", maskEmail(email));
        
        return emailDomainService.checkDomainFromEmail(email);
    }

    /**
     * Get validation service health and cache statistics
     * 
     * @return Service health information and cache statistics
     */
    @GetMapping("/validation/health")
    @Operation(
        summary = "Get Email Validation Service Health",
        description = "Returns health status and cache statistics for the email validation service"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Service health information retrieved successfully")
    })
    public ResponseEntity<Map<String, Object>> getValidationHealth() {
        log.info("🔍 Email validation service health check requested");
        
        Map<String, Object> health = Map.of(
            "service", "EmailDomainService",
            "status", "healthy",
            "cacheStats", emailDomainService.getCacheStats(),
            "timestamp", java.time.Instant.now()
        );
        
        return ResponseEntity.ok(health);
    }

    /**
     * Clear validation caches (for testing/maintenance)
     * 
     * @return Cache clear confirmation
     */
    @PostMapping("/validation/clear-cache")
    @Operation(
        summary = "Clear Validation Caches",
        description = "Clears all validation caches for testing or maintenance purposes"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Caches cleared successfully")
    })
    public ResponseEntity<Map<String, Object>> clearValidationCache() {
        log.info("🧹 Email validation cache clear requested");
        
        emailDomainService.clearCaches();
        
        Map<String, Object> response = Map.of(
            "success", true,
            "message", "All validation caches cleared successfully",
            "timestamp", java.time.Instant.now()
        );
        
        return ResponseEntity.ok(response);
    }

    /**
     * Mask email for logging (privacy protection)
     */
    private String maskEmail(String email) {
        if (email == null || email.length() < 3) return "***";
        
        int atIndex = email.indexOf('@');
        if (atIndex == -1) return "***";
        
        String localPart = email.substring(0, atIndex);
        String domain = email.substring(atIndex);
        
        if (localPart.length() <= 2) {
            return "*".repeat(localPart.length()) + domain;
        }
        
        return localPart.charAt(0) + "*".repeat(localPart.length() - 2) + localPart.charAt(localPart.length() - 1) + domain;
    }
}
package com.example.jwtauthenticator.controller;

import com.example.jwtauthenticator.enums.UserRole;
import com.example.jwtauthenticator.util.RoleValidationUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Role Demo Controller
 * 
 * Demonstrates hierarchical role-based access control where higher roles inherit lower role permissions:
 * - SUPER_ADMIN can access all endpoints (SUPER_ADMIN + ADMIN + USER)
 * - ADMIN can access ADMIN + USER endpoints  
 * - USER can access USER endpoints only
 * 
 * This controller validates that our role hierarchy implementation is working correctly.
 */
@RestController
@RequestMapping("/api/demo")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Role Demo", description = "Demo endpoints to test hierarchical role-based access control")
public class RoleDemoController {

    private final RoleValidationUtil roleValidationUtil;

    /**
     * PUBLIC Demo Endpoint - No authentication required
     * Anyone can access this endpoint
     */
    @GetMapping("/public")
    @Operation(
        summary = "Public Demo Endpoint", 
        description = "Public endpoint accessible by anyone without authentication. Used to verify basic API functionality."
    )
    public ResponseEntity<Map<String, Object>> publicEndpoint() {
        Map<String, Object> response = buildResponse(
            "PUBLIC_ACCESS",
            "This is a public endpoint - no authentication required",
            null,
            "Anyone can access this endpoint"
        );
        
        log.info("🌍 Public endpoint accessed");
        return ResponseEntity.ok(response);
    }

    /**
     * USER Level Demo Endpoint - Requires ROLE_USER or higher
     * Accessible by: USER, ADMIN, SUPER_ADMIN (due to hierarchy)
     */
    @GetMapping("/user")
    @PreAuthorize("hasRole('USER')")
    @Operation(
        summary = "User Level Demo Endpoint", 
        description = "Demonstrates USER level access. Accessible by users with ROLE_USER or higher due to role hierarchy.",
        security = { @SecurityRequirement(name = "Bearer Authentication") }
    )
    public ResponseEntity<Map<String, Object>> userEndpoint(Authentication authentication) {
        UserRole currentRole = roleValidationUtil.getHighestRole(authentication);
        Set<UserRole> userRoles = roleValidationUtil.getUserRoles(authentication);
        
        Map<String, Object> response = buildResponse(
            "USER_ACCESS",
            "You have successfully accessed a USER level endpoint!",
            currentRole,
            "This endpoint can be accessed by: USER, ADMIN, SUPER_ADMIN"
        );
        
        response.put("yourRoles", userRoles.stream().map(UserRole::getRoleName).toList());
        response.put("accessLevel", "USER (Level 1)");
        
        log.info("👤 USER endpoint accessed by user: {} with role: {}", 
            authentication.getName(), currentRole);
        
        return ResponseEntity.ok(response);
    }

    /**
     * ADMIN Level Demo Endpoint - Requires ROLE_ADMIN or higher  
     * Accessible by: ADMIN, SUPER_ADMIN (due to hierarchy)
     * NOT accessible by: USER
     */
    @GetMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(
        summary = "Admin Level Demo Endpoint", 
        description = "Demonstrates ADMIN level access. Accessible by users with ROLE_ADMIN or ROLE_SUPER_ADMIN only.",
        security = { @SecurityRequirement(name = "Bearer Authentication") }
    )
    public ResponseEntity<Map<String, Object>> adminEndpoint(Authentication authentication) {
        UserRole currentRole = roleValidationUtil.getHighestRole(authentication);
        Set<UserRole> userRoles = roleValidationUtil.getUserRoles(authentication);
        
        Map<String, Object> response = buildResponse(
            "ADMIN_ACCESS",
            "You have successfully accessed an ADMIN level endpoint!",
            currentRole,
            "This endpoint can be accessed by: ADMIN, SUPER_ADMIN"
        );
        
        response.put("yourRoles", userRoles.stream().map(UserRole::getRoleName).toList());
        response.put("accessLevel", "ADMIN (Level 2)");
        response.put("canAccessUserEndpoints", true);
        
        log.info("🛠️ ADMIN endpoint accessed by user: {} with role: {}", 
            authentication.getName(), currentRole);
        
        return ResponseEntity.ok(response);
    }

    /**
     * SUPER_ADMIN Level Demo Endpoint - Requires ROLE_SUPER_ADMIN only
     * Accessible by: SUPER_ADMIN only
     * NOT accessible by: USER, ADMIN
     */
    @GetMapping("/super-admin")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Operation(
        summary = "Super Admin Level Demo Endpoint", 
        description = "Demonstrates SUPER_ADMIN level access. Accessible by users with ROLE_SUPER_ADMIN only.",
        security = { @SecurityRequirement(name = "Bearer Authentication") }
    )
    public ResponseEntity<Map<String, Object>> superAdminEndpoint(Authentication authentication) {
        UserRole currentRole = roleValidationUtil.getHighestRole(authentication);
        Set<UserRole> userRoles = roleValidationUtil.getUserRoles(authentication);
        
        Map<String, Object> response = buildResponse(
            "SUPER_ADMIN_ACCESS",
            "You have successfully accessed a SUPER_ADMIN level endpoint!",
            currentRole,
            "This endpoint can be accessed by: SUPER_ADMIN only"
        );
        
        response.put("yourRoles", userRoles.stream().map(UserRole::getRoleName).toList());
        response.put("accessLevel", "SUPER_ADMIN (Level 3)");
        response.put("canAccessUserEndpoints", true);
        response.put("canAccessAdminEndpoints", true);
        
        log.info("🔧 SUPER_ADMIN endpoint accessed by user: {} with role: {}", 
            authentication.getName(), currentRole);
        
        return ResponseEntity.ok(response);
    }

    /**
     * Role Information Endpoint - Shows current user's role information
     * Requires authentication but accessible by any authenticated user
     */
    @GetMapping("/my-role-info")
    @Operation(
        summary = "Get Current User Role Information", 
        description = "Returns detailed information about the current user's roles and permissions.",
        security = { @SecurityRequirement(name = "Bearer Authentication") }
    )
    public ResponseEntity<Map<String, Object>> getCurrentUserRoleInfo(Authentication authentication) {
        UserRole highestRole = roleValidationUtil.getHighestRole(authentication);
        Set<UserRole> userRoles = roleValidationUtil.getUserRoles(authentication);
        
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", "Your role information");
        response.put("username", authentication.getName());
        response.put("timestamp", LocalDateTime.now().toString());
        
        // Current role information
        if (highestRole != null) {
            Map<String, Object> roleInfo = new HashMap<>();
            roleInfo.put("primaryRole", highestRole.getRoleName());
            roleInfo.put("roleLevel", highestRole.getRoleNumber());
            roleInfo.put("displayName", highestRole.getDisplayName());
            roleInfo.put("allRoles", userRoles.stream().map(UserRole::getRoleName).toList());
            roleInfo.put("inheritedRoles", highestRole.getAllInheritedRoles().stream()
                .map(UserRole::getRoleName).toList());
            response.put("roleInformation", roleInfo);
            
            // Access permissions
            Map<String, Boolean> permissions = new HashMap<>();
            permissions.put("canAccessUserEndpoints", highestRole.hasAccess(UserRole.USER));
            permissions.put("canAccessAdminEndpoints", highestRole.hasAccess(UserRole.ADMIN));
            permissions.put("canAccessSuperAdminEndpoints", highestRole.hasAccess(UserRole.SUPER_ADMIN));
            response.put("permissions", permissions);
            
        } else {
            response.put("roleInformation", Map.of("error", "No role assigned"));
        }
        
        // Role hierarchy explanation
        response.put("roleHierarchy", Map.of(
            "description", "SUPER_ADMIN (Level 3) > ADMIN (Level 2) > USER (Level 1)",
            "inheritance", "Higher roles inherit permissions from lower roles"
        ));
        
        log.info("ℹ️ Role info requested by user: {} with role: {}", 
            authentication.getName(), highestRole);
        
        return ResponseEntity.ok(response);
    }

    /**
     * Access Test Matrix - Shows which endpoints the current user can access
     */
    @GetMapping("/access-test")
    @Operation(
        summary = "Test Access Matrix", 
        description = "Shows which demo endpoints the current user can access based on their role.",
        security = { @SecurityRequirement(name = "Bearer Authentication") }
    )
    public ResponseEntity<Map<String, Object>> testAccessMatrix(Authentication authentication) {
        UserRole currentRole = roleValidationUtil.getHighestRole(authentication);
        
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", "Access test matrix for your current role");
        response.put("currentRole", currentRole != null ? currentRole.getRoleName() : "No role");
        response.put("timestamp", LocalDateTime.now().toString());
        
        // Test access to each endpoint
        Map<String, Map<String, Object>> accessMatrix = new HashMap<>();
        
        accessMatrix.put("/api/demo/public", Map.of(
            "accessible", true,
            "reason", "Public endpoint - no authentication required"
        ));
        
        accessMatrix.put("/api/demo/user", Map.of(
            "accessible", roleValidationUtil.hasRoleOrHigher(authentication, UserRole.USER),
            "reason", "Requires ROLE_USER or higher"
        ));
        
        accessMatrix.put("/api/demo/admin", Map.of(
            "accessible", roleValidationUtil.hasRoleOrHigher(authentication, UserRole.ADMIN),
            "reason", "Requires ROLE_ADMIN or higher"
        ));
        
        accessMatrix.put("/api/demo/super-admin", Map.of(
            "accessible", roleValidationUtil.hasRoleOrHigher(authentication, UserRole.SUPER_ADMIN),
            "reason", "Requires ROLE_SUPER_ADMIN only"
        ));
        
        response.put("accessMatrix", accessMatrix);
        
        log.info("🧪 Access matrix requested by user: {} with role: {}", 
            authentication.getName(), currentRole);
        
        return ResponseEntity.ok(response);
    }

    /**
     * Helper method to build consistent response structure
     */
    private Map<String, Object> buildResponse(String accessType, String message, UserRole currentRole, String description) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("accessType", accessType);
        response.put("message", message);
        response.put("description", description);
        response.put("timestamp", LocalDateTime.now().toString());
        
        if (currentRole != null) {
            response.put("currentRole", currentRole.getRoleName());
            response.put("roleLevel", currentRole.getRoleNumber());
        }
        
        // Add navigation suggestions
        Map<String, String> navigation = new HashMap<>();
        navigation.put("roleInfo", "GET /api/demo/my-role-info - Get your role information");
        navigation.put("accessTest", "GET /api/demo/access-test - Test access matrix");
        navigation.put("jwtDebug", "GET /api/test/jwt/debug - Debug JWT token contents");
        response.put("navigation", navigation);
        
        return response;
    }
}
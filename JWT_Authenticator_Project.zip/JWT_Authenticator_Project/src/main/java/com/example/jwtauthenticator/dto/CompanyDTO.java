package com.example.jwtauthenticator.dto;

import com.example.jwtauthenticator.entity.Company;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompanyDTO {
    private Integer companyId;
    private String companyName;
    private String companyDescription;
    private String status;
    private String companyLogoUrl;
    private String domainName;
    private String emailDomains;
    private String websiteUrl;
    private String contactEmail;
    private String phoneNumber;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String stateProvince;
    private String postalCode;
    private String country;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static CompanyDTO fromEntity(Company company) {
        if (company == null) return null;
        
        return CompanyDTO.builder()
                .companyId(company.getCompanyId())
                .companyName(company.getCompanyName())
                .companyDescription(company.getCompanyDescription())
                .status(company.getStatus())
                .companyLogoUrl(company.getCompanyLogoUrl())
                .domainName(company.getDomainName())
                .emailDomains(company.getEmailDomains())
                .websiteUrl(company.getWebsiteUrl())
                .contactEmail(company.getContactEmail())
                .phoneNumber(company.getPhoneNumber())
                .addressLine1(company.getAddressLine1())
                .addressLine2(company.getAddressLine2())
                .city(company.getCity())
                .stateProvince(company.getStateProvince())
                .postalCode(company.getPostalCode())
                .country(company.getCountry())
                .createdAt(company.getCreatedAt())
                .updatedAt(company.getUpdatedAt())
                .build();
    }
}
package com.example.jwtauthenticator.security;

import com.example.jwtauthenticator.enums.UserRole;
import com.example.jwtauthenticator.util.RoleValidationUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Custom Access Denied Handler
 * 
 * Handles cases where authenticated users try to access endpoints they don't have permission for.
 * Provides detailed information about required roles and current user permissions.
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class CustomAccessDeniedHandler implements AccessDeniedHandler {

    private final RoleValidationUtil roleValidationUtil;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response,
                       AccessDeniedException accessDeniedException) throws IOException {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String requestURI = request.getRequestURI();
        String method = request.getMethod();
        String username = authentication != null ? authentication.getName() : "anonymous";

        // Get current user's role information
        UserRole currentHighestRole = roleValidationUtil.getCurrentUserHighestRole();
        Set<UserRole> currentRoles = roleValidationUtil.getCurrentUserRoles();

        log.warn("🔒 Access denied - User: {}, Roles: {}, URI: {} {}, Error: {}", 
            username, currentRoles, method, requestURI, accessDeniedException.getMessage());

        // Determine required role for this endpoint
        UserRole requiredRole = determineRequiredRole(requestURI);
        
        // Build detailed error response
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("error", "Access Denied");
        errorResponse.put("message", buildAccessDeniedMessage(currentHighestRole, requiredRole, requestURI));
        errorResponse.put("status", HttpServletResponse.SC_FORBIDDEN);
        errorResponse.put("path", requestURI);
        errorResponse.put("method", method);
        errorResponse.put("timestamp", LocalDateTime.now().toString());
        errorResponse.put("username", username);
        
        // Current user role information
        Map<String, Object> userRoleInfo = new HashMap<>();
        userRoleInfo.put("currentRole", currentHighestRole != null ? currentHighestRole.getRoleName() : "No role");
        userRoleInfo.put("currentRoleLevel", currentHighestRole != null ? currentHighestRole.getRoleNumber() : 0);
        userRoleInfo.put("allUserRoles", currentRoles.stream().map(UserRole::getRoleName).toList());
        errorResponse.put("currentUser", userRoleInfo);
        
        // Required role information
        Map<String, Object> requiredRoleInfo = new HashMap<>();
        requiredRoleInfo.put("minimumRequiredRole", requiredRole.getRoleName());
        requiredRoleInfo.put("minimumRequiredLevel", requiredRole.getRoleNumber());
        requiredRoleInfo.put("acceptableRoles", getAcceptableRoles(requiredRole));
        errorResponse.put("requirements", requiredRoleInfo);
        
        // Add suggestions for resolution
        errorResponse.put("suggestions", getAccessSuggestions(currentHighestRole, requiredRole, requestURI));

        // Set response properties
        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");

        // Add CORS headers
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");

        // Write JSON response
        response.getWriter().write(objectMapper.writeValueAsString(errorResponse));
    }

    /**
     * Determine the minimum role required for accessing a specific endpoint
     */
    private UserRole determineRequiredRole(String requestURI) {
        if (requestURI.startsWith("/api/super/") || 
            requestURI.startsWith("/api/id-generator/")) {
            return UserRole.SUPER_ADMIN;
        } else if (requestURI.startsWith("/api/admin/") ||
                   requestURI.startsWith("/api/roles/") ||
                   requestURI.startsWith("/api/companies/") ||
                   requestURI.startsWith("/api/dashboard/admin/") ||
                   requestURI.startsWith("/api/brands/admin/")) {
            return UserRole.ADMIN;
        } else if (requestURI.startsWith("/api/users/") ||
                   requestURI.startsWith("/api/v1/api-keys/") ||
                   requestURI.startsWith("/api/v1/dashboard/")) {
            return UserRole.USER;
        }
        
        // Default to USER for most authenticated endpoints
        return UserRole.USER;
    }

    /**
     * Get list of roles that can access the required role level
     */
    private java.util.List<String> getAcceptableRoles(UserRole requiredRole) {
        return UserRole.getAllRoleNames().stream()
            .map(UserRole::fromRoleName)
            .filter(role -> role.hasAccess(requiredRole))
            .map(UserRole::getRoleName)
            .toList();
    }

    /**
     * Build appropriate access denied message
     */
    private String buildAccessDeniedMessage(UserRole currentRole, UserRole requiredRole, String requestURI) {
        if (currentRole == null) {
            return String.format("Access denied. You don't have any assigned role. This endpoint requires %s or higher.", 
                requiredRole.getRoleName());
        }

        return String.format(
            "Access denied. Your current role '%s' (Level %d) cannot access this endpoint. " +
            "This endpoint requires '%s' (Level %d) or higher. " +
            "Please contact an administrator if you believe you should have access to '%s'.",
            currentRole.getRoleName(), 
            currentRole.getRoleNumber(),
            requiredRole.getRoleName(), 
            requiredRole.getRoleNumber(),
            requestURI
        );
    }

    /**
     * Provide suggestions for resolving access issues
     */
    private Map<String, String> getAccessSuggestions(UserRole currentRole, UserRole requiredRole, String requestURI) {
        Map<String, String> suggestions = new HashMap<>();
        
        if (currentRole == null) {
            suggestions.put("contactAdmin", "Contact your system administrator to get a role assigned");
            suggestions.put("relogin", "Try logging out and logging back in to refresh your permissions");
        } else if (currentRole.getRoleNumber() < requiredRole.getRoleNumber()) {
            suggestions.put("roleUpgrade", String.format(
                "You need %s role or higher. Contact admin to upgrade from %s to %s", 
                requiredRole.getRoleName(), currentRole.getRoleName(), requiredRole.getRoleName()));
            
            // Suggest alternative endpoints the user can access
            if (requiredRole == UserRole.ADMIN && currentRole == UserRole.USER) {
                suggestions.put("userEndpoints", "You can access /api/users/**, /api/v1/api-keys/**, /api/v1/dashboard/** endpoints");
            }
        }
        
        suggestions.put("documentation", "Visit /swagger-ui.html to see all available endpoints for your role");
        suggestions.put("roleHierarchy", "Role hierarchy: SUPER_ADMIN > ADMIN > USER (higher roles inherit lower permissions)");
        
        return suggestions;
    }
}
package com.example.jwtauthenticator.repository;

import com.example.jwtauthenticator.entity.ApiKeyAddOn;
import com.example.jwtauthenticator.entity.AddOnPackage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Repository
public interface ApiKeyAddOnRepository extends JpaRepository<ApiKeyAddOn, String> {

    /**
     * Find all active add-ons for an API key
     */
    @Query(value = "SELECT * FROM api_key_addons " +
           "WHERE api_key_id = :apiKeyId " +
           "AND is_active = true AND expires_at > :currentTime " +
           "AND requests_remaining > 0 ORDER BY activated_at ASC", nativeQuery = true)
    List<ApiKeyAddOn> findActiveAddOnsForApiKey(@Param("apiKeyId") UUID apiKeyId, 
                                               @Param("currentTime") LocalDateTime currentTime);
    
    /**
     * Find active add-ons by API key ID (convenience method)
     */
    default List<ApiKeyAddOn> findActiveAddOnsByApiKeyId(UUID apiKeyId) {
        return findActiveAddOnsForApiKey(apiKeyId, LocalDateTime.now());
    }
    
    /**
     * Find active add-ons by API key hash (requires join with api_keys table)
     */
    @Query(value = "SELECT a.* FROM api_key_addons a " +
           "JOIN api_keys ak ON ak.id = a.api_key_id " +
           "WHERE ak.key_hash = :apiKeyHash " +
           "AND a.is_active = true AND a.expires_at > :currentTime " +
           "AND a.requests_remaining > 0 ORDER BY a.activated_at ASC", 
           nativeQuery = true)
    List<ApiKeyAddOn> findActiveAddOnsByApiKeyHash(@Param("apiKeyHash") String apiKeyHash, 
                                                  @Param("currentTime") LocalDateTime currentTime);
    
    /**
     * Find active add-ons by API key hash (convenience method)
     */
    default List<ApiKeyAddOn> findActiveAddOnsByApiKeyHashNow(String apiKeyHash) {
        return findActiveAddOnsByApiKeyHash(apiKeyHash, LocalDateTime.now());
    }

    /**
     * Find all add-ons for an API key (including expired/inactive)
     */
    @Query(value = "SELECT * FROM api_key_addons " +
           "WHERE api_key_id = :apiKeyId " +
           "ORDER BY activated_at DESC", nativeQuery = true)
    List<ApiKeyAddOn> findByApiKeyIdOrderByActivatedAtDesc(@Param("apiKeyId") UUID apiKeyId);

    /**
     * Find all add-ons for a user
     */
    List<ApiKeyAddOn> findByUserFkIdOrderByActivatedAtDesc(String userFkId);

    /**
     * Find add-ons by package type
     */
    List<ApiKeyAddOn> findByAddOnPackage(AddOnPackage addOnPackage);

    /**
     * Find expiring add-ons (within next N days)
     */
    @Query("SELECT addon FROM ApiKeyAddOn addon WHERE addon.isActive = true " +
           "AND addon.expiresAt BETWEEN :now AND :expirationThreshold")
    List<ApiKeyAddOn> findExpiringAddOns(@Param("now") LocalDateTime now,
                                        @Param("expirationThreshold") LocalDateTime expirationThreshold);

    /**
     * Find nearly exhausted add-ons (< 10% remaining)
     */
    @Query("SELECT addon FROM ApiKeyAddOn addon WHERE addon.isActive = true " +
           "AND addon.requestsRemaining < (addon.additionalRequests * 0.1)")
    List<ApiKeyAddOn> findNearlyExhaustedAddOns();

    /**
     * Get total additional requests available for an API key
     */
    @Query(value = "SELECT COALESCE(SUM(requests_remaining), 0) FROM api_key_addons " +
           "WHERE api_key_id = :apiKeyId AND is_active = true " +
           "AND expires_at > :currentTime", nativeQuery = true)
    Integer getTotalAdditionalRequestsAvailable(@Param("apiKeyId") UUID apiKeyId,
                                              @Param("currentTime") LocalDateTime currentTime);

    /**
     * Get monthly spending on add-ons for a user
     */
    @Query("SELECT COALESCE(SUM(addon.monthlyPrice), 0.0) FROM ApiKeyAddOn addon " +
           "WHERE addon.userFkId = :userFkId AND addon.isActive = true " +
           "AND addon.billingCycleStart <= :currentTime AND addon.billingCycleEnd > :currentTime")
    Double getMonthlySpendingForUser(@Param("userFkId") String userFkId,
                                   @Param("currentTime") LocalDateTime currentTime);

    /**
     * Find add-ons that need auto-renewal
     */
    @Query("SELECT addon FROM ApiKeyAddOn addon WHERE addon.autoRenew = true " +
           "AND addon.isActive = true AND addon.expiresAt BETWEEN :now AND :renewalWindow")
    List<ApiKeyAddOn> findAddOnsForAutoRenewal(@Param("now") LocalDateTime now,
                                              @Param("renewalWindow") LocalDateTime renewalWindow);

    /**
     * Clean up expired add-ons
     */
    @Query("UPDATE ApiKeyAddOn addon SET addon.isActive = false " +
           "WHERE addon.expiresAt < :currentTime AND addon.isActive = true")
    int deactivateExpiredAddOns(@Param("currentTime") LocalDateTime currentTime);

    /**
     * Get system-wide add-on statistics
     */
    @Query("SELECT " +
           "COUNT(addon) as totalAddOns, " +
           "COUNT(DISTINCT addon.apiKeyId) as apiKeysWithAddOns, " +
           "SUM(addon.monthlyPrice) as totalMonthlyRevenue, " +
           "AVG(addon.monthlyPrice) as avgAddOnPrice " +
           "FROM ApiKeyAddOn addon WHERE addon.isActive = true")
    Object[] getSystemWideAddOnStats();
}
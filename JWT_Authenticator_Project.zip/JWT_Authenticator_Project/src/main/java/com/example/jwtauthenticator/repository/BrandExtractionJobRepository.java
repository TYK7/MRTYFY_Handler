package com.example.jwtauthenticator.repository;

import com.example.jwtauthenticator.entity.BrandExtractionJob;
import com.example.jwtauthenticator.entity.BrandExtractionJob.Status;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.*;

@Repository
public interface BrandExtractionJobRepository extends JpaRepository<BrandExtractionJob, Long> {

    @Query("""
           SELECT j FROM BrandExtractionJob j
           WHERE j.status = :status
           ORDER BY j.updatedAt ASC
           """)
    List<BrandExtractionJob> findByStatusOrderByUpdatedAt(@Param("status") Status status);

    Optional<BrandExtractionJob> findTopByUrlAndStatusIn(String url, Collection<Status> statuses);

    @Modifying
    @Query("UPDATE BrandExtractionJob j SET j.status = :status, j.lastAttemptAt = :now WHERE j.id = :id")
    int markProcessing(@Param("id") Long id, @Param("status") Status status, @Param("now") LocalDateTime now);
}
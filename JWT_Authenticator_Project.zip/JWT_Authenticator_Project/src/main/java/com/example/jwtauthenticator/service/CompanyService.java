package com.example.jwtauthenticator.service;

import com.example.jwtauthenticator.dto.CompanyDTO;
import com.example.jwtauthenticator.repository.CompanyRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
public class CompanyService {

    @Autowired
    private CompanyRepository companyRepository;

    public List<CompanyDTO> getAllCompanies() {
        return companyRepository.findAll().stream()
                .map(CompanyDTO::fromEntity)
                .collect(Collectors.toList());
    }

    public List<CompanyDTO> getActiveCompanies() {
        return companyRepository.findActiveCompanies().stream()
                .map(CompanyDTO::fromEntity)
                .collect(Collectors.toList());
    }

    public Optional<CompanyDTO> getCompanyById(Integer companyId) {
        return companyRepository.findById(companyId)
                .map(CompanyDTO::fromEntity);
    }

    public Optional<CompanyDTO> getCompanyByName(String companyName) {
        return companyRepository.findByCompanyName(companyName)
                .map(CompanyDTO::fromEntity);
    }

    public Optional<CompanyDTO> getCompanyByDomain(String domainName) {
        return companyRepository.findByDomainName(domainName)
                .map(CompanyDTO::fromEntity);
    }

    public Optional<CompanyDTO> getDefaultCompany() {
        return companyRepository.findDefaultCompany()
                .map(CompanyDTO::fromEntity);
    }
}
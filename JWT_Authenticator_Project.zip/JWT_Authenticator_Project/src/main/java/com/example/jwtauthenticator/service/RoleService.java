package com.example.jwtauthenticator.service;

import com.example.jwtauthenticator.dto.RoleDTO;
import com.example.jwtauthenticator.repository.RoleRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
public class RoleService {

    @Autowired
    private RoleRepository roleRepository;

    public List<RoleDTO> getAllRoles() {
        return roleRepository.findAll().stream()
                .map(RoleDTO::fromEntity)
                .collect(Collectors.toList());
    }

    public Optional<RoleDTO> getRoleById(Integer roleId) {
        return roleRepository.findById(roleId)
                .map(RoleDTO::fromEntity);
    }

    public Optional<RoleDTO> getRoleByName(String roleName) {
        return roleRepository.findByRoleName(roleName)
                .map(RoleDTO::fromEntity);
    }

    public Optional<RoleDTO> getDefaultUserRole() {
        return roleRepository.findDefaultUserRole()
                .map(RoleDTO::fromEntity);
    }

    public List<RoleDTO> getRolesByScope(String scope) {
        return roleRepository.findAll().stream()
                .filter(role -> scope.equals(role.getScope()))
                .map(RoleDTO::fromEntity)
                .collect(Collectors.toList());
    }
}
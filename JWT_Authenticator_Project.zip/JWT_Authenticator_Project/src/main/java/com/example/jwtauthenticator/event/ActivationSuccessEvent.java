package com.example.jwtauthenticator.event;

import com.example.jwtauthenticator.entity.User;
import com.example.jwtauthenticator.dto.ApiKeyGeneratedResponseDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Event published when user activation is successful and API key is created.
 * Used to send activation success email after transaction commits.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ActivationSuccessEvent {
    private User user;
    private ApiKeyGeneratedResponseDTO apiKey;
}
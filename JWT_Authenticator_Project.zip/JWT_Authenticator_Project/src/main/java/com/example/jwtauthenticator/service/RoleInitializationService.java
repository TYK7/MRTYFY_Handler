package com.example.jwtauthenticator.service;

import com.example.jwtauthenticator.entity.Role;
import com.example.jwtauthenticator.enums.UserRole;
import com.example.jwtauthenticator.repository.RoleRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Role Initialization Service
 * 
 * Ensures all required roles exist in the database on application startup.
 * Runs as CommandLineRunner with high priority (Order(1)) to initialize roles
 * before other services that might depend on them.
 */
@Service
@Slf4j
@RequiredArgsConstructor
@Order(1) // High priority - run early in startup
public class RoleInitializationService implements CommandLineRunner {

    private final RoleRepository roleRepository;

    @Override
    @Transactional
    public void run(String... args) {
        log.info("🚀 Starting role initialization...");
        
        try {
            initializeSystemRoles();
            verifyRoleHierarchy();
            log.info("✅ Role initialization completed successfully");
        } catch (Exception e) {
            log.error("❌ Role initialization failed: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to initialize system roles", e);
        }
    }

    /**
     * Initialize all system roles from UserRole enum
     */
    private void initializeSystemRoles() {
        log.info("📋 Initializing system roles...");
        
        for (UserRole userRole : UserRole.values()) {
            createOrUpdateRole(userRole);
        }
        
        log.info("📋 System roles initialization completed");
    }

    /**
     * Create or update a role in the database
     * Handles both roleName and roleNumber constraints to avoid conflicts
     */
    private void createOrUpdateRole(UserRole userRole) {
        String roleName = userRole.getDatabaseRoleName();
        Integer roleNumber = userRole.getRoleNumber();
        
        try {
            // Check if role exists by name
            Optional<Role> existingRoleByName = roleRepository.findByRoleName(roleName);
            // Check if role exists by number
            Optional<Role> existingRoleByNumber = roleRepository.findByRoleNumber(roleNumber);
            
            if (existingRoleByName.isPresent()) {
                // Role exists by name - update if necessary
                Role role = existingRoleByName.get();
                boolean updated = false;
                
                // Check if there's a conflict with role number
                if (existingRoleByNumber.isPresent() && 
                    !existingRoleByNumber.get().getRoleId().equals(role.getRoleId())) {
                    // There's another role with the same number - this is a conflict
                    Role conflictingRole = existingRoleByNumber.get();
                    log.warn("⚠️ Role number conflict detected: {} ({}) conflicts with {} ({})", 
                        roleName, roleNumber, conflictingRole.getRoleName(), conflictingRole.getRoleNumber());
                    
                    // Remove the conflicting role if it's not the target role
                    log.info("🗑️ Removing conflicting role: {} ({})", 
                        conflictingRole.getRoleName(), conflictingRole.getRoleNumber());
                    roleRepository.delete(conflictingRole);
                }
                
                if (!roleNumber.equals(role.getRoleNumber())) {
                    role.setRoleNumber(roleNumber);
                    updated = true;
                }
                
                String expectedDescription = userRole.getDisplayName() + " - " + userRole.getPermissionsDescription().trim();
                if (!expectedDescription.equals(role.getRoleDescription())) {
                    role.setRoleDescription(expectedDescription);
                    updated = true;
                }
                
                if (!userRole.getScope().equals(role.getScope())) {
                    role.setScope(userRole.getScope());
                    updated = true;
                }
                
                if (updated) {
                    roleRepository.save(role);
                    log.info("🔄 Updated role: {} ({})", roleName, roleNumber);
                } else {
                    log.debug("✅ Role already up to date: {} ({})", roleName, roleNumber);
                }
                
            } else if (existingRoleByNumber.isPresent()) {
                // Role exists by number but not by name - update the name
                Role role = existingRoleByNumber.get();
                log.info("🔄 Found role by number ({}), updating name from '{}' to '{}'", 
                    roleNumber, role.getRoleName(), roleName);
                
                role.setRoleName(roleName);
                role.setRoleDescription(userRole.getDisplayName() + " - " + userRole.getPermissionsDescription().trim());
                role.setScope(userRole.getScope());
                
                roleRepository.save(role);
                log.info("🔄 Updated role: {} ({})", roleName, roleNumber);
                
            } else {
                // Role doesn't exist - create new one
                Role newRole = Role.builder()
                    .roleName(roleName)
                    .roleNumber(roleNumber)
                    .roleDescription(userRole.getDisplayName() + " - " + userRole.getPermissionsDescription().trim())
                    .scope(userRole.getScope())
                    .build();
                
                roleRepository.save(newRole);
                log.info("➕ Created new role: {} ({})", roleName, roleNumber);
            }
            
        } catch (org.springframework.dao.DataIntegrityViolationException e) {
            // Handle constraint violations gracefully
            if (e.getMessage().contains("role_rolenumber_key")) {
                log.error("❌ Role number {} already exists. Attempting to resolve conflict...", roleNumber);
                resolveRoleNumberConflict(userRole);
            } else if (e.getMessage().contains("role_rolename_key")) {
                log.error("❌ Role name '{}' already exists. Attempting to resolve conflict...", roleName);
                resolveRoleNameConflict(userRole);
            } else {
                log.error("❌ Database constraint violation for role {}: {}", roleName, e.getMessage());
                throw new RuntimeException("Database constraint violation for role: " + roleName, e);
            }
        } catch (Exception e) {
            log.error("❌ Failed to create/update role {}: {}", roleName, e.getMessage());
            throw new RuntimeException("Failed to initialize role: " + roleName, e);
        }
    }
    
    /**
     * Resolve conflicts when role number already exists
     */
    private void resolveRoleNumberConflict(UserRole userRole) {
        try {
            Optional<Role> conflictingRole = roleRepository.findByRoleNumber(userRole.getRoleNumber());
            if (conflictingRole.isPresent()) {
                Role existing = conflictingRole.get();
                log.info("🔄 Resolving role number conflict: Updating existing role '{}' to match '{}'", 
                    existing.getRoleName(), userRole.getDatabaseRoleName());
                
                existing.setRoleName(userRole.getDatabaseRoleName());
                existing.setRoleDescription(userRole.getDisplayName() + " - " + userRole.getPermissionsDescription().trim());
                existing.setScope(userRole.getScope());
                
                roleRepository.save(existing);
                log.info("✅ Resolved role number conflict for {} ({})", userRole.getDatabaseRoleName(), userRole.getRoleNumber());
            }
        } catch (Exception e) {
            log.error("❌ Failed to resolve role number conflict: {}", e.getMessage());
            throw new RuntimeException("Failed to resolve role number conflict for: " + userRole.getDatabaseRoleName(), e);
        }
    }
    
    /**
     * Resolve conflicts when role name already exists
     */
    private void resolveRoleNameConflict(UserRole userRole) {
        try {
            Optional<Role> conflictingRole = roleRepository.findByRoleName(userRole.getDatabaseRoleName());
            if (conflictingRole.isPresent()) {
                Role existing = conflictingRole.get();
                log.info("🔄 Resolving role name conflict: Updating role '{}' number to {}", 
                    existing.getRoleName(), userRole.getRoleNumber());
                
                existing.setRoleNumber(userRole.getRoleNumber());
                existing.setRoleDescription(userRole.getDisplayName() + " - " + userRole.getPermissionsDescription().trim());
                existing.setScope(userRole.getScope());
                
                roleRepository.save(existing);
                log.info("✅ Resolved role name conflict for {} ({})", userRole.getDatabaseRoleName(), userRole.getRoleNumber());
            }
        } catch (Exception e) {
            log.error("❌ Failed to resolve role name conflict: {}", e.getMessage());
            throw new RuntimeException("Failed to resolve role name conflict for: " + userRole.getDatabaseRoleName(), e);
        }
    }

    /**
     * Verify role hierarchy is correctly set up
     */
    private void verifyRoleHierarchy() {
        log.info("🔍 Verifying role hierarchy...");
        
        // Test hierarchical access
        UserRole superAdmin = UserRole.SUPER_ADMIN;
        UserRole admin = UserRole.ADMIN;
        UserRole user = UserRole.USER;
        
        // Verify SUPER_ADMIN has access to all roles
        if (!superAdmin.hasAccess(admin) || !superAdmin.hasAccess(user)) {
            throw new RuntimeException("SUPER_ADMIN role hierarchy verification failed");
        }
        
        // Verify ADMIN has access to USER but not SUPER_ADMIN
        if (!admin.hasAccess(user) || admin.hasAccess(superAdmin)) {
            throw new RuntimeException("ADMIN role hierarchy verification failed");
        }
        
        // Verify USER only has access to itself
        if (user.hasAccess(admin) || user.hasAccess(superAdmin)) {
            throw new RuntimeException("USER role hierarchy verification failed");
        }
        
        log.info("✅ Role hierarchy verification completed");
        
        // Log hierarchy for debugging
        for (UserRole role : UserRole.values()) {
            log.info("🏗️  {}", role.getHierarchyString());
        }
    }

    /**
     * Get role statistics for monitoring
     */
    public RoleStatistics getRoleStatistics() {
        try {
            long totalRoles = roleRepository.count();
            
            long userRoles = roleRepository.findByRoleName("USER")
                .map(role -> 1L)
                .orElse(0L);
                
            long adminRoles = roleRepository.findByRoleName("ADMIN")
                .map(role -> 1L)
                .orElse(0L);
                
            long superAdminRoles = roleRepository.findByRoleName("SUPER_ADMIN")
                .map(role -> 1L)
                .orElse(0L);
            
            return new RoleStatistics(totalRoles, userRoles, adminRoles, superAdminRoles);
            
        } catch (Exception e) {
            log.error("❌ Failed to get role statistics: {}", e.getMessage());
            return new RoleStatistics(0, 0, 0, 0);
        }
    }

    /**
     * Force re-initialization of roles (for admin operations)
     */
    @Transactional
    public void reinitializeRoles() {
        log.warn("⚠️ Force re-initializing all system roles...");
        run();
    }

    /**
     * Check if all required roles are properly initialized
     */
    public boolean areAllRolesInitialized() {
        try {
            for (UserRole userRole : UserRole.values()) {
                if (roleRepository.findByRoleName(userRole.getDatabaseRoleName()).isEmpty()) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            log.error("❌ Error checking role initialization status: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Role statistics record
     */
    public record RoleStatistics(
        long totalRoles,
        long userRoles,
        long adminRoles,
        long superAdminRoles
    ) {
        public boolean isHealthy() {
            return totalRoles >= 3 && userRoles > 0 && adminRoles > 0 && superAdminRoles > 0;
        }
    }
}
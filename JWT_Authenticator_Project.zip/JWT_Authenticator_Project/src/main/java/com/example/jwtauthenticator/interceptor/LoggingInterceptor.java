package com.example.jwtauthenticator.interceptor;

import com.example.jwtauthenticator.util.LoggingUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Interceptor for automatic request/response logging with MDC context management.
 * Captures request details, execution time, and response status for comprehensive logging.
 * 
 * @author BrandSnap API Team
 * @since 1.0.0
 */
@Slf4j
@Component
public class LoggingInterceptor implements HandlerInterceptor {

    private static final String START_TIME_ATTRIBUTE = "startTime";
    private static final String REQUEST_LOGGED_ATTRIBUTE = "requestLogged";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        long startTime = System.currentTimeMillis();
        request.setAttribute(START_TIME_ATTRIBUTE, startTime);

        // Initialize logging context
        LoggingUtil.initializeRequestContext(request);

        // Extract and set user context if available
        String userId = extractUserId(request);
        if (userId != null) {
            LoggingUtil.setUserContext(userId);
        }

        // Extract and set API key context if available
        String apiKey = extractApiKey(request);
        if (apiKey != null) {
            LoggingUtil.setApiKeyContext(apiKey);
        }

        // Extract and set session context if available
        String sessionId = request.getSession(false) != null ? request.getSession().getId() : null;
        if (sessionId != null) {
            LoggingUtil.setSessionContext(sessionId);
        }

        // Log the request (avoid logging static resources)
        if (!isStaticResource(request)) {
            LoggingUtil.logApiRequest(
                request.getRequestURI(),
                request.getMethod(),
                userId,
                apiKey,
                LoggingUtil.extractClientIp(request)
            );
            request.setAttribute(REQUEST_LOGGED_ATTRIBUTE, true);
        }

        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        // Calculate execution time
        Long startTime = (Long) request.getAttribute(START_TIME_ATTRIBUTE);
        if (startTime != null) {
            long executionTime = System.currentTimeMillis() - startTime;
            LoggingUtil.setExecutionTime(executionTime);

            // Log response for non-static resources
            Boolean requestLogged = (Boolean) request.getAttribute(REQUEST_LOGGED_ATTRIBUTE);
            if (Boolean.TRUE.equals(requestLogged)) {
                LoggingUtil.logApiResponse(
                    request.getRequestURI(),
                    response.getStatus(),
                    executionTime
                );

                // Log slow requests
                if (executionTime > 5000) {
                    log.warn("SLOW_REQUEST - URI: {}, Method: {}, ExecutionTime: {}ms, Status: {}", 
                            request.getRequestURI(), request.getMethod(), executionTime, response.getStatus());
                }
            }
        }
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        // Log any exceptions that occurred
        if (ex != null) {
            LoggingUtil.logError(
                "REQUEST_PROCESSING",
                ex,
                String.format("URI: %s, Method: %s", request.getRequestURI(), request.getMethod())
            );
        }

        // Clear MDC context to prevent memory leaks
        LoggingUtil.clearContext();
    }

    /**
     * Extract user ID from request (from JWT token, session, or header)
     */
    private String extractUserId(HttpServletRequest request) {
        // Try to get from request attribute (set by authentication filter)
        Object userIdAttr = request.getAttribute("userId");
        if (userIdAttr != null) {
            return userIdAttr.toString();
        }

        // Try to get from custom header
        String userIdHeader = request.getHeader("X-User-ID");
        if (userIdHeader != null && !userIdHeader.trim().isEmpty()) {
            return userIdHeader;
        }

        // Try to get from session
        if (request.getSession(false) != null) {
            Object sessionUserId = request.getSession().getAttribute("userId");
            if (sessionUserId != null) {
                return sessionUserId.toString();
            }
        }

        return null;
    }

    /**
     * Extract API key from request headers
     */
    private String extractApiKey(HttpServletRequest request) {
        // Try Authorization header
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7);
        }

        // Try X-API-Key header
        String apiKeyHeader = request.getHeader("X-API-Key");
        if (apiKeyHeader != null && !apiKeyHeader.trim().isEmpty()) {
            return apiKeyHeader;
        }

        // Try api_key parameter
        String apiKeyParam = request.getParameter("api_key");
        if (apiKeyParam != null && !apiKeyParam.trim().isEmpty()) {
            return apiKeyParam;
        }

        return null;
    }

    /**
     * Check if the request is for a static resource
     */
    private boolean isStaticResource(HttpServletRequest request) {
        String uri = request.getRequestURI();
        return uri.contains("/static/") || 
               uri.contains("/css/") || 
               uri.contains("/js/") || 
               uri.contains("/images/") || 
               uri.contains("/favicon.ico") ||
               uri.contains("/webjars/") ||
               uri.endsWith(".css") ||
               uri.endsWith(".js") ||
               uri.endsWith(".png") ||
               uri.endsWith(".jpg") ||
               uri.endsWith(".jpeg") ||
               uri.endsWith(".gif") ||
               uri.endsWith(".ico") ||
               uri.endsWith(".svg");
    }
}
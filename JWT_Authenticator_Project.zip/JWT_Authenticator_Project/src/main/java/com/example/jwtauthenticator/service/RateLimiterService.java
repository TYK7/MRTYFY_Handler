package com.example.jwtauthenticator.service;

import com.example.jwtauthenticator.config.ForwardConfig;
import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.Bucket4j;
import io.github.bucket4j.ConsumptionProbe;
import io.github.bucket4j.Refill;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class RateLimiterService {

    private final long requestsPerMinute;
    private final long publicRequestsPerMinute;
    // ✅ FIXED: Use bounded cache to prevent memory leaks from unlimited bucket growth
    private final Map<String, BucketEntry> buckets = new ConcurrentHashMap<>();
    private static final int MAX_BUCKETS = 10000; // Limit bucket cache size
    
    // Helper class to track bucket access time for proper LRU eviction
    private static class BucketEntry {
        final Bucket bucket;
        volatile long lastAccessed;
        
        BucketEntry(Bucket bucket) {
            this.bucket = bucket;
            this.lastAccessed = System.currentTimeMillis();
        }
        
        void updateAccess() {
            this.lastAccessed = System.currentTimeMillis();
        }
    }

    public RateLimiterService(ForwardConfig config) {
        this.requestsPerMinute = config.getRequestsPerMinute();
        // For public endpoints, use a more restrictive rate limit (half of the authenticated limit)
        this.publicRequestsPerMinute = Math.max(10, config.getRequestsPerMinute() / 2);
    }

    private Bucket newBucket() {
        Refill refill = Refill.intervally(requestsPerMinute, Duration.ofMinutes(1));
        Bandwidth limit = Bandwidth.classic(requestsPerMinute, refill);
        return Bucket4j.builder().addLimit(limit).build();
    }
    
    private Bucket newPublicBucket() {
        Refill refill = Refill.intervally(publicRequestsPerMinute, Duration.ofMinutes(1));
        Bandwidth limit = Bandwidth.classic(publicRequestsPerMinute, refill);
        return Bucket4j.builder().addLimit(limit).build();
    }

    public ConsumptionProbe consume(String userId) {
        // ✅ FIXED: Implement proper LRU eviction to prevent memory leaks
        if (buckets.size() >= MAX_BUCKETS) {
            evictOldestEntries();
        }
        
        BucketEntry entry = buckets.computeIfAbsent(userId, k -> new BucketEntry(newBucket()));
        entry.updateAccess();
        return entry.bucket.tryConsumeAndReturnRemaining(1);
    }
    
    private void evictOldestEntries() {
        // Remove 20% of oldest entries to prevent frequent evictions
        int toRemove = MAX_BUCKETS / 5;
        buckets.entrySet().stream()
            .sorted((e1, e2) -> Long.compare(e1.getValue().lastAccessed, e2.getValue().lastAccessed))
            .limit(toRemove)
            .map(Map.Entry::getKey)
            .forEach(buckets::remove);
    }
    
    /**
     * Consume a token from the public rate limiter bucket for the given IP address.
     * Public endpoints have a more restrictive rate limit.
     * 
     * @param ipAddress The client IP address
     * @return A consumption probe indicating whether the request was allowed
     */
    public ConsumptionProbe consumePublic(String ipAddress) {
        // Use a prefix to distinguish public buckets from authenticated user buckets
        String key = "public:" + ipAddress;
        
        // ✅ FIXED: Apply same LRU eviction logic for public buckets
        if (buckets.size() >= MAX_BUCKETS) {
            evictOldestEntries();
        }
        
        BucketEntry entry = buckets.computeIfAbsent(key, k -> new BucketEntry(newPublicBucket()));
        entry.updateAccess();
        return entry.bucket.tryConsumeAndReturnRemaining(1);
    }
}

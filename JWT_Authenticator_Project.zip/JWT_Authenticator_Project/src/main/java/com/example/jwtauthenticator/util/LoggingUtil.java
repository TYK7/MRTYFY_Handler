package com.example.jwtauthenticator.util;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import jakarta.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * Utility class for enhanced logging with structured data and MDC support.
 * Provides methods for adding contextual information to logs for better traceability.
 * 
 * @author BrandSnap API Team
 * @since 1.0.0
 */
@Slf4j
@Component
public class LoggingUtil {

    // MDC Keys
    public static final String TRACE_ID = "traceId";
    public static final String SPAN_ID = "spanId";
    public static final String USER_ID = "userId";
    public static final String API_KEY = "apiKey";
    public static final String CLIENT_IP = "clientIp";
    public static final String REQUEST_URI = "requestUri";
    public static final String HTTP_METHOD = "httpMethod";
    public static final String USER_AGENT = "userAgent";
    public static final String EXECUTION_TIME = "executionTime";
    public static final String REQUEST_ID = "requestId";
    public static final String SESSION_ID = "sessionId";

    /**
     * Initialize MDC with trace and span IDs for request tracking
     */
    public static void initializeTracing() {
        String traceId = generateTraceId();
        String spanId = generateSpanId();
        
        MDC.put(TRACE_ID, traceId);
        MDC.put(SPAN_ID, spanId);
        
        log.debug("Initialized tracing - TraceId: {}, SpanId: {}", traceId, spanId);
    }

    /**
     * Initialize MDC with HTTP request context
     */
    public static void initializeRequestContext(HttpServletRequest request) {
        initializeTracing();
        
        String requestId = generateRequestId();
        String clientIp = extractClientIp(request);
        
        MDC.put(REQUEST_ID, requestId);
        MDC.put(CLIENT_IP, clientIp);
        MDC.put(REQUEST_URI, request.getRequestURI());
        MDC.put(HTTP_METHOD, request.getMethod());
        MDC.put(USER_AGENT, request.getHeader("User-Agent"));
        
        log.info("Request started - Method: {}, URI: {}, ClientIP: {}, RequestId: {}", 
                request.getMethod(), request.getRequestURI(), clientIp, requestId);
    }

    /**
     * Add user context to MDC
     */
    public static void setUserContext(String userId) {
        if (userId != null && !userId.trim().isEmpty()) {
            MDC.put(USER_ID, userId);
            log.debug("User context set - UserId: {}", userId);
        }
    }

    /**
     * Add API key context to MDC (masked for security)
     */
    public static void setApiKeyContext(String apiKey) {
        if (apiKey != null && !apiKey.trim().isEmpty()) {
            String maskedApiKey = maskApiKey(apiKey);
            MDC.put(API_KEY, maskedApiKey);
            log.debug("API key context set - ApiKey: {}", maskedApiKey);
        }
    }

    /**
     * Add session context to MDC
     */
    public static void setSessionContext(String sessionId) {
        if (sessionId != null && !sessionId.trim().isEmpty()) {
            MDC.put(SESSION_ID, sessionId);
            log.debug("Session context set - SessionId: {}", sessionId);
        }
    }

    /**
     * Set execution time in MDC
     */
    public static void setExecutionTime(long executionTimeMs) {
        MDC.put(EXECUTION_TIME, String.valueOf(executionTimeMs));
    }

    /**
     * Clear all MDC context
     */
    public static void clearContext() {
        String traceId = MDC.get(TRACE_ID);
        log.debug("Clearing MDC context - TraceId: {}", traceId);
        MDC.clear();
    }

    /**
     * Log API request with structured data
     */
    public static void logApiRequest(String endpoint, String method, String userId, String apiKey, String clientIp) {
        log.info("API_REQUEST - Endpoint: {}, Method: {}, UserId: {}, ApiKey: {}, ClientIP: {}", 
                endpoint, method, userId, maskApiKey(apiKey), clientIp);
    }

    /**
     * Log API response with structured data
     */
    public static void logApiResponse(String endpoint, int statusCode, long executionTime) {
        log.info("API_RESPONSE - Endpoint: {}, StatusCode: {}, ExecutionTime: {}ms", 
                endpoint, statusCode, executionTime);
    }

    /**
     * Log security event
     */
    public static void logSecurityEvent(String event, String userId, String clientIp, String details) {
        log.warn("SECURITY_EVENT - Event: {}, UserId: {}, ClientIP: {}, Details: {}", 
                event, userId, clientIp, details);
    }

    /**
     * Log authentication event
     */
    public static void logAuthenticationEvent(String event, String userId, String clientIp, boolean success) {
        if (success) {
            log.info("AUTH_SUCCESS - Event: {}, UserId: {}, ClientIP: {}", event, userId, clientIp);
        } else {
            log.warn("AUTH_FAILURE - Event: {}, UserId: {}, ClientIP: {}", event, userId, clientIp);
        }
    }

    /**
     * Log performance metrics
     */
    public static void logPerformanceMetrics(String operation, long executionTime, String additionalInfo) {
        if (executionTime > 5000) { // Log slow operations (>5 seconds)
            log.warn("SLOW_OPERATION - Operation: {}, ExecutionTime: {}ms, Info: {}", 
                    operation, executionTime, additionalInfo);
        } else {
            log.info("PERFORMANCE - Operation: {}, ExecutionTime: {}ms, Info: {}", 
                    operation, executionTime, additionalInfo);
        }
    }

    /**
     * Log database operation
     */
    public static void logDatabaseOperation(String operation, String table, long executionTime, int recordCount) {
        log.info("DB_OPERATION - Operation: {}, Table: {}, ExecutionTime: {}ms, RecordCount: {}", 
                operation, table, executionTime, recordCount);
    }

    /**
     * Log error with context
     */
    public static void logError(String operation, Exception exception, String additionalContext) {
        log.error("ERROR - Operation: {}, Exception: {}, Context: {}, Message: {}", 
                operation, exception.getClass().getSimpleName(), additionalContext, exception.getMessage(), exception);
    }

    /**
     * Log business event
     */
    public static void logBusinessEvent(String event, String userId, String details) {
        log.info("BUSINESS_EVENT - Event: {}, UserId: {}, Details: {}", event, userId, details);
    }

    // Private utility methods

    private static String generateTraceId() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 16);
    }

    private static String generateSpanId() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 8);
    }

    private static String generateRequestId() {
        return "REQ-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")) + 
               "-" + UUID.randomUUID().toString().substring(0, 8);
    }

    public static String extractClientIp(HttpServletRequest request) {
        String clientIp = request.getHeader("X-Forwarded-For");
        if (clientIp == null || clientIp.isEmpty() || "unknown".equalsIgnoreCase(clientIp)) {
            clientIp = request.getHeader("X-Real-IP");
        }
        if (clientIp == null || clientIp.isEmpty() || "unknown".equalsIgnoreCase(clientIp)) {
            clientIp = request.getHeader("Proxy-Client-IP");
        }
        if (clientIp == null || clientIp.isEmpty() || "unknown".equalsIgnoreCase(clientIp)) {
            clientIp = request.getHeader("WL-Proxy-Client-IP");
        }
        if (clientIp == null || clientIp.isEmpty() || "unknown".equalsIgnoreCase(clientIp)) {
            clientIp = request.getRemoteAddr();
        }
        
        // Handle multiple IPs in X-Forwarded-For
        if (clientIp != null && clientIp.contains(",")) {
            clientIp = clientIp.split(",")[0].trim();
        }
        
        return clientIp != null ? clientIp : "unknown";
    }

    private static String maskApiKey(String apiKey) {
        if (apiKey == null || apiKey.length() < 8) {
            return "***";
        }
        return apiKey.substring(0, 4) + "***" + apiKey.substring(apiKey.length() - 4);
    }
}
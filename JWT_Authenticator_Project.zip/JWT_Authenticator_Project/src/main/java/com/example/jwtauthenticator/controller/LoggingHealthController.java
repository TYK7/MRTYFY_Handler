package com.example.jwtauthenticator.controller;

import com.example.jwtauthenticator.monitoring.LoggingMonitoringService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Controller for logging system health checks and monitoring endpoints.
 * Provides endpoints to check logging system status and metrics.
 * 
 * @author BrandSnap API Team
 * @since 1.0.0
 */
@Slf4j
@RestController
@RequestMapping("/actuator/logging")
@RequiredArgsConstructor
public class LoggingHealthController implements HealthIndicator {

    private final LoggingMonitoringService monitoringService;

    /**
     * Health check endpoint for logging system
     */
    @Override
    public Health health() {
        try {
            boolean isHealthy = monitoringService.isLoggingHealthy();
            String status = monitoringService.getLoggingStatus();
            
            Health.Builder builder = isHealthy ? Health.up() : Health.down();
            
            return builder
                    .withDetail("status", status)
                    .withDetail("errorCount", monitoringService.getCurrentErrorCount())
                    .withDetail("warningCount", monitoringService.getCurrentWarningCount())
                    .withDetail("requestCount", monitoringService.getCurrentRequestCount())
                    .build();
                    
        } catch (Exception e) {
            log.error("Error checking logging health", e);
            return Health.down()
                    .withDetail("error", e.getMessage())
                    .build();
        }
    }

    /**
     * Get detailed logging metrics
     */
    @GetMapping("/metrics")
    public ResponseEntity<Map<String, Object>> getLoggingMetrics() {
        try {
            Map<String, Object> metrics = new HashMap<>();
            metrics.put("status", monitoringService.getLoggingStatus());
            metrics.put("healthy", monitoringService.isLoggingHealthy());
            metrics.put("errorCount", monitoringService.getCurrentErrorCount());
            metrics.put("warningCount", monitoringService.getCurrentWarningCount());
            metrics.put("requestCount", monitoringService.getCurrentRequestCount());
            
            return ResponseEntity.ok(metrics);
            
        } catch (Exception e) {
            log.error("Error retrieving logging metrics", e);
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "Failed to retrieve logging metrics");
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.internalServerError().body(errorResponse);
        }
    }

    /**
     * Test logging endpoint - generates log entries for testing
     */
    @GetMapping("/test")
    public ResponseEntity<Map<String, String>> testLogging() {
        try {
            log.info("TEST_LOG_INFO - Testing INFO level logging");
            log.warn("TEST_LOG_WARN - Testing WARN level logging");
            log.debug("TEST_LOG_DEBUG - Testing DEBUG level logging");
            
            // Don't generate ERROR logs in test endpoint as it affects monitoring
            
            Map<String, String> response = new HashMap<>();
            response.put("message", "Test log entries generated successfully");
            response.put("levels", "INFO, WARN, DEBUG");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Error in logging test endpoint", e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Failed to generate test logs");
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.internalServerError().body(errorResponse);
        }
    }
}
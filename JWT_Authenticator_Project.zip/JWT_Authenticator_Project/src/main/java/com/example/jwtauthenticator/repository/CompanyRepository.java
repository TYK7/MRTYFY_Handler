package com.example.jwtauthenticator.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.jwtauthenticator.entity.Company;

@Repository
public interface CompanyRepository extends JpaRepository<Company, Integer> {
    
    Optional<Company> findByCompanyName(String companyName);
    
    Optional<Company> findByDomainName(String domainName);
    
    boolean existsByCompanyName(String companyName);
    
    boolean existsByDomainName(String domainName);
    
    List<Company> findByStatus(String status);
    
    @Query("SELECT c FROM Company c WHERE c.status = 'Active'")
    List<Company> findActiveCompanies();
    
    @Query(value = "SELECT * FROM company c WHERE c.emaildomains LIKE CONCAT('%@', :email, '%')", nativeQuery = true)
    Optional<Company> findByEmailDomain(@Param("email") String email);
    
    // Find default company (optional - first active company)
    @Query("SELECT c FROM Company c WHERE c.status = 'Active' ORDER BY c.companyId ASC")
    Optional<Company> findDefaultCompany();
}
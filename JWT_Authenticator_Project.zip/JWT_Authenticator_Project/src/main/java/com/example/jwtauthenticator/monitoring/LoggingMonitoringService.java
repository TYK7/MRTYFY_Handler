package com.example.jwtauthenticator.monitoring;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Service for monitoring logging system health and performance.
 * Tracks log file sizes, error rates, and system health metrics.
 * 
 * @author BrandSnap API Team
 * @since 1.0.0
 */
@Slf4j
@Service
public class LoggingMonitoringService {

    @Value("${app.logging.dir:./logs}")
    private String logDirectory;

    @Value("${app.logging.monitoring.enabled:true}")
    private boolean monitoringEnabled;

    @Value("${app.logging.monitoring.error-threshold:10}")
    private int errorThreshold;

    @Value("${app.logging.monitoring.error-window-minutes:5}")
    private int errorWindowMinutes;

    private final AtomicLong errorCount = new AtomicLong(0);
    private final AtomicLong warningCount = new AtomicLong(0);
    private final AtomicLong requestCount = new AtomicLong(0);
    private LocalDateTime lastResetTime = LocalDateTime.now();

    /**
     * Monitor log file sizes and system health every 5 minutes
     */
    @Scheduled(fixedRate = 300000) // 5 minutes
    public void monitorLogFiles() {
        if (!monitoringEnabled) {
            return;
        }

        try {
            Path logDir = Paths.get(logDirectory);
            if (!Files.exists(logDir)) {
                log.warn("Log directory does not exist: {}", logDirectory);
                return;
            }

            long totalLogSize = 0;
            int logFileCount = 0;

            // Check main log files
            String[] logFiles = {
                "brandsnap-api-application.log",
                "brandsnap-api-error.log",
                "brandsnap-api-api.log",
                "brandsnap-api-security.log",
                "brandsnap-api-performance.log",
                "brandsnap-api-database.log"
            };

            for (String logFileName : logFiles) {
                Path logFile = logDir.resolve(logFileName);
                if (Files.exists(logFile)) {
                    long fileSize = Files.size(logFile);
                    totalLogSize += fileSize;
                    logFileCount++;

                    // Check if file is getting too large
                    if (fileSize > 500 * 1024 * 1024) { // 500MB
                        log.warn("LARGE_LOG_FILE - File: {}, Size: {} MB", 
                                logFileName, fileSize / (1024 * 1024));
                    }
                }
            }

            log.info("LOG_MONITORING - TotalSize: {} MB, FileCount: {}, ErrorCount: {}, WarningCount: {}, RequestCount: {}", 
                    totalLogSize / (1024 * 1024), logFileCount, 
                    errorCount.get(), warningCount.get(), requestCount.get());

            // Check disk space
            File logDirFile = new File(logDirectory);
            long freeSpace = logDirFile.getFreeSpace();
            long totalSpace = logDirFile.getTotalSpace();
            double freeSpacePercent = (double) freeSpace / totalSpace * 100;

            if (freeSpacePercent < 10) {
                log.error("LOW_DISK_SPACE - Available: {:.2f}%, Free: {} GB", 
                        freeSpacePercent, freeSpace / (1024 * 1024 * 1024));
            } else if (freeSpacePercent < 20) {
                log.warn("DISK_SPACE_WARNING - Available: {:.2f}%, Free: {} GB", 
                        freeSpacePercent, freeSpace / (1024 * 1024 * 1024));
            }

        } catch (IOException e) {
            log.error("Error monitoring log files", e);
        }
    }

    /**
     * Reset error counters every hour
     */
    @Scheduled(fixedRate = 3600000) // 1 hour
    public void resetCounters() {
        if (!monitoringEnabled) {
            return;
        }

        long errors = errorCount.getAndSet(0);
        long warnings = warningCount.getAndSet(0);
        long requests = requestCount.getAndSet(0);

        log.info("HOURLY_STATS_RESET - Errors: {}, Warnings: {}, Requests: {}, Period: {} to {}", 
                errors, warnings, requests, 
                lastResetTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

        lastResetTime = LocalDateTime.now();
    }

    /**
     * Clean up old log files daily
     */
    @Scheduled(cron = "0 0 2 * * ?") // 2 AM daily
    public void cleanupOldLogs() {
        if (!monitoringEnabled) {
            return;
        }

        try {
            Path logDir = Paths.get(logDirectory);
            Path archiveDir = logDir.resolve("archive");
            
            if (!Files.exists(archiveDir)) {
                return;
            }

            LocalDateTime cutoffDate = LocalDateTime.now().minusDays(30);
            
            Files.walk(archiveDir)
                    .filter(Files::isRegularFile)
                    .filter(path -> {
                        try {
                            return Files.getLastModifiedTime(path).toInstant()
                                    .isBefore(cutoffDate.atZone(java.time.ZoneId.systemDefault()).toInstant());
                        } catch (IOException e) {
                            return false;
                        }
                    })
                    .forEach(path -> {
                        try {
                            Files.delete(path);
                            log.info("Deleted old log file: {}", path.getFileName());
                        } catch (IOException e) {
                            log.warn("Failed to delete old log file: {}", path.getFileName(), e);
                        }
                    });

        } catch (IOException e) {
            log.error("Error cleaning up old log files", e);
        }
    }

    /**
     * Increment error counter
     */
    public void incrementErrorCount() {
        long count = errorCount.incrementAndGet();
        
        // Check if error threshold is exceeded
        if (count > errorThreshold) {
            log.error("ERROR_THRESHOLD_EXCEEDED - Count: {}, Threshold: {}, Window: {} minutes", 
                    count, errorThreshold, errorWindowMinutes);
        }
    }

    /**
     * Increment warning counter
     */
    public void incrementWarningCount() {
        warningCount.incrementAndGet();
    }

    /**
     * Increment request counter
     */
    public void incrementRequestCount() {
        requestCount.incrementAndGet();
    }

    /**
     * Get current error count
     */
    public long getCurrentErrorCount() {
        return errorCount.get();
    }

    /**
     * Get current warning count
     */
    public long getCurrentWarningCount() {
        return warningCount.get();
    }

    /**
     * Get current request count
     */
    public long getCurrentRequestCount() {
        return requestCount.get();
    }

    /**
     * Check if logging system is healthy
     */
    public boolean isLoggingHealthy() {
        try {
            Path logDir = Paths.get(logDirectory);
            if (!Files.exists(logDir)) {
                return false;
            }

            // Check if we can write to log directory
            Path testFile = logDir.resolve("health-check.tmp");
            Files.write(testFile, "health check".getBytes());
            Files.delete(testFile);

            // Check error rate
            return errorCount.get() <= errorThreshold;

        } catch (IOException e) {
            log.error("Logging health check failed", e);
            return false;
        }
    }

    /**
     * Get logging system status
     */
    public String getLoggingStatus() {
        if (!monitoringEnabled) {
            return "MONITORING_DISABLED";
        }

        if (!isLoggingHealthy()) {
            return "UNHEALTHY";
        }

        if (errorCount.get() > errorThreshold / 2) {
            return "WARNING";
        }

        return "HEALTHY";
    }
}
package com.example.jwtauthenticator.security;

import com.example.jwtauthenticator.entity.User;
import com.example.jwtauthenticator.repository.UserRepository;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Optional;

@Service
public class JwtUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;
    private final PasswordEncoder bcryptEncoder;

    public JwtUserDetailsService(UserRepository userRepository, PasswordEncoder bcryptEncoder) {
        this.userRepository = userRepository;
        this.bcryptEncoder = bcryptEncoder;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        throw new UnsupportedOperationException("Use loadUserByUsernameAndBrandId instead");
    }

    public UserDetails loadUserByUsernameAndBrandId(String username, String brandId) throws UsernameNotFoundException {
        // Prefer lookup by username and brandId to enforce tenant/brand context
        Optional<User> userOptional = userRepository.findByUsernameAndBrandId(username, brandId);

        // Optional fallback for default brand if such behavior is intended
        if (userOptional.isEmpty() && "default".equalsIgnoreCase(brandId)) {
            userOptional = userRepository.findByUsername(username);
        }

        if (userOptional.isEmpty()) {
            throw new UsernameNotFoundException("User not found with username: " + username);
        }

        User user = userOptional.get();
        String roleName = getRoleNameWithPrefix(user);
        return new org.springframework.security.core.userdetails.User(
                user.getUsername(),
                user.getPassword(),
                Collections.singletonList(new SimpleGrantedAuthority(roleName))
        );
    }
    public UserDetails loadUserByUsernameAndEmail(String username, String email) throws UsernameNotFoundException {
        // First try to find by username and brandId
        Optional<User> userOptional = userRepository.findByUsernameAndEmail(username, email);
        
        
        if (!userOptional.isPresent()) {
            throw new UsernameNotFoundException("User not found with username: " + username);
        }
        
        User user = userOptional.get();
        String roleName = getRoleNameWithPrefix(user);
        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
                Collections.singletonList(new SimpleGrantedAuthority(roleName)));
    }

    public User save(User user) {
        user.setPassword(bcryptEncoder.encode(user.getPassword()));
        return userRepository.save(user);
    }
    
    /**
     * Helper method to extract role name with proper ROLE_ prefix
     * Ensures consistency with Spring Security and JWT token generation
     */
    private String getRoleNameWithPrefix(User user) {
        if (user == null || user.getRole() == null) {
            return "ROLE_USER"; // Default role
        }
        
        try {
            String roleName = user.getRole().getRoleName();
            if (roleName == null || roleName.trim().isEmpty()) {
                return "ROLE_USER"; // Default role
            }
            
            // Ensure ROLE_ prefix for Spring Security
            if (!roleName.startsWith("ROLE_")) {
                roleName = "ROLE_" + roleName.toUpperCase();
            }
            
            return roleName;
        } catch (Exception e) {
            // In case of lazy-loading issues, default to USER
            return "ROLE_USER";
        }
    }
}

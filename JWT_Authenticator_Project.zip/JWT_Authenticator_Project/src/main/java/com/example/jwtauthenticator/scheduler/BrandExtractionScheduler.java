package com.example.jwtauthenticator.scheduler;

import com.example.jwtauthenticator.dto.BrandExtractionResponse;
import com.example.jwtauthenticator.entity.BrandExtractionJob;
import com.example.jwtauthenticator.entity.Company;
import com.example.jwtauthenticator.repository.BrandExtractionJobRepository;
import com.example.jwtauthenticator.repository.CompanyRepository;
import com.example.jwtauthenticator.service.BrandExtractionService;
import com.example.jwtauthenticator.service.ForwardService;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;

@Component
@RequiredArgsConstructor
@Slf4j
public class BrandExtractionScheduler {

    private final BrandExtractionJobRepository jobRepository;
    private final ForwardService forwardService;
    private final BrandExtractionService brandExtractionService;
    private final CompanyRepository companyRepository;
    private final ObjectMapper objectMapper;
    @Qualifier("brandExtractionTaskScheduler")
    private final TaskScheduler taskScheduler;

    @Value("${brand.enrichment.batch-size:5}")
    private int batchSize;

    @Value("${brand.enrichment.max-attempts:3}")
    private int maxAttempts;

    @Value("${brand.enrichment.delay-ms:30000}")
    private long delayMs;

    // ✅ Prevent concurrent executions 
    private final AtomicBoolean isProcessing = new AtomicBoolean(false);

    /**
     * 🚀 SMART SCHEDULER: Trigger processing after registration 
     * ✅ Only runs when there are actually jobs to process
     * ✅ Self-scheduling: continues processing until queue is empty
     */
    public void triggerProcessingAfterRegistration() {
        log.info("🔄 Brand extraction triggered after registration");
        scheduleNextProcessing(0); // Start immediately
    }

    /**
     * 🔧 ADMIN: Manual trigger for brand extraction processing
     * ✅ Useful for admin operations or manual brand data refresh
     */
    public void manualTrigger() {
        log.info("🔧 Brand extraction manually triggered by admin");
        scheduleNextProcessing(0); // Start immediately
    }

    /**
     * 🔄 SCHEDULE NEXT PROCESSING: Smart delay-based scheduling
     */
    private void scheduleNextProcessing(long delayMs) {
        if (isProcessing.get()) {
            log.debug("⏳ Brand extraction already processing, skipping schedule");
            return;
        }

        log.info("⏰ Scheduling brand extraction in {}ms", delayMs);
        taskScheduler.schedule(this::processQueue, 
            java.time.Instant.now().plusMillis(delayMs));
    }

    /**
     * 🎯 PROCESS QUEUE: Core processing logic (now event-driven)
     * ✅ REMOVED @Scheduled - now triggered dynamically
     */
    @Transactional
    public void processQueue() {
        // ✅ Prevent concurrent executions
        if (!isProcessing.compareAndSet(false, true)) {
            log.debug("⏳ Brand extraction already processing, skipping");
            return;
        }

        try {
            List<BrandExtractionJob> jobs = jobRepository.findByStatusOrderByUpdatedAt(BrandExtractionJob.Status.PENDING);
            if (jobs.isEmpty()) {
                log.info("✅ No pending brand extraction jobs, stopping scheduler");
                return; // ✅ SMART: Stop scheduling when no jobs
            }

            log.info("🔄 Processing {} brand extraction jobs", jobs.size());
            int processed = 0;
            for (BrandExtractionJob job : jobs) {
                if (processed >= batchSize) break;

                try {
                    int updated = jobRepository.markProcessing(job.getId(), BrandExtractionJob.Status.PROCESSING, LocalDateTime.now());
                    if (updated == 0) continue; // skip if concurrently taken

                    ResponseEntity<String> resp = forwardService.forwardSync(job.getUrl());
                    if (!resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null) {
                        fail(job, "External API non-2xx or empty body");
                        continue;
                    }

                    // Get company for brand linking
                    Optional<Company> companyOpt = companyRepository.findByDomainName(job.getDomain());
                    Company company = companyOpt.orElse(null);

                    // Persist brand and assets WITH company linking
                    brandExtractionService.extractAndStoreBrandData(job.getUrl(), resp.getBody(), company);

                    // Update Company from CompanyData and logo URL
                    BrandExtractionResponse dto = objectMapper.readValue(resp.getBody(), BrandExtractionResponse.class);
                    updateCompanyFromExtraction(job.getDomain(), dto);

                    markDone(job);
                    processed++;
                    log.info("✅ Processed brand extraction job for domain: {}", job.getDomain());
                } catch (Exception e) {
                    fail(job, e.getMessage());
                }
            }

            // ✅ SMART: Check if more jobs need processing
            List<BrandExtractionJob> remainingJobs = jobRepository.findByStatusOrderByUpdatedAt(BrandExtractionJob.Status.PENDING);
            if (!remainingJobs.isEmpty()) {
                log.info("⏰ {} more jobs pending, scheduling next processing in {}ms", 
                    remainingJobs.size(), delayMs);
                scheduleNextProcessing(delayMs); // Continue processing after delay
            } else {
                log.info("🎉 All brand extraction jobs completed, scheduler stopped");
            }

        } finally {
            isProcessing.set(false); // ✅ Always release the lock
        }
    }

    private void markDone(BrandExtractionJob job) {
        job.setStatus(BrandExtractionJob.Status.DONE);
        job.setError(null);
        job.setUpdatedAt(LocalDateTime.now());
        jobRepository.save(job);
    }

    private void fail(BrandExtractionJob job, String error) {
        job.setAttempts(job.getAttempts() + 1);
        job.setLastAttemptAt(LocalDateTime.now());
        job.setError(error);
        if (job.getAttempts() >= maxAttempts) {
            job.setStatus(BrandExtractionJob.Status.FAILED);
        } else {
            job.setStatus(BrandExtractionJob.Status.PENDING);
        }
        jobRepository.save(job);
        log.warn("Job {} failed attempt {}: {}", job.getId(), job.getAttempts(), error);
    }

    private void updateCompanyFromExtraction(String domain, BrandExtractionResponse dto) {
        Optional<Company> companyOpt = companyRepository.findByDomainName(domain);
        if (companyOpt.isEmpty()) return;

        Company c = companyOpt.get();
        BrandExtractionResponse.CompanyData company = dto.getCompany();
        if (company != null) {
            if (company.getName() != null && !company.getName().isBlank()) c.setCompanyName(company.getName());
            if (company.getDescription() != null && !company.getDescription().isBlank()) c.setCompanyDescription(company.getDescription());
            if (company.getWebsite() != null && !company.getWebsite().isBlank()) c.setWebsiteUrl(cleanWebsiteUrl(company.getWebsite()));
        }

        String logoUrl = extractLogoUrl(dto);
        if (logoUrl != null && !logoUrl.isBlank()) {
            c.setCompanyLogoUrl(logoUrl);
        }

        // Mark Active after enrichment
        c.setStatus("Active");
        companyRepository.save(c);
    }

    private String extractLogoUrl(BrandExtractionResponse dto) {
        if (dto == null || dto.getLogo() == null) return null;
        var l = dto.getLogo();
        if (isNonEmpty(l.getLogo())) return l.getLogo();
        if (isNonEmpty(l.getLinkedInLogo())) return l.getLinkedInLogo();
        if (isNonEmpty(l.getIcon())) return l.getIcon();
        if (isNonEmpty(l.getBanner())) return l.getBanner();
        return null;
    }

    private boolean isNonEmpty(String s) {
        return s != null && !s.isBlank();
    }

    private String cleanWebsiteUrl(String website) {
        if (website == null) return null;
        String w = website.trim().toLowerCase()
                .replace("https://", "")
                .replace("http://", "");
        if (w.startsWith("www.")) {
            w = w.substring(4);
        }
        if (w.endsWith("/")) {
            w = w.substring(0, w.length() - 1);
        }
        return w;
    }
}
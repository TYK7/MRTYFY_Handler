package com.example.jwtauthenticator.service;

import com.example.jwtauthenticator.dto.BrandExtractionResponse;
import com.example.jwtauthenticator.dto.success.SuccessResponseDTO;
import com.example.jwtauthenticator.entity.User;
import com.example.jwtauthenticator.entity.Company;
import com.example.jwtauthenticator.entity.Brand;
import com.example.jwtauthenticator.repository.UserRepository;
import com.example.jwtauthenticator.repository.BrandRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.jwtauthenticator.repository.CompanyRepository;
import com.example.jwtauthenticator.config.AppConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 🔄 AsyncEnrichmentService: Handles user profile enrichment in background
 * ✅ SOLUTION: Uses @Async with proper @Transactional(propagation = REQUIRES_NEW)
 * ✅ SAFE: Avoids Hibernate LazyInitializationException with fresh queries
 */
@Service
@Slf4j
public class AsyncEnrichmentService {

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private CompanyRepository companyRepository;
    
    @Autowired
    private BrandRepository brandRepository;
    
    @Autowired
    private EmailDomainService emailDomainService;
    
    @Autowired
    private ForwardService forwardService;
    
    @Autowired
    private EmailService emailService;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    @Autowired
    private AppConfig appConfig;
    
    @Autowired
    private com.example.jwtauthenticator.scheduler.BrandExtractionScheduler brandExtractionScheduler;

    /**
     * 🔄 ASYNC: Main enrichment orchestrator
     * ✅ SAFE: Each step runs in separate transaction to avoid session issues
     */
    @Async
    public void performUserEnrichment(String userId, String email) {
        try {
            log.info("🔍 Starting comprehensive async enrichment for user: {} with email: {}", userId, email);
            
            // Step 1: Email domain validation
            performEmailValidation(userId, email);
            
            // Step 2: Company enrichment (if not generic provider)
            performCompanyEnrichment(userId, email);
            
            // Step 3: Send verification email
            sendVerificationEmail(userId);
            
            log.info("✅ Completed comprehensive async enrichment for user: {}", userId);
            
        } catch (Exception e) {
            log.error("💥 Comprehensive async enrichment failed for user: {} with email: {}", userId, email, e);
            handleEnrichmentFailure(userId, email, e.getMessage());
        }
    }

    /**
     * 📧 STEP 1: Email domain validation in separate transaction
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void performEmailValidation(String userId, String email) {
        try {
            log.info("📧 Performing async email validation for user: {} with email: {}", userId, email);
            
            // Call the comprehensive email domain validation
            ResponseEntity<?> validationResult = emailDomainService.checkDomainFromEmail(email);
            
            // Fresh database query to avoid session issues
            Optional<User> userOpt = userRepository.findById(userId);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                
                if (validationResult.getStatusCode().is2xxSuccessful()) {
                    user.setFutureV5("EMAIL_VALIDATION_SUCCESS");
                    
                    // Extract and store constructed URL if available
                    if (validationResult.getBody() instanceof SuccessResponseDTO successResponse) {
                        Map<String, Object> data = successResponse.getData();
                        if (data != null && data.containsKey("constructedUrl")) {
                            user.setFutureI3((String) data.get("constructedUrl"));
                        }
                    }
                    
                    log.info("✅ Email validation successful for user: {}", userId);
                } else {
                    user.setFutureV5("EMAIL_VALIDATION_FAILED");
                    user.setFutureI4("Email domain validation failed during async processing");
                    log.warn("⚠️ Email validation failed for user: {} - Status: {}", userId, validationResult.getStatusCode());
                }
                
                userRepository.save(user);
            }
            
        } catch (Exception e) {
            log.error("💥 Async email validation failed for user: {} with email: {}", userId, email, e);
            // Update status on error
            updateUserOnError(userId, "EMAIL_VALIDATION_ERROR", "Email validation error: " + e.getMessage());
        }
    }

    /**
     * 🏢 STEP 2: Company enrichment in separate transaction
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void performCompanyEnrichment(String userId, String email) {
        try {
            String domain = extractDomainFromEmail(email);
            log.info("🏗️ Performing async company enrichment for user: {} with domain: {}", userId, domain);
            
            // Skip enrichment for generic email providers
            if (isGenericEmailProvider(domain)) {
                log.info("📧 Skipping enrichment for generic email provider: {}", domain);
                updateUserCompanyStatus(userId, "COMPANY_ENRICHMENT_SKIPPED");
                return;
            }
            
            // Fresh query to avoid session issues
            Optional<User> userOpt = userRepository.findById(userId);
            if (!userOpt.isPresent()) {
                log.error("❌ User not found for enrichment: {}", userId);
                return;
            }
            
            User user = userOpt.get();
            
            // ✅ SAFE: Find company by domain instead of lazy loading
            Optional<Company> companyOpt = companyRepository.findByDomainName(domain);
            if (companyOpt.isEmpty()) {
                log.error("❌ No company found for domain: {}", domain);
                user.setFutureI2("COMPANY_ENRICHMENT_NO_COMPANY");
                userRepository.save(user);
                return;
            }
            
            Company company = companyOpt.get();
            
            // Only enrich if company is in "Pending Validation" status
            if (!"Pending Validation".equals(company.getStatus())) {
                log.info("⏭️ Company already processed for domain: {} - Status: {}", domain, company.getStatus());
                user.setFutureI2("COMPANY_ENRICHMENT_ALREADY_PROCESSED");
                userRepository.save(user);
                return;
            }
            
            // Construct URL for ForwardService call
            String constructedUrl = "https://" + domain;
            
            // ✅ HYBRID APPROACH: Use immediate sync (no job creation)
            // This avoids duplication with BrandExtractionScheduler
            ResponseEntity<String> response = forwardService.forwardCompanyImmediateSync(constructedUrl);
            
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                // Use existing createCompanyFromForwardServiceSync method
                Company enrichedCompany = createCompanyFromForwardServiceSync(domain, response.getBody());
                
                if (enrichedCompany != null) {
                    user.setFutureI2("COMPANY_ENRICHMENT_SUCCESS");
                    log.info("✅ Company enrichment successful: {} (ID: {})", 
                            enrichedCompany.getCompanyName(), enrichedCompany.getCompanyId());
                    
                    // ✅ HYBRID: Optionally trigger detailed brand extraction for scheduler
                    scheduleDetailedBrandExtractionIfNeeded(constructedUrl, domain, enrichedCompany);
                    
                } else {
                    user.setFutureI2("COMPANY_ENRICHMENT_PARTIAL");
                    log.warn("⚠️ Company enrichment partially successful for domain: {}", domain);
                }
            } else {
                user.setFutureI2("COMPANY_ENRICHMENT_FAILED");
                log.warn("⚠️ ForwardService failed for domain: {} - Status: {}", domain, response.getStatusCode());
            }
            
            userRepository.save(user);
            
        } catch (Exception e) {
            log.error("💥 Async company enrichment failed for user: {} with email: {}", userId, email, e);
            updateUserOnError(userId, "COMPANY_ENRICHMENT_ERROR", "Company enrichment error: " + e.getMessage());
        }
    }

    /**
     * 📨 STEP 3: Send verification email in separate transaction
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void sendVerificationEmail(String userId) {
        try {
            // Fresh database query to avoid session issues
            Optional<User> userOpt = userRepository.findById(userId);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                
                // Send email regardless of validation status (user account is created)
                String emailValidationStatus = user.getFutureV5();
                boolean emailValidationOk = emailValidationStatus == null || 
                                          "EMAIL_VALIDATION_SUCCESS".equals(emailValidationStatus) ||
                                          !"EMAIL_VALIDATION_ERROR".equals(emailValidationStatus);
                
                if (emailValidationOk) {
                    String baseUrl = appConfig.getApiUrl("");
                    emailService.sendVerificationEmail(
                        user.getEmail(), 
                        user.getUsername(), 
                        user.getVerificationToken(), 
                        baseUrl
                    );
                    log.info("📧 Verification email sent to user: {} at email: {}", userId, user.getEmail());
                } else {
                    log.warn("⚠️ Skipping verification email due to failed email validation for user: {}", userId);
                }
            }
        } catch (Exception e) {
            log.error("💥 Failed to send verification email for user: {}", userId, e);
        }
    }

    /**
     * ⚠️ Handle enrichment failures
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void handleEnrichmentFailure(String userId, String email, String errorMessage) {
        try {
            Optional<User> userOpt = userRepository.findById(userId);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                
                user.setFutureV5("EMAIL_VALIDATION_FAILED");
                user.setFutureI2("COMPANY_ENRICHMENT_FAILED");
                user.setFutureI4("Async enrichment failed: " + errorMessage);
                
                // Update company status
                String domain = extractDomainFromEmail(email);
                Optional<Company> companyOpt = companyRepository.findByDomainName(domain);
                if (companyOpt.isPresent()) {
                    Company company = companyOpt.get();
                    if ("Pending Validation".equals(company.getStatus())) {
                        company.setStatus("Enrichment Failed");
                        company.setCompanyDescription("Enrichment failed but account remains active");
                        company.setUpdatedAt(LocalDateTime.now());
                        companyRepository.save(company);
                    }
                }
                
                userRepository.save(user);
                log.info("⚠️ Updated user {} status after enrichment failure - account remains active", userId);
            }
        } catch (Exception e) {
            log.error("💥 Failed to handle async enrichment failure for user: {}", userId, e);
        }
    }

    
    private void scheduleDetailedBrandExtractionIfNeeded(String url, String domain, Company company) {
        try {
            // Only create jobs for companies that might benefit from detailed brand extraction
            // Skip if it's a very basic domain or if detailed extraction already exists
            Company targetCompany = company;
            if (targetCompany == null) {
                Optional<Company> companyOpt = companyRepository.findByDomainName(domain);
                if (companyOpt.isPresent()) {
                    targetCompany = companyOpt.get();
                }
            }
            
            if (targetCompany != null) {
                
                // Check if we need brand linking - either new company or existing company with unlinked brands
                boolean needsBrandLinking = false;
                String reason = "";
                
                if ("Pending Validation".equals(targetCompany.getStatus()) && 
                    (targetCompany.getCompanyLogoUrl() == null || targetCompany.getCompanyLogoUrl().isEmpty())) {
                    needsBrandLinking = true;
                    reason = "new company needs brand data";
                } else if ("Active".equals(targetCompany.getStatus())) {
                    // Check if there are existing brands for this domain that are not linked to any company
                    String normalizedUrl = url.toLowerCase().trim();
                    if (normalizedUrl.startsWith("http://")) {
                        normalizedUrl = normalizedUrl.substring(7);
                    } else if (normalizedUrl.startsWith("https://")) {
                        normalizedUrl = normalizedUrl.substring(8);
                    }
                    if (normalizedUrl.endsWith("/")) {
                        normalizedUrl = normalizedUrl.substring(0, normalizedUrl.length() - 1);
                    }
                    
                    // Check if there are unlinked brands for this URL
                    Optional<Brand> existingBrand = brandRepository.findByNormalizedWebsite(normalizedUrl);
                    if (existingBrand.isPresent() && existingBrand.get().getCompany() == null) {
                        needsBrandLinking = true;
                        reason = "found unlinked brand for active company";
                        log.info("🔍 Found unlinked brand '{}' (ID: {}) for active company domain: {}", 
                                existingBrand.get().getName(), existingBrand.get().getId(), domain);
                    } else {
                        log.info("✅ No unlinked brands found for active company domain: {}", domain);
                    }
                }
                
                if (needsBrandLinking) {
                    // Create extraction job using original forwardCompanySync
                    log.info("🔄 Scheduling detailed brand extraction for domain: {} (Status: {}) - Reason: {}", 
                            domain, targetCompany.getStatus(), reason);
                    forwardService.forwardCompanySync(url);
                    
                    // ✅ SMART TRIGGER: Activate the intelligent scheduler
                    // Only runs when there are actually jobs to process!
                    brandExtractionScheduler.triggerProcessingAfterRegistration();
                    log.info("✅ Smart brand extraction scheduler triggered for domain: {}", domain);
                }
            }
            
        } catch (Exception e) {
            log.warn("⚠️ Failed to schedule detailed brand extraction for domain: {}", domain, e);
            // Not critical - continue without detailed extraction
        }
    }

    // ==================== HELPER METHODS ====================
    
    private void updateUserOnError(String userId, String v5Status, String errorMessage) {
        try {
            Optional<User> userOpt = userRepository.findById(userId);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                user.setFutureV5(v5Status);
                user.setFutureI4(errorMessage);
                userRepository.save(user);
            }
        } catch (Exception saveEx) {
            log.error("Failed to save error status for user: {}", userId, saveEx);
        }
    }
    
    private void updateUserCompanyStatus(String userId, String i2Status) {
        try {
            Optional<User> userOpt = userRepository.findById(userId);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                user.setFutureI2(i2Status);
                userRepository.save(user);
            }
        } catch (Exception saveEx) {
            log.error("Failed to save company status for user: {}", userId, saveEx);
        }
    }
    
    public String extractDomainFromEmail(String email) {
        if (email == null || !email.contains("@")) {
            return null;
        }
        return email.substring(email.lastIndexOf("@") + 1).toLowerCase();
    }
    
    // ✅ REMOVED DUPLICATE: Use AuthService.GENERIC_EMAIL_PROVIDERS instead
    // This method now delegates to AuthService to avoid duplication
    private boolean isGenericEmailProvider(String domain) {
        // ⚠️ TODO: Refactor to use a shared EmailProviderService or move to utility class
        // For now, maintain comprehensive list here until refactoring
        return domain != null && isInGenericProvidersList(domain.toLowerCase());
    }
    
    /**
     * 📧 COMPREHENSIVE: All known public email providers (synchronized with AuthService)
     * ✅ UPDATED: Added modern providers and missing variants
     */
    private boolean isInGenericProvidersList(String domain) {
        return switch (domain) {
            // Google Services
            case "gmail.com", "googlemail.com" -> true;
            
            // Microsoft Services
            case "outlook.com", "hotmail.com", "live.com", "msn.com" -> true;
            
            // Yahoo Services
            case "yahoo.com", "yahoo.co.uk", "yahoo.ca", "ymail.com", "yahoo.in", "yahoo.de" -> true;
            
            // Apple Services
            case "icloud.com", "me.com", "mac.com" -> true;
            
            // Privacy-Focused Providers
            case "protonmail.com", "proton.me", "tutanota.com", "duck.com" -> true;
            
            // Business Email Providers
            case "zoho.com", "fastmail.com" -> true;
            
            // Legacy Providers
            case "aol.com", "mail.com" -> true;
            
            // Modern Providers
            case "hey.com", "superhuman.com" -> true;
            
            // Temporary/Disposable Email (should be flagged)
            case "temp-mail.org", "10minutemail.com", "guerrillamail.com", "mailinator.com" -> true;
            
            default -> false;
        };
    }
    /**
     * Create company from ForwardService response (SYNC version)
     */
    public Company createCompanyFromForwardServiceSync(String domain, String responseBody) {
        try {
            log.info("🔄 Creating/updating company from ForwardService response for domain: {}", domain);

            BrandExtractionResponse brandResponse = objectMapper.readValue(
                responseBody, BrandExtractionResponse.class
            );
            BrandExtractionResponse.CompanyData companyData = brandResponse.getCompany();

            if (companyData == null) {
                log.warn("⚠️ No company data in ForwardService response for domain: {}", domain);
                return createFallbackCompanyForDomain(domain);
            }

            // Check DB for existing company
            Optional<Company> companyOpt = companyRepository.findByDomainName(domain);

            Company company;
            if (companyOpt.isPresent()) {
                company = companyOpt.get();
                company.setStatus("Active");
                log.info("✏️ Updating existing company for domain: {}", domain);
            } else {
                company = new Company();
                company.setDomainName(domain);
                company.setCreatedAt(LocalDateTime.now());
                log.info("🆕 Creating new company for domain: {}", domain);
            }

            // Map/update fields
            company.setCompanyName(StringUtils.hasText(companyData.getName()) ?
                    companyData.getName() : generateCompanyNameFromDomain(domain));
            company.setCompanyDescription(companyData.getDescription());
            company.setStatus("Active");
            company.setCompanyLogoUrl(extractLogoUrl(brandResponse));
            company.setWebsiteUrl(StringUtils.hasText(companyData.getWebsite()) ?
                    companyData.getWebsite() : "https://" + domain);
            company.setEmailDomains("@" + domain);
            company.setAddressLine1(companyData.getLocation());

            // ✅ Handle headquarters safely
            String headquarters = companyData.getHeadquarters();
            String normalizedHeadquarters = headquarters; // fallback

            if (StringUtils.hasText(headquarters) &&
                headquarters.trim().startsWith("[") &&
                headquarters.trim().endsWith("]")) {
                try {
                    List<String> parts = objectMapper.readValue(headquarters, List.class);
                    normalizedHeadquarters = String.join(", ", parts);
                } catch (Exception e) {
                    log.warn("⚠️ Failed to parse headquarters JSON array: {}", headquarters, e);
                }
            }

            // Extract City + Country properly (limited to varchar(100))
            String[] cityCountry = extractCityAndCountry(normalizedHeadquarters);
            company.setCity(cityCountry[0]);
            company.setCountry(cityCountry[1]);

            company.setUpdatedAt(LocalDateTime.now());

            return companyRepository.save(company);

        } catch (Exception e) {
            log.error("💥 Error creating/updating company from ForwardService response for domain: {}", domain, e);
            return createFallbackCompanyForDomain(domain);
        }
    }
     
    
    /**
     * Generate company name from domain using Java 21 features
     */
    public String generateCompanyNameFromDomain(String domain) {
        String baseDomain = domain.split("\\.")[0]; // Remove TLD
        
        return Arrays.stream(baseDomain.split("-"))
            .map(word -> word.substring(0, 1).toUpperCase() + 
                        word.substring(1).toLowerCase())
            .collect(Collectors.joining(" "));
    }
    
    /**
     * Extract logo URL from brand response
     */
    public String extractLogoUrl(BrandExtractionResponse brandResponse) {
        if (brandResponse.getLogo() == null) return null;
        var l = brandResponse.getLogo();
        if (StringUtils.hasText(l.getLogo())) return l.getLogo();
        if (StringUtils.hasText(l.getLinkedInLogo())) return l.getLinkedInLogo();
        if (StringUtils.hasText(l.getIcon())) return l.getIcon();
        if (StringUtils.hasText(l.getBanner())) return l.getBanner();
        return null;
    }
     /**
     * Create fallback company when ForwardService fails
     */
    private Company createFallbackCompanyForDomain(String domain) {
        log.info("🔄 Creating fallback company for domain: {}", domain);
        
        Company fallbackCompany = Company.builder()
            .companyName(generateCompanyNameFromDomain(domain))
            .domainName(domain)
            .status("Pending")
            .companyDescription("Company profile pending verification")
            .websiteUrl("https://" + domain)
            .emailDomains("@" + domain) // ✅ FIXED: Single string with @ prefix
            .createdAt(LocalDateTime.now())
            .updatedAt(LocalDateTime.now())
            .build();
        
        return companyRepository.save(fallbackCompany);
    }
    
 // Ensure we don’t break varchar(100)
    private String safeTrim(String value, int maxLen) {
        if (value == null) return null;
        return value.length() > maxLen ? value.substring(0, maxLen) : value;
    }

    /**
     * Extracts city and country from a headquarters string.
     * Example:
     *   "Hyderabad, Telangana 500081, IN" -> ["Telangana 500081", "IN"]
     *   "Fremont, CA, US" -> ["CA", "US"]
     *   "JustOneString" -> ["JustOneString", null]
     */
    private String[] extractCityAndCountry(String headquarters) {
        if (!StringUtils.hasText(headquarters)) return new String[]{null, null};

        String[] parts = headquarters.split(",");
        if (parts.length == 1) {
            return new String[]{safeTrim(headquarters.trim(), 100), null};
        }

        String country = parts[parts.length - 1].trim();
        String city = parts[parts.length - 2].trim();

        return new String[]{safeTrim(city, 100), safeTrim(country, 100)};
    }

}
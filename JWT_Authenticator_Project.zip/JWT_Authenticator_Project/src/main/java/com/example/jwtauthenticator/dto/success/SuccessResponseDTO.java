package com.example.jwtauthenticator.dto.success;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * 🎯 STANDARDIZED SUCCESS RESPONSE DTO
 * 
 * Provides consistent success response format across all endpoints
 * Supports different success types with contextual data
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SuccessResponseDTO {
    
    // ==================== BASIC SUCCESS INFO ====================
    
    /**
     * Success flag - always true for success responses
     */
    @Builder.Default
    private boolean success = true;
    
    /**
     * HTTP status code
     */
    private int status;
    
    /**
     * Machine-readable success code for client applications
     * Examples: "EMAIL_VALIDATED", "DOMAIN_ACCESSIBLE", "REGISTRATION_READY"
     */
    private String successCode;
    
    /**
     * Human-readable success message
     */
    private String message;
    
    /**
     * Detailed description or additional information
     */
    private String details;
    
    /**
     * Response timestamp
     */
    @Builder.Default
    private Instant timestamp = Instant.now();
    
    /**
     * Request path that generated this response
     */
    private String path;
    
    /**
     * HTTP method used
     */
    private String method;
    
    /**
     * Unique trace ID for request tracking
     */
    private String traceId;
    
    /**
     * Additional contextual data
     */
    private Map<String, Object> data;
    
    /**
     * Processing metadata
     */
    private Map<String, Object> metadata;
    
    // ==================== FACTORY METHODS ====================
    
    /**
     * Create basic success response
     */
    public static SuccessResponseDTO basic(int status, String successCode, String message, String details) {
        return SuccessResponseDTO.builder()
                .status(status)
                .successCode(successCode)
                .message(message)
                .details(details)
                .build();
    }
    
    /**
     * Create email validation success response
     */
    public static SuccessResponseDTO emailValidated(String email, String domain, Map<String, Object> validationResults) {
        return SuccessResponseDTO.builder()
                .status(200)
                .successCode("EMAIL_VALIDATED")
                .message("Email validation completed successfully")
                .details("Email '" + email + "' has been validated and is ready for registration")
                .data(Map.of(
                    "email", email,
                    "domain", domain,
                    "validationResults", validationResults
                ))
                .build();
    }
    
    /**
     * Create domain accessible success response
     */
    public static SuccessResponseDTO domainAccessible(String domain, String constructedUrl, Map<String, Object> checkResults) {
        return SuccessResponseDTO.builder()
                .status(200)
                .successCode("DOMAIN_ACCESSIBLE")
                .message("Domain validation completed successfully")
                .details("Domain '" + domain + "' is accessible and ready for use")
                .data(Map.of(
                    "domain", domain,
                    "constructedUrl", constructedUrl,
                    "checkResults", checkResults
                ))
                .build();
    }
    
    /**
     * Create registration ready success response
     */
    public static SuccessResponseDTO registrationReady(String email, Map<String, Object> allChecks) {
        // Extract constructedUrl for AuthService compatibility
        Map<String, Object> responseData = new HashMap<>();
        responseData.put("email", email);
        responseData.put("allChecks", allChecks);
        responseData.put("readyForRegistration", true);
        
        // ✅ FIX: Include constructedUrl directly in data for AuthService
        if (allChecks.containsKey("constructedUrl")) {
            responseData.put("constructedUrl", allChecks.get("constructedUrl"));
        }
        
        return SuccessResponseDTO.builder()
                .status(200)
                .successCode("REGISTRATION_READY")
                .message("Email validation completed - ready for registration")
                .details("All validation checks passed successfully")
                .data(responseData)
                .build();
    }
    
    /**
     * Create partial success response (some checks failed but email is still usable)
     */
    public static SuccessResponseDTO partialSuccess(String email, String domain, Map<String, Object> results, String warnings) {
        // Extract constructedUrl for AuthService compatibility
        Map<String, Object> responseData = new HashMap<>();
        responseData.put("email", email);
        responseData.put("domain", domain);
        responseData.put("results", results);
        responseData.put("warnings", warnings);
        
        // ✅ FIX: Include constructedUrl directly in data for AuthService
        if (results.containsKey("constructedUrl")) {
            responseData.put("constructedUrl", results.get("constructedUrl"));
        }
        
        return SuccessResponseDTO.builder()
                .status(200)
                .successCode("PARTIAL_VALIDATION")
                .message("Email validation completed with warnings")
                .details("Email is valid but some optional checks failed: " + warnings)
                .data(responseData)
                .build();
    }
}
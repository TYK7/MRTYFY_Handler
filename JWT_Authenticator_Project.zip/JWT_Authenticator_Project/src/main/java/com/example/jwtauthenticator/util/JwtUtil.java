package com.example.jwtauthenticator.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Component
public class JwtUtil {

    @Value("${jwt.secret:secret}")
    private String secretString;
    
    private SecretKey getSecretKey() {
        return Keys.hmacShaKeyFor(secretString.getBytes(StandardCharsets.UTF_8));
    }

    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    public String extractUserId(String token) {
        return extractClaim(token, claims -> claims.get("id", String.class));
    }
    
    public String extractRole(String token) {
        return extractClaim(token, claims -> claims.get("role", String.class));
    }
    
    // TODO: Remove this method after migration - keeping for backward compatibility
    @Deprecated
    public String extractUserID(String token) {
        return extractUserId(token); // Delegate to the main method
    }
    public Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }
    private Claims extractAllClaims(String token) {
        return Jwts.parser().verifyWith(getSecretKey()).build().parseSignedClaims(token).getPayload();
    }

    public Boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    // Token expiration times in milliseconds
    private static final long ACCESS_TOKEN_EXPIRATION = 1000 * 60 * 60 * 10; // 10 hours
    private static final long REFRESH_TOKEN_EXPIRATION = 1000 * 60 * 60 * 24 * 7; // 7 days
    
    public String generateToken(UserDetails userDetails, String userId, String roleName) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("id", userId); // Use primary key (MRTFY000001) format
        claims.put("role", roleName); // Add role claim
        return createToken(claims, userDetails.getUsername(), ACCESS_TOKEN_EXPIRATION);
    }

    // Overloaded method for backward compatibility
    public String generateToken(UserDetails userDetails, String userId) {
        return generateToken(userDetails, userId, "ROLE_USER"); // Default role
    }

    public String generateRefreshToken(UserDetails userDetails, String userId, String roleName) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("id", userId); // Use primary key (MRTFY000001) format
        claims.put("role", roleName); // Add role claim  
        return createToken(claims, userDetails.getUsername(), REFRESH_TOKEN_EXPIRATION);
    }

    // Overloaded method for backward compatibility
    public String generateRefreshToken(UserDetails userDetails, String userId) {
        return generateRefreshToken(userDetails, userId, "ROLE_USER"); // Default role
    }
    
    public long getAccessTokenExpirationTimeInSeconds() {
        return ACCESS_TOKEN_EXPIRATION / 1000;
    }
    
    public long getRefreshTokenExpirationTimeInSeconds() {
        return REFRESH_TOKEN_EXPIRATION / 1000;
    }

    private String createToken(Map<String, Object> claims, String subject, long expirationTime) {

        return Jwts.builder().claims(claims).subject(subject).issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + expirationTime))
                .signWith(getSecretKey()).compact();
    }

    public Boolean validateToken(String token, UserDetails userDetails) {
        try {
            final String username = extractUsername(token);
            return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
        } catch (io.jsonwebtoken.ExpiredJwtException | io.jsonwebtoken.SignatureException | io.jsonwebtoken.MalformedJwtException | io.jsonwebtoken.UnsupportedJwtException | IllegalArgumentException e) {
            return false;
        }
    }
}

package com.example.jwtauthenticator.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Custom Authentication Entry Point
 * 
 * Handles cases where users try to access protected endpoints without proper authentication.
 * Returns structured JSON error responses instead of default Spring Security error pages.
 */
@Component
@Slf4j
public class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
                         AuthenticationException authException) throws IOException {

        String requestURI = request.getRequestURI();
        String method = request.getMethod();
        String userAgent = request.getHeader("User-Agent");
        String clientIP = getClientIP(request);

        log.warn("🚫 Unauthorized access attempt - URI: {} {}, IP: {}, User-Agent: {}, Error: {}", 
            method, requestURI, clientIP, userAgent, authException.getMessage());

        // Determine error type and message
        String errorType = determineErrorType(authException, request);
        String errorMessage = buildErrorMessage(errorType, requestURI);

        // Build error response
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("error", "Authentication Required");
        errorResponse.put("message", errorMessage);
        errorResponse.put("type", errorType);
        errorResponse.put("status", HttpServletResponse.SC_UNAUTHORIZED);
        errorResponse.put("path", requestURI);
        errorResponse.put("method", method);
        errorResponse.put("timestamp", LocalDateTime.now().toString());
        
        // Add suggestions for resolution
        errorResponse.put("suggestions", getAuthenticationSuggestions(requestURI));

        // Set response properties
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");

        // Add CORS headers for frontend integration
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");

        // Write JSON response
        response.getWriter().write(objectMapper.writeValueAsString(errorResponse));
    }

    /**
     * Determine the specific type of authentication error
     */
    private String determineErrorType(AuthenticationException authException, HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        
        if (authHeader == null) {
            return "MISSING_TOKEN";
        } else if (!authHeader.startsWith("Bearer ")) {
            return "INVALID_TOKEN_FORMAT";
        } else if (authException.getMessage().contains("expired")) {
            return "EXPIRED_TOKEN";
        } else if (authException.getMessage().contains("malformed")) {
            return "MALFORMED_TOKEN";
        } else {
            return "INVALID_TOKEN";
        }
    }

    /**
     * Build appropriate error message based on error type
     */
    private String buildErrorMessage(String errorType, String requestURI) {
        return switch (errorType) {
            case "MISSING_TOKEN" -> 
                "Authentication token is required to access this endpoint. Please include a valid JWT token in the Authorization header.";
            
            case "INVALID_TOKEN_FORMAT" -> 
                "Invalid token format. Please use 'Bearer <token>' format in the Authorization header.";
            
            case "EXPIRED_TOKEN" -> 
                "Your authentication token has expired. Please login again to get a new token.";
            
            case "MALFORMED_TOKEN" -> 
                "The provided token is malformed or corrupted. Please login again to get a valid token.";
            
            case "INVALID_TOKEN" -> 
                "The provided authentication token is invalid. Please login again to get a valid token.";
            
            default -> 
                "Authentication is required to access this endpoint. Please provide a valid JWT token.";
        };
    }

    /**
     * Provide helpful suggestions for resolving authentication issues
     */
    private Map<String, String> getAuthenticationSuggestions(String requestURI) {
        Map<String, String> suggestions = new HashMap<>();
        
        suggestions.put("login", "POST /auth/login - Login with username/password to get JWT token");
        suggestions.put("refresh", "POST /auth/refresh - Use refresh token to get new access token");
        suggestions.put("format", "Authorization header format: 'Bearer <your-jwt-token>'");
        
        if (requestURI.startsWith("/api/external/") || requestURI.startsWith("/api/secure/")) {
            suggestions.put("apiKey", "These endpoints may also accept API key authentication via X-API-KEY header");
        }
        
        suggestions.put("documentation", "Visit /swagger-ui.html for API documentation and authentication details");
        
        return suggestions;
    }

    /**
     * Extract client IP address from request
     */
    private String getClientIP(HttpServletRequest request) {
        String xfHeader = request.getHeader("X-Forwarded-For");
        if (xfHeader != null && !xfHeader.isEmpty() && !"unknown".equalsIgnoreCase(xfHeader)) {
            return xfHeader.split(",")[0].trim();
        }
        
        String xrealIp = request.getHeader("X-Real-IP");
        if (xrealIp != null && !xrealIp.isEmpty() && !"unknown".equalsIgnoreCase(xrealIp)) {
            return xrealIp;
        }
        
        return request.getRemoteAddr();
    }
}
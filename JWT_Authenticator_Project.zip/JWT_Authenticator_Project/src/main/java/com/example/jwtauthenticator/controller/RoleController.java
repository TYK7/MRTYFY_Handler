package com.example.jwtauthenticator.controller;

import com.example.jwtauthenticator.dto.RoleDTO;
import com.example.jwtauthenticator.service.RoleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/roles")
@Tag(name = "Role Management", description = "APIs for managing user roles")
@Slf4j
public class RoleController {

    @Autowired
    private RoleService roleService;

    @Operation(summary = "Get all roles", description = "Retrieve all available roles in the system")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Roles retrieved successfully")
    })
    @GetMapping
    public ResponseEntity<List<RoleDTO>> getAllRoles() {
        List<RoleDTO> roles = roleService.getAllRoles();
        return ResponseEntity.ok(roles);
    }

    @Operation(summary = "Get role by ID", description = "Retrieve a specific role by its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Role found"),
            @ApiResponse(responseCode = "404", description = "Role not found")
    })
    @GetMapping("/{roleId}")
    public ResponseEntity<RoleDTO> getRoleById(@PathVariable Integer roleId) {
        return roleService.getRoleById(roleId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Get role by name", description = "Retrieve a specific role by its name")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Role found"),
            @ApiResponse(responseCode = "404", description = "Role not found")
    })
    @GetMapping("/name/{roleName}")
    public ResponseEntity<RoleDTO> getRoleByName(@PathVariable String roleName) {
        return roleService.getRoleByName(roleName)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Get roles by scope", description = "Retrieve roles filtered by scope")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Roles retrieved successfully")
    })
    @GetMapping("/scope/{scope}")
    public ResponseEntity<List<RoleDTO>> getRolesByScope(@PathVariable String scope) {
        List<RoleDTO> roles = roleService.getRolesByScope(scope);
        return ResponseEntity.ok(roles);
    }

    @Operation(summary = "Get default user role", description = "Retrieve the default role assigned to new users")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Default role found"),
            @ApiResponse(responseCode = "404", description = "Default role not configured")
    })
    @GetMapping("/default")
    public ResponseEntity<RoleDTO> getDefaultUserRole() {
        return roleService.getDefaultUserRole()
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
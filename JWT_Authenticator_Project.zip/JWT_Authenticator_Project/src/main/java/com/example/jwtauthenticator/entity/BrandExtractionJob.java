package com.example.jwtauthenticator.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "brand_extraction_job", indexes = {
        @Index(name = "idx_bej_status_updated", columnList = "status, updatedAt"),
        @Index(name = "idx_bej_url", columnList = "url")
})
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class BrandExtractionJob {

    public enum Status { PENDING, PROCESSING, DONE, FAILED }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 2048)
    private String url;

    @Column(nullable = false, length = 255)
    private String domain;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Status status;

    @Column(nullable = false)
    @Builder.Default
    private int attempts = 0;

    @Column(length = 1000)
    private String error;

    private LocalDateTime lastAttemptAt;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(nullable = false)
    private LocalDateTime updatedAt;
}
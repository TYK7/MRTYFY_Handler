package com.example.jwtauthenticator.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "company")
public class Company {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "companyid")
    private Integer companyId;

    @NotBlank
    @Column(name = "companyname", unique = true, nullable = false)
    private String companyName;

    @Column(name = "companydescription", length = 1000)
    private String companyDescription;

    @Column(name = "status", nullable = false, length = 50)
    private String status = "Active";

    @Column(name = "companylogourl", length = 2048)
    private String companyLogoUrl;

    @NotBlank
    @Column(name = "domainname", unique = true, nullable = false)
    private String domainName;

    @Column(name = "emaildomains", columnDefinition = "text")
    private String emailDomains;

    @Column(name = "websiteurl", length = 2048)
    private String websiteUrl;

    @Column(name = "contactemail")
    private String contactEmail;

    @Column(name = "phonenumber", length = 50)
    private String phoneNumber;

    @Column(name = "addressline1")
    private String addressLine1;

    @Column(name = "addressline2")
    private String addressLine2;

    @Column(name = "city", length = 100)
    private String city;

    @Column(name = "stateprovince", length = 100)
    private String stateProvince;

    @Column(name = "postalcode", length = 20)
    private String postalCode;

    @Column(name = "country", length = 100)
    private String country;

    @Column(name = "createdat", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updatedat")
    private LocalDateTime updatedAt;

    // Note: Removed bidirectional relationship to avoid circular references
    // Users can be fetched via UserRepository.findByCompany(company) if needed

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (status == null || status.trim().isEmpty()) {
            status = "Active";
        }
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    public Integer getId() {
        return companyId;
    }
}
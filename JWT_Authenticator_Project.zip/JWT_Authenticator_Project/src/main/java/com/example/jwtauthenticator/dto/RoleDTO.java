package com.example.jwtauthenticator.dto;

import com.example.jwtauthenticator.entity.Role;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RoleDTO {
    private Integer roleId;
    private String roleName;
    private Integer roleNumber;
    private String roleDescription;
    private String scope;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static RoleDTO fromEntity(Role role) {
        if (role == null) return null;
        
        return RoleDTO.builder()
                .roleId(role.getRoleId())
                .roleName(role.getRoleName())
                .roleNumber(role.getRoleNumber())
                .roleDescription(role.getRoleDescription())
                .scope(role.getScope())
                .createdAt(role.getCreatedAt())
                .updatedAt(role.getUpdatedAt())
                .build();
    }
}
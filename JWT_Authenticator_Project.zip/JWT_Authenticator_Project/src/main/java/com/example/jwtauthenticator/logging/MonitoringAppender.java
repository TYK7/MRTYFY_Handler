package com.example.jwtauthenticator.logging;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.AppenderBase;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import com.example.jwtauthenticator.monitoring.LoggingMonitoringService;

/**
 * Custom Logback appender that integrates with LoggingMonitoringService
 * to track error rates and logging metrics.
 * 
 * @author BrandSnap API Team
 * @since 1.0.0
 */
@Component
public class MonitoringAppender extends AppenderBase<ILoggingEvent> implements ApplicationContextAware {

    private ApplicationContext applicationContext;
    private LoggingMonitoringService monitoringService;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @Override
    public void start() {
        if (applicationContext != null) {
            try {
                monitoringService = applicationContext.getBean(LoggingMonitoringService.class);
            } catch (Exception e) {
                // Monitoring service not available, continue without it
                addWarn("LoggingMonitoringService not available: " + e.getMessage());
            }
        }
        super.start();
    }

    @Override
    protected void append(ILoggingEvent event) {
        if (monitoringService == null) {
            return;
        }

        try {
            switch (event.getLevel().levelInt) {
                case ch.qos.logback.classic.Level.ERROR_INT:
                    monitoringService.incrementErrorCount();
                    break;
                case ch.qos.logback.classic.Level.WARN_INT:
                    monitoringService.incrementWarningCount();
                    break;
                default:
                    // For INFO, DEBUG, TRACE - count as requests if from controller
                    if (event.getLoggerName().contains("controller")) {
                        monitoringService.incrementRequestCount();
                    }
                    break;
            }
        } catch (Exception e) {
            // Don't let monitoring failures affect logging
            addWarn("Error in monitoring appender: " + e.getMessage());
        }
    }
}
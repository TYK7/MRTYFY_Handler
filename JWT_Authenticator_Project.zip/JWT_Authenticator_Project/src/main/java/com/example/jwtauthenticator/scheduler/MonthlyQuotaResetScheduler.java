package com.example.jwtauthenticator.scheduler;
import com.example.jwtauthenticator.entity.ApiKeyMonthlyUsage;
import com.example.jwtauthenticator.entity.QuotaResetAudit;
import com.example.jwtauthenticator.entity.User;
import com.example.jwtauthenticator.enums.UserPlan;
import com.example.jwtauthenticator.repository.ApiKeyMonthlyUsageRepository;
import com.example.jwtauthenticator.repository.ApiKeyUsageStatsRepository;
import com.example.jwtauthenticator.repository.QuotaResetAuditRepository;
import com.example.jwtauthenticator.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Enterprise-grade monthly quota reset scheduler
 * Resets all API key quotas on the 1st of every month at 00:01 UTC
 * 
 * Features:
 * - Calendar month reset (industry standard)
 * - Batch processing for performance
 * - Comprehensive error handling
 * - Detailed logging and monitoring
 * - Atomic operations to prevent data corruption
 * 
 * @author BrandSnap API Team
 * @version 1.0
 * @since Java 21
 */
@Service
@RequiredArgsConstructor
@Slf4j
@ConditionalOnProperty(name = "app.quota.reset.enabled", havingValue = "true", matchIfMissing = true)
public class MonthlyQuotaResetScheduler {
    
    private final ApiKeyMonthlyUsageRepository usageRepository;
    private final ApiKeyUsageStatsRepository usageStatsRepository;
    private final QuotaResetAuditRepository auditRepository;
    private final UserRepository userRepository;
    
    private static final int DEFAULT_BATCH_SIZE = 100;
    private static final int PROGRESS_LOG_INTERVAL = 500;
    
    /**
     * Scheduled monthly reset - runs at 00:01 UTC on 1st of every month
     * Cron expression: "0 1 0 1 * ?" = second minute hour day-of-month month day-of-week
     */
    @Scheduled(cron = "${app.quota.reset.cron:0 1 0 1 * ?}")
    @Transactional
    public void executeMonthlyQuotaReset() {
        LocalDateTime startTime = LocalDateTime.now();
        log.info("🔄 STARTING Monthly Quota Reset - {}", startTime);
        
        try {
            QuotaResetResult result = performBulkQuotaReset();
            
            LocalDateTime endTime = LocalDateTime.now();
            long durationMs = java.time.Duration.between(startTime, endTime).toMillis();
            
            log.info("✅ COMPLETED Monthly Quota Reset - Duration: {}ms, Success: {}, Failed: {}, Skipped: {}", 
                    durationMs, result.getSuccessCount(), result.getFailureCount(), result.getSkippedCount());
            
            // Log summary statistics
            logResetSummary(result, durationMs);
            
        } catch (Exception e) {
            log.error("❌ FAILED Monthly Quota Reset: {}", e.getMessage(), e);
            // Could add notification service here for admin alerts
            throw e; // Re-throw to trigger monitoring alerts
        }
    }
    
    /**
     * Manual reset endpoint for admin operations
     * Can be called through admin controller
     */
    @Transactional
    public QuotaResetResult performManualQuotaReset() {
        log.warn("⚠️ MANUAL quota reset triggered by administrator");
        
        // Create special audit log for manual execution
        LocalDate currentDate = LocalDate.now(ZoneId.of("UTC"));
        LocalDateTime executionStartTime = LocalDateTime.now(ZoneId.of("UTC"));
        String newMonthYear = currentDate.format(DateTimeFormatter.ofPattern("yyyy-MM"));
        
        QuotaResetAudit auditLog = QuotaResetAudit.builder()
                .resetDate(currentDate)
                .monthYear(newMonthYear)
                .executionStatus(QuotaResetAudit.ExecutionStatus.STARTED)
                .triggeredBy("MANUAL_ADMIN")
                .notes("Manual quota reset triggered by administrator")
                .build();
        auditRepository.save(auditLog);
        
        try {
            QuotaResetResult result = performBulkQuotaReset();
            
            // Update audit log with results
            long executionDurationMs = System.currentTimeMillis() - executionStartTime.atZone(ZoneId.of("UTC")).toInstant().toEpochMilli();
            auditLog.setRecordsProcessed(result.getTotalProcessed());
            auditLog.setRecordsSuccessful(result.getSuccessCount());
            auditLog.setRecordsFailed(result.getFailureCount());
            auditLog.setRecordsSkipped(result.getSkippedCount());
            auditLog.setExecutionDurationMs(executionDurationMs);
            auditLog.setExecutionStatus(result.hasFailures() ? 
                    QuotaResetAudit.ExecutionStatus.COMPLETED_WITH_ERRORS : 
                    QuotaResetAudit.ExecutionStatus.COMPLETED);
            auditRepository.save(auditLog);
            
            return result;
            
        } catch (Exception e) {
            // Update audit log for failure
            long executionDurationMs = System.currentTimeMillis() - executionStartTime.atZone(ZoneId.of("UTC")).toInstant().toEpochMilli();
            auditLog.setExecutionStatus(QuotaResetAudit.ExecutionStatus.FAILED);
            auditLog.setExecutionDurationMs(executionDurationMs);
            auditLog.setErrorMessage(e.getMessage());
            auditRepository.save(auditLog);
            
            throw e;
        }
    }
    
    /**
     * Core bulk reset logic
     * Processes all API key usage records that need monthly reset
     */
    private QuotaResetResult performBulkQuotaReset() {
        // Use UTC timezone to match cron execution
        LocalDate currentDate = LocalDate.now(ZoneId.of("UTC"));
        LocalDateTime executionStartTime = LocalDateTime.now(ZoneId.of("UTC"));
        
        // Use previous month's last day to catch records that need reset
        LocalDate resetDate = currentDate.withDayOfMonth(1).minusDays(1);
        String newMonthYear = currentDate.format(DateTimeFormatter.ofPattern("yyyy-MM"));
        String previousMonthYear = resetDate.format(DateTimeFormatter.ofPattern("yyyy-MM"));
        
        log.info("📅 Reset execution date: {}, Reset cutoff date: {}, Target month: {}, Previous month: {}", 
                currentDate, resetDate, newMonthYear, previousMonthYear);
        
        // 🎯 CREATE AUDIT LOG ENTRY
        QuotaResetAudit auditLog = QuotaResetAudit.builder()
                .resetDate(currentDate)
                .monthYear(newMonthYear)
                .executionStatus(QuotaResetAudit.ExecutionStatus.STARTED)
                .triggeredBy("SCHEDULER")
                .notes("Automated monthly quota reset - " + 
                       (usageRepository.count() == 0 ? "FIRST RESET (empty database)" : "Regular monthly reset"))
                .build();
        auditLog = auditRepository.save(auditLog);
        
        // Find all usage records that need reset using calendar month logic
        List<ApiKeyMonthlyUsage> usagesToReset = usageRepository.findAllNeedingReset(resetDate);
        
        log.info("📊 Found {} API key usage records requiring reset for month {}", 
                usagesToReset.size(), newMonthYear);
        
        // 🧹 CLEANUP OLD API KEY USAGE STATS (keep only last 3 months for performance)
        cleanupOldUsageStats(currentDate, auditLog);
        
        if (usagesToReset.isEmpty()) {
            log.info("✨ No records need reset - all quotas are already current for month {}", newMonthYear);
            
            // Update audit log for empty result
            auditLog.setRecordsProcessed(0);
            auditLog.setRecordsSuccessful(0);
            auditLog.setRecordsFailed(0);
            auditLog.setExecutionStatus(QuotaResetAudit.ExecutionStatus.COMPLETED);
            auditLog.setExecutionDurationMs(System.currentTimeMillis() - executionStartTime.atZone(ZoneId.of("UTC")).toInstant().toEpochMilli());
            auditRepository.save(auditLog);
            
            return new QuotaResetResult(0, 0, 0, newMonthYear);
        }
        
        AtomicInteger successCount = new AtomicInteger(0);
        AtomicInteger failureCount = new AtomicInteger(0);
        AtomicInteger skippedCount = new AtomicInteger(0);
        
        // Update audit log to IN_PROGRESS
        auditLog.setRecordsProcessed(usagesToReset.size());
        auditLog.setExecutionStatus(QuotaResetAudit.ExecutionStatus.IN_PROGRESS);
        auditRepository.save(auditLog);
        
        // Process in batches for better performance and memory management
        int batchSize = Integer.parseInt(System.getProperty("app.quota.reset.batch-size", String.valueOf(DEFAULT_BATCH_SIZE)));
        
        for (int i = 0; i < usagesToReset.size(); i += batchSize) {
            int endIndex = Math.min(i + batchSize, usagesToReset.size());
            List<ApiKeyMonthlyUsage> batch = usagesToReset.subList(i, endIndex);
            
            processBatch(batch, resetDate, newMonthYear, successCount, failureCount, skippedCount);
            
            // Log progress for large datasets
            if ((i + batchSize) % PROGRESS_LOG_INTERVAL == 0 || endIndex == usagesToReset.size()) {
                log.info("📈 Progress: {}/{} records processed (Success: {}, Failed: {}, Skipped: {})", 
                        Math.min(i + batchSize, usagesToReset.size()), usagesToReset.size(),
                        successCount.get(), failureCount.get(), skippedCount.get());
            }
        }
        
        // 🎯 FINALIZE AUDIT LOG
        long executionDurationMs = System.currentTimeMillis() - executionStartTime.atZone(ZoneId.of("UTC")).toInstant().toEpochMilli();
        auditLog.setRecordsSuccessful(successCount.get());
        auditLog.setRecordsFailed(failureCount.get());
        auditLog.setRecordsSkipped(skippedCount.get());
        auditLog.setExecutionDurationMs(executionDurationMs);
        auditLog.setExecutionStatus(failureCount.get() > 0 ? 
                QuotaResetAudit.ExecutionStatus.COMPLETED_WITH_ERRORS : 
                QuotaResetAudit.ExecutionStatus.COMPLETED);
        auditRepository.save(auditLog);
        
        return new QuotaResetResult(successCount.get(), failureCount.get(), skippedCount.get(), newMonthYear);
    }
    
    /**
     * Process a batch of usage records
     * Uses individual transaction handling for each record to prevent batch failures
     */
    private void processBatch(List<ApiKeyMonthlyUsage> batch, LocalDate resetDate, String newMonthYear,
                             AtomicInteger successCount, AtomicInteger failureCount, AtomicInteger skippedCount) {
        
        for (ApiKeyMonthlyUsage usage : batch) {
            try {
                if (resetSingleUsageRecord(usage, resetDate, newMonthYear)) {
                    successCount.incrementAndGet();
                } else {
                    skippedCount.incrementAndGet();
                }
            } catch (Exception e) {
                failureCount.incrementAndGet();
                log.error("❌ Failed to reset usage for API key {}: {}", usage.getApiKeyId(), e.getMessage());
                // Continue processing other records even if one fails
            }
        }
    }
    
    /**
     * Reset a single usage record
     * Handles the complete reset logic including user plan validation
     */
    @Transactional
    protected boolean resetSingleUsageRecord(ApiKeyMonthlyUsage usage, LocalDate resetDate, String newMonthYear) {
        // Find the user to get current plan information
        Optional<User> userOpt = userRepository.findById(usage.getUserId());
        if (userOpt.isEmpty()) {
            log.warn("⚠️ User not found for usage record: {}, skipping reset", usage.getUserId());
            return false;
        }
        
        User user = userOpt.get();
        UserPlan plan = user.getPlan();
        
        // Store old values for logging
        int oldTotalCalls = usage.getTotalCalls() != null ? usage.getTotalCalls() : 0;
        int oldQuotaLimit = usage.getQuotaLimit() != null ? usage.getQuotaLimit() : 0;
        String oldMonthYear = usage.getMonthYear();
        
        // Calculate new limits based on current user plan
        int newQuotaLimit = plan.getMonthlyApiCalls();
        int newGraceLimit = plan.getGraceLimit("api_calls");
        
        LocalDate actualResetDate = LocalDate.now(java.time.ZoneId.of("UTC")).withDayOfMonth(1);
        
        // 🎯 PRESERVE HISTORICAL DATA: Check if new month record already exists
        Optional<ApiKeyMonthlyUsage> existingNewMonth = usageRepository
            .findByApiKeyIdAndMonthYear(usage.getApiKeyId(), newMonthYear);
        
        if (existingNewMonth.isPresent()) {
            // ✅ New month record already exists (maybe from previous partial reset)
            // Just ensure it's properly reset
            ApiKeyMonthlyUsage newMonthUsage = existingNewMonth.get();
            newMonthUsage.resetForNewMonth(actualResetDate, newQuotaLimit, newGraceLimit);
            usageRepository.save(newMonthUsage);
            
            log.debug("✅ Updated existing new month record for API key {}: 0/{} calls ({}) | User: {} | Plan: {}", 
                    usage.getApiKeyId(), newQuotaLimit, newMonthYear, usage.getUserId(), plan.name());
            
        } else {
            // 🎯 CREATE BRAND NEW record for new month, preserving old record
            ApiKeyMonthlyUsage newMonthUsage = ApiKeyMonthlyUsage.builder()
                .apiKeyId(usage.getApiKeyId())
                .userId(usage.getUserId())
                .monthYear(newMonthYear)           // 🔑 KEY DIFFERENTIATOR: "2025-02"
                .totalCalls(0)
                .successfulCalls(0)
                .failedCalls(0)
                .quotaExceededCalls(0)
                .lastResetDate(actualResetDate)
                .quotaLimit(newQuotaLimit)
                .graceLimit(newGraceLimit)
                .build();
            
            usageRepository.save(newMonthUsage);  // Creates NEW record with NEW UUID
            
            log.debug("✅ Created new month record for API key {}: {}/{} calls ({}) → 0/{} calls ({}) | User: {} | Plan: {} | ✨ PRESERVED HISTORICAL DATA", 
                    usage.getApiKeyId(), oldTotalCalls, oldQuotaLimit, oldMonthYear,
                    newQuotaLimit, newMonthYear, usage.getUserId(), plan.name());
        }
        
        // ✨ OLD RECORD WITH month_year="2025-01" REMAINS COMPLETELY UNTOUCHED!
        log.debug("📊 Historical record preserved: API key {} month {} with {} calls", 
                usage.getApiKeyId(), oldMonthYear, oldTotalCalls);
        
        return true;
    }
    
    /**
     * 🧹 CLEANUP: Remove old API key usage stats to maintain database performance
     * Keeps only the last 3 months of data (current + 2 previous months)
     */
    private void cleanupOldUsageStats(LocalDate currentDate, QuotaResetAudit auditLog) {
        try {
            // Calculate cutoff date - keep last 3 months
            LocalDate cutoffDate = currentDate.minusMonths(3).withDayOfMonth(1);
            LocalDateTime cutoffDateTime = cutoffDate.atStartOfDay();
            
            log.info("🧹 Cleaning up usage stats older than {}", cutoffDate);
            
            // Count records to be deleted for logging
            long recordsToDelete = usageStatsRepository.countByWindowStartBefore(cutoffDateTime);
            
            if (recordsToDelete > 0) {
                // Delete old records
                long deletedRecords = usageStatsRepository.deleteByWindowStartBefore(cutoffDateTime);
                
                log.info("🧹 Cleaned up {} old usage stats records (older than {})", deletedRecords, cutoffDate);
                
                // Add note to audit log
                String existingNotes = auditLog.getNotes() != null ? auditLog.getNotes() : "";
                auditLog.setNotes(existingNotes + " | Cleaned up " + deletedRecords + " old usage stats records");
                
            } else {
                log.info("🧹 No old usage stats records found to cleanup");
            }
            
        } catch (Exception e) {
            log.error("❌ Failed to cleanup old usage stats: {}", e.getMessage(), e);
            // Don't fail the entire reset process due to cleanup issues
        }
    }
    
    /**
     * Log comprehensive reset summary for monitoring and audit purposes
     */
    private void logResetSummary(QuotaResetResult result, long durationMs) {
        log.info("📋 RESET SUMMARY for month {}:", result.getMonthYear());
        log.info("   ✅ Successfully reset: {} API keys", result.getSuccessCount());
        log.info("   ❌ Failed to reset: {} API keys", result.getFailureCount());
        log.info("   ⏭️ Skipped (user not found): {} API keys", result.getSkippedCount());
        log.info("   📊 Total processed: {} API keys", result.getTotalProcessed());
        log.info("   ⏱️ Processing duration: {}ms (avg: {:.2f}ms per record)", 
                durationMs, result.getTotalProcessed() > 0 ? (double) durationMs / result.getTotalProcessed() : 0);
        
        // Performance metrics
        if (result.getTotalProcessed() > 0) {
            double recordsPerSecond = (result.getTotalProcessed() * 1000.0) / durationMs;
            log.info("   🚀 Processing rate: {:.1f} records/second", recordsPerSecond);
        }
        
        // Alert on failures
        if (result.getFailureCount() > 0) {
            double failureRate = (result.getFailureCount() * 100.0) / result.getTotalProcessed();
            log.warn("⚠️ Failure rate: {:.2f}% - Review logs for specific errors", failureRate);
        }
    }
    
    /**
     * Result class for reset operations
     * Provides comprehensive information about the reset process
     */
    public static class QuotaResetResult {
        private final int successCount;
        private final int failureCount;
        private final int skippedCount;
        private final String monthYear;
        
        public QuotaResetResult(int successCount, int failureCount, int skippedCount, String monthYear) {
            this.successCount = successCount;
            this.failureCount = failureCount;
            this.skippedCount = skippedCount;
            this.monthYear = monthYear;
        }
        
        // Getters
        public int getSuccessCount() { return successCount; }
        public int getFailureCount() { return failureCount; }
        public int getSkippedCount() { return skippedCount; }
        public String getMonthYear() { return monthYear; }
        public int getTotalProcessed() { return successCount + failureCount + skippedCount; }
        
        public boolean hasFailures() { return failureCount > 0; }
        public boolean isSuccessful() { return failureCount == 0 && getTotalProcessed() > 0; }
        public double getSuccessRate() {
            int total = getTotalProcessed();
            return total > 0 ? (successCount * 100.0) / total : 100.0;
        }
        
        @Override
        public String toString() {
            return String.format("QuotaResetResult{month='%s', success=%d, failed=%d, skipped=%d, total=%d, successRate=%.1f%%}",
                    monthYear, successCount, failureCount, skippedCount, getTotalProcessed(), getSuccessRate());
        }
    }
}
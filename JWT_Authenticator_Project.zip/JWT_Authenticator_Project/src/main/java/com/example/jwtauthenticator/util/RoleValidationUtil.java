package com.example.jwtauthenticator.util;

import com.example.jwtauthenticator.enums.UserRole;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Role Validation Utility
 * 
 * Provides utility methods for validating hierarchical role access
 * and checking permissions in the role-based authentication system.
 */
@Component
public class RoleValidationUtil {

    /**
     * Check if the current user has the required role or higher
     * Uses hierarchical role checking
     * 
     * @param requiredRole The minimum role required
     * @return true if user has access, false otherwise
     */
    public boolean hasRoleOrHigher(UserRole requiredRole) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            return false;
        }

        return hasRoleOrHigher(authentication, requiredRole);
    }

    /**
     * Check if the given authentication has the required role or higher
     * 
     * @param authentication Spring Security authentication object
     * @param requiredRole The minimum role required
     * @return true if user has access, false otherwise
     */
    public boolean hasRoleOrHigher(Authentication authentication, UserRole requiredRole) {
        if (authentication == null || requiredRole == null) {
            return false;
        }

        Set<String> userRoles = authentication.getAuthorities().stream()
            .map(GrantedAuthority::getAuthority)
            .collect(Collectors.toSet());

        // Check if user has any role that can access the required role
        for (UserRole userRole : UserRole.values()) {
            if (userRoles.contains(userRole.getRoleName()) && userRole.hasAccess(requiredRole)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get the highest role of the current user
     * 
     * @return The highest UserRole, or null if not authenticated
     */
    public UserRole getCurrentUserHighestRole() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            return null;
        }

        return getHighestRole(authentication);
    }

    /**
     * Get the highest role from authentication object
     * 
     * @param authentication Spring Security authentication
     * @return The highest UserRole, or null if no valid roles found
     */
    public UserRole getHighestRole(Authentication authentication) {
        if (authentication == null) {
            return null;
        }

        Set<String> userRoles = authentication.getAuthorities().stream()
            .map(GrantedAuthority::getAuthority)
            .collect(Collectors.toSet());

        UserRole highestRole = null;
        int highestRoleNumber = 0;

        for (UserRole role : UserRole.values()) {
            if (userRoles.contains(role.getRoleName()) && role.getRoleNumber() > highestRoleNumber) {
                highestRole = role;
                highestRoleNumber = role.getRoleNumber();
            }
        }

        return highestRole;
    }

    /**
     * Get all roles of the current user
     * 
     * @return Set of UserRole objects the user has
     */
    public Set<UserRole> getCurrentUserRoles() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            return Set.of();
        }

        return getUserRoles(authentication);
    }

    /**
     * Get all roles from authentication object
     * 
     * @param authentication Spring Security authentication
     * @return Set of UserRole objects
     */
    public Set<UserRole> getUserRoles(Authentication authentication) {
        if (authentication == null) {
            return Set.of();
        }

        Set<String> roleNames = authentication.getAuthorities().stream()
            .map(GrantedAuthority::getAuthority)
            .collect(Collectors.toSet());

        return UserRole.getAllRoleNames().stream()
            .filter(roleNames::contains)
            .map(UserRole::fromRoleName)
            .collect(Collectors.toSet());
    }

    /**
     * Check if current user is admin or higher (ADMIN or SUPER_ADMIN)
     */
    public boolean isAdminOrHigher() {
        return hasRoleOrHigher(UserRole.ADMIN);
    }

    /**
     * Check if current user is super admin
     */
    public boolean isSuperAdmin() {
        return hasExactRole(UserRole.SUPER_ADMIN);
    }

    /**
     * Check if current user is regular user (USER role only)
     */
    public boolean isRegularUser() {
        return hasExactRole(UserRole.USER);
    }

    /**
     * Check if user has exactly the specified role (not inherited)
     * 
     * @param role The exact role to check for
     * @return true if user has exactly this role
     */
    public boolean hasExactRole(UserRole role) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            return false;
        }

        return authentication.getAuthorities().stream()
            .map(GrantedAuthority::getAuthority)
            .anyMatch(auth -> auth.equals(role.getRoleName()));
    }

    /**
     * Check if user has any of the specified roles or higher
     * 
     * @param requiredRoles Collection of roles, user needs at least one
     * @return true if user has any of the required roles or higher
     */
    public boolean hasAnyRoleOrHigher(Collection<UserRole> requiredRoles) {
        if (requiredRoles == null || requiredRoles.isEmpty()) {
            return false;
        }

        return requiredRoles.stream()
            .anyMatch(this::hasRoleOrHigher);
    }

    /**
     * Check if user can access a specific endpoint based on role requirements
     * 
     * @param endpointPath The endpoint path (e.g., "/api/admin/users")
     * @return true if user has access to this endpoint
     */
    public boolean canAccessEndpoint(String endpointPath) {
        if (endpointPath == null) {
            return false;
        }

        // Define endpoint-to-role mappings
        if (endpointPath.startsWith("/api/super/")) {
            return hasRoleOrHigher(UserRole.SUPER_ADMIN);
        } else if (endpointPath.startsWith("/api/admin/") || 
                   endpointPath.startsWith("/api/roles/") ||
                   endpointPath.startsWith("/api/companies/") ||
                   endpointPath.startsWith("/api/dashboard/admin/")) {
            return hasRoleOrHigher(UserRole.ADMIN);
        } else if (endpointPath.startsWith("/api/users/") ||
                   endpointPath.startsWith("/api/v1/api-keys/") ||
                   endpointPath.startsWith("/api/dashboard/user/")) {
            return hasRoleOrHigher(UserRole.USER);
        }

        // Default: require authentication but no specific role
        return getCurrentUserHighestRole() != null;
    }

    /**
     * Get role hierarchy information for debugging
     * 
     * @return String representation of current user's role hierarchy
     */
    public String getCurrentUserRoleHierarchy() {
        UserRole highestRole = getCurrentUserHighestRole();
        if (highestRole == null) {
            return "No authenticated user";
        }

        StringBuilder hierarchy = new StringBuilder();
        hierarchy.append("Current User Role Hierarchy:\n");
        hierarchy.append("Primary Role: ").append(highestRole.getHierarchyString()).append("\n");
        hierarchy.append("Inherited Access: ");
        
        Set<UserRole> inheritedRoles = highestRole.getAllInheritedRoles();
        hierarchy.append(inheritedRoles.stream()
            .map(UserRole::getRoleName)
            .collect(Collectors.joining(", ")));

        return hierarchy.toString();
    }

    /**
     * Validate role name format and existence
     * 
     * @param roleName The role name to validate
     * @return ValidationResult with success/failure and message
     */
    public ValidationResult validateRoleName(String roleName) {
        if (roleName == null || roleName.trim().isEmpty()) {
            return new ValidationResult(false, "Role name cannot be null or empty");
        }

        if (!UserRole.isValidRoleName(roleName)) {
            return new ValidationResult(false, "Invalid role name: " + roleName + 
                ". Valid roles are: " + String.join(", ", UserRole.getAllRoleNames()));
        }

        return new ValidationResult(true, "Role name is valid");
    }

    /**
     * Validation result record
     */
    public record ValidationResult(boolean isValid, String message) {}
}
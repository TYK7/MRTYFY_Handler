package com.example.jwtauthenticator.repository.projection;

public interface BrandCompanyProjection {
    String getName();
    String getWebsite();
    String getDescription();
    String getIndustry();
    String getLocation();
    String getFounded();
    String getCompanyType();
    String getEmployees();
    String getLogo();
    String getHeadquarters();
}
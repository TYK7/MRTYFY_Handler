package com.example.jwtauthenticator.service;

import com.example.jwtauthenticator.config.ForwardConfig;
import com.example.jwtauthenticator.dto.BrandExtractionResponse;
import com.example.jwtauthenticator.entity.Brand;
import com.example.jwtauthenticator.entity.BrandAsset;
import com.example.jwtauthenticator.entity.BrandColor;
import com.example.jwtauthenticator.entity.BrandFont;
import com.example.jwtauthenticator.entity.BrandImage;
import com.example.jwtauthenticator.entity.BrandSocialLink;
import com.example.jwtauthenticator.repository.BrandRepository;
import com.example.jwtauthenticator.repository.projection.BrandCompanyProjection;
import com.example.jwtauthenticator.repository.BrandExtractionJobRepository;
import com.example.jwtauthenticator.repository.CompanyRepository;
import com.example.jwtauthenticator.util.DomainExtractionUtil;
import com.example.jwtauthenticator.entity.Company;
import com.example.jwtauthenticator.entity.BrandExtractionJob;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.benmanes.caffeine.cache.Cache;
import com.example.jwtauthenticator.entity.ApiKey; // PHASE 3 INTEGRATION
import jakarta.servlet.http.HttpServletRequest; // PHASE 3 INTEGRATION
import jakarta.servlet.http.HttpServletResponse; // PHASE 3 INTEGRATION
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ForwardService {

    private static final String EXTERNAL_API ="http://202.65.155.117:3000/api/extract-company-details";
    private final WebClient forwardWebClient;
    private final Cache<String, String> forwardCache;
    private final ForwardConfig forwardConfig;
    private final BrandExtractionService brandExtractionService;
    private final BrandRepository brandRepository;
    private final ObjectMapper objectMapper;
    private final RivoFetchLoggingService rivoFetchLoggingService; // PHASE 3 INTEGRATION

    // Added for fast sync company path
    private final BrandExtractionJobRepository brandExtractionJobRepository;
    private final CompanyRepository companyRepository;
    private final DomainExtractionUtil domainExtractionUtil;
    
    @Value("${app.brand-extraction.enabled:true}")
    private boolean brandExtractionEnabled;

    /**
     * ✅ SYNC VERSION: Synchronous forward method for testing (no async issues)
     */
    @org.springframework.transaction.annotation.Transactional(readOnly = true)
    public ResponseEntity<String> forwardSync(String url) {
        // First check if the URL exists in the brands table
        Optional<Brand> existingBrand = findBrandByUrl(url);
        if (existingBrand.isPresent()) {
            log.info("Found cached brand data for URL: {}", url);
            try {
                Brand brand = existingBrand.get();
                // Initialize collections within transaction to avoid LazyInitializationException
                initializeBrandCollections(brand);
                
                BrandExtractionResponse response = convertBrandToExtractionResponse(brand);
                String jsonResponse = objectMapper.writeValueAsString(response);
                return ResponseEntity.ok(jsonResponse);
            } catch (Exception e) {
                log.error("Error converting brand data to response for URL: {}", url, e);
                // Fall through to external API call on error
            }
        }

        // Check in-memory cache as fallback
        String cached = forwardCache.getIfPresent(url);
        if (cached != null) {
            log.info("Found in-memory cached data for URL: {}", url);
            return ResponseEntity.ok(cached);
        }

        // Call external API
        log.info("Calling external API for URL: {}", url);
        try {
            String response = forwardWebClient.post()
                .uri(EXTERNAL_API)
                .bodyValue(Map.of("url", url))
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(forwardConfig.getTimeoutSeconds()))
                .block(); // Synchronous call

            if (response != null) {
                // Cache the response
                forwardCache.put(url, response);
                
                // Trigger brand extraction if enabled
                if (brandExtractionEnabled) {
                    try {
                        triggerBrandExtraction(url, response);
                    } catch (Exception e) {
                        log.warn("Brand extraction failed for URL: {} - {}", url, e.getMessage());
                    }
                }
                
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.status(500).body("{\"error\":\"No response from external API\"}");
            }
        } catch (Exception e) {
            log.error("Forwarding error", e);
            return ResponseEntity.status(500).body("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }

    public CompletableFuture<ResponseEntity<String>> forward(String url) {
        // First check if the URL exists in the brands table
        Optional<Brand> existingBrand = findBrandByUrl(url);
        if (existingBrand.isPresent()) {
            log.info("Found cached brand data for URL: {}", url);
            try {
                BrandExtractionResponse response = convertBrandToExtractionResponse(existingBrand.get());
                String jsonResponse = objectMapper.writeValueAsString(response);
                return CompletableFuture.completedFuture(ResponseEntity.ok(jsonResponse));
            } catch (Exception e) {
                log.error("Error converting brand data to response for URL: {}", url, e);
                // Fall through to external API call on error
            }
        }

        // Check in-memory cache as fallback
        String cached = forwardCache.getIfPresent(url);
        if (cached != null) {
            log.info("Found in-memory cached data for URL: {}", url);
            // Even for cached responses, trigger brand extraction if enabled
            if (brandExtractionEnabled) {
                triggerBrandExtraction(url, cached);
            }
            return CompletableFuture.completedFuture(ResponseEntity.ok(cached));
        }

        // Make external API call only if not found in database or cache
        log.info("Making external API call for URL: {}", url);
        return forwardWebClient.post()
                .uri(EXTERNAL_API)
                .bodyValue(Collections.singletonMap("url", url))
                .exchangeToMono(resp -> resp.bodyToMono(String.class)
                        .map(body -> ResponseEntity.status(resp.statusCode()).body(body)))
                .timeout(Duration.ofSeconds(forwardConfig.getTimeoutSeconds()))
                .doOnError(e -> log.error("Forwarding error", e))
                .toFuture()
                .thenApply(response -> {
                    if (response.getStatusCode().is2xxSuccessful()) {
                        forwardCache.put(url, response.getBody());
                        
                        // Trigger brand data extraction for successful responses
                        if (brandExtractionEnabled) {
                            triggerBrandExtraction(url, response.getBody());
                        }
                    }
                    return response;
                });
    }
    
    /**
     * 🚀 PHASE 3: Forward with RivoFetch Logging Integration
     * 
     * Enhanced forward method that includes comprehensive RivoFetch logging
     * for analytics and monitoring purposes.
     * 
     * @param url URL to forward to external API
     * @param request HTTP servlet request for context extraction
     * @param response HTTP servlet response for logging
     * @param apiKey API key used for the request
     * @return CompletableFuture with response entity
     */
    public CompletableFuture<ResponseEntity<String>> forwardWithLogging(
            String url, 
            HttpServletRequest request, 
            HttpServletResponse response, 
            ApiKey apiKey) {
        
        long startTime = System.currentTimeMillis();
        
        // First check if the URL exists in the brands table
        Optional<Brand> existingBrand = findBrandByUrl(url);
        if (existingBrand.isPresent()) {
            log.info("Found cached brand data for URL: {}", url);
            try {
                BrandExtractionResponse brandResponse = convertBrandToExtractionResponse(existingBrand.get());
                String jsonResponse = objectMapper.writeValueAsString(brandResponse);
                
                // Log successful cached response (DATABASE_HIT) - SYNCHRONOUS to ensure logging
                boolean logged = rivoFetchLoggingService.logSuccessfulRivoFetchSync(
                        request, response, apiKey, startTime, jsonResponse, "DATABASE_HIT", url);
                if (!logged) {
                    log.warn("⚠️ Failed to log DATABASE_HIT for URL: {}", url);
                }
                
                return CompletableFuture.completedFuture(ResponseEntity.ok(jsonResponse));
            } catch (Exception e) {
                log.error("Error converting brand data to response for URL: {}", url, e);
                
                // Log the error - SYNCHRONOUS to ensure logging
                boolean logged = rivoFetchLoggingService.logFailedRivoFetchSync(
                        request, apiKey, startTime, 
                        "Brand data conversion error: " + e.getMessage(), 500, url);
                if (!logged) {
                    log.warn("⚠️ Failed to log brand conversion error for URL: {}", url);
                }
                
                // Fall through to external API call on error
            }
        }

        // Check in-memory cache as fallback
        String cached = forwardCache.getIfPresent(url);
        if (cached != null) {
            log.info("Found in-memory cached data for URL: {}", url);
            
            // Log successful cached response (MEMORY_HIT) - SYNCHRONOUS to ensure logging
            boolean logged = rivoFetchLoggingService.logSuccessfulRivoFetchSync(
                    request, response, apiKey, startTime, cached, "MEMORY_HIT", url);
            if (!logged) {
                log.warn("⚠️ Failed to log MEMORY_HIT for URL: {}", url);
            }
            
            // Even for cached responses, trigger brand extraction if enabled
            if (brandExtractionEnabled) {
                triggerBrandExtraction(url, cached);
            }
            return CompletableFuture.completedFuture(ResponseEntity.ok(cached));
        }

        // Make external API call only if not found in database or cache
        log.info("Making external API call for URL: {}", url);
        return forwardWebClient.post()
                .uri(EXTERNAL_API)
                .bodyValue(Collections.singletonMap("url", url))
                .exchangeToMono(resp -> resp.bodyToMono(String.class)
                        .map(body -> ResponseEntity.status(resp.statusCode()).body(body)))
                .timeout(Duration.ofSeconds(forwardConfig.getTimeoutSeconds()))
                .doOnError(e -> {
                    log.error("Forwarding error for URL: {}", url, e);
                    
                    // Log the error - SYNCHRONOUS to ensure logging
                    boolean logged = rivoFetchLoggingService.logFailedRivoFetchSync(
                            request, apiKey, startTime, 
                            "External API error: " + e.getMessage(), 500, url);
                    if (!logged) {
                        log.warn("⚠️ Failed to log external API error for URL: {}", url);
                    }
                })
                .toFuture()
                .thenApply(forwardResponse -> {
                    if (forwardResponse.getStatusCode().is2xxSuccessful()) {
                        // Cache successful response
                        forwardCache.put(url, forwardResponse.getBody());
                        
                        // Log successful response (MISS - external API call) - SYNCHRONOUS to ensure logging
                        boolean logged = rivoFetchLoggingService.logSuccessfulRivoFetchSync(
                                request, response, apiKey, startTime, forwardResponse.getBody(), "MISS", url);
                        if (!logged) {
                            log.warn("⚠️ Failed to log MISS for URL: {}", url);
                        }
                        
                        // Trigger brand data extraction for successful responses
                        if (brandExtractionEnabled) {
                            triggerBrandExtraction(url, forwardResponse.getBody());
                        }
                    } else {
                        // Log failed response - SYNCHRONOUS to ensure logging
                        boolean logged = rivoFetchLoggingService.logFailedRivoFetchSync(
                                request, apiKey, startTime, 
                                "External API returned status: " + forwardResponse.getStatusCode(),
                                forwardResponse.getStatusCode().value(), url);
                        if (!logged) {
                            log.warn("⚠️ Failed to log failed response for URL: {}", url);
                        }
                    }
                    return forwardResponse;
                })
                .exceptionally(throwable -> {
                    log.error("Exception in forward operation for URL: {}", url, throwable);
                    
                    // Log the exception - SYNCHRONOUS to ensure logging
                    boolean logged = rivoFetchLoggingService.logFailedRivoFetchSync(
                            request, apiKey, startTime, 
                            "Forward operation exception: " + throwable.getMessage(), 500, url);
                    if (!logged) {
                        log.warn("⚠️ Failed to log exception for URL: {}", url);
                    }
                    
                    // Return error response
                    return ResponseEntity.status(500).body("Internal server error");
                });
    }
    
    /**
     * 🚀 PHASE 3: Forward with RivoFetch Logging for Public Requests
     */
    public CompletableFuture<ResponseEntity<String>> forwardWithPublicLogging(
            String url, 
            HttpServletRequest request, 
            HttpServletResponse response) {
        
        long startTime = System.currentTimeMillis();
        
        // First check if the URL exists in the brands table
        Optional<Brand> existingBrand = findBrandByUrl(url);
        if (existingBrand.isPresent()) {
            log.info("Found cached brand data for URL: {}", url);
            try {
                BrandExtractionResponse brandResponse = convertBrandToExtractionResponse(existingBrand.get());
                String jsonResponse = objectMapper.writeValueAsString(brandResponse);
                
                // Log successful cached response (DATABASE_HIT)
                rivoFetchLoggingService.logSuccessfulPublicRivoFetchAsync(
                        request, response, startTime, jsonResponse, "DATABASE_HIT", url);
                
                return CompletableFuture.completedFuture(ResponseEntity.ok(jsonResponse));
            } catch (Exception e) {
                log.error("Error converting brand data to response for URL: {}", url, e);
                
                // Log the error
                rivoFetchLoggingService.logFailedPublicRivoFetchAsync(
                        request, startTime, 
                        "Brand data conversion error: " + e.getMessage(), 500, url);
                
                // Fall through to external API call on error
            }
        }

        // Check in-memory cache as fallback
        String cached = forwardCache.getIfPresent(url);
        if (cached != null) {
            log.info("Found in-memory cached data for URL: {}", url);
            
            // Log successful cached response (MEMORY_HIT)
            rivoFetchLoggingService.logSuccessfulPublicRivoFetchAsync(
                    request, response, startTime, cached, "MEMORY_HIT", url);
            
            // Even for cached responses, trigger brand extraction if enabled
            if (brandExtractionEnabled) {
                triggerBrandExtraction(url, cached);
            }
            return CompletableFuture.completedFuture(ResponseEntity.ok(cached));
        }

        // Make external API call only if not found in database or cache
        log.info("Making external API call for URL: {}", url);
        return forwardWebClient.post()
                .uri(EXTERNAL_API)
                .bodyValue(Collections.singletonMap("url", url))
                .exchangeToMono(resp -> resp.bodyToMono(String.class)
                        .map(body -> ResponseEntity.status(resp.statusCode()).body(body)))
                .timeout(Duration.ofSeconds(forwardConfig.getTimeoutSeconds()))
                .doOnError(e -> {
                    log.error("Forwarding error for URL: {}", url, e);
                    
                    // Log the error asynchronously
                    rivoFetchLoggingService.logFailedPublicRivoFetchAsync(
                            request, startTime, 
                            "External API error: " + e.getMessage(), 500, url);
                })
                .toFuture()
                .thenApply(forwardResponse -> {
                    if (forwardResponse.getStatusCode().is2xxSuccessful()) {
                        // Cache successful response
                        forwardCache.put(url, forwardResponse.getBody());
                        
                        // Log successful response (MISS - external API call)
                        rivoFetchLoggingService.logSuccessfulPublicRivoFetchAsync(
                                request, response, startTime, forwardResponse.getBody(), "MISS", url);
                        
                        // Trigger brand data extraction for successful responses
                        if (brandExtractionEnabled) {
                            triggerBrandExtraction(url, forwardResponse.getBody());
                        }
                    } else {
                        // Log failed response
                        rivoFetchLoggingService.logFailedPublicRivoFetchAsync(
                                request, startTime, 
                                "External API returned status: " + forwardResponse.getStatusCode(),
                                forwardResponse.getStatusCode().value(), url);
                    }
                    return forwardResponse;
                })
                .exceptionally(throwable -> {
                    log.error("Exception in forward operation for URL: {}", url, throwable);
                    
                    // Log the exception
                    rivoFetchLoggingService.logFailedPublicRivoFetchAsync(
                            request, startTime, 
                            "Forward operation exception: " + throwable.getMessage(), 500, url);
                    
                    // Return error response
                    return ResponseEntity.status(500).body("Internal server error");
                });
    }
    
    /**
     * Trigger brand data extraction asynchronously
     */
    private void triggerBrandExtraction(String url, String apiResponse) {
        try {
            log.info("Triggering brand extraction for URL: {}", url);
            Brand brand = brandExtractionService.extractAndStoreBrandData(url, apiResponse);
            log.info("Brand extraction completed for: {} (Brand ID: {})", url, brand.getId());
        } catch (Exception e) {
            log.error("Brand extraction failed for URL: {}", url, e);
            // Don't throw the exception as this shouldn't affect the main forward operation
        }
    }

    /**
     * Convert Brand entity data to BrandExtractionResponse format
     */
    private BrandExtractionResponse convertBrandToExtractionResponse(Brand brand) {
        BrandExtractionResponse response = new BrandExtractionResponse();
        
        // Set basic message
        response.setMessage(brand.getExtractionMessage() != null ? 
            brand.getExtractionMessage() : "Data retrieved from cache");
        
        // Set company data
        BrandExtractionResponse.CompanyData companyData = new BrandExtractionResponse.CompanyData();
        companyData.setName(brand.getName());
        companyData.setDescription(brand.getDescription());
        companyData.setIndustry(brand.getIndustry());
        companyData.setLocation(brand.getLocation());
        companyData.setFounded(brand.getFounded());
        companyData.setCompanyType(brand.getCompanyType());
        companyData.setEmployees(brand.getEmployees());
        companyData.setWebsite(brand.getWebsite());
        
        // Set new fields with smart mapping
        companyData.setCompanySize(brand.getEmployees());
        companyData.setHeadquarters(brand.getLocation());
        companyData.setType(brand.getCompanyType());
        
        // Parse JSON fields back to lists for performance
        try {
            if (brand.getSpecialties() != null && !brand.getSpecialties().trim().isEmpty()) {
                List<String> specialties = objectMapper.readValue(brand.getSpecialties(), 
                    new TypeReference<List<String>>() {});
                companyData.setSpecialties(specialties);
            }
            if (brand.getLocations() != null && !brand.getLocations().trim().isEmpty()) {
                List<String> locations = objectMapper.readValue(brand.getLocations(), 
                    new TypeReference<List<String>>() {});
                companyData.setLocations(locations);
            }
        } catch (Exception e) {
            log.warn("Failed to deserialize specialties/locations for brand: {}", brand.getName(), e);
        }
        
        // Convert social links
        Map<String, String> socialLinks = new HashMap<>();
        for (BrandSocialLink socialLink : brand.getSocialLinks()) {
            if (socialLink.getUrl() != null && !socialLink.getUrl().isEmpty()) {
                socialLinks.put(socialLink.getPlatform().toString().toLowerCase(), socialLink.getUrl());
            }
            if (socialLink.getExtractionError() != null && 
                socialLink.getPlatform() == BrandSocialLink.Platform.LINKEDIN) {
                companyData.setLinkedInError(socialLink.getExtractionError());
            }
        }
        companyData.setSocialLinks(socialLinks);
        response.setCompany(companyData);
        
        // Set logo data from assets
        BrandExtractionResponse.LogoData logoData = new BrandExtractionResponse.LogoData();
        for (BrandAsset asset : brand.getAssets()) {
            switch (asset.getAssetType()) {
                case LOGO:
                    logoData.setLogo(asset.getOriginalUrl());
                    break;
                case SYMBOL:
                    logoData.setSymbol(asset.getOriginalUrl());
                    break;
                case ICON:
                    logoData.setIcon(asset.getOriginalUrl());
                    break;
                case BANNER:
                    logoData.setBanner(asset.getOriginalUrl());
                    break;
                case LINKEDIN_BANNER:
                    logoData.setLinkedInBanner(asset.getOriginalUrl());
                    break;
                case LINKEDIN_LOGO:
                    logoData.setLinkedInLogo(asset.getOriginalUrl());
                    break;
                default:
                    break;
            }
        }
        response.setLogo(logoData);
        
        // Set colors
        List<BrandExtractionResponse.ColorData> colors = brand.getColors().stream()
            .map(this::convertBrandColorToColorData)
            .collect(Collectors.toList());
        response.setColors(colors);
        
        // Set fonts
        List<BrandExtractionResponse.FontData> fonts = brand.getFonts().stream()
            .map(this::convertBrandFontToFontData)
            .collect(Collectors.toList());
        response.setFonts(fonts);
        
        // Set images
        List<BrandExtractionResponse.ImageData> images = brand.getImages().stream()
            .map(this::convertBrandImageToImageData)
            .collect(Collectors.toList());
        response.setImages(images);
        
        // Set performance data
        BrandExtractionResponse.PerformanceData performanceData = new BrandExtractionResponse.PerformanceData();
        performanceData.setExtractionTimeSeconds(brand.getExtractionTimeSeconds());
        performanceData.setTimestamp(brand.getLastExtractionTimestamp());
        response.setPerformance(performanceData);
        
        return response;
    }
    
    private BrandExtractionResponse.ColorData convertBrandColorToColorData(BrandColor brandColor) {
        BrandExtractionResponse.ColorData colorData = new BrandExtractionResponse.ColorData();
        colorData.setHex(brandColor.getHexCode());
        colorData.setRgb(brandColor.getRgbValue());
        colorData.setBrightness(brandColor.getBrightness());
        colorData.setName(brandColor.getColorName());
        return colorData;
    }
    
    private BrandExtractionResponse.FontData convertBrandFontToFontData(BrandFont brandFont) {
        BrandExtractionResponse.FontData fontData = new BrandExtractionResponse.FontData();
        fontData.setName(brandFont.getFontName());
        fontData.setType(brandFont.getFontType());
        fontData.setStack(brandFont.getFontStack());
        return fontData;
    }
    
    private BrandExtractionResponse.ImageData convertBrandImageToImageData(BrandImage brandImage) {
        BrandExtractionResponse.ImageData imageData = new BrandExtractionResponse.ImageData();
        imageData.setSrc(brandImage.getSourceUrl());
        imageData.setAlt(brandImage.getAltText());
        return imageData;
    }

    /**
     * Find brand by URL with improved matching logic
     */
    private Optional<Brand> findBrandByUrl(String url) {
        // Try exact match first
        Optional<Brand> exactMatch = brandRepository.findByWebsite(url);
        if (exactMatch.isPresent()) {
            return exactMatch;
        }
        
        // Try normalized URL matching using database query
        Optional<Brand> normalizedMatch = brandRepository.findByNormalizedWebsite(url);
        if (normalizedMatch.isPresent()) {
            return normalizedMatch;
        }
        
        // Try domain-based matching for better URL variations handling
        String domain = extractDomainFromUrl(url);
        if (domain != null) {
            Optional<Brand> domainMatch = brandRepository.findByDomainMatch(domain);
            if (domainMatch.isPresent()) {
                return domainMatch;
            }
            
            // Fallback to contains search
            List<Brand> containsMatches = brandRepository.findByWebsiteContaining(domain);
            if (!containsMatches.isEmpty()) {
                return Optional.of(containsMatches.get(0)); // Return the first match
            }
        }
        
        return Optional.empty();
    }
    
    /**
     * Extract domain from URL for flexible matching
     */
    private String extractDomainFromUrl(String url) {
        if (url == null || url.trim().isEmpty()) {
            return null;
        }
        
        try {
            // Remove protocol
            String cleanUrl = url.toLowerCase()
                    .replace("https://", "")
                    .replace("http://", "")
                    .replace("www.", "");
            
            // Remove trailing slash and path
            int slashIndex = cleanUrl.indexOf('/');
            if (slashIndex > 0) {
                cleanUrl = cleanUrl.substring(0, slashIndex);
            } else if (cleanUrl.endsWith("/")) {
                cleanUrl = cleanUrl.substring(0, cleanUrl.length() - 1);
            }
            
            return cleanUrl;
        } catch (Exception e) {
            log.warn("Failed to extract domain from URL: {}", url, e);
            return null;
        }
    }

    /**
     * Initialize brand collections within transaction to avoid LazyInitializationException
     */
    private void initializeBrandCollections(Brand brand) {
        try {
            // Force initialization of collections within the transaction
            if (brand.getSocialLinks() != null) brand.getSocialLinks().size();
            if (brand.getAssets() != null) brand.getAssets().size();
            if (brand.getColors() != null) brand.getColors().size();
            if (brand.getFonts() != null) brand.getFonts().size();
            if (brand.getImages() != null) brand.getImages().size();
            log.debug("Successfully initialized brand collections for: {}", brand.getName());
        } catch (Exception e) {
            log.warn("Failed to initialize some collections for brand: {} - {}", brand.getName(), e.getMessage());
            // Continue anyway - the defensive checks in convertBrandToExtractionResponse will handle nulls
        }
    }

    public ForwardConfig getForwardConfig() {
        return forwardConfig;
    }

     private String[] extractCityAndCountry(String headquarters) {
        if (!StringUtils.hasText(headquarters)) return new String[]{null, null};

        String[] parts = headquarters.split(",");
        if (parts.length == 1) {
            return new String[]{safeTrim(headquarters.trim(), 100), null};
        }

        String country = parts[parts.length - 1].trim();
        String city = parts[parts.length - 2].trim();

        return new String[]{safeTrim(city, 100), safeTrim(country, 100)};
    }
     // Ensure we don’t break varchar(100)
    private String safeTrim(String value, int maxLen) {
        if (value == null) return null;
        return value.length() > maxLen ? value.substring(0, maxLen) : value;
    }
    // ===== NEW: Fast synchronous company path (projection + queue) =====
    @org.springframework.transaction.annotation.Transactional
    public ResponseEntity<String> forwardCompanySync(String url) {
        try {
            // Extract domain for company lookup
            String normalizedUrl = cleanWebsiteUrl(url);
            String domain = extractMainDomainSafe(normalizedUrl);
            
            // 1) Try minimal projection from Brand (fast)
            Optional<BrandCompanyProjection> pOpt = brandRepository.findCompanyProjectionByNormalizedWebsite(url);
            if (pOpt.isPresent()) {
                // ✅ FIXED: Check if brand has company_id and link it if missing
                Optional<Brand> fullBrand = findBrandByUrl(url);
                log.info("🔍 DEBUG: Found brand projection for URL: {}, fullBrand present: {}", url, fullBrand.isPresent());
                
                if (fullBrand.isPresent()) {
                    Brand brand = fullBrand.get();
                    Company existingCompany = brand.getCompany();
                    log.info("🔍 DEBUG: Brand '{}' (ID: {}) has company: {}", 
                            brand.getName(), brand.getId(), 
                            existingCompany != null ? existingCompany.getCompanyId() : "NULL");
                    
                    if (existingCompany == null) {
                        log.info("🔗 Found existing brand without company_id, linking to company for domain: {}", domain);
                        
                        // Convert brand data back to API response format for proper company creation
                        BrandExtractionResponse brandResponse = convertBrandToExtractionResponse(brand);
                        // String brandResponseJson = objectMapper.writeValueAsString(brandResponse);
                        
                        // Create proper company record with full details from brand data
                        Company company = createCompanyFromBrandData(domain, brandResponse);
                        
                        // Link brand to company
                        brand.setCompany(company);
                        brandRepository.save(brand);
                        
                        log.info("✅ Successfully linked brand '{}' (ID: {}) to company '{}' (ID: {}) with full details", 
                                brand.getName(), brand.getId(), company.getCompanyName(), company.getCompanyId());
                    }
                }
                
                BrandCompanyProjection p = pOpt.get();
                BrandExtractionResponse resp = new BrandExtractionResponse();
                BrandExtractionResponse.CompanyData c = new BrandExtractionResponse.CompanyData();
                
                c.setName(p.getName());
                c.setWebsite(p.getWebsite());
                c.setDescription(p.getDescription());
                c.setIndustry(p.getIndustry());
                c.setLocation(p.getLocation());
                c.setFounded(p.getFounded());
                c.setCompanyType(p.getCompanyType());
                c.setEmployees(p.getEmployees());
                c.setHeadquarters(p.getHeadquarters());
                resp.setCompany(c);
                BrandExtractionResponse.LogoData logoData = new  BrandExtractionResponse.LogoData();
                logoData.setIcon(p.getLogo());
                return ResponseEntity.ok(objectMapper.writeValueAsString(resp));
            }

            // 2) Not found: upsert placeholder Company and enqueue job

            Company company = companyRepository.findByDomainName(domain)
                    .orElseGet(() -> {
                        Company c = Company.builder()
                                .companyName(domain)
                                .companyDescription("Processing…")
                                .status("Pending")
                                .domainName(domain)
                                .emailDomains("@" + domain)
                                .websiteUrl(normalizedUrl)
                                .build();
                        return companyRepository.save(c);
                    });

            // Deduplicate pending/processing
            var existing = brandExtractionJobRepository.findTopByUrlAndStatusIn(
                    normalizedUrl,
                    java.util.List.of(BrandExtractionJob.Status.PENDING, BrandExtractionJob.Status.PROCESSING)
            );
            if (existing.isEmpty()) {
                BrandExtractionJob job = BrandExtractionJob.builder()
                        .url(normalizedUrl)
                        .domain(domain)
                        .status(BrandExtractionJob.Status.PENDING)
                        .attempts(0)
                        .build();
                brandExtractionJobRepository.save(job);
            }

            // Return minimal response immediately
            BrandExtractionResponse resp = new BrandExtractionResponse();
            BrandExtractionResponse.CompanyData c = new BrandExtractionResponse.CompanyData();
            c.setName(company.getCompanyName());
            c.setWebsite(company.getWebsiteUrl());
            c.setDescription(company.getCompanyDescription());
            resp.setCompany(c);
            return ResponseEntity.ok(objectMapper.writeValueAsString(resp));
        } catch (Exception e) {
            log.error("forwardCompanySync failed for URL: {}", url, e);
            return ResponseEntity.status(500).body("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }

    /**
     * 🚀 HYBRID APPROACH: Immediate sync enrichment without creating jobs
     * ✅ Used by AsyncEnrichmentService for fast user registration
     * ✅ Does NOT create BrandExtractionJobs (avoids duplication with scheduler)
     */
    @org.springframework.transaction.annotation.Transactional
    public ResponseEntity<String> forwardCompanyImmediateSync(String url) {
        try {
            log.info("🔍 Performing immediate company sync for URL: {}", url);
            
            // Extract domain for company lookup
            String normalizedUrl = cleanWebsiteUrl(url);
            String domain = extractMainDomainSafe(normalizedUrl);
            
            // 1) Try minimal projection from Brand (fast)
            Optional<BrandCompanyProjection> pOpt = brandRepository.findCompanyProjectionByNormalizedWebsite(url);
            if (pOpt.isPresent()) {
                log.info("✅ Found existing brand data for URL: {}", url);
                
                // ✅ CRITICAL FIX: Check if brand has company_id and link it if missing
                Optional<Brand> fullBrand = findBrandByUrl(url);
                if (fullBrand.isPresent()) {
                    Brand brand = fullBrand.get();
                    Company existingCompany = brand.getCompany();
                    log.info("🔍 DEBUG: Brand '{}' (ID: {}) has company: {}", 
                            brand.getName(), brand.getId(), 
                            existingCompany != null ? existingCompany.getCompanyId() : "NULL");
                    
                    if (existingCompany == null) {
                        log.info("🔗 Found existing brand without company_id, linking to company for domain: {}", domain);
                        
                        // Convert brand data back to API response format for proper company creation
                        BrandExtractionResponse brandResponse = convertBrandToExtractionResponse(brand);
                        
                        // Create proper company record with full details from brand data
                        Company company = createCompanyFromBrandData(domain, brandResponse);
                        
                        // Link brand to company
                        brand.setCompany(company);
                        brandRepository.save(brand);
                        
                        log.info("✅ Successfully linked brand '{}' (ID: {}) to company '{}' (ID: {}) with full details", 
                                brand.getName(), brand.getId(), company.getCompanyName(), company.getCompanyId());
                    }
                }
                
                BrandCompanyProjection p = pOpt.get();
                BrandExtractionResponse resp = new BrandExtractionResponse();
                BrandExtractionResponse.CompanyData c = new BrandExtractionResponse.CompanyData();
                
                c.setName(p.getName());
                c.setWebsite(p.getWebsite());
                c.setDescription(p.getDescription());
                c.setIndustry(p.getIndustry());
                c.setLocation(p.getLocation());
                c.setFounded(p.getFounded());
                c.setCompanyType(p.getCompanyType());
                c.setEmployees(p.getEmployees());
                c.setHeadquarters(p.getHeadquarters());
                resp.setCompany(c);
                BrandExtractionResponse.LogoData logoData = new BrandExtractionResponse.LogoData();
                logoData.setIcon(p.getLogo());
                resp.setLogo(logoData);
                return ResponseEntity.ok(objectMapper.writeValueAsString(resp));
            }

            // 2) Not found in Brand table: Create basic company placeholder

            // Create or update basic company info without brand extraction
            Company company = companyRepository.findByDomainName(domain)
                    .orElseGet(() -> {
                        Company c = Company.builder()
                                .companyName(domain)
                                .companyDescription("Company information will be enriched shortly")
                                .status("Pending Validation")
                                .domainName(domain)
                                .emailDomains("@" + domain)
                                .websiteUrl(normalizedUrl)
                                .build();
                        return companyRepository.save(c);
                    });

            // ✅ KEY DIFFERENCE: Do NOT create BrandExtractionJob here
            // Let the scheduler handle brand extraction separately
            
            // Return basic company response
            BrandExtractionResponse resp = new BrandExtractionResponse();
            BrandExtractionResponse.CompanyData c = new BrandExtractionResponse.CompanyData();
            c.setName(company.getCompanyName());
            c.setWebsite(company.getWebsiteUrl());
            c.setDescription(company.getCompanyDescription());
            resp.setCompany(c);
            
            log.info("✅ Created basic company placeholder for domain: {}", domain);
            return ResponseEntity.ok(objectMapper.writeValueAsString(resp));
            
        } catch (Exception e) {
            log.error("💥 forwardCompanyImmediateSync failed for URL: {}", url, e);
            return ResponseEntity.status(500).body("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }

    private String cleanWebsiteUrl(String website) {
        if (website == null) return null;
        String w = website.trim().toLowerCase()
                .replace("https://", "")
                .replace("http://", "");
        if (w.startsWith("www.")) w = w.substring(4);
        int slashIndex = w.indexOf('/');
        if (slashIndex > 0) {
            w = w.substring(0, slashIndex);
        }
        if (w.endsWith("/")) w = w.substring(0, w.length() - 1);
        return w;
    }

    private String extractMainDomainSafe(String normalizedUrl) {
        try {
            return domainExtractionUtil.extractMainDomain(normalizedUrl);
        } catch (Exception e) {
            return normalizedUrl; // fallback
        }
    }
    
    /**
     * Create company from brand data with full details
     */
    private Company createCompanyFromBrandData(String domain, BrandExtractionResponse brandResponse) {
        try {
            log.info("🔄 Creating/updating company from brand data for domain: {}", domain);

            BrandExtractionResponse.CompanyData companyData = brandResponse.getCompany();
            if (companyData == null) {
                log.warn("⚠️ No company data in brand response for domain: {}", domain);
                return createFallbackCompanyForDomain(domain);
            }

            // Check DB for existing company
            Optional<Company> companyOpt = companyRepository.findByDomainName(domain);

            Company company;
            if (companyOpt.isPresent()) {
                company = companyOpt.get();
                company.setStatus("Active");
                log.info("✏️ Updating existing company for domain: {}", domain);
            } else {
                company = new Company();
                company.setDomainName(domain);
                company.setCreatedAt(java.time.LocalDateTime.now());
                log.info("🆕 Creating new company for domain: {}", domain);
            }

            // Map/update fields with full details from brand data
            company.setCompanyName(org.springframework.util.StringUtils.hasText(companyData.getName()) ?
                    companyData.getName() : generateCompanyNameFromDomain(domain));
            company.setCompanyDescription(companyData.getDescription());
            company.setStatus("Active");
            company.setCompanyLogoUrl(extractLogoUrl(brandResponse));
            company.setWebsiteUrl(org.springframework.util.StringUtils.hasText(companyData.getWebsite()) ?
                    companyData.getWebsite() : "https://" + domain);
            company.setEmailDomains("@" + domain);
            company.setAddressLine1(companyData.getLocation());

            // Handle headquarters safely
            String headquarters = companyData.getHeadquarters();
            if (org.springframework.util.StringUtils.hasText(headquarters) &&
                headquarters.trim().startsWith("[") &&
                headquarters.trim().endsWith("]")) {
                try {
                    List<String> parts = objectMapper.readValue(headquarters, List.class);
                    company.setAddressLine2(String.join(", ", parts));
                } catch (Exception e) {
                    company.setAddressLine2(headquarters);
                }
            } else {
                company.setAddressLine2(headquarters);
            }

            // Extract City + Country properly (limited to varchar(100))
            String[] cityCountry = extractCityAndCountry(headquarters);
            company.setCity(cityCountry[0]);
            company.setCountry(cityCountry[1]);

            company.setUpdatedAt(LocalDateTime.now());

            return companyRepository.save(company);

        } catch (Exception e) {
            log.error("💥 Error creating/updating company from brand data for domain: {}", domain, e);
            return createFallbackCompanyForDomain(domain);
        }
    }
    
    /**
     * Create fallback company when brand data is insufficient
     */
    private Company createFallbackCompanyForDomain(String domain) {
        log.info("🔄 Creating fallback company for domain: {}", domain);
        
        Company company = Company.builder()
                .companyName(generateCompanyNameFromDomain(domain))
                .companyDescription("Company information being processed...")
                .status("Pending")
                .domainName(domain)
                .emailDomains("@" + domain)
                .websiteUrl("https://" + domain)
                .createdAt(java.time.LocalDateTime.now())
                .build();
        
        return companyRepository.save(company);
    }
    
    /**
     * Generate company name from domain
     */
    private String generateCompanyNameFromDomain(String domain) {
        if (domain == null || domain.trim().isEmpty()) {
            return "Unknown Company";
        }
        
        // Remove common TLDs and format as company name
        String name = domain.toLowerCase()
                .replaceAll("\\.(com|org|net|io|co|in|uk|us)$", "")
                .replace(".", " ")
                .replace("-", " ")
                .replace("_", " ");
        
        // Capitalize first letter of each word
        String[] words = name.split("\\s+");
        StringBuilder result = new StringBuilder();
        for (String word : words) {
            if (word.length() > 0) {
                result.append(Character.toUpperCase(word.charAt(0)))
                      .append(word.substring(1).toLowerCase())
                      .append(" ");
            }
        }
        
        return result.toString().trim();
    }
    
    /**
     * Extract logo URL from brand response
     */
    private String extractLogoUrl(BrandExtractionResponse brandResponse) {
        if (brandResponse.getLogo() != null && brandResponse.getLogo().getIcon() != null) {
            return brandResponse.getLogo().getIcon();
        }
        return null;
    }
}

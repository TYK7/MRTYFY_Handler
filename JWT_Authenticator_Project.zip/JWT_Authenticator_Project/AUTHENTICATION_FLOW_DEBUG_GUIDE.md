# 🔍 Authentication & Authorization Flow - Line-by-Line Debug Guide

## 🎯 Complete Request Flow Explanation

Let's trace through what happens when you hit an authorized endpoint like `GET /api/demo/admin` with a JWT token.

---

## 📋 **STEP-BY-STEP EXECUTION FLOW**

### 🚀 **1. HTTP REQUEST ARRIVES**
```http
GET /api/demo/admin HTTP/1.1
Host: localhost:8080
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json
```

**What happens:**
- Spring Boot receives the HTTP request
- Request goes through the **Security Filter Chain** (configured in `SecurityConfig.java`)
- Multiple security filters will process this request **in order**

---

### 🔐 **2. SECURITY FILTER CHAIN EXECUTION**

**Filter Order (as configured in SecurityConfig):**
1. `ApiKeyAuthenticationFilter` 
2. `JwtRequestFilter` ⬅️ **Main JWT Authentication**
3. `ExternalApiSecurityFilter`

#### 📍 **2.1. ApiKeyAuthenticationFilter Execution**
```java
// File: ApiKeyAuthenticationFilter.java
@Override
protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
```

**Debug Trace:**
- ✅ **Line 1**: Filter checks if request path starts with `/api/external/` or `/api/secure/`
- ✅ **Line 2**: Our request is `/api/demo/admin` → **SKIP THIS FILTER**
- ✅ **Line 3**: `filterChain.doFilter(request, response)` → Continue to next filter

#### 📍 **2.2. JwtRequestFilter Execution** ⭐ **MAIN AUTHENTICATION**
```java
// File: JwtRequestFilter.java
@Override
protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
    
    // STEP 1: Extract Authorization header
    final String requestTokenHeader = request.getHeader("Authorization");
    log.debug("🔍 Processing request: {} {}", request.getMethod(), request.getRequestURI());
    log.debug("🔍 Authorization header: {}", requestTokenHeader != null ? "Present" : "Missing");
```

**Debug Trace:**
- ✅ **Line 1**: `request.getHeader("Authorization")` → `"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."`
- ✅ **Line 2**: Log shows: `🔍 Processing request: GET /api/demo/admin`
- ✅ **Line 3**: Log shows: `🔍 Authorization header: Present`

```java
    // STEP 2: Validate token format
    String username = null;
    String jwtToken = null;
    
    if (requestTokenHeader != null && requestTokenHeader.startsWith("Bearer ")) {
        jwtToken = requestTokenHeader.substring(7); // Remove "Bearer " prefix
        log.debug("🎫 JWT token extracted: {}...", jwtToken.substring(0, Math.min(20, jwtToken.length())));
```

**Debug Trace:**
- ✅ **Line 1**: Token starts with "Bearer " → **VALID FORMAT**
- ✅ **Line 2**: `jwtToken = requestTokenHeader.substring(7)` → Extract actual JWT token
- ✅ **Line 3**: Log shows: `🎫 JWT token extracted: eyJhbGciOiJIUzI1NiIs...`

```java
        try {
            // STEP 3: Extract username from token
            username = jwtUtil.extractUsername(jwtToken);
            log.debug("👤 Username extracted from token: {}", username);
```

**Debug Trace - JwtUtil.extractUsername():**
```java
// File: JwtUtil.java - extractUsername()
public String extractUsername(String token) {
    String username = extractClaim(token, Claims::getSubject);
    log.debug("📋 Extracted username: {}", username);
    return username;
}
```
- ✅ **Line 1**: Calls `extractClaim()` with `Claims::getSubject`
- ✅ **Line 2**: JWT subject claim contains: `"MRTFY000036"` (business ID)
- ✅ **Line 3**: Returns username: `"MRTFY000036"`

```java
        } catch (ExpiredJwtException e) {
            log.warn("⚠️ JWT Token has expired: {}", e.getMessage());
            // Handle expired token...
        } catch (Exception e) {
            log.warn("⚠️ Unable to get JWT Token or JWT Token is invalid: {}", e.getMessage());
        }
    }
```

**Debug Trace:**
- ✅ **Line 1**: No exception thrown → Token is valid and not expired
- ✅ **Line 2**: Continue execution

```java
    // STEP 4: Authenticate user if not already authenticated
    if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
        log.debug("🔐 Authenticating user: {}", username);
        
        UserDetails userDetails = this.jwtUserDetailsService.loadUserByUsername(username);
        log.debug("👤 User details loaded: {}, authorities: {}", 
            userDetails.getUsername(), userDetails.getAuthorities());
```

**Debug Trace - JwtUserDetailsService.loadUserByUsername():**
```java
// File: JwtUserDetailsService.java
@Override
public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    log.debug("🔍 Loading user details for username: {}", username);
    
    // Find user in database
    User user = userRepository.findById(username)
            .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));
    
    log.debug("✅ User found: {} with role ID: {}", user.getUsername(), user.getRoleId());
    
    // Load role from database
    Role role = roleRepository.findById(user.getRoleId())
            .orElse(null);
    
    String roleName = (role != null) ? role.getRoleName() : "ROLE_USER";
    log.debug("🎭 Role assigned: {}", roleName);
    
    // Create authorities
    Collection<SimpleGrantedAuthority> authorities = List.of(new SimpleGrantedAuthority(roleName));
    
    // Return UserDetails with authorities
    return new User(user.getUsername(), user.getPassword(), user.isEnabled(), 
                   true, true, true, authorities);
}
```

**Debug Trace:**
- ✅ **Line 1**: Query database for user: `"MRTFY000036"`
- ✅ **Line 2**: User found with role ID: `2`
- ✅ **Line 3**: Query database for role ID `2` → Role name: `"ROLE_ADMIN"`
- ✅ **Line 4**: Create authority: `SimpleGrantedAuthority("ROLE_ADMIN")`
- ✅ **Line 5**: Return UserDetails with `ROLE_ADMIN` authority

```java
        // STEP 5: Validate token against user details
        if (jwtUtil.validateToken(jwtToken, userDetails)) {
            log.debug("✅ JWT token is valid for user: {}", username);
```

**Debug Trace - JwtUtil.validateToken():**
```java
// File: JwtUtil.java
public Boolean validateToken(String token, UserDetails userDetails) {
    final String username = extractUsername(token);
    final String role = extractRole(token); // Extract role from JWT
    
    boolean isValidUser = username.equals(userDetails.getUsername());
    boolean isNotExpired = !isTokenExpired(token);
    
    log.debug("🔍 Token validation - User match: {}, Not expired: {}", isValidUser, isNotExpired);
    
    return isValidUser && isNotExpired;
}
```

**Debug Trace:**
- ✅ **Line 1**: Username from token matches UserDetails → `true`
- ✅ **Line 2**: Token not expired → `true`
- ✅ **Line 3**: **TOKEN IS VALID** → Return `true`

```java
            // STEP 6: Create authentication and set in SecurityContext
            UsernamePasswordAuthenticationToken authToken = 
                new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                
            authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
            SecurityContextHolder.getContext().setAuthentication(authToken);
            
            log.debug("🔐 Authentication set in SecurityContext for user: {}", username);
        }
    }
    
    // STEP 7: Continue filter chain
    filterChain.doFilter(request, response);
}
```

**Debug Trace:**
- ✅ **Line 1**: Create `UsernamePasswordAuthenticationToken` with authorities: `[ROLE_ADMIN]`
- ✅ **Line 2**: Set authentication details (IP, session info)
- ✅ **Line 3**: **SET AUTHENTICATION IN SECURITY CONTEXT**
- ✅ **Line 4**: **SecurityContext now contains authenticated user with ROLE_ADMIN**
- ✅ **Line 5**: Continue to next filter

#### 📍 **2.3. ExternalApiSecurityFilter Execution**
```java
// This filter checks for external API endpoints - our request doesn't match
// So it continues to Spring Security's authorization
```

---

### 🛡️ **3. SPRING SECURITY AUTHORIZATION**

Now the request reaches Spring Security's built-in authorization mechanism.

#### 📍 **3.1. SecurityConfig Authorization Rules Check**
```java
// File: SecurityConfig.java - filterChain() method
.authorizeHttpRequests(authz -> authz
    // ... other matchers ...
    
    // 🛠️ ADMIN Level Endpoints (ROLE_ADMIN+ due to hierarchy)  
    .requestMatchers("/api/admin/**", "/api/roles/**", "/api/companies/**", 
                   "/api/dashboard/admin/**", "/api/brands/admin/**")
        .hasRole("ADMIN")
        
    // Our request: /api/demo/admin matches .requestMatchers("/api/admin/**")
)
```

**Debug Trace:**
- ✅ **Line 1**: Request URI: `/api/demo/admin`
- ✅ **Line 2**: Check against pattern: `/api/admin/**` → **NO MATCH**
- ❌ **Line 3**: Check against other patterns...

Wait! Our demo endpoint is `/api/demo/admin`, but the SecurityConfig doesn't have a specific rule for `/api/demo/**`. Let's check what rule it matches:

```java
// Looking further down in SecurityConfig...
.requestMatchers("/api/test/**").authenticated()

// Default: All other endpoints require authentication
.anyRequest().authenticated()
```

**Debug Trace:**
- ✅ **Line 1**: `/api/demo/admin` doesn't match `/api/test/**`
- ✅ **Line 2**: Falls to `.anyRequest().authenticated()` → **REQUIRES AUTHENTICATION ONLY**
- ✅ **Line 3**: User is authenticated with `ROLE_ADMIN` → **ACCESS GRANTED**

**Note**: The demo endpoints are protected by `@PreAuthorize` annotations instead!

#### 📍 **3.2. Role Hierarchy Application**
```java
// File: RoleHierarchyConfig.java
@Bean
public RoleHierarchy roleHierarchy() {
    // Hierarchy: ROLE_SUPER_ADMIN > ROLE_ADMIN > ROLE_USER
    // This means ROLE_ADMIN can access ROLE_USER endpoints
    // This means ROLE_SUPER_ADMIN can access ROLE_ADMIN and ROLE_USER endpoints
}
```

**Debug Trace:**
- ✅ **Line 1**: Current user has `ROLE_ADMIN`
- ✅ **Line 2**: Hierarchy allows `ROLE_ADMIN` to access `ROLE_USER` endpoints
- ✅ **Line 3**: **Role hierarchy applied to authorities**

---

### 🎯 **4. CONTROLLER METHOD EXECUTION**

Request now reaches the controller method:

```java
// File: RoleDemoController.java
@GetMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
public ResponseEntity<Map<String, Object>> adminEndpoint(Authentication authentication) {
```

#### 📍 **4.1. @PreAuthorize Evaluation**
```java
// Spring Security evaluates: @PreAuthorize("hasRole('ADMIN')")
// Current user authorities: [ROLE_ADMIN]
// hasRole('ADMIN') checks for authority: ROLE_ADMIN
```

**Debug Trace:**
- ✅ **Line 1**: Evaluate `hasRole('ADMIN')`
- ✅ **Line 2**: User has authority `ROLE_ADMIN`
- ✅ **Line 3**: **AUTHORIZATION SUCCESSFUL** → Method execution continues

#### 📍 **4.2. Method Execution**
```java
UserRole currentRole = roleValidationUtil.getHighestRole(authentication);
// Calls RoleValidationUtil.getHighestRole()
```

**Debug Trace - RoleValidationUtil.getHighestRole():**
```java
// File: RoleValidationUtil.java
public UserRole getHighestRole(Authentication authentication) {
    Set<UserRole> roles = getUserRoles(authentication);
    return roles.stream()
            .max(Comparator.comparing(UserRole::getRoleNumber))
            .orElse(null);
}
```

**Debug Trace:**
- ✅ **Line 1**: Get all user roles from authentication
- ✅ **Line 2**: User roles: `[ROLE_ADMIN]` → `[UserRole.ADMIN]`
- ✅ **Line 3**: Find highest role by number: `UserRole.ADMIN (Level 2)`
- ✅ **Line 4**: Return `UserRole.ADMIN`

#### 📍 **4.3. Build Response**
```java
Map<String, Object> response = buildResponse(
    "ADMIN_ACCESS",
    "You have successfully accessed an ADMIN level endpoint!",
    currentRole,
    "This endpoint can be accessed by: ADMIN, SUPER_ADMIN"
);

return ResponseEntity.ok(response);
```

**Debug Trace:**
- ✅ **Line 1**: Build success response with role information
- ✅ **Line 2**: Return HTTP 200 OK with JSON response

---

## ❌ **FAILURE SCENARIOS**

### **Scenario 1: No Authentication Token**
```http
GET /api/demo/admin HTTP/1.1
# Missing Authorization header
```

**Debug Trace:**
1. `JwtRequestFilter` → No Authorization header → No authentication set
2. Spring Security → Request requires authentication → **AUTHENTICATION REQUIRED**
3. `CustomAuthenticationEntryPoint.commence()` is called
4. Returns HTTP 401 with detailed JSON error

### **Scenario 2: USER trying to access ADMIN endpoint**
```http
GET /api/demo/admin HTTP/1.1
Authorization: Bearer <user-jwt-token-with-ROLE_USER>
```

**Debug Trace:**
1. `JwtRequestFilter` → Token valid → Set authentication with `ROLE_USER`
2. Spring Security → Request passes `.anyRequest().authenticated()`
3. Controller → `@PreAuthorize("hasRole('ADMIN')")` is evaluated
4. `hasRole('ADMIN')` → User has `ROLE_USER` → **AUTHORIZATION FAILS**
5. `CustomAccessDeniedHandler.handle()` is called
6. Returns HTTP 403 with detailed JSON error explaining role requirements

### **Scenario 3: Expired Token**
```http
GET /api/demo/admin HTTP/1.1
Authorization: Bearer <expired-jwt-token>
```

**Debug Trace:**
1. `JwtRequestFilter` → `jwtUtil.extractUsername()` throws `ExpiredJwtException`
2. Exception caught → No authentication set
3. Continues to Spring Security → **AUTHENTICATION REQUIRED**
4. `CustomAuthenticationEntryPoint` returns HTTP 401 with "EXPIRED_TOKEN" error

---

## 🎯 **SUCCESS FLOW SUMMARY**

```
1. HTTP Request → "GET /api/demo/admin" + JWT token
2. ApiKeyAuthenticationFilter → Skip (not API key endpoint)
3. JwtRequestFilter → Extract & validate JWT → Set authentication with ROLE_ADMIN
4. ExternalApiSecurityFilter → Skip (not external endpoint)  
5. Spring Security → Check .anyRequest().authenticated() → User authenticated → PASS
6. Controller → @PreAuthorize("hasRole('ADMIN')") → User has ROLE_ADMIN → PASS
7. Method execution → Build response → Return HTTP 200 OK
```

## 🔧 **Key Debug Points**

**To debug authentication issues, check:**
1. **JWT Token**: `GET /api/test/jwt/debug` - See token contents
2. **User Role Info**: `GET /api/demo/my-role-info` - See current roles
3. **Access Matrix**: `GET /api/demo/access-test` - Test what you can access
4. **Application Logs**: Look for log messages from each filter
5. **Database**: Verify user role assignments in `users` and `role` tables

**Log Levels to Enable:**
```properties
# Enable debug logging for security
logging.level.com.example.jwtauthenticator.security=DEBUG
logging.level.org.springframework.security=DEBUG
```

This completes the entire authentication and authorization flow! 🎉
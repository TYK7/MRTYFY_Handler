# 🚀 BrandSnap API - Complete Collection Usage Guide

## 📋 Overview

This comprehensive Postman collection covers the entire BrandSnap API platform with **100+ endpoints** organized into **10 logical categories**. It includes automated testing, proper authentication handling, environment management, and detailed examples.

---

## 🎯 **Collection Structure**

### **🔐 1. Authentication & User Management**
Core user account operations including registration, login, profile management, and password changes.

### **🔑 2. API Key Management** 
Complete API key lifecycle - create, read, update, delete, and monitor API keys for external access.

### **🏢 3. Brand Information API**
Core brand data retrieval endpoints - the heart of the BrandSnap platform for extracting brand information from domains.

### **📊 4. Analytics & Dashboard**
Usage analytics, statistics, dashboard data, and performance monitoring endpoints.

### **🏛️ 5. Role Management**
Role-based access control testing and permissions management.

### **🏢 6. Company Management**
Organization and company profile management for multi-tenant support.

### **📁 7. File Management**
File upload and management capabilities for brand assets and documents.

### **🔧 8. Admin Functions**
Administrative endpoints requiring elevated permissions (ADMIN/SUPER_ADMIN).

### **📞 9. External API Integration**
Integration endpoints for external services and API forwarding.

### **🔍 10. Reference Data**
Static reference data like countries, regions, industries, and plan configurations.

### **🏥 11. Health & Monitoring**
System health checks, monitoring endpoints, and debugging tools.

### **🧪 12. Testing & Validation**
Comprehensive testing scenarios for role-based access and functionality validation.

---

## 🚀 **Quick Start Guide**

### **Step 1: Import Collections**
```bash
# Import these files into Postman:
1. BrandSnap_API_Complete_Collection.json
2. BrandSnap_API_Environment.json
```

### **Step 2: Set Up Environment**
1. Select the **"BrandSnap API Environment"**
2. Verify these key variables:
   - `base_url`: `http://localhost:8080/myapp`
   - `test_username`: `testuser`
   - `test_password`: `password123`

### **Step 3: Test Application Health**
```http
GET {{base_url}}/actuator/health
```
Expected: `200 OK` with `{"status":"UP"}`

### **Step 4: Authenticate**
```http
POST {{base_url}}/auth/login
{
  "username": "{{test_username}}",
  "password": "{{test_password}}"
}
```
The JWT token will be automatically saved to `{{jwt_token}}`.

### **Step 5: Test Core Functionality**
```http
GET {{base_url}}/api/brand-info?domain=apple.com
```

---

## 🔐 **Authentication Patterns**

### **1. JWT Bearer Token (Most Common)**
```http
Authorization: Bearer {{jwt_token}}
```
**Used for:** All user-authenticated endpoints

### **2. API Key Authentication**
```http
X-API-Key: {{api_key}}
```
**Used for:** External API access, programmatic access

### **3. No Authentication (Public Endpoints)**
**Used for:** Health checks, reference data, public demos

---

## 📊 **Endpoint Categories & Usage**

### **🔐 Authentication Flow**

#### **Complete User Registration & Login Flow:**
```bash
1. POST /auth/register          # Create new account
2. [Email verification]         # Check email and verify
3. POST /auth/login            # Get JWT tokens
4. GET /api/users/profile      # Get user profile
5. PUT /api/users/profile      # Update profile if needed
```

#### **Authentication Examples:**
```json
// Registration
{
  "username": "newuser123",
  "email": "user@example.com",
  "password": "SecurePassword123!",
  "firstName": "John",
  "lastName": "Doe",
  "companyName": "Test Company",
  "agreeToTerms": true
}

// Login Response
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "refreshToken": "refresh_token_here",
  "user": {
    "id": 1,
    "username": "testuser",
    "role": "USER"
  }
}
```

### **🔑 API Key Management Flow**

#### **Complete API Key Lifecycle:**
```bash
1. POST /api/keys              # Create API key
2. GET /api/keys               # List all keys
3. GET /api/keys/{id}          # Get key details
4. PUT /api/keys/{id}          # Update key settings
5. GET /api/keys/{id}/usage    # Monitor usage
6. DELETE /api/keys/{id}       # Revoke key
```

#### **API Key Creation Example:**
```json
{
  "name": "Production API Key",
  "description": "API key for production environment",
  "environment": "PRODUCTION",
  "rateLimitTier": "PROFESSIONAL",
  "allowedDomains": ["example.com", "api.example.com"],
  "scopes": ["brand:read", "analytics:read"]
}
```

### **🏢 Brand Information API**

#### **Core Brand Extraction Workflow:**
```bash
1. GET /api/brand-info?domain=apple.com    # Extract brand info
2. GET /api/brands/search?query=tech       # Search existing brands
3. GET /api/brands/{id}                    # Get brand details
4. GET /api/categories                     # Get brand categories
```

#### **Brand Info Response Example:**
```json
{
  "success": true,
  "domain": "apple.com",
  "brandName": "Apple Inc.",
  "description": "Technology company",
  "logo": "https://example.com/apple-logo.png",
  "colors": ["#000000", "#FFFFFF"],
  "category": "Technology",
  "extractedAt": "2025-08-29T10:30:45.123Z",
  "confidence": 0.95
}
```

### **📊 Analytics & Dashboard**

#### **Analytics Workflow:**
```bash
1. GET /api/dashboard/overview              # Get dashboard summary
2. GET /api/analytics/usage                 # Detailed usage analytics
3. GET /api/analytics/top-domains           # Most requested domains
4. GET /api/analytics/errors                # Error statistics
5. GET /api/analytics/rate-limit-status     # Rate limit monitoring
```

#### **Dashboard Response Example:**
```json
{
  "totalApiKeys": 5,
  "totalRequests": 15420,
  "requestsThisMonth": 3200,
  "successfulRequests": 14980,
  "topDomains": [
    {"domain": "apple.com", "count": 1200},
    {"domain": "google.com", "count": 980}
  ],
  "rateLimitStatus": {
    "tier": "PROFESSIONAL",
    "limit": 10000,
    "used": 3200,
    "remaining": 6800
  }
}
```

### **🏛️ Role-Based Access Control**

#### **Role Hierarchy Testing:**
```bash
# Test role hierarchy (USER → ADMIN → SUPER_ADMIN)
1. GET /api/demo/public        # Public (no auth)
2. GET /api/demo/user          # USER+ access
3. GET /api/demo/admin         # ADMIN+ access
4. GET /api/demo/super-admin   # SUPER_ADMIN only
5. GET /api/demo/my-role-info  # Current role info
```

#### **Expected Access Matrix:**
| Role | Public | User | Admin | Super Admin |
|------|--------|------|-------|-------------|
| **Anonymous** | ✅ 200 | ❌ 401 | ❌ 401 | ❌ 401 |
| **USER** | ✅ 200 | ✅ 200 | ❌ 403 | ❌ 403 |
| **ADMIN** | ✅ 200 | ✅ 200 | ✅ 200 | ❌ 403 |
| **SUPER_ADMIN** | ✅ 200 | ✅ 200 | ✅ 200 | ✅ 200 |

---

## 🧪 **Testing Workflows**

### **🔄 Complete Testing Sequence**

#### **1. Environment Setup**
```bash
✅ Health Check           → GET /actuator/health
✅ Application Info       → GET /actuator/info
✅ Generate Test ID       → GET /api/test/generate-id
```

#### **2. Authentication Testing**
```bash
✅ User Registration      → POST /auth/register
✅ User Login             → POST /auth/login
✅ Token Refresh          → POST /auth/refresh
✅ JWT Debug             → GET /api/test/jwt/debug
✅ Get Profile           → GET /api/users/profile
```

#### **3. Core Functionality**
```bash
✅ Brand Info Extraction  → GET /api/brand-info?domain=apple.com
✅ Search Brands          → GET /api/brands/search?query=tech
✅ Create API Key         → POST /api/keys
✅ Dashboard Overview     → GET /api/dashboard/overview
```

#### **4. Role-Based Access**
```bash
✅ Public Access          → GET /api/demo/public
✅ User Access            → GET /api/demo/user
✅ Admin Access           → GET /api/demo/admin (may fail if USER role)
✅ Role Information       → GET /api/demo/my-role-info
```

#### **5. Advanced Features**
```bash
✅ File Upload            → POST /api/files/upload
✅ Company Management     → GET /api/companies/profile
✅ Analytics              → GET /api/analytics/usage
✅ Reference Data         → GET /api/reference/countries
```

### **🎯 Automated Test Validation**

The collection includes **automated test scripts** for:

#### **Status Code Validation**
```javascript
pm.test('Request successful', function () {
    pm.response.to.have.status(200);
});
```

#### **Response Time Monitoring**
```javascript
pm.test('Response time is acceptable', function () {
    pm.expect(pm.response.responseTime).to.be.below(5000);
});
```

#### **Authentication Token Management**
```javascript
// Auto-save JWT tokens
if (responseJson.token) {
    pm.collectionVariables.set('jwt_token', responseJson.token);
}
```

#### **Role Hierarchy Validation**
```javascript
pm.test('ADMIN can access USER endpoints', function () {
    pm.response.to.have.status(200);
});
```

---

## 📈 **Performance & Monitoring**

### **Response Time Expectations**
- **Authentication:** < 1 second
- **Brand Info Extraction:** < 3 seconds  
- **API Key Operations:** < 500ms
- **Analytics Queries:** < 2 seconds
- **Health Checks:** < 200ms

### **Rate Limiting**
Different tiers have different limits:
- **FREE:** 100 requests/month
- **BASIC:** 1,000 requests/month
- **PROFESSIONAL:** 10,000 requests/month
- **ENTERPRISE:** Custom limits

### **Monitoring Headers**
```http
X-Rate-Limit-Limit: 10000
X-Rate-Limit-Remaining: 9950
X-Rate-Limit-Reset: 1693526400
X-Request-ID: abc123
```

---

## 🛠️ **Advanced Usage**

### **🔄 Environment Switching**

#### **Local Development**
```json
{
  "base_url": "http://localhost:8080/myapp"
}
```

#### **Staging**
```json
{
  "base_url": "https://staging-api.brandsnap.com"
}
```

#### **Production**
```json
{
  "base_url": "https://api.brandsnap.com"
}
```

### **🔐 Advanced Authentication**

#### **Multi-Role Testing**
```bash
# Set up different role tokens
user_jwt_token     → USER role access
admin_jwt_token    → ADMIN role access  
super_admin_jwt_token → SUPER_ADMIN role access
```

#### **API Key vs JWT Token**
```bash
# JWT Token (User Context)
Authorization: Bearer {{jwt_token}}

# API Key (External Access)
X-API-Key: {{api_key}}
```

### **📊 Batch Operations**

#### **Run Collection with Newman**
```bash
# Install Newman
npm install -g newman

# Run entire collection
newman run BrandSnap_API_Complete_Collection.json \
  -e BrandSnap_API_Environment.json \
  --reporters cli,html \
  --reporter-html-export report.html
```

#### **Run Specific Folder**
```bash
newman run BrandSnap_API_Complete_Collection.json \
  -e BrandSnap_API_Environment.json \
  --folder "Authentication & User Management"
```

---

## 🚨 **Troubleshooting**

### **Common Issues & Solutions**

#### **🔴 401 Unauthorized**
```
Problem: JWT token missing or expired
Solutions:
  ✅ Run login request to get fresh token
  ✅ Check token expiration (default: 10 hours)
  ✅ Verify username/password are correct
  ✅ Ensure user account is verified
```

#### **🔴 403 Forbidden**
```
Problem: Insufficient role permissions
Solutions:
  ✅ Check required role for endpoint
  ✅ Use appropriate role account (USER/ADMIN/SUPER_ADMIN)
  ✅ Verify role hierarchy requirements
  ✅ Test with /api/demo/my-role-info
```

#### **🔴 429 Rate Limited**
```
Problem: API rate limit exceeded
Solutions:
  ✅ Check rate limit headers
  ✅ Wait for rate limit reset
  ✅ Upgrade to higher tier plan
  ✅ Use different API key
```

#### **🔴 500 Internal Server Error**
```
Problem: Server-side error
Solutions:
  ✅ Check application logs
  ✅ Verify database connectivity
  ✅ Test with simpler endpoints first
  ✅ Check request payload format
```

### **🔧 Debug Tools**

#### **JWT Token Analysis**
```http
GET {{base_url}}/api/test/jwt/debug
Authorization: Bearer {{jwt_token}}
```

#### **System Health Check**
```http
GET {{base_url}}/api/system/health
Authorization: Bearer {{jwt_token}}
```

#### **Rate Limit Status**
```http
GET {{base_url}}/api/analytics/rate-limit-status
Authorization: Bearer {{jwt_token}}
```

---

## 📚 **API Documentation References**

### **Swagger/OpenAPI**
```http
GET {{base_url}}/swagger-ui/index.html
```

### **API Reference**
```http
GET {{base_url}}/api-docs
```

### **Postman Documentation**
Each request includes detailed descriptions, examples, and response schemas.

---

## 🎉 **Best Practices**

### **✅ Collection Organization**
- Use folders to group related endpoints
- Name requests clearly and consistently
- Include descriptions for all requests
- Add proper response examples

### **✅ Environment Management**
- Use environment variables for all dynamic values
- Keep sensitive data in secret variables
- Use different environments for dev/staging/prod
- Document all variables with descriptions

### **✅ Testing Strategy**
- Include automated tests for critical paths
- Test both success and error scenarios
- Validate response schemas and data
- Monitor performance and response times

### **✅ Authentication**
- Always use HTTPS in production
- Rotate API keys regularly
- Implement proper token refresh logic
- Use appropriate authentication method per endpoint

### **✅ Error Handling**
- Always check response status codes
- Log errors appropriately
- Implement retry logic for transient failures
- Provide meaningful error messages

---

## 📞 **Support & Resources**

### **Getting Help**
- Check application logs for detailed error information
- Use debug endpoints to analyze tokens and permissions
- Test with simpler endpoints before complex operations
- Verify environment variables are set correctly

### **Community Resources**
- API Documentation: Available at `/swagger-ui`
- Collection Updates: Check for latest versions
- Best Practices: Follow this guide for optimal usage
- Testing Examples: Use provided test scenarios

---

## 🎯 **Success Metrics**

After completing this guide, you should be able to:

✅ **Successfully authenticate** and receive JWT tokens  
✅ **Extract brand information** from any domain  
✅ **Create and manage API keys** for external access  
✅ **Monitor usage analytics** and rate limits  
✅ **Test role-based access** control properly  
✅ **Handle errors gracefully** with proper debugging  
✅ **Run automated tests** for validation  
✅ **Scale operations** using batch processing  

---

**Happy API Testing! 🚀**

*This collection provides comprehensive coverage of the BrandSnap API platform with over 100 endpoints, automated testing, and production-ready examples.*
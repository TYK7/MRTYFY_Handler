# ⚡ BrandSnap API - Quick Reference Guide

## 🚀 **5-Minute Quick Start**

### **1. Import & Setup**
```bash
1. Import: BrandSnap_API_Complete_Collection.json
2. Import: BrandSnap_API_Environment.json
3. Select Environment: "BrandSnap API Environment"
```

### **2. Test Health**
```http
GET {{base_url}}/actuator/health
→ Should return: {"status":"UP"}
```

### **3. Login**
```http
POST {{base_url}}/auth/login
{
  "username": "testuser",
  "password": "password123"
}
→ JWT token auto-saved to {{jwt_token}}
```

### **4. Test Core Feature**
```http
GET {{base_url}}/api/brand-info?domain=apple.com
→ Returns brand information for Apple
```

---

## 📋 **Essential Endpoints**

### **🔐 Authentication**
```http
POST /auth/register     → Register new user
POST /auth/login        → Get JWT token
POST /auth/refresh      → Refresh token
GET  /api/users/profile → Get user profile
```

### **🏢 Brand Information**
```http
GET /api/brand-info?domain={domain}  → Extract brand data
GET /api/brands/search?query={term}  → Search brands
GET /api/brands/{id}                 → Get brand details
GET /api/categories                  → Get categories
```

### **🔑 API Keys**
```http
POST   /api/keys           → Create API key
GET    /api/keys           → List API keys
GET    /api/keys/{id}      → Get key details
PUT    /api/keys/{id}      → Update key
DELETE /api/keys/{id}      → Delete key
```

### **📊 Analytics**
```http
GET /api/dashboard/overview    → Dashboard summary
GET /api/analytics/usage       → Usage statistics
GET /api/analytics/top-domains → Popular domains
```

---

## 🔑 **Authentication Methods**

### **JWT Bearer Token** (Most Common)
```http
Authorization: Bearer {{jwt_token}}
```

### **API Key** (External Access)
```http
X-API-Key: {{api_key}}
```

### **No Auth** (Public Endpoints)
```http
# No authentication header needed
```

---

## 🎯 **Common Use Cases**

### **🔄 User Registration Flow**
```bash
1. POST /auth/register       → Create account
2. [Verify email]           → Check email inbox
3. POST /auth/login         → Get JWT token
4. GET /api/users/profile   → Get user data
```

### **🏢 Brand Extraction Workflow**
```bash
1. POST /auth/login                    → Authenticate
2. GET /api/brand-info?domain=apple.com → Extract brand
3. GET /api/brands/search?query=tech   → Search more brands
4. GET /api/dashboard/overview         → Check usage stats
```

### **🔑 API Key Setup**
```bash
1. POST /auth/login       → Authenticate as user
2. POST /api/keys         → Create API key
3. Test with: GET /api/brand-info?domain=google.com
   Header: X-API-Key: {{api_key}}
```

### **📊 Analytics Review**
```bash
1. POST /auth/login              → Authenticate
2. GET /api/dashboard/overview   → Get summary
3. GET /api/analytics/usage      → Detailed stats
4. GET /api/analytics/top-domains → Popular requests
```

---

## 🧪 **Testing Scenarios**

### **✅ Health Check**
```http
GET /actuator/health → 200 OK
```

### **✅ Authentication Test**
```http
POST /auth/login → Should get JWT token
```

### **✅ Core Functionality**
```http
GET /api/brand-info?domain=apple.com → Brand data
```

### **✅ Role Access Test**
```bash
GET /api/demo/public      → 200 (anyone)
GET /api/demo/user        → 200 (authenticated)
GET /api/demo/admin       → 200/403 (depends on role)
GET /api/demo/my-role-info → Shows your role
```

---

## 🚨 **Common Errors & Fixes**

### **401 Unauthorized**
```bash
Problem: Missing or invalid JWT token
Fix: Run login request to get fresh token
```

### **403 Forbidden**
```bash
Problem: Insufficient permissions
Fix: Check required role for endpoint
```

### **429 Rate Limited**
```bash
Problem: Too many requests
Fix: Wait for rate limit reset or upgrade plan
```

### **500 Server Error**
```bash
Problem: Application error
Fix: Check application health and logs
```

---

## 📊 **Environment Variables**

### **Essential Variables**
```json
{
  "base_url": "http://localhost:8080/myapp",
  "jwt_token": "auto-populated by login",
  "api_key": "auto-populated when creating API key",
  "test_username": "testuser",
  "test_password": "password123"
}
```

### **Auto-Populated Variables**
```bash
jwt_token     → Set by login response
refresh_token → Set by login response  
api_key       → Set by API key creation
user_id       → Set by login response
```

---

## 🎯 **Role Hierarchy**

```
SUPER_ADMIN (Level 300) ──┐
                          ├─→ Can access ALL endpoints
ADMIN (Level 200) ────────┤
                          ├─→ Can access ADMIN + USER endpoints
USER (Level 100) ─────────┤
                          └─→ Can access USER endpoints only
```

### **Role Testing**
```bash
GET /api/demo/user        → USER, ADMIN, SUPER_ADMIN ✅
GET /api/demo/admin       → ADMIN, SUPER_ADMIN ✅ | USER ❌
GET /api/demo/super-admin → SUPER_ADMIN ✅ | USER, ADMIN ❌
```

---

## ⚙️ **Collection Features**

### **🤖 Automated Features**
- ✅ Auto-save JWT tokens from login
- ✅ Auto-set Authorization headers
- ✅ Response time monitoring
- ✅ Error handling and logging
- ✅ Status code validation

### **🧪 Testing Features**
- ✅ Automated test scripts
- ✅ Response validation
- ✅ Performance monitoring
- ✅ Error scenario testing
- ✅ Role hierarchy validation

### **📊 Monitoring Features**
- ✅ Response time tracking
- ✅ Success/failure logging
- ✅ Rate limit monitoring
- ✅ Token expiration alerts

---

## 🏆 **Success Checklist**

After setup, you should be able to:

✅ **Health Check** - GET /actuator/health returns 200  
✅ **Authentication** - Login returns JWT token  
✅ **Brand Extraction** - Get brand info for any domain  
✅ **API Key Creation** - Create and use API keys  
✅ **Dashboard Access** - View usage statistics  
✅ **Role Testing** - Test role-based access control  
✅ **Error Handling** - Proper error responses  
✅ **Performance** - Response times under 5 seconds  

---

## 📚 **Quick Commands**

### **Newman CLI Testing**
```bash
# Test entire collection
newman run BrandSnap_API_Complete_Collection.json -e BrandSnap_API_Environment.json

# Test specific folder
newman run BrandSnap_API_Complete_Collection.json -e BrandSnap_API_Environment.json --folder "Authentication & User Management"

# Generate HTML report
newman run BrandSnap_API_Complete_Collection.json -e BrandSnap_API_Environment.json --reporters cli,html --reporter-html-export report.html
```

### **Postman Runner**
```bash
1. Click "Runner" in Postman
2. Select collection: "BrandSnap API - Complete Collection"  
3. Select environment: "BrandSnap API Environment"
4. Click "Run BrandSnap API"
```

---

## 🔗 **Useful Links**

- **Swagger UI**: `{{base_url}}/swagger-ui/index.html`
- **API Docs**: `{{base_url}}/api-docs`
- **Health Check**: `{{base_url}}/actuator/health`
- **App Info**: `{{base_url}}/actuator/info`

---

**⚡ Pro Tips:**
- Always test health check first
- Use environment variables for all dynamic values
- Check console logs for detailed information
- Run login before testing authenticated endpoints
- Use Newman for automated testing

**Happy Testing! 🚀**
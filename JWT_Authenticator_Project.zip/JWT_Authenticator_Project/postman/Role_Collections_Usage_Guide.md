# 🎯 BrandSnap API - Role Management Postman Collections Usage Guide

## 📦 Collections Overview

This guide covers two specialized Postman collections for testing role-based access control in the BrandSnap API:

1. **🏛️ Role Management API Collection** - Core role CRUD operations
2. **🎭 Role Demo API Collection** - Role hierarchy and access control testing

---

## 🚀 Quick Setup Instructions

### 1. **Import Collections**
```bash
# Import both collections into Postman:
- Role_Management_API_Collection.json
- Role_Demo_API_Collection.json
```

### 2. **Set Environment Variables**
Create a new environment in Postman with these variables:

| Variable | Value | Description |
|----------|-------|-------------|
| `base_url` | `http://localhost:8080/myapp` | Application base URL |
| `jwt_token` | `""` | Current JWT token (auto-filled) |
| `user_jwt_token` | `""` | USER role JWT token |
| `admin_jwt_token` | `""` | ADMIN role JWT token |
| `super_admin_jwt_token` | `""` | SUPER_ADMIN role JWT token |

### 3. **Test Application Health**
```http
GET {{base_url}}/actuator/health
```
Should return `200 OK` with `{"status":"UP"}`

---

## 🏛️ **Role Management API Collection**

### **Purpose**
Test core role management operations and administrative functions.

### **Key Endpoints**
- `GET /api/roles` - Get all roles
- `GET /api/roles/{id}` - Get role by ID  
- `GET /api/roles/name/{name}` - Get role by name
- `GET /api/roles/scope/{scope}` - Get roles by scope
- `GET /api/roles/default` - Get default user role

### **🧪 Testing Scenarios**

#### **1. Basic Role Retrieval**
```http
GET /api/roles
Authorization: Bearer {{jwt_token}}
```
**Expected Response:**
```json
[
  {
    "roleId": 1,
    "roleName": "User",
    "roleNumber": 100,
    "roleDescription": "Standard application user...",
    "scope": "Application"
  },
  // ... other roles
]
```

#### **2. Role Hierarchy Verification**
```http
GET /api/roles/scope/Application
```
Should return User and Admin roles (both Application scope).

#### **3. Default Role Check**
```http
GET /api/roles/default
```
Should return User role (roleNumber: 100).

### **⚡ Automated Tests**
The collection includes automated tests for:
- ✅ Status code validation
- ✅ Response structure verification
- ✅ Role hierarchy validation
- ✅ Data integrity checks

---

## 🎭 **Role Demo API Collection**

### **Purpose**
Comprehensive testing of role-based access control and hierarchical permissions.

### **🏗️ Role Hierarchy**
```
SUPER_ADMIN (Level 3) ──→ Can access ALL endpoints
    ↓ inherits from
ADMIN (Level 2) ────────→ Can access ADMIN + USER endpoints
    ↓ inherits from
USER (Level 1) ─────────→ Can access USER endpoints only
```

### **📋 Endpoint Categories**

#### **🌍 Public Access** (No Authentication)
- `GET /api/demo/public` - Anyone can access

#### **👤 USER Level Access** (USER + ADMIN + SUPER_ADMIN)
- `GET /api/demo/user` - Basic user functionality

#### **🛠️ ADMIN Level Access** (ADMIN + SUPER_ADMIN)
- `GET /api/demo/admin` - Administrative functions

#### **🔧 SUPER_ADMIN Level Access** (SUPER_ADMIN only)
- `GET /api/demo/super-admin` - System administration

#### **ℹ️ Information Endpoints** (Authenticated users)
- `GET /api/demo/my-role-info` - Current user's role details
- `GET /api/demo/access-test` - Access matrix for current role

---

## 🧪 **Testing Workflow**

### **Step 1: Get Authentication Tokens**

#### **Get USER Token**
```http
POST {{base_url}}/auth/login
Content-Type: application/json

{
  "username": "testuser",
  "password": "password123"
}
```
Response saves token to `{{user_jwt_token}}`.

#### **Get ADMIN Token**
```http
POST {{base_url}}/auth/login
Content-Type: application/json

{
  "username": "testadmin", 
  "password": "password123"
}
```
Response saves token to `{{admin_jwt_token}}`.

#### **Get SUPER_ADMIN Token**
```http
POST {{base_url}}/auth/login
Content-Type: application/json

{
  "username": "testsuperadmin",
  "password": "password123"
}
```
Response saves token to `{{super_admin_jwt_token}}`.

### **Step 2: Test Public Access**
```http
GET {{base_url}}/api/demo/public
# No authentication required
```

### **Step 3: Test Role Hierarchy**

#### **USER Role Testing**
```http
# Should work (USER accessing USER endpoint)
GET {{base_url}}/api/demo/user
Authorization: Bearer {{user_jwt_token}}

# Should fail (USER accessing ADMIN endpoint)  
GET {{base_url}}/api/demo/admin
Authorization: Bearer {{user_jwt_token}}
# Expected: 403 Forbidden
```

#### **ADMIN Role Testing**
```http
# Should work (ADMIN accessing USER endpoint - inheritance)
GET {{base_url}}/api/demo/user
Authorization: Bearer {{admin_jwt_token}}

# Should work (ADMIN accessing ADMIN endpoint)
GET {{base_url}}/api/demo/admin  
Authorization: Bearer {{admin_jwt_token}}

# Should fail (ADMIN accessing SUPER_ADMIN endpoint)
GET {{base_url}}/api/demo/super-admin
Authorization: Bearer {{admin_jwt_token}}
# Expected: 403 Forbidden
```

#### **SUPER_ADMIN Role Testing**
```http
# Should work (SUPER_ADMIN accessing all endpoints)
GET {{base_url}}/api/demo/user
GET {{base_url}}/api/demo/admin
GET {{base_url}}/api/demo/super-admin
Authorization: Bearer {{super_admin_jwt_token}}
```

### **Step 4: Analyze Role Information**
```http
GET {{base_url}}/api/demo/my-role-info
Authorization: Bearer {{admin_jwt_token}}
```

**Expected Response for ADMIN:**
```json
{
  "roleInformation": {
    "primaryRole": "ROLE_ADMIN",
    "roleLevel": 200,
    "allRoles": ["ROLE_USER", "ROLE_ADMIN"],
    "inheritedRoles": ["ROLE_USER"]
  },
  "permissions": {
    "canAccessUserEndpoints": true,
    "canAccessAdminEndpoints": true,
    "canAccessSuperAdminEndpoints": false
  }
}
```

### **Step 5: Test Access Matrix**
```http
GET {{base_url}}/api/demo/access-test
Authorization: Bearer {{admin_jwt_token}}
```

**Expected Response for ADMIN:**
```json
{
  "accessMatrix": {
    "/api/demo/public": {"accessible": true},
    "/api/demo/user": {"accessible": true},
    "/api/demo/admin": {"accessible": true},
    "/api/demo/super-admin": {"accessible": false}
  }
}
```

---

## 🔍 **Automated Test Validation**

### **Test Scripts Included**

#### **Status Code Tests**
```javascript
pm.test('Status code is 200', function () {
    pm.response.to.have.status(200);
});
```

#### **Role Hierarchy Tests**
```javascript
pm.test('ADMIN can access USER endpoints (role hierarchy)', function () {
    pm.response.to.have.status(200);
});

pm.test('USER cannot access ADMIN endpoints (access control)', function () {
    pm.expect(pm.response.code).to.be.oneOf([401, 403]);
});
```

#### **Response Structure Tests**
```javascript
pm.test('Response contains role information', function () {
    const responseJson = pm.response.json();
    pm.expect(responseJson.roleInformation).to.be.an('object');
    pm.expect(responseJson.permissions).to.be.an('object');
});
```

---

## 📊 **Expected Test Results**

### **✅ Access Control Matrix**

| Role | Public | User | Admin | Super Admin |
|------|--------|------|-------|-------------|
| **Anonymous** | ✅ 200 | ❌ 401 | ❌ 401 | ❌ 401 |
| **USER** | ✅ 200 | ✅ 200 | ❌ 403 | ❌ 403 |
| **ADMIN** | ✅ 200 | ✅ 200 | ✅ 200 | ❌ 403 |
| **SUPER_ADMIN** | ✅ 200 | ✅ 200 | ✅ 200 | ✅ 200 |

### **📈 Performance Expectations**
- Response times < 2 seconds
- Consistent role hierarchy behavior
- Proper error messages for access denials

---

## 🛠️ **Troubleshooting**

### **Common Issues**

#### **🔴 401 Unauthorized**
```
Problem: JWT token missing or invalid
Solution: Run login requests to get fresh tokens
Check: Token expiration (10 hours default)
```

#### **🔴 403 Forbidden**
```
Problem: Insufficient role permissions
Solution: Use appropriate role token (USER → ADMIN → SUPER_ADMIN)
Check: Role hierarchy requirements
```

#### **🔴 404 Not Found**
```
Problem: Endpoint not available or incorrect URL
Solution: Check base_url variable and endpoint paths
Check: Application is running on correct port
```

#### **🔴 500 Internal Server Error**
```
Problem: Application error or database issue
Solution: Check application logs
Check: Role initialization completed successfully
```

### **🔧 Debug Tools**

#### **JWT Token Debug**
```http
GET {{base_url}}/api/test/jwt/debug
Authorization: Bearer {{jwt_token}}
```
Shows token contents, roles, expiration.

#### **Health Check**
```http
GET {{base_url}}/actuator/health
```
Verifies application health.

#### **Application Info**
```http
GET {{base_url}}/actuator/info
```
Shows application version and configuration.

---

## 💡 **Best Practices**

### **1. Test Organization**
- Run public endpoints first
- Test role hierarchy systematically (USER → ADMIN → SUPER_ADMIN)
- Use automated tests for consistent validation

### **2. Token Management**
- Keep tokens organized in environment variables
- Refresh tokens when they expire
- Use role-specific tokens for accurate testing

### **3. Error Validation**
- Verify proper error codes (401, 403, 404)
- Check error message content
- Test edge cases (invalid roles, expired tokens)

### **4. Performance Testing**
- Monitor response times
- Test with concurrent requests
- Validate under load

---

## 📞 **Support**

### **Need Help?**
- Check application logs for detailed error messages
- Verify role initialization completed successfully
- Ensure database contains proper role data
- Test with fresh JWT tokens

### **Role Data Verification**
```sql
SELECT roleid, rolename, rolenumber, roledescription, scope 
FROM role 
ORDER BY rolenumber;
```

Expected results:
- User (100, Application)
- Admin (200, Application)  
- Super Admin (300, Global)

---

**Happy Testing! 🚀**

*This guide ensures comprehensive testing of your role-based access control system.*
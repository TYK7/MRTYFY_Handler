---
description: Repository Information Overview
alwaysApply: true
---

# BrandSnap API Information

## Summary
BrandSnap API is an API-first platform for retrieving brand identity information using domain names. It provides JWT authentication, API key management, rate limiting, and comprehensive analytics for tracking API usage. The system includes user management, brand data extraction, and dashboard functionality.

## Structure
- **src/main/java**: Core Java source code organized in MVC pattern
- **src/main/resources**: Configuration files, properties, and static resources
- **src/test**: Test classes and test configuration
- **database**: SQL scripts for dashboard views and database setup
- **docs**: Comprehensive documentation for API usage and integration
- **postman**: Postman collections for testing API endpoints
- **ProjectDocInfo**: Additional project documentation and guides

## Language & Runtime
**Language**: Java
**Version**: Java 21
**Build System**: Maven
**Package Manager**: Maven
**Framework**: Spring Boot 3.2.0

## Dependencies
**Main Dependencies**:
- Spring Boot Starters (Web, Security, Data JPA, Validation, Mail)
- PostgreSQL for database
- JWT (io.jsonwebtoken:jjwt) for authentication
- Bucket4j for rate limiting
- Caffeine for caching
- Google API Client for OAuth2 integration
- SpringDoc OpenAPI for API documentation

**Development Dependencies**:
- Spring Boot Test
- JUnit Jupiter
- Spring Security Test
- Lombok for reducing boilerplate code

## Build & Installation
```bash
mvn clean install
mvn spring-boot:run
```

## Testing
**Framework**: JUnit Jupiter with Spring Boot Test
**Test Location**: src/test/java
**Naming Convention**: *Test.java and *Tests.java
**Configuration**: application-test.properties, junit-platform.properties
**Run Command**:
```bash
mvn test
```

## Database
**Type**: PostgreSQL
**Configuration**: 
- Spring Data JPA with Hibernate
- Connection pooling with HikariCP
- Database views for dashboard analytics

## Security Features
**Authentication**: 
- JWT-based authentication
- API key authentication for external services
- Google OAuth2 integration
- Two-factor authentication support

**Authorization**:
- Role-based access control
- API key scopes and domain validation
- Rate limiting based on user plans

## API Features
**Core Functionality**:
- Brand information retrieval by domain
- User management and authentication
- API key management and analytics
- Usage tracking and rate limiting
- Dashboard for monitoring API usage

**Integration Points**:
- External file storage via SFTP
- Email notifications
- Google authentication
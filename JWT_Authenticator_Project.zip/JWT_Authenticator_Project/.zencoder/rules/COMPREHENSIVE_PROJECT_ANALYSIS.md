# 🚀 BrandSnap API - Comprehensive Project Analysis & Reference

## 📋 Table of Contents
1. [Project Overview](#project-overview)
2. [Architecture & Technology Stack](#architecture--technology-stack)
3. [Database Schema & Entities](#database-schema--entities)
4. [API Endpoints Reference](#api-endpoints-reference)
5. [Security & Authentication](#security--authentication)
6. [Service Layer Architecture](#service-layer-architecture)
7. [Configuration & Deployment](#configuration--deployment)
8. [Testing Framework](#testing-framework)
9. [Monitoring & Analytics](#monitoring--analytics)
10. [Feature Breakdown](#feature-breakdown)

---

## 🎯 Project Overview

**BrandSnap API** is a comprehensive, API-first platform for retrieving brand identity information using domain names. It combines JWT authentication, API key management, rate limiting, and advanced analytics.

### Core Value Proposition
- **Brand Intelligence**: Extract brand data, assets, colors, fonts from any domain
- **Secure API Access**: JWT + API Key dual authentication system
- **Enterprise-Ready**: Role-based access control, rate limiting, analytics
- **Scalable Architecture**: Spring Boot 3.2.0 with Java 21

### Key Statistics
- **40+ Controllers** handling different API endpoints
- **28+ Entities** managing complex business data
- **60+ Services** providing business logic
- **Comprehensive Testing** with JUnit Jupiter
- **PostgreSQL** database with optimized connection pooling
- **Multi-tier** rate limiting (FREE/PRO/BUSINESS)

---

## 🏗️ Architecture & Technology Stack

### Core Framework
```yaml
Framework: Spring Boot 3.2.0
Language: Java 21
Build System: Maven
Package: com.example.jwtauthenticator
Database: PostgreSQL
```

### Key Dependencies
```xml
<!-- Authentication & Security -->
io.jsonwebtoken:jjwt:0.12.3
spring-boot-starter-security
spring-boot-starter-oauth2-client

<!-- Database & JPA -->
spring-boot-starter-data-jpa
postgresql:runtime

<!-- Rate Limiting & Caching -->
bucket4j-core:8.0.1
caffeine:3.1.8

<!-- Monitoring & Documentation -->
spring-boot-starter-actuator
springdoc-openapi-starter-webmvc-ui:2.2.0

<!-- File Transfer & Storage -->
jsch:0.1.55 (SFTP)
```

### Architectural Patterns
- **MVC Pattern**: Controllers → Services → Repositories
- **Aspect-Oriented Programming**: Security annotations, logging
- **Event-Driven**: Email notifications, async processing
- **Repository Pattern**: Spring Data JPA repositories
- **Strategy Pattern**: Multiple file storage implementations
- **Factory Pattern**: ID generation, rate limiting

---

## 🗄️ Database Schema & Entities

### Core Business Entities

#### 👤 **User Management**
```java
@Entity User {
    String id;           // Primary key: DOMBR000001 format
    UUID userId;         // UUID for internal operations
    String username;     // Unique username
    String email;        // Unique email
    String password;     // Encrypted password
    Role role;           // RBAC role relationship
    Company company;     // Multi-tenancy support
    UserPlan plan;       // FREE/PRO/BUSINESS
    LocalDateTime createdAt;
    // ... profile fields
}

@Entity Role {
    String roleId;       // Primary key
    String roleName;     // ROLE_USER, ROLE_ADMIN, ROLE_SUPER_ADMIN
    String description;
    Set<String> permissions;
}

@Entity Company {
    String companyId;    // Primary key
    String companyName;
    String domain;
    String contactEmail;
    // ... company details
}
```

#### 🔑 **API Key Management**
```java
@Entity ApiKey {
    UUID id;
    String keyHash;          // SHA-256 hash of actual key
    String keyPreview;       // Masked display version
    String userFkId;         // Foreign key to User.id
    String name;
    String description;
    boolean isActive;
    LocalDateTime expiresAt;
    String allowedIps;       // JSON array
    String registeredDomain; // Primary domain
    String allowedDomains;   // Additional domains
    RateLimitTier rateLimitTier;
    ApiKeyEnvironment environment;
    String scopes;           // Comma-separated ApiKeyScope values
    LocalDateTime createdAt;
    LocalDateTime lastUsedAt;
}

@Entity ApiKeyUsageStats {
    // Monthly usage tracking
    UUID apiKeyId;
    int year;
    int month;
    int totalRequests;
    int successfulRequests;
    int errorRequests;
    LocalDateTime lastUpdated;
}

@Entity ApiKeyRequestLog {
    // Detailed request logging
    UUID id;
    UUID apiKeyId;
    String endpoint;
    String method;
    String ipAddress;
    int responseStatus;
    long responseTimeMs;
    LocalDateTime requestTimestamp;
}
```

#### 🏢 **Brand Data Model**
```java
@Entity Brand {
    Long id;
    String name;
    String website;         // Unique domain
    String description;
    String industry;
    String location;
    String founded;
    Long categoryId;        // Business category
    Long subCategoryId;
    String specialties;     // JSON array
    String companyLocations;// JSON array
    String companyId;       // Relationship to Company
    LocalDateTime createdAt;
    LocalDateTime updatedAt;
    
    // Relationships
    List<BrandAsset> assets;
    List<BrandColor> colors;
    List<BrandFont> fonts;
    List<BrandSocialLink> socialLinks;
    List<BrandImage> images;
}

@Entity BrandAsset {
    Long id;
    Long brandId;
    String fileName;
    String filePath;
    String fileUrl;
    String assetType;       // LOGO, ICON, BANNER, etc.
    String mimeType;
    Long fileSize;
    LocalDateTime uploadedAt;
}

@Entity BrandColor {
    Long id;
    Long brandId;
    String colorType;       // PRIMARY, SECONDARY, ACCENT
    String hexCode;
    String usage;           // Description of color usage
}
```

#### 📊 **Analytics & Monitoring**
```java
@Entity ApiKeyMonthlyUsage {
    UUID id;
    UUID apiKeyId;
    String userFkId;
    int year;
    int month;
    int currentUsage;
    int monthlyLimit;
    LocalDateTime resetAt;
    LocalDateTime lastUpdated;
}

@Entity RivoFetchRequestLog {
    UUID id;
    String endpoint;
    String method;
    String parameters;
    int responseStatus;
    long processingTimeMs;
    String errorMessage;
    LocalDateTime requestTimestamp;
}

@Entity LoginLog {
    UUID id;
    String userFkId;
    String loginMethod;     // PASSWORD, GOOGLE_OAUTH, API_KEY
    String ipAddress;
    String userAgent;
    boolean successful;
    LocalDateTime loginTimestamp;
}
```

### Enum Definitions

#### 🔐 **ApiKeyScope** (60+ Scopes)
```java
// Basic Permissions
READ_BASIC, READ_ADVANCED, READ_USERS, READ_BRANDS
WRITE_BASIC, WRITE_ADVANCED, WRITE_USERS, WRITE_BRANDS
DELETE_USERS, DELETE_BRANDS, DELETE_CATEGORIES

// Admin & System
ADMIN_ACCESS, SYSTEM_MONITOR, FULL_ACCESS

// Business API
BUSINESS_READ, BUSINESS_WRITE, SERVER_ACCESS

// Domain & Analytics
DOMAIN_HEALTH, DOMAIN_INSIGHTS, AI_SUMMARIES
ANALYTICS_READ, ANALYTICS_WRITE

// Special Permissions
DOMAINLESS_ACCESS, INTERNAL_API
```

#### 🎯 **Rate Limit Tiers**
```java
FREE_TIER:      100 requests/month
PRO_TIER:       1,000 requests/month  
BUSINESS_TIER:  Unlimited requests
```

---

## 🌐 API Endpoints Reference

### **Authentication Endpoints** (`/auth/`)
```http
POST   /auth/register              # User registration
POST   /auth/login                 # Username/password login
POST   /auth/login/email           # Email-based login
POST   /auth/token                 # JWT token refresh
POST   /auth/google                # Google OAuth login
POST   /auth/forgot-password       # Password reset request
POST   /auth/reset-password        # Password reset confirmation
POST   /auth/tfa/setup             # 2FA setup
POST   /auth/tfa/verify            # 2FA verification
GET    /auth/check-username        # Username availability
GET    /auth/check-email           # Email availability
POST   /auth/public-forward        # Public brand info (rate-limited)
```

### **API Key Management** (`/api/v1/api-keys/`)
```http
GET    /api/v1/api-keys/           # List user's API keys
POST   /api/v1/api-keys/           # Create new API key
PUT    /api/v1/api-keys/{id}       # Update API key
DELETE /api/v1/api-keys/{id}       # Delete API key
POST   /api/v1/api-keys/{id}/revoke# Revoke API key
GET    /api/v1/api-keys/{id}/usage # Usage statistics
GET    /api/v1/api-keys/{id}/logs  # Request logs
```

### **External/Secure API** (`/api/external/`, `/api/secure/`)
```http
GET    /api/external/users         # Read users (API Key + READ_USERS scope)
POST   /api/external/users         # Create user (API Key + WRITE_USERS scope)
GET    /api/secure/brand-info      # Brand information (API Key protected)
GET    /api/secure/categories      # Category hierarchy
POST   /api/secure/analytics       # Analytics data submission
```

### **Brand Data Endpoints** (`/api/brands/`)
```http
GET    /api/brands/{id}            # Get brand by ID
GET    /api/brands/by-website      # Get brand by domain
GET    /api/brands/all             # List all brands (paginated)
GET    /api/brands/search          # Search brands
GET    /api/brands/assets/{id}     # Download brand assets
GET    /api/brands/images/{id}     # Download brand images
POST   /api/brands/admin/extract   # Admin: Trigger brand extraction
```

### **Dashboard & Analytics** (`/api/v1/dashboard/`)
```http
GET    /api/v1/dashboard/overview  # User dashboard summary
GET    /api/v1/dashboard/usage     # Usage statistics
GET    /api/v1/dashboard/api-keys  # API key analytics
GET    /api/v1/dashboard/requests  # Request history
GET    /api/v1/dashboard/admin/    # Admin dashboard (ROLE_ADMIN+)
```

### **User Management** (`/api/users/`)
```http
GET    /api/users/profile          # Get user profile
PUT    /api/users/profile          # Update profile
POST   /api/users/change-password  # Change password
POST   /api/users/upload-avatar    # Upload profile image
GET    /api/users/activity         # User activity log
```

### **Admin Endpoints** (`/api/admin/`)
```http
GET    /api/admin/users            # List all users (ROLE_ADMIN+)
GET    /api/admin/api-keys         # Manage all API keys
GET    /api/admin/analytics        # System analytics
POST   /api/admin/quota-reset      # Manual quota reset
GET    /api/admin/system-health    # System monitoring
```

### **Testing & Development** (`/test/`)
```http
GET    /test/jwt-validation        # Test JWT token validity
GET    /test/api-key-validation    # Test API key validity
GET    /test/rate-limiting         # Test rate limiting
POST   /test/brand-extraction      # Test brand extraction
```

---

## 🔒 Security & Authentication

### Authentication Methods

#### 1. **JWT Authentication** (User Management)
```http
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```
- **Used for**: User dashboard, API key management, admin functions
- **Token contains**: userId, username, role, expiration
- **Expiration**: 10 hours (configurable)
- **Refresh**: 7 days refresh token

#### 2. **API Key Authentication** (External APIs)
```http
X-API-Key: sk-1234567890abcdef...
# OR
Authorization: Bearer sk-1234567890abcdef...
```
- **Used for**: External integrations, business APIs
- **Features**: Scope-based permissions, rate limiting, domain validation
- **Tracking**: Usage analytics, request logging

#### 3. **Google OAuth Integration**
```http
POST /auth/google
{
  "tokenId": "google-jwt-token",
  "email": "user@domain.com"
}
```

### Security Filters Chain
```java
1. ApiKeyAuthenticationFilter    # Process API key authentication
2. JwtRequestFilter             # Process JWT tokens  
3. ExternalApiSecurityFilter    # Domain/IP validation for external APIs
```

### Role-Based Access Control (RBAC)
```yaml
ROLE_USER:       # Basic user permissions
  - /api/users/**
  - /api/v1/api-keys/**
  - /api/v1/dashboard/**

ROLE_ADMIN:      # Admin permissions (includes USER)
  - /api/admin/**
  - /api/roles/**
  - /api/companies/**
  - /api/brands/admin/**

ROLE_SUPER_ADMIN: # Super admin (includes ADMIN)
  - /api/super/**
  - /api/id-generator/**
  - Full system access
```

### API Key Scopes & Permissions
```java
// Scope validation using annotations
@RequireApiKeyScope(ApiKeyScope.READ_USERS)
public ResponseEntity<?> getUsers() { ... }

@RequireApiKeyScope({ApiKeyScope.WRITE_USERS, ApiKeyScope.ADMIN_ACCESS})
public ResponseEntity<?> createUser() { ... }
```

### Rate Limiting Strategy
```java
// Monthly-based rate limiting
FREE_TIER:      100 requests/month
PRO_TIER:       1,000 requests/month
BUSINESS_TIER:  Unlimited

// Rate limiting headers
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 847
X-RateLimit-Reset: 1672531200
X-RateLimit-Tier: PRO_TIER
```

---

## ⚙️ Service Layer Architecture

### Core Service Categories

#### **Authentication Services**
- **AuthService**: User login, registration, JWT generation
- **GoogleTokenVerificationService**: Google OAuth integration
- **PasswordResetService**: Password reset workflow
- **TfaService**: Two-factor authentication management

#### **API Key Management Services**
- **ApiKeyService**: CRUD operations for API keys
- **EnhancedApiKeyService**: Advanced key management
- **ApiKeyAuthenticationService**: Key validation & authentication
- **ApiKeyStatisticsService**: Usage analytics
- **ApiKeyCleanupService**: Automated cleanup of expired keys

#### **Brand Data Services**
- **BrandInfoService**: Core brand information retrieval
- **BrandExtractionService**: Automated brand data extraction
- **BrandDataService**: Brand CRUD operations
- **BrandManagementService**: Advanced brand management
- **BrandOptimizedService**: Performance-optimized queries

#### **Rate Limiting & Usage Services**
- **RateLimiterService**: General rate limiting
- **ProfessionalRateLimitService**: Advanced rate limiting
- **MonthlyUsageTrackingService**: Usage tracking
- **StreamlinedUsageTracker**: Optimized usage tracking

#### **File Storage Services**
- **FileStorageService**: Abstract file storage interface
- **SftpFileStorageService**: SFTP-based storage
- **HttpFileStorageService**: HTTP-based storage
- **RemoteFileStorageService**: Generic remote storage

#### **Analytics & Monitoring Services**
- **ApiKeyDashboardService**: Dashboard data aggregation
- **UnifiedDashboardService**: Unified analytics
- **UsageStatsService**: Usage statistics
- **RequestLoggingService**: Request/response logging
- **ConnectionPoolHealthService**: Database monitoring

#### **Utility Services**
- **IdGeneratorService**: Unique ID generation (MRTFY000001, DOMBR000001)
- **EmailService**: Email notifications
- **DomainValidationService**: Domain validation
- **RequestContextExtractorService**: Request metadata extraction

### Service Integration Patterns

#### **Event-Driven Architecture**
```java
@EventListener
public void handleUserRegistration(UserRegistrationEvent event) {
    emailService.sendWelcomeEmail(event.getUser());
    analyticsService.trackUserSignup(event.getUser());
}
```

#### **Async Processing**
```java
@Async
public CompletableFuture<BrandData> extractBrandDataAsync(String domain) {
    // Heavy brand extraction work
    return CompletableFuture.completedFuture(brandData);
}
```

#### **Caching Strategy**
```java
@Cacheable(value = "brandData", key = "#domain")
public BrandData getBrandByDomain(String domain) { ... }

@CacheEvict(value = "brandData", key = "#domain")
public void updateBrandData(String domain, BrandData data) { ... }
```

---

## 🔧 Configuration & Deployment

### Configuration Files

#### **application.properties** (Main Config)
```properties
# Server Configuration
server.address=0.0.0.0
server.port=${PORT:8080}
server.servlet.context-path=/myapp

# Database
spring.profiles.active=postgres

# JWT Configuration
jwt.secret=${JWT_SECRET:your-secret-key}
jwt.expiry-seconds=${JWT_EXPIRY_SECONDS:36000}

# File Storage
app.file-storage.type=sftp
app.file-storage.remote.host=${SFTP_HOST:202.65.155.125}

# Rate Limiting
app.quota.reset.enabled=true
app.quota.reset.cron=0 1 0 1 * ?
```

#### **application-postgres.properties** (Database)
```properties
# PostgreSQL Configuration
spring.datasource.url=jdbc:postgresql://202.65.155.115:5432/postgres
spring.datasource.username=postgres
spring.datasource.password=Marketyfy@123

# Connection Pool Optimization
spring.datasource.hikari.maximum-pool-size=40
spring.datasource.hikari.minimum-idle=10
spring.datasource.hikari.connection-timeout=5000
spring.datasource.hikari.idle-timeout=300000
spring.datasource.hikari.max-lifetime=480000

# JPA Configuration
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
```

### Build & Deployment

#### **Maven Configuration** (pom.xml)
```xml
<groupId>com.brandsnapapi</groupId>
<artifactId>brandsnap-api</artifactId>
<version>0.0.1-SNAPSHOT</version>
<packaging>war</packaging>

<properties>
    <java.version>21</java.version>
    <jjwt.version>0.12.3</jjwt.version>
    <springdoc.version>2.2.0</springdoc.version>
</properties>
```

#### **Build Commands**
```bash
# Clean and compile
mvn clean install

# Run application
mvn spring-boot:run

# Run tests
mvn test

# Package for deployment
mvn clean package
```

#### **Docker Deployment** (Planned)
```dockerfile
FROM openjdk:21-jdk-slim
COPY target/brandsnap-api-0.0.1-SNAPSHOT.war app.war
EXPOSE 8080
ENTRYPOINT ["java","-jar","/app.war"]
```

### Environment Variables
```bash
# Database
DB_HOST=202.65.155.115
DB_PORT=5432
DB_NAME=postgres
DB_USERNAME=postgres
DB_PASSWORD=Marketyfy@123

# JWT
JWT_SECRET=your-super-secure-secret-key
JWT_EXPIRY_SECONDS=36000

# SFTP Storage
SFTP_HOST=202.65.155.125
SFTP_USERNAME=ubuntu
SFTP_PASSWORD=sAFtR6r06nmH

# Google OAuth
GOOGLE_CLIENT_ID=333815600502-fcfheqik99ceft5sq5nk4f8ae5aialec.apps.googleusercontent.com

# Email
MAIL_USERNAME=tyedukondalu@stratapps.com
MAIL_PASSWORD=whesvjdtjmyhgwwt
```

---

## 🧪 Testing Framework

### Test Structure
```
src/test/java/com/example/jwtauthenticator/
├── controller/          # Controller unit tests
├── service/            # Service layer tests  
├── repository/         # Repository tests
├── integration/        # Integration tests
├── security/           # Security tests
└── util/              # Utility tests
```

### Testing Configuration

#### **JUnit Platform** (junit-platform.properties)
```properties
junit.jupiter.displayname.generator.default=org.junit.jupiter.api.DisplayNameGenerator$ReplaceUnderscores
junit.jupiter.execution.parallel.enabled=false
junit.jupiter.testinstance.lifecycle.default=per_class
```

#### **Test Application Properties** (application-test.properties)
```properties
spring.profiles.active=test
spring.datasource.url=jdbc:h2:mem:testdb
spring.jpa.hibernate.ddl-auto=create-drop
logging.level.org.springframework.security=DEBUG
```

### Test Categories

#### **Unit Tests**
- Service layer business logic
- Utility functions
- Entity validation
- JWT token generation/validation

#### **Integration Tests**
- Controller endpoint testing
- Database operations
- Security filters
- API key authentication flow

#### **Security Tests**
- Authentication mechanisms
- Authorization checks
- Rate limiting
- Input validation

### Maven Test Configuration
```xml
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-surefire-plugin</artifactId>
    <version>3.1.2</version>
    <configuration>
        <includes>
            <include>**/*Test.java</include>
            <include>**/*Tests.java</include>
        </includes>
        <systemPropertyVariables>
            <spring.profiles.active>test</spring.profiles.active>
        </systemPropertyVariables>
    </configuration>
</plugin>
```

---

## 📊 Monitoring & Analytics

### Application Monitoring

#### **Spring Boot Actuator Endpoints**
```http
GET /actuator/health              # Application health
GET /actuator/info                # Application info
GET /actuator/metrics             # Application metrics
GET /actuator/hikaricp            # Database pool metrics
```

#### **Custom Health Checks**
- **DatabaseHealthIndicator**: Database connectivity
- **SftpHealthIndicator**: SFTP storage connectivity
- **RateLimitHealthIndicator**: Rate limiting service health

### Analytics Features

#### **API Usage Analytics**
```java
@Entity ApiKeyRequestLog {
    UUID apiKeyId;
    String endpoint;
    String method;
    int responseStatus;
    long responseTimeMs;
    String ipAddress;
    LocalDateTime requestTimestamp;
}
```

#### **Dashboard Metrics**
- Total API calls (monthly/daily)
- Success vs error rates
- Response time analytics
- Top used endpoints
- API key usage distribution
- Rate limit violations

#### **User Analytics**
- Registration trends
- Login patterns
- Feature usage
- Plan distribution
- Geographic distribution (IP-based)

### Logging Configuration

#### **Logback Configuration**
```xml
<!-- Multiple log files by category -->
<appender name="API_LOG" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <file>logs/brandsnap-api-api.log</file>
    <filter class="ch.qos.logback.classic.filter.LevelFilter">
        <level>INFO</level>
        <onMatch>ACCEPT</onMatch>
        <onMismatch>DENY</onMismatch>
    </filter>
</appender>

<!-- Separate log files -->
logs/brandsnap-api-application.log   # General application
logs/brandsnap-api-security.log      # Security events
logs/brandsnap-api-database.log      # Database operations
logs/brandsnap-api-api.log           # API requests
logs/brandsnap-api-error.log         # Error events
logs/brandsnap-api-performance.log   # Performance metrics
```

#### **Request Logging**
```java
@Aspect
@Component
public class RequestLoggingAspect {
    @Around("@annotation(LogExecutionTime)")
    public Object logExecutionTime(ProceedingJoinPoint joinPoint) {
        // Log request details, execution time, response status
    }
}
```

---

## 🎯 Feature Breakdown

### **Core Features Implemented** ✅

#### 1. **User Authentication System**
- JWT-based authentication with refresh tokens
- Google OAuth2 integration
- Password reset workflow with email verification
- Two-factor authentication (2FA) support
- Username/email availability checking
- Session management and security

#### 2. **API Key Management**
- Complete CRUD operations for API keys
- Scope-based permissions (60+ scopes)
- Domain validation and IP whitelisting
- API key analytics and usage tracking
- Automated key cleanup and expiration
- Rate limiting per key tier

#### 3. **Brand Data Extraction**
- Automated brand information extraction from domains
- Brand assets collection (logos, images, fonts)
- Color palette extraction
- Social media links discovery
- Brand categorization
- File storage integration (SFTP/HTTP/Local)

#### 4. **Rate Limiting System**
- Multi-tier rate limiting (FREE/PRO/BUSINESS)
- Monthly quota management
- Real-time usage tracking
- Automated quota resets
- Usage analytics and reporting
- Rate limit headers in responses

#### 5. **Role-Based Access Control (RBAC)**
- Hierarchical role system (USER → ADMIN → SUPER_ADMIN)
- Method-level security annotations
- Dynamic role assignment
- Company-based multi-tenancy
- Granular permission management

#### 6. **Analytics & Dashboard**
- User dashboard with usage statistics
- Admin dashboard for system monitoring
- API key performance analytics
- Request/response logging
- Error tracking and reporting
- Real-time metrics

#### 7. **File Management System**
- Multiple storage backends (SFTP, HTTP, Local)
- Brand asset management
- User profile image upload
- File upload/download APIs
- Storage quota management

#### 8. **Email System**
- Welcome emails for new users
- Password reset emails
- Quota notification emails
- Email template system (FreeMarker)
- SMTP configuration

### **Advanced Features** 🚀

#### 9. **Connection Pool Optimization**
- HikariCP configuration for PostgreSQL
- Connection leak detection
- Pool size optimization (40 max connections)
- Health monitoring
- Performance metrics

#### 10. **Async Processing**
- Asynchronous brand extraction
- Background email sending
- Async analytics processing
- Configurable thread pools

#### 11. **Caching Strategy**
- Caffeine cache integration
- Brand data caching
- User session caching
- Cache eviction policies

#### 12. **Security Hardening**
- HTTPS enforcement
- HSTS headers
- Frame options security
- Input validation and sanitization
- SQL injection prevention
- XSS protection

#### 13. **API Documentation**
- OpenAPI 3.0 specification
- Swagger UI integration
- Comprehensive endpoint documentation
- Request/response examples
- Authentication guides

#### 14. **Testing Infrastructure**
- Comprehensive unit test suite
- Integration testing
- Security testing
- Performance testing
- Test data management

### **Planned Features** 🔄

#### 15. **Microservices Architecture**
- Service decomposition
- Inter-service communication
- Service discovery
- Circuit breaker pattern

#### 16. **Enhanced Analytics**
- Machine learning insights
- Predictive analytics
- Advanced reporting
- Data export capabilities

#### 17. **Mobile API Support**
- Mobile-optimized endpoints
- Push notification system
- Offline sync capabilities

---

## 🔍 Quick Reference for Development

### **Common Development Tasks**

#### **Adding New API Endpoint**
1. Create controller method with proper annotations
2. Add security configuration in SecurityConfig
3. Implement service layer logic
4. Add request/response DTOs
5. Write unit and integration tests
6. Update API documentation

#### **Adding New Entity**
1. Create entity class with JPA annotations
2. Create repository interface
3. Add database migration (if needed)
4. Create service layer methods
5. Add validation and constraints
6. Write repository tests

#### **Debugging Authentication Issues**
1. Check JWT token validity in logs
2. Verify API key scopes and permissions
3. Review security filter chain order
4. Test with /test/jwt-validation endpoint
5. Check rate limiting status

#### **Performance Optimization**
1. Monitor database connection pool usage
2. Check query performance with EXPLAIN
3. Review cache hit rates
4. Analyze async processing performance
5. Monitor memory usage and GC

### **Important File Locations**
```
Configuration Files:
├── src/main/resources/application.properties
├── src/main/resources/application-postgres.properties
├── src/main/resources/application-security-features.yml
└── src/main/resources/application-dynamic-auth.yml

Security Configuration:
├── src/main/java/.../config/SecurityConfig.java
├── src/main/java/.../security/JwtRequestFilter.java
├── src/main/java/.../security/ApiKeyAuthenticationFilter.java
└── src/main/java/.../util/JwtUtil.java

Key Controllers:
├── src/main/java/.../controller/AuthController.java
├── src/main/java/.../controller/ApiKeyController.java  
├── src/main/java/.../controller/ExternalApiController.java
├── src/main/java/.../controller/BrandController.java
└── src/main/java/.../controller/DashboardController.java

Core Services:
├── src/main/java/.../service/AuthService.java
├── src/main/java/.../service/ApiKeyService.java
├── src/main/java/.../service/BrandInfoService.java
├── src/main/java/.../service/RateLimiterService.java
└── src/main/java/.../service/UserService.java
```

### **Quick Commands**
```bash
# Build and run
mvn clean install && mvn spring-boot:run

# Run tests
mvn test

# Check dependency tree
mvn dependency:tree

# Generate site documentation
mvn site

# Database migration check
mvn flyway:info
```

---

## 📞 Support & Maintenance

### **Troubleshooting Guide**

#### **Common Issues & Solutions**
1. **Connection Pool Exhaustion**: Check HikariCP metrics, optimize queries
2. **JWT Token Expiration**: Implement proper token refresh mechanism
3. **Rate Limit Exceeded**: Review user plan and usage patterns
4. **SFTP Connection Failed**: Check network connectivity and credentials
5. **Database Lock Timeout**: Optimize transaction boundaries

#### **Monitoring Checklist**
- [ ] Database connection pool health
- [ ] API response times < 2s
- [ ] Error rate < 1%
- [ ] Memory usage < 80%
- [ ] Disk space for logs and assets
- [ ] SFTP storage connectivity

#### **Security Checklist**
- [ ] JWT secret rotation
- [ ] API key expiration enforcement
- [ ] Failed login attempt monitoring
- [ ] SQL injection protection tests
- [ ] Rate limiting effectiveness
- [ ] HTTPS certificate renewal

This comprehensive analysis serves as the definitive reference for understanding, maintaining, and extending the BrandSnap API project. Keep this document updated as the project evolves.

---

*Last Updated: December 2024*
*Version: 1.0*
*Project: BrandSnap API - JWT_Authenticator_Project*
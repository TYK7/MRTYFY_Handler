# Secure API Access Documentation

## 🔐 **Overview**

The Secure API Access system provides domain-based access control for API keys, supporting all domain types including `.com`, `.org`, `.io`, `.in`, `.co`, etc. This system ensures that API keys can only be used from registered domains, providing an additional layer of security.

## 🌐 **Supported Domain Types**

The system supports all common TLD types:
- **Generic TLDs**: `.com`, `.org`, `.net`, `.edu`, `.gov`, `.mil`, `.int`
- **Country Code TLDs**: `.in`, `.co`, `.uk`, `.de`, `.fr`, `.au`, `.ca`, `.br`, etc.
- **New gTLDs**: `.io`, `.ai`, `.me`, `.ly`, `.be`, `.it`, `.app`, `.dev`, `.tech`, etc.
- **Specialized TLDs**: `.info`, `.biz`, `.name`, `.pro`, `.museum`, `.travel`, `.jobs`

### **Example Supported Domains**:
- `xamply.com`
- `xamplyfy.co`
- `xamplyfy.in`
- `api.mycompany.org`
- `app.startup.io`
- `dashboard.business.ai`

## 🚀 **Quick Start**

### **1. Create API Key with Domain**

```bash
curl -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "My Production API Key",
    "description": "API key for production website",
    "registeredDomain": "xamply.com",
    "rateLimitTier": "STANDARD"
  }'
```

**Response:**
```json
{
  "id": "123e4567-e89b-12d3-a456-426614174000",
  "name": "My Production API Key",
  "keyValue": "sk-1234567890abcdef..."
}
```

### **2. Use API Key for Secure Access**

```bash
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: sk-1234567890abcdef..." \
  -H "Origin: https://xamply.com" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://external-api.example.com/data"
  }'
```

## 📚 **API Endpoints**

### **Management Endpoints (JWT Authentication)**

#### **Create API Key with Domain**
```
POST /api/v1/api-keys/with-domain
Authorization: Bearer JWT_TOKEN
```

**Request Body:**
```json
{
  "name": "string (required)",
  "description": "string (optional)",
  "registeredDomain": "string (required) - e.g., xamply.com, xamplyfy.co, xamplyfy.in",
  "rateLimitTier": "BASIC|STANDARD|PREMIUM|ENTERPRISE|UNLIMITED",
  "allowedIps": ["string"] (optional),
  "allowedDomains": ["string"] (optional - for future hybrid approach),
  "scopes": ["string"] (optional),
  "expiresAt": "2024-12-31T23:59:59" (optional)
}
```

#### **Update API Key Domain**
```
PUT /api/v1/api-keys/{keyId}/domain
Authorization: Bearer JWT_TOKEN
```

**Request Body:**
```json
{
  "domain": "new-domain.com"
}
```

#### **Get API Keys with Domains**
```
GET /api/v1/api-keys/with-domains
Authorization: Bearer JWT_TOKEN
```

#### **Check Domain Availability**
```
GET /api/v1/api-keys/domain/check?domain=example.com
Authorization: Bearer JWT_TOKEN
```

#### **Get Domain Suggestions**
```
GET /api/v1/api-keys/domain/suggestions?baseDomain=mycompany
Authorization: Bearer JWT_TOKEN
```

### **Secure Access Endpoints (API Key Authentication)**

#### **Secure Forward Request**
```
POST /api/secure/forward
x-api-key: YOUR_API_KEY
Origin: https://your-registered-domain.com
```

**Request Body:**
```json
{
  "url": "https://external-api.example.com/endpoint"
}
```

#### **Health Check**
```
GET /api/secure/health
x-api-key: YOUR_API_KEY
Origin: https://your-registered-domain.com
```

## 🔒 **Authentication & Security**

### **API Key Authentication**

1. **Header**: Use `x-api-key` header
2. **Domain Validation**: Request must include `Origin` or `Referer` header matching registered domain
3. **Rate Limiting**: Professional rate limiting based on API key tier

**Example Headers:**
```
x-api-key: sk-1234567890abcdef...
Origin: https://xamply.com
```

### **Domain Validation Process**

1. **Extract Domain**: From `Origin`, `Referer`, or `Host` headers (in priority order)
2. **Normalize Domain**: Convert to lowercase, remove `www` prefix
3. **Validate Format**: Ensure valid domain format with supported TLD
4. **Check Registration**: Verify domain matches API key's registered domain
5. **Fallback Check**: Check additional allowed domains (if configured)

### **Supported Domain Formats**

✅ **Valid Formats:**
- `example.com`
- `api.example.com`
- `app.startup.io`
- `dashboard.company.co`
- `service.business.in`
- `www.website.org` (normalized to `website.org`)

❌ **Invalid Formats:**
- `localhost` (for production)
- `192.168.1.1` (IP addresses)
- `example` (missing TLD)
- `example.` (trailing dot)

## 🚦 **Rate Limiting**

### **Rate Limit Tiers**

| Tier | Requests/Hour | Burst Limit | Additional Requests |
|------|---------------|-------------|-------------------|
| BASIC | 1,000 | 50 | 0 |
| STANDARD | 5,000 | 100 | 1,000 |
| PREMIUM | 25,000 | 500 | 5,000 |
| ENTERPRISE | 100,000 | 1,000 | 25,000 |
| UNLIMITED | ∞ | 2,000 | ∞ |

### **Rate Limit Headers**

```
X-RateLimit-Limit: 5000
X-RateLimit-Remaining: 4999
X-RateLimit-Reset: 1640995200
X-RateLimit-Tier: STANDARD
X-RateLimit-Total-Remaining: 5999
X-RateLimit-Additional-Available: 1000
```

## 🛠 **Error Handling**

### **Common Error Codes**

| HTTP Status | Error Code | Description |
|-------------|------------|-------------|
| 401 | `INVALID_API_KEY` | API key is invalid or expired |
| 401 | `MISSING_API_KEY` | API key header is missing |
| 403 | `DOMAIN_NOT_ALLOWED` | Request domain doesn't match registered domain |
| 403 | `MISSING_DOMAIN_HEADER` | Origin/Referer header is missing |
| 403 | `INVALID_FORMAT` | Domain format is invalid |
| 429 | `RATE_LIMIT_EXCEEDED` | Rate limit exceeded |
| 400 | `DOMAIN_ALREADY_EXISTS` | Domain already registered to another API key |

### **Error Response Format**

```json
{
  "error": "Domain validation failed",
  "status": 403,
  "errorCode": "DOMAIN_NOT_ALLOWED",
  "timestamp": "2024-01-15T10:30:00Z",
  "requestDomain": "unauthorized.com",
  "expectedDomain": "xamply.com",
  "suggestions": [
    "Ensure your request includes Origin or Referer header",
    "Verify your domain is registered for this API key",
    "Check that your domain format is correct"
  ]
}
```

## 🧪 **Testing Examples**

### **JavaScript/Browser Testing**

```javascript
// Using fetch API
const response = await fetch('http://localhost:8080/myapp/api/secure/forward', {
  method: 'POST',
  headers: {
    'x-api-key': 'sk-1234567890abcdef...',
    'Content-Type': 'application/json',
    // Origin header is automatically set by browser
  },
  body: JSON.stringify({
    url: 'https://external-api.example.com/data'
  })
});

const data = await response.json();
console.log(data);
```

### **Node.js Testing**

```javascript
const axios = require('axios');

const response = await axios.post(
  'http://localhost:8080/myapp/api/secure/forward',
  { url: 'https://external-api.example.com/data' },
  {
    headers: {
      'x-api-key': 'sk-1234567890abcdef...',
      'Origin': 'https://xamply.com'
    }
  }
);

console.log(response.data);
```

### **Python Testing**

```python
import requests

response = requests.post(
    'http://localhost:8080/myapp/api/secure/forward',
    json={'url': 'https://external-api.example.com/data'},
    headers={
        'x-api-key': 'sk-1234567890abcdef...',
        'Origin': 'https://xamply.com'
    }
)

print(response.json())
```

## 🔧 **Configuration**

### **Application Properties**

```properties
# Domain validation settings
app.security.domain-validation.enabled=true

# Request logging
app.analytics.request-logging.enabled=true
app.analytics.async-logging=true

# Rate limiting
app.rate-limit.enabled=true
app.rate-limit.apply-to-api-key=true
```

### **Dynamic Authentication Configuration**

```yaml
app:
  auth:
    method: both  # Support both JWT and API key
    api-key-header: x-api-key
    require-auth: true
    excluded-paths:
      - /api/secure/**  # Public endpoints with API key validation
```

## 🚀 **Migration Guide**

### **From Existing API Keys**

1. **Existing API keys** without registered domains will continue to work
2. **New API keys** must include a registered domain
3. **Domain registration** can be added to existing keys via update endpoint
4. **Backward compatibility** is maintained for existing integrations

### **Gradual Migration Steps**

1. **Phase 1**: Create new API keys with domains
2. **Phase 2**: Update existing API keys to include domains
3. **Phase 3**: Enable strict domain validation
4. **Phase 4**: Deprecate non-domain API keys

## 📊 **Monitoring & Analytics**

### **Request Logging**

All API key requests are logged with:
- API key ID
- Request domain
- Response time
- Success/failure status
- Error details (if any)

### **Security Monitoring**

- Domain validation failures
- Rate limit violations
- Invalid API key attempts
- Suspicious request patterns

## 🔮 **Future Enhancements**

### **Phase 2 Features** (Coming Soon):
- **Hybrid Approach**: Primary domain + additional allowed domains
- **Subdomain Wildcards**: `*.example.com` support
- **IP Allowlist Fallback**: Fallback to IP validation on domain failure
- **Enhanced Error Messages**: More detailed suggestions and help

### **Advanced Features** (Roadmap):
- **HMAC Signature Validation**: Additional security layer
- **Geo-blocking**: Country-based access control
- **Time-based Restrictions**: Schedule-based API access
- **Advanced Analytics**: Detailed usage reports and insights

---

## 📞 **Support**

For questions or issues:
1. Check the error response for detailed information
2. Verify domain registration and format
3. Ensure proper headers are included
4. Check rate limit status
5. Contact support with API key ID and error details

---

**Last Updated**: January 2024  
**Version**: 1.0.0
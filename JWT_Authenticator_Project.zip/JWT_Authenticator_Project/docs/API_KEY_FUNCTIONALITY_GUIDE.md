# 🔑 Complete API Key Functionality Guide for Angular Integration

## 📋 **API Key Creation - Required & Optional Fields**

### **✅ REQUIRED FIELDS:**

```typescript
interface ApiKeyCreateRequest {
  // REQUIRED: Basic Information
  name: string;                    // API key name (max 255 chars)
  registeredDomain: string;        // Primary domain (e.g., "api.mywebsite.com")
  
  // REQUIRED for Angular: Authentication
  // JWT token in Authorization header: "Bearer <token>"
}
```

### **✅ OPTIONAL FIELDS (Recommended for Production):**

```typescript
interface ApiKeyCreateRequestFull {
  // Basic Information
  name: string;                    // REQUIRED
  description?: string;            // Optional description (max 1000 chars)
  registeredDomain: string;        // REQUIRED
  
  // Security Configuration
  prefix?: string;                 // Custom prefix (e.g., "sk-", "prod-", "dev-")
  allowedIps?: string[];          // IP restrictions ["192.168.1.100", "10.0.0.0/24"]
  allowedDomains?: string[];      // Additional domains ["staging.site.com"]
  
  // Permissions & Access
  scopes?: string[];              // Permissions ["READ_USERS", "WRITE_BRANDS"]
  rateLimitTier?: string;         // "BASIC" | "STANDARD" | "PREMIUM" | "ENTERPRISE" | "UNLIMITED"
  
  // Expiration
  expiresAt?: string;             // ISO date string (future date)
}
```

---

## 🎯 **API Key Types & Use Cases**

### **1. Standard User API Key**
```json
{
  "name": "My Website API Key",
  "description": "For website integration",
  "registeredDomain": "mywebsite.com",
  "prefix": "sk-",
  "rateLimitTier": "BASIC",
  "scopes": ["READ_USERS", "READ_BRANDS", "READ_CATEGORIES"]
}
```
**Use Case**: Basic website integration, read-only access

### **2. Business API Key**
```json
{
  "name": "Business Integration Key",
  "description": "For business operations",
  "registeredDomain": "business.company.com",
  "prefix": "biz-",
  "rateLimitTier": "PREMIUM",
  "allowedIps": ["203.0.113.45", "192.168.1.0/24"],
  "scopes": ["BUSINESS_READ", "BUSINESS_WRITE", "READ_USERS", "READ_BRANDS"]
}
```
**Use Case**: Business integrations with higher limits and write access

### **3. Server-to-Server API Key**
```json
{
  "name": "Backend Service Key",
  "description": "For server-to-server communication",
  "registeredDomain": "api.internal.com",
  "prefix": "srv-",
  "rateLimitTier": "ENTERPRISE",
  "scopes": ["SERVER_ACCESS", "BACKEND_API", "BUSINESS_READ", "BUSINESS_WRITE"]
}
```
**Use Case**: Microservices, backend integrations (bypasses domain validation)

### **4. Admin API Key**
```json
{
  "name": "Admin System Key",
  "description": "For administrative operations",
  "registeredDomain": "admin.company.com",
  "prefix": "admin-",
  "rateLimitTier": "UNLIMITED",
  "scopes": ["FULL_ACCESS"]
}
```
**Use Case**: Administrative tools, system management (bypasses all validation)

### **5. Testing/Development API Key**
```json
{
  "name": "Development Test Key",
  "description": "For testing and development",
  "registeredDomain": "localhost",
  "prefix": "test-",
  "rateLimitTier": "STANDARD",
  "scopes": ["DOMAINLESS_ACCESS", "READ_USERS", "READ_BRANDS"]
}
```
**Use Case**: Development, testing tools like Postman/cURL (bypasses domain validation)

---

## 🔐 **Available Scopes (Permissions)**

### **📖 Read Permissions**
- `READ_USERS` - Read user information
- `READ_BRANDS` - Read brand information  
- `READ_CATEGORIES` - Read category information
- `READ_API_KEYS` - Read own API key information

### **✏️ Write Permissions**
- `WRITE_USERS` - Create/update users
- `WRITE_BRANDS` - Create/update brands
- `WRITE_CATEGORIES` - Create/update categories

### **🗑️ Delete Permissions**
- `DELETE_USERS` - Delete users
- `DELETE_BRANDS` - Delete brands
- `DELETE_CATEGORIES` - Delete categories

### **🔑 API Key Management**
- `MANAGE_API_KEYS` - Full API key management
- `REVOKE_API_KEYS` - Revoke API keys

### **👑 Admin Permissions**
- `ADMIN_ACCESS` - Administrative functions (bypasses domain validation)
- `SYSTEM_MONITOR` - System monitoring (bypasses domain validation)
- `FULL_ACCESS` - Complete system access (bypasses all validation)

### **💼 Business API Permissions**
- `BUSINESS_READ` - Business data read access
- `BUSINESS_WRITE` - Business data write access

### **🔗 Server-to-Server Permissions** *(NEW)*
- `SERVER_ACCESS` - Server-to-server communication (bypasses domain validation)
- `BACKEND_API` - Backend service API access (bypasses domain validation)
- `SERVICE_ACCESS` - Microservice communication (bypasses domain validation)
- `INTERNAL_API` - Internal API access (bypasses domain validation)

### **🌐 Special Permissions** *(NEW)*
- `DOMAINLESS_ACCESS` - Explicit domain bypass (for testing/development)

---

## 🚀 **Rate Limit Tiers**

| **Tier** | **Requests/Hour** | **Burst Limit** | **Use Case** |
|----------|-------------------|------------------|--------------|
| `BASIC` | 1,000 | 50/min | Personal projects, small websites |
| `STANDARD` | 5,000 | 100/min | Small businesses, moderate usage |
| `PREMIUM` | 25,000 | 500/min | Growing businesses, high usage |
| `ENTERPRISE` | 100,000 | 2,000/min | Large businesses, enterprise apps |
| `UNLIMITED` | No limit | No limit | Admin keys, critical systems |

---

## 📡 **API Endpoints for Angular Integration**

### **Base URL**: `http://localhost:8080/myapp`

### **1. Authentication Endpoints**
```typescript
// Login to get JWT token
POST /auth/login
{
  "username": "your-username",
  "password": "your-password"
}
// Response: { "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." }
```

### **2. API Key Management Endpoints**

#### **Create API Key**
```typescript
POST /api/v1/api-keys
Headers: {
  "Authorization": "Bearer <JWT_TOKEN>",
  "Content-Type": "application/json"
}
Body: {
  "name": "My Angular App Key",
  "description": "API key for Angular application",
  "registeredDomain": "myapp.com",
  "prefix": "ng-",
  "rateLimitTier": "STANDARD",
  "scopes": ["READ_USERS", "READ_BRANDS", "BUSINESS_READ"]
}
```

#### **List User's API Keys**
```typescript
GET /api/v1/api-keys
Headers: {
  "Authorization": "Bearer <JWT_TOKEN>"
}
```

#### **Get Specific API Key**
```typescript
GET /api/v1/api-keys/{keyId}
Headers: {
  "Authorization": "Bearer <JWT_TOKEN>"
}
```

#### **Update API Key**
```typescript
PUT /api/v1/api-keys/{keyId}
Headers: {
  "Authorization": "Bearer <JWT_TOKEN>",
  "Content-Type": "application/json"
}
Body: {
  "name": "Updated Key Name",
  "description": "Updated description",
  "active": true,
  "scopes": ["READ_USERS", "WRITE_BRANDS"]
}
```

#### **Delete API Key**
```typescript
DELETE /api/v1/api-keys/{keyId}
Headers: {
  "Authorization": "Bearer <JWT_TOKEN>"
}
```

### **3. API Usage Endpoints**

#### **External Business API (with scopes)**
```typescript
GET /api/external/users
Headers: {
  "x-api-key": "<API_KEY>",
  "Origin": "https://myapp.com"  // Must match registered domain
}
```

#### **Secure Forward API (advanced security)**
```typescript
POST /api/secure/forward
Headers: {
  "x-api-key": "<API_KEY>",
  "Content-Type": "application/json",
  "Origin": "https://myapp.com"  // Optional (has fallback strategies)
}
Body: {
  "url": "https://external-api.com/data"
}
```

#### **Internal Forward API (JWT or API Key)**
```typescript
POST /forward
Headers: {
  "Authorization": "Bearer <JWT_TOKEN>",  // OR
  "x-api-key": "<API_KEY>",              // OR both
  "Content-Type": "application/json"
}
Body: {
  "url": "https://external-api.com/data"
}
```

---

## 🧪 **Complete Postman Collection**

### **Collection Structure:**
```
JWT Authenticator API
├── 🔐 Authentication
│   ├── Login (Get JWT Token)
│   ├── Register User
│   └── Refresh Token
├── 🔑 API Key Management
│   ├── Create Standard API Key
│   ├── Create Business API Key
│   ├── Create Server-to-Server Key
│   ├── Create Admin Key
│   ├── Create Testing Key
│   ├── List All API Keys
│   ├── Get API Key by ID
│   ├── Update API Key
│   └── Delete API Key
├── 🌐 API Usage - External APIs
│   ├── Get Users (READ_USERS scope)
│   ├── Create User (WRITE_USERS scope)
│   ├── Get Brands (READ_BRANDS scope)
│   ├── Get Business Data (BUSINESS_READ scope)
│   ├── Admin Operation (ADMIN_ACCESS scope)
│   └── Get API Key Info
├── 🔒 API Usage - Secure Forward
│   ├── Secure Forward (with domain)
│   ├── Secure Forward (IP fallback)
│   ├── Secure Forward (server-to-server)
│   └── Health Check
└── 🚀 API Usage - Internal Forward
    ├── Forward with JWT
    ├── Forward with API Key
    └── Forward with Both
```

---

## 📝 **Angular Service Implementation Example**

### **API Key Service**
```typescript
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface ApiKeyCreateRequest {
  name: string;
  description?: string;
  registeredDomain: string;
  prefix?: string;
  allowedIps?: string[];
  allowedDomains?: string[];
  scopes?: string[];
  rateLimitTier?: string;
  expiresAt?: string;
}

export interface ApiKeyResponse {
  id: string;
  name: string;
  description?: string;
  registeredDomain: string;
  prefix: string;
  keyHash: string;  // Partial key for identification
  scopes: string[];
  rateLimitTier: string;
  active: boolean;
  createdAt: string;
  lastUsedAt?: string;
  expiresAt?: string;
}

export interface ApiKeyGeneratedResponse extends ApiKeyResponse {
  keyValue: string;  // Full API key (shown only once)
}

@Injectable({
  providedIn: 'root'
})
export class ApiKeyService {
  private baseUrl = 'http://localhost:8080/myapp/api/v1/api-keys';

  constructor(private http: HttpClient) {}

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('jwt_token');
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  }

  // Create API Key
  createApiKey(request: ApiKeyCreateRequest): Observable<ApiKeyGeneratedResponse> {
    return this.http.post<ApiKeyGeneratedResponse>(
      this.baseUrl, 
      request, 
      { headers: this.getAuthHeaders() }
    );
  }

  // Get all API keys for current user
  getApiKeys(): Observable<ApiKeyResponse[]> {
    return this.http.get<ApiKeyResponse[]>(
      this.baseUrl, 
      { headers: this.getAuthHeaders() }
    );
  }

  // Get specific API key
  getApiKey(keyId: string): Observable<ApiKeyResponse> {
    return this.http.get<ApiKeyResponse>(
      `${this.baseUrl}/${keyId}`, 
      { headers: this.getAuthHeaders() }
    );
  }

  // Update API key
  updateApiKey(keyId: string, updates: Partial<ApiKeyCreateRequest>): Observable<ApiKeyResponse> {
    return this.http.put<ApiKeyResponse>(
      `${this.baseUrl}/${keyId}`, 
      updates, 
      { headers: this.getAuthHeaders() }
    );
  }

  // Delete API key
  deleteApiKey(keyId: string): Observable<void> {
    return this.http.delete<void>(
      `${this.baseUrl}/${keyId}`, 
      { headers: this.getAuthHeaders() }
    );
  }
}
```

### **API Usage Service**
```typescript
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiUsageService {
  private baseUrl = 'http://localhost:8080/myapp';

  constructor(private http: HttpClient) {}

  // Use External API with API Key
  callExternalApi(apiKey: string, endpoint: string): Observable<any> {
    const headers = new HttpHeaders({
      'x-api-key': apiKey,
      'Origin': window.location.origin,  // Automatically set current domain
      'Content-Type': 'application/json'
    });

    return this.http.get(`${this.baseUrl}/api/external/${endpoint}`, { headers });
  }

  // Use Secure Forward API
  secureForward(apiKey: string, targetUrl: string): Observable<any> {
    const headers = new HttpHeaders({
      'x-api-key': apiKey,
      'Origin': window.location.origin,  // Optional (has fallback)
      'Content-Type': 'application/json'
    });

    return this.http.post(
      `${this.baseUrl}/api/secure/forward`,
      { url: targetUrl },
      { headers }
    );
  }

  // Use Internal Forward API with JWT
  internalForward(targetUrl: string): Observable<any> {
    const token = localStorage.getItem('jwt_token');
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });

    return this.http.post(
      `${this.baseUrl}/forward`,
      { url: targetUrl },
      { headers }
    );
  }
}
```

---

## 🎯 **Best Practices for Angular Integration**

### **1. API Key Storage**
```typescript
// Store API keys securely
class ApiKeyManager {
  private readonly STORAGE_KEY = 'api_keys';

  storeApiKey(keyId: string, keyValue: string, metadata: any): void {
    const keys = this.getStoredKeys();
    keys[keyId] = {
      value: keyValue,
      metadata: metadata,
      createdAt: new Date().toISOString()
    };
    
    // Use secure storage in production
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(keys));
  }

  getApiKey(keyId: string): string | null {
    const keys = this.getStoredKeys();
    return keys[keyId]?.value || null;
  }

  private getStoredKeys(): any {
    const stored = localStorage.getItem(this.STORAGE_KEY);
    return stored ? JSON.parse(stored) : {};
  }
}
```

### **2. Error Handling**
```typescript
// Handle API key errors
handleApiKeyError(error: any): void {
  switch (error.status) {
    case 401:
      console.error('Invalid API key');
      // Redirect to API key management
      break;
    case 403:
      console.error('Domain validation failed or insufficient permissions');
      // Show domain/scope error message
      break;
    case 429:
      console.error('Rate limit exceeded');
      // Show rate limit message with retry info
      break;
    default:
      console.error('API error:', error.message);
  }
}
```

### **3. Domain Configuration**
```typescript
// Configure domains for different environments
const API_CONFIG = {
  development: {
    domain: 'localhost',
    apiKey: 'test-key-for-development'
  },
  staging: {
    domain: 'staging.myapp.com',
    apiKey: 'staging-api-key'
  },
  production: {
    domain: 'myapp.com',
    apiKey: 'production-api-key'
  }
};
```

---

## 🔧 **Testing Strategy**

### **1. Development Testing**
- Create API key with `DOMAINLESS_ACCESS` scope
- Test from localhost without domain headers
- Use Postman/cURL for API testing

### **2. Staging Testing**
- Create API key with staging domain
- Test domain validation
- Test rate limiting

### **3. Production Testing**
- Create production API key with proper domain
- Test all security features
- Monitor rate limits and usage

---

This guide provides everything you need to integrate API keys with your Angular project. The system now supports all use cases with proper fallback strategies and clean architecture!
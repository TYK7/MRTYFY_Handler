# 🚀 Rivo9Fetch API - Quick Start Integration Guide

> **Get your brand extraction API up and running in 5 minutes**

## 📋 What You'll Build

By the end of this guide, you'll have:
- ✅ A working API key from our web application
- ✅ Brand extraction functionality in your application
- ✅ Proper error handling and rate limiting
- ✅ Production-ready code examples in JavaScript, Node.js, Python, and Java

## 🎯 **What This API Does**

Our **Rivo9Fetch** endpoint extracts comprehensive brand information from any website:
- **🎨 Visual Assets**: Logos, icons, banners, color palettes
- **🏢 Company Data**: Name, description, industry, social links
- **📱 Design Elements**: Fonts, images, brand colors
- **⚡ Fast Response**: Average extraction time under 3 seconds

## 📋 **Table of Contents**
- [🎯 What This API Does](#-what-this-api-does)
- [🧩 Common Use Cases](#-common-use-cases)
- [🔑 Getting Your API Key](#-getting-your-api-key)
- [⏱️ 5-Minute Integration](#️-5-minute-integration)
- [🛡️ Rivo9Fetch API Reference](#️-rivo9fetch-api-reference)
- [💻 Integration Examples](#-integration-examples)
- [🔒 Security Best Practices](#-security-best-practices)
- [📊 Monitoring & Usage](#-monitoring--usage)

---

## 🧩 **Common Use Cases**

### **🎨 SaaS Auto-Branding**
Automatically extract company logos and colors when users sign up with their domain:
```javascript
// When user enters their company domain during onboarding
const setupUserBranding = async (companyDomain) => {
  const brandData = await rivo9fetch(`https://${companyDomain}`);
  return {
    logo: brandData.Logo?.Logo,
    primaryColor: brandData.Colors?.[0]?.hex,
    companyName: brandData.Company?.Name
  };
};
```

### **🤝 Sales Lead Enrichment**
Gather comprehensive company information for prospect research:
```javascript
// Enrich prospect data for sales teams
const enrichProspect = async (prospectDomain) => {
  const brandData = await rivo9fetch(`https://${prospectDomain}`);
  return {
    companyInfo: brandData.Company,
    socialLinks: brandData.Company?.SocialLinks,
    industry: brandData.Company?.Industry,
    employeeCount: brandData.Company?.Employees
  };
};
```

### **📊 Brand Compliance Monitoring**
Monitor brand consistency across company digital properties:
```javascript
// Verify brand consistency across platforms
const monitorBrandConsistency = async (mainSite, socialProfiles) => {
  const mainBrand = await rivo9fetch(mainSite);
  const socialBrands = await Promise.all(
    socialProfiles.map(profile => rivo9fetch(profile))
  );
  return analyzeBrandConsistency(mainBrand, socialBrands);
};
```

### **🏢 Company Database Building**
Build comprehensive company profiles from domain names:
```javascript
// Build company database for market research
const buildCompanyProfile = async (domains) => {
  const companyProfiles = await Promise.all(
    domains.map(async (domain) => {
      const brandData = await rivo9fetch(domain);
      return {
        domain,
        company: brandData.Company,
        branding: {
          logo: brandData.Logo?.Logo,
          colors: brandData.Colors?.slice(0, 3),
          fonts: brandData.Fonts
        }
      };
    })
  );
  return companyProfiles;
};
```

---

## 🌐 **API Information**

| Component | URL |
|-----------|-----|
| **API Base URL** | `http://202.65.155.125:8080/myapp` |
| **Web Application** | `http://202.65.155.117` |
| **Rivo9Fetch Endpoint** | `http://202.65.155.125:8080/myapp/api/v1/secure/rivofetch` |

## 🔑 **Getting Your API Key**

### **Step 1: Create Account & Get API Key**

1. **Visit our web application**: http://202.65.155.117
2. **Create an account** or login to your existing account
3. **Navigate to API Keys section** in your dashboard
4. **Create a new API key** with your domain configuration
5. **Copy your API key** - it will look like: `sk-1234567890abcdef...`

> **Important**: You'll need to register your domain (e.g., `yourdomain.com`) when creating the API key for security validation.

---

## ⏱️ 5-Minute Integration

### **Step 1: Test Your API Key (1 minute)**

```bash
# Quick health check
curl -X GET "http://202.65.155.125:8080/myapp/api/v1/secure/health" \
  -H "x-api-key: sk-your-api-key-here" \
  -H "Origin: https://yourdomain.com"

# Expected response: {"status": "healthy", ...}
```

### **Step 2: Your First Brand Extraction (2 minutes)**

```bash
# Extract brand data from any website
curl -X POST "http://202.65.155.125:8080/myapp/api/v1/secure/rivofetch" \
  -H "Content-Type: application/json" \
  -H "x-api-key: sk-your-api-key-here" \
  -H "Origin: https://yourdomain.com" \
  -d '{
    "url": "https://github.com"
  }'
```

---

## 🛡️ **Rivo9Fetch API Endpoint - Complete Reference**

### **Endpoint Details**
```
POST /api/v1/secure/rivofetch
Base URL: http://202.65.155.125:8080/myapp
Full URL: http://202.65.155.125:8080/myapp/api/v1/secure/rivofetch
```

### **Required Headers**
```http
Content-Type: application/json
x-api-key: sk-your-api-key-here
Origin: https://yourdomain.com
```

### **Request Payload**
```json
{
  "url": "https://target-website.com"
}
```

### **Complete Success Response (200 OK)**
```json
{
  "Logo": {
    "Logo": "https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png",
    "Symbol": "https://github.githubassets.com/images/modules/logos_page/GitHub-Symbol.png",
    "Icon": "https://github.com/favicon.ico",
    "Banner": "https://github.githubassets.com/images/modules/site/social-cards/github-social.png",
    "LinkedInBanner": null,
    "LinkedInLogo": null
  },
  "Colors": [
    {
      "hex": "#24292f",
      "rgb": "rgb(36, 41, 47)",
      "brightness": 41,
      "name": "GitHub Dark",
      "width": null,
      "height": null,
      "colors": null
    },
    {
      "hex": "#0969da",
      "rgb": "rgb(9, 105, 218)",
      "brightness": 113,
      "name": "GitHub Blue",
      "width": null,
      "height": null,
      "colors": null
    },
    {
      "hex": "#ffffff",
      "rgb": "rgb(255, 255, 255)",
      "brightness": 255,
      "name": "White",
      "width": null,
      "height": null,
      "colors": null
    }
  ],
  "Fonts": [
    {
      "name": "-apple-system",
      "type": "system",
      "stack": "-apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif"
    },
    {
      "name": "SFMono-Regular",
      "type": "monospace",
      "stack": "SFMono-Regular, Consolas, 'Liberation Mono', Menlo, monospace"
    }
  ],
  "Images": [
    {
      "src": "https://github.githubassets.com/images/modules/site/home-campaign/hero-bg.webp",
      "alt": "GitHub hero background"
    },
    {
      "src": "https://github.githubassets.com/images/modules/site/home-campaign/productivity.png",
      "alt": "Productivity illustration"
    }
  ],
  "Company": {
    "Name": "GitHub",
    "Description": "GitHub is where over 100 million developers shape the future of software, together. Contribute to the open source community, manage your Git repositories, and review code like a pro.",
    "Industry": "Technology",
    "Location": "San Francisco, CA",
    "Founded": "2008",
    "CompanyType": "Public",
    "Employees": "1,001-5,000",
    "Website": "https://github.com",
    "SocialLinks": {
      "linkedin": "https://linkedin.com/company/github",
      "twitter": "https://twitter.com/github",
      "facebook": "https://facebook.com/GitHub"
    },
    "LinkedInError": null,
    "CompanySize": "Large",
    "Headquarters": "San Francisco, California",
    "Type": "Technology Company",
    "Specialties": [
      "Software Development",
      "Version Control",
      "Open Source",
      "DevOps",
      "Collaboration Tools"
    ],
    "Locations": [
      "San Francisco, CA",
      "Remote Worldwide"
    ]
  },
  "_performance": {
    "extractionTimeSeconds": 2.34,
    "timestamp": "2024-01-15T10:30:00Z"
  },
  "_message": "Brand extraction completed successfully"
}
```

### **Error Responses**

#### **401 Unauthorized - Invalid API Key**
```json
{
  "error": "API key not found or invalid",
  "status": 401,
  "errorCode": "INVALID_API_KEY",
  "timestamp": "2024-01-15T10:30:00Z",
  "suggestions": [
    "Verify your API key is correct",
    "Check if the API key is active",
    "Ensure the API key hasn't expired"
  ]
}
```

#### **403 Forbidden - Domain Validation Failed**
```json
{
  "error": "Domain validation failed. Request domain 'unauthorized.com' is not allowed for this API key.",
  "status": 403,
  "errorCode": "DOMAIN_NOT_ALLOWED",
  "timestamp": "2024-01-15T10:30:00Z",
  "requestDomain": "unauthorized.com",
  "expectedDomain": "yourdomain.com",
  "suggestions": [
    "Ensure your request includes Origin header",
    "Verify your domain is registered for this API key",
    "Check that your domain format is correct"
  ]
}
```

#### **400 Bad Request - Invalid URL**
```json
{
  "error": "Invalid URL format provided",
  "status": 400,
  "errorCode": "INVALID_URL",
  "timestamp": "2024-01-15T10:30:00Z",
  "suggestions": [
    "Provide a valid HTTP or HTTPS URL",
    "Ensure URL includes protocol (http:// or https://)",
    "Check URL format and accessibility"
  ]
}
```

#### **429 Too Many Requests - Rate Limit Exceeded**
```json
{
  "error": "Rate limit exceeded. You have made 200/200 requests in the current window.",
  "status": 429,
  "errorCode": "RATE_LIMIT_EXCEEDED",
  "timestamp": "2024-01-15T10:30:00Z",
  "rateLimitInfo": {
    "limit": 200,
    "remaining": 0,
    "resetTime": "2024-01-16T00:00:00Z",
    "tier": "PRO_TIER"
  },
  "suggestions": [
    "Wait for rate limit reset",
    "Implement exponential backoff",
    "Consider upgrading to a higher plan"
  ]
}
```

#### **502 Bad Gateway - External API Error**
```json
{
  "error": "Unable to extract data from the target website",
  "status": 502,
  "errorCode": "EXTERNAL_API_ERROR",
  "timestamp": "2024-01-15T10:30:00Z",
  "suggestions": [
    "Verify the target URL is accessible",
    "Check if the website is blocking requests",
    "Try again later if the website is temporarily unavailable"
  ]
}
```

#### **504 Gateway Timeout - Request Timeout**
```json
{
  "error": "Request timed out while extracting brand data",
  "status": 504,
  "errorCode": "TIMEOUT_ERROR",
  "timestamp": "2024-01-15T10:30:00Z",
  "suggestions": [
    "Retry the request with exponential backoff",
    "Check if the target website is responding slowly",
    "Contact support if timeouts persist"
  ]
}
```

---

## 💻 **Integration Examples**

### **Step 3: Add to Your Application (5 minutes)**

#### **Option A: JavaScript/React**
```javascript
// Create a simple brand extractor component
import React, { useState } from 'react';

function BrandExtractor() {
  const [url, setUrl] = useState('');
  const [brandData, setBrandData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const extractBrand = async () => {
    if (!url) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch('http://202.65.155.125:8080/myapp/api/v1/secure/rivofetch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': process.env.REACT_APP_API_KEY,
          'Origin': window.location.origin
        },
        body: JSON.stringify({ url })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to extract brand data');
      }

      const data = await response.json();
      setBrandData(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="brand-extractor">
      <div className="input-group">
        <input 
          type="url" 
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Enter website URL (e.g., https://github.com)"
          className="url-input"
        />
        <button 
          onClick={extractBrand} 
          disabled={loading || !url}
          className="extract-btn"
        >
          {loading ? 'Extracting...' : 'Extract Brand'}
        </button>
      </div>

      {error && (
        <div className="error-message">
          ❌ {error}
        </div>
      )}

      {brandData && (
        <div className="brand-results">
          <h3>✅ Brand Data Extracted</h3>
          
          {brandData.Company?.Name && (
            <div className="company-info">
              <h4>{brandData.Company.Name}</h4>
              <p>{brandData.Company.Description}</p>
            </div>
          )}

          {brandData.Logo?.Logo && (
            <div className="logo-section">
              <img 
                src={brandData.Logo.Logo} 
                alt="Company Logo" 
                style={{ maxWidth: '200px', height: 'auto' }}
              />
            </div>
          )}

          {brandData.Colors && brandData.Colors.length > 0 && (
            <div className="colors-section">
              <h5>Brand Colors:</h5>
              <div className="color-palette">
                {brandData.Colors.slice(0, 5).map((color, index) => (
                  <div 
                    key={index}
                    className="color-swatch"
                    style={{ 
                      backgroundColor: color.hex,
                      width: '40px',
                      height: '40px',
                      display: 'inline-block',
                      margin: '5px',
                      borderRadius: '4px',
                      border: '1px solid #ccc'
                    }}
                    title={`${color.name || 'Color'}: ${color.hex}`}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default BrandExtractor;
```

#### **Option B: Node.js/Express Backend**
```javascript
const express = require('express');
const fetch = require('node-fetch');

const app = express();
app.use(express.json());

// Environment variables
const API_KEY = process.env.RIVO9_API_KEY;
const API_BASE_URL = process.env.RIVO9_BASE_URL || 'http://202.65.155.125:8080/myapp';
const ORIGIN = process.env.RIVO9_ORIGIN || 'https://yourdomain.com';

// Brand extraction endpoint
app.post('/api/extract-brand', async (req, res) => {
  const { url } = req.body;

  if (!url) {
    return res.status(400).json({ 
      success: false, 
      error: 'URL is required' 
    });
  }

  try {
    const response = await fetch(`${API_BASE_URL}/api/v1/secure/rivofetch`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': API_KEY,
        'Origin': ORIGIN
      },
      body: JSON.stringify({ url })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return res.status(response.status).json({
        success: false,
        error: errorData.error || 'Brand extraction failed',
        errorCode: errorData.errorCode
      });
    }

    const brandData = await response.json();
    
    // Transform data for your application
    const result = {
      success: true,
      data: {
        company: {
          name: brandData.Company?.Name,
          description: brandData.Company?.Description,
          industry: brandData.Company?.Industry,
          website: brandData.Company?.Website
        },
        branding: {
          logo: brandData.Logo?.Logo,
          colors: brandData.Colors?.slice(0, 5).map(c => ({
            hex: c.hex,
            name: c.name
          })),
          fonts: brandData.Fonts?.map(f => f.name)
        },
        extractedAt: new Date().toISOString()
      }
    };

    res.json(result);

  } catch (error) {
    console.error('Brand extraction error:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error',
      message: error.message
    });
  }
});

// Health check endpoint
app.get('/api/health', async (req, res) => {
  try {
    const response = await fetch(`${API_BASE_URL}/api/v1/secure/health`, {
      headers: {
        'x-api-key': API_KEY,
        'Origin': ORIGIN
      }
    });

    if (response.ok) {
      res.json({ status: 'healthy', apiConnection: 'ok' });
    } else {
      res.status(503).json({ status: 'unhealthy', apiConnection: 'failed' });
    }
  } catch (error) {
    res.status(503).json({ 
      status: 'unhealthy', 
      error: error.message 
    });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
```

#### **Option C: Python/Flask**
```python
from flask import Flask, request, jsonify
import requests
import os
from datetime import datetime

app = Flask(__name__)

# Configuration
API_KEY = os.getenv('RIVO9_API_KEY')
API_BASE_URL = os.getenv('RIVO9_BASE_URL', 'http://202.65.155.125:8080/myapp')
ORIGIN = os.getenv('RIVO9_ORIGIN', 'https://yourdomain.com')

@app.route('/api/extract-brand', methods=['POST'])
def extract_brand():
    data = request.get_json()
    url = data.get('url')
    
    if not url:
        return jsonify({
            'success': False,
            'error': 'URL is required'
        }), 400
    
    try:
        response = requests.post(
            f'{API_BASE_URL}/api/v1/secure/rivofetch',
            headers={
                'Content-Type': 'application/json',
                'x-api-key': API_KEY,
                'Origin': ORIGIN
            },
            json={'url': url},
            timeout=30
        )
        
        if not response.ok:
            error_data = response.json()
            return jsonify({
                'success': False,
                'error': error_data.get('error', 'Brand extraction failed'),
                'errorCode': error_data.get('errorCode')
            }), response.status_code
        
        brand_data = response.json()
        
        # Transform data for your application
        result = {
            'success': True,
            'data': {
                'company': {
                    'name': brand_data.get('Company', {}).get('Name'),
                    'description': brand_data.get('Company', {}).get('Description'),
                    'industry': brand_data.get('Company', {}).get('Industry'),
                    'website': brand_data.get('Company', {}).get('Website')
                },
                'branding': {
                    'logo': brand_data.get('Logo', {}).get('Logo'),
                    'colors': [
                        {'hex': c.get('hex'), 'name': c.get('name')}
                        for c in brand_data.get('Colors', [])[:5]
                    ],
                    'fonts': [f.get('name') for f in brand_data.get('Fonts', [])]
                },
                'extractedAt': datetime.now().isoformat()
            }
        }
        
        return jsonify(result)
        
    except requests.RequestException as e:
        return jsonify({
            'success': False,
            'error': 'Network error occurred',
            'message': str(e)
        }), 500
    except Exception as e:
        return jsonify({
            'success': False,
            'error': 'Internal server error',
            'message': str(e)
        }), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    try:
        response = requests.get(
            f'{API_BASE_URL}/api/v1/secure/health',
            headers={
                'x-api-key': API_KEY,
                'Origin': ORIGIN
            },
            timeout=10
        )
        
        if response.ok:
            return jsonify({'status': 'healthy', 'apiConnection': 'ok'})
        else:
            return jsonify({'status': 'unhealthy', 'apiConnection': 'failed'}), 503
            
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'error': str(e)
        }), 503

if __name__ == '__main__':
    app.run(debug=True, port=5000)
```

#### **Option D: Java/Spring Boot**
```java
package com.yourcompany.brandextractor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.beans.factory.annotation.Value;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.HashMap;
import java.util.Map;
import java.time.LocalDateTime;

@SpringBootApplication
@RestController
@RequestMapping("/api")
public class BrandExtractorApplication {

    @Value("${rivo9.api.key}")
    private String apiKey;

    @Value("${rivo9.base.url:http://202.65.155.125:8080/myapp}")
    private String apiBaseUrl;

    @Value("${rivo9.origin:https://yourdomain.com}")
    private String origin;

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    public static void main(String[] args) {
        SpringApplication.run(BrandExtractorApplication.class, args);
    }

    @PostMapping("/extract-brand")
    public ResponseEntity<?> extractBrand(@RequestBody BrandExtractionRequest request) {
        try {
            // Validate input
            if (request.getUrl() == null || request.getUrl().trim().isEmpty()) {
                return ResponseEntity.badRequest()
                    .body(createErrorResponse("URL is required", "MISSING_URL"));
            }

            // Prepare headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("x-api-key", apiKey);
            headers.set("Origin", origin);

            // Prepare request body
            Map<String, String> requestBody = new HashMap<>();
            requestBody.put("url", request.getUrl());

            HttpEntity<Map<String, String>> entity = new HttpEntity<>(requestBody, headers);

            // Make API call
            ResponseEntity<String> response = restTemplate.postForEntity(
                apiBaseUrl + "/api/v1/secure/rivofetch",
                entity,
                String.class
            );

            // Parse and transform response
            JsonNode brandData = objectMapper.readTree(response.getBody());
            BrandExtractionResponse result = transformBrandData(brandData);

            return ResponseEntity.ok(result);

        } catch (HttpClientErrorException e) {
            return handleClientError(e);
        } catch (HttpServerErrorException e) {
            return handleServerError(e);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(createErrorResponse("Internal server error: " + e.getMessage(), "INTERNAL_ERROR"));
        }
    }

    @GetMapping("/health")
    public ResponseEntity<?> healthCheck() {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("x-api-key", apiKey);
            headers.set("Origin", origin);

            HttpEntity<String> entity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(
                apiBaseUrl + "/api/v1/secure/health",
                HttpMethod.GET,
                entity,
                String.class
            );

            Map<String, Object> healthResponse = new HashMap<>();
            healthResponse.put("status", "healthy");
            healthResponse.put("apiConnection", "ok");
            healthResponse.put("timestamp", LocalDateTime.now());

            return ResponseEntity.ok(healthResponse);

        } catch (Exception e) {
            Map<String, Object> healthResponse = new HashMap<>();
            healthResponse.put("status", "unhealthy");
            healthResponse.put("error", e.getMessage());
            healthResponse.put("timestamp", LocalDateTime.now());

            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(healthResponse);
        }
    }

    private BrandExtractionResponse transformBrandData(JsonNode brandData) {
        BrandExtractionResponse response = new BrandExtractionResponse();
        
        // Transform company data
        JsonNode company = brandData.get("Company");
        if (company != null) {
            CompanyInfo companyInfo = new CompanyInfo();
            companyInfo.setName(getTextValue(company, "Name"));
            companyInfo.setDescription(getTextValue(company, "Description"));
            companyInfo.setIndustry(getTextValue(company, "Industry"));
            companyInfo.setWebsite(getTextValue(company, "Website"));
            response.setCompany(companyInfo);
        }

        // Transform branding data
        BrandingInfo brandingInfo = new BrandingInfo();
        
        JsonNode logo = brandData.get("Logo");
        if (logo != null) {
            brandingInfo.setLogo(getTextValue(logo, "Logo"));
        }

        JsonNode colors = brandData.get("Colors");
        if (colors != null && colors.isArray()) {
            java.util.List<ColorInfo> colorList = new java.util.ArrayList<>();
            for (JsonNode color : colors) {
                ColorInfo colorInfo = new ColorInfo();
                colorInfo.setHex(getTextValue(color, "hex"));
                colorInfo.setName(getTextValue(color, "name"));
                colorList.add(colorInfo);
            }
            brandingInfo.setColors(colorList.subList(0, Math.min(5, colorList.size())));
        }

        JsonNode fonts = brandData.get("Fonts");
        if (fonts != null && fonts.isArray()) {
            java.util.List<String> fontList = new java.util.ArrayList<>();
            for (JsonNode font : fonts) {
                String fontName = getTextValue(font, "name");
                if (fontName != null) {
                    fontList.add(fontName);
                }
            }
            brandingInfo.setFonts(fontList);
        }

        response.setBranding(brandingInfo);
        response.setExtractedAt(LocalDateTime.now());
        response.setSuccess(true);

        return response;
    }

    private String getTextValue(JsonNode node, String fieldName) {
        JsonNode field = node.get(fieldName);
        return field != null && !field.isNull() ? field.asText() : null;
    }

    private ResponseEntity<?> handleClientError(HttpClientErrorException e) {
        try {
            JsonNode errorData = objectMapper.readTree(e.getResponseBodyAsString());
            return ResponseEntity.status(e.getStatusCode()).body(errorData);
        } catch (Exception parseException) {
            return ResponseEntity.status(e.getStatusCode())
                .body(createErrorResponse(e.getMessage(), "CLIENT_ERROR"));
        }
    }

    private ResponseEntity<?> handleServerError(HttpServerErrorException e) {
        try {
            JsonNode errorData = objectMapper.readTree(e.getResponseBodyAsString());
            return ResponseEntity.status(e.getStatusCode()).body(errorData);
        } catch (Exception parseException) {
            return ResponseEntity.status(e.getStatusCode())
                .body(createErrorResponse("Server error occurred", "SERVER_ERROR"));
        }
    }

    private Map<String, Object> createErrorResponse(String message, String errorCode) {
        Map<String, Object> error = new HashMap<>();
        error.put("success", false);
        error.put("error", message);
        error.put("errorCode", errorCode);
        error.put("timestamp", LocalDateTime.now());
        return error;
    }

    // Request/Response DTOs
    public static class BrandExtractionRequest {
        private String url;

        public String getUrl() { return url; }
        public void setUrl(String url) { this.url = url; }
    }

    public static class BrandExtractionResponse {
        private boolean success;
        private CompanyInfo company;
        private BrandingInfo branding;
        private LocalDateTime extractedAt;

        // Getters and setters
        public boolean isSuccess() { return success; }
        public void setSuccess(boolean success) { this.success = success; }
        
        public CompanyInfo getCompany() { return company; }
        public void setCompany(CompanyInfo company) { this.company = company; }
        
        public BrandingInfo getBranding() { return branding; }
        public void setBranding(BrandingInfo branding) { this.branding = branding; }
        
        public LocalDateTime getExtractedAt() { return extractedAt; }
        public void setExtractedAt(LocalDateTime extractedAt) { this.extractedAt = extractedAt; }
    }

    public static class CompanyInfo {
        private String name;
        private String description;
        private String industry;
        private String website;

        // Getters and setters
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        
        public String getIndustry() { return industry; }
        public void setIndustry(String industry) { this.industry = industry; }
        
        public String getWebsite() { return website; }
        public void setWebsite(String website) { this.website = website; }
    }

    public static class BrandingInfo {
        private String logo;
        private java.util.List<ColorInfo> colors;
        private java.util.List<String> fonts;

        // Getters and setters
        public String getLogo() { return logo; }
        public void setLogo(String logo) { this.logo = logo; }
        
        public java.util.List<ColorInfo> getColors() { return colors; }
        public void setColors(java.util.List<ColorInfo> colors) { this.colors = colors; }
        
        public java.util.List<String> getFonts() { return fonts; }
        public void setFonts(java.util.List<String> fonts) { this.fonts = fonts; }
    }

    public static class ColorInfo {
        private String hex;
        private String name;

        // Getters and setters
        public String getHex() { return hex; }
        public void setHex(String hex) { this.hex = hex; }
        
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
    }
}
```

**Maven Dependencies (pom.xml):**
```xml
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>com.fasterxml.jackson.core</groupId>
        <artifactId>jackson-databind</artifactId>
    </dependency>
</dependencies>
```

**Application Properties (application.properties):**
```properties
# API Configuration
rivo9.api.key=sk-your-api-key-here
rivo9.base.url=http://202.65.155.125:8080/myapp
rivo9.origin=https://yourdomain.com

# Server Configuration
server.port=8080
```

**Usage Example:**
```bash
# Test the Java application
curl -X POST "http://localhost:8080/api/extract-brand" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://github.com"}'

# Health check
curl -X GET "http://localhost:8080/api/health"
```

#### **Option E: Angular Integration**

**⚠️ Security Note**: For Angular apps, route API requests through your secure backend to avoid exposing API keys in the frontend.

**Service Implementation:**
```typescript
// brand-extractor.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BrandExtractorService {
  private apiUrl = '/api/extract-brand'; // Your backend proxy endpoint

  constructor(private http: HttpClient) {}

  extractBrand(url: string): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    return this.http.post(this.apiUrl, { url }, { headers });
  }

  healthCheck(): Observable<any> {
    return this.http.get('/api/health');
  }
}
```

**Component Usage:**
```typescript
// brand-extractor.component.ts
import { Component } from '@angular/core';
import { BrandExtractorService } from './brand-extractor.service';

@Component({
  selector: 'app-brand-extractor',
  template: `
    <div class="brand-extractor">
      <div class="input-group">
        <input 
          [(ngModel)]="url" 
          placeholder="Enter website URL (e.g., https://github.com)"
          type="url"
          class="form-control">
        <button 
          (click)="extractBrand()" 
          [disabled]="loading || !url"
          class="btn btn-primary">
          {{loading ? 'Extracting...' : 'Extract Brand'}}
        </button>
      </div>
      
      <div *ngIf="error" class="alert alert-danger">
        {{error}}
      </div>
      
      <div *ngIf="brandData" class="results">
        <h3>{{brandData.company?.name}}</h3>
        <div *ngIf="brandData.branding?.logo" class="logo">
          <img [src]="brandData.branding.logo" 
               alt="Company Logo"
               style="max-height: 100px;">
        </div>
        <div *ngIf="brandData.branding?.colors?.length" class="colors">
          <h4>Brand Colors:</h4>
          <div class="color-palette">
            <div *ngFor="let color of brandData.branding.colors" 
                 class="color-swatch"
                 [style.background-color]="color.hex"
                 [title]="color.name || color.hex">
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .brand-extractor { padding: 20px; }
    .input-group { display: flex; margin-bottom: 20px; }
    .form-control { flex: 1; padding: 10px; margin-right: 10px; }
    .btn { padding: 10px 20px; }
    .results { margin-top: 20px; }
    .color-palette { display: flex; gap: 10px; }
    .color-swatch { width: 40px; height: 40px; border-radius: 4px; }
  `]
})
export class BrandExtractorComponent {
  url = '';
  brandData: any = null;
  loading = false;
  error: string | null = null;

  constructor(private brandService: BrandExtractorService) {}

  extractBrand() {
    if (!this.url) return;
    
    this.loading = true;
    this.error = null;
    this.brandData = null;
    
    this.brandService.extractBrand(this.url).subscribe({
      next: (data) => {
        this.brandData = data;
        this.loading = false;
      },
      error: (error) => {
        console.error('Brand extraction failed:', error);
        this.error = error.error?.message || 'Failed to extract brand data';
        this.loading = false;
      }
    });
  }
}
```

**Backend Proxy (Node.js/Express):**
```javascript
// Your Angular app's backend proxy
app.post('/api/extract-brand', async (req, res) => {
  try {
    const response = await fetch('http://202.65.155.125:8080/myapp/api/v1/secure/rivofetch', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.RIVO9_API_KEY,
        'Origin': process.env.RIVO9_ORIGIN
      },
      body: JSON.stringify(req.body)
    });

    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Brand extraction failed' });
  }
});
```

---

---

## 🔧 Environment Setup

### **Environment Variables**
Create a `.env` file in your project root:

```bash
# API Configuration
RIVO9_API_KEY=sk-your-api-key-here
RIVO9_BASE_URL=http://202.65.155.125:8080/myapp
RIVO9_ORIGIN=https://yourdomain.com

# Optional: Performance tuning
RIVO9_TIMEOUT=30000
RIVO9_RETRY_ATTEMPTS=3
```

### **For Different Environments**

#### **Development**
```bash
RIVO9_API_KEY=sk-dev-key-123...
RIVO9_BASE_URL=http://202.65.155.125:8080/myapp
RIVO9_ORIGIN=http://localhost:3000
```

#### **Staging**
```bash
RIVO9_API_KEY=sk-staging-key-456...
RIVO9_BASE_URL=http://202.65.155.125:8080/myapp
RIVO9_ORIGIN=https://staging.yourdomain.com
```

#### **Production**
```bash
RIVO9_API_KEY=sk-prod-key-789...
RIVO9_BASE_URL=http://202.65.155.125:8080/myapp
RIVO9_ORIGIN=https://yourdomain.com
```

---

## 🚨 Common Issues & Quick Fixes

### **❌ "Invalid API key" Error**
```bash
# Check if your API key is correct
curl -X GET "http://202.65.155.125:8080/myapp/api/v1/secure/health" \
  -H "x-api-key: YOUR_API_KEY" \
  -H "Origin: https://yourdomain.com"

# If you get 401, your API key is invalid
```

**Fix:** Verify your API key in the dashboard or create a new one.

### **❌ "Domain validation failed" Error**
```javascript
// Make sure Origin header matches your registered domain
const response = await fetch('http://202.65.155.125:8080/myapp/api/v1/secure/rivofetch', {
  headers: {
    'x-api-key': 'sk-your-key',
    'Origin': 'https://yourdomain.com', // Must match exactly!
    'Content-Type': 'application/json'
  }
});
```

**Fix:** Ensure the Origin header exactly matches your registered domain.

### **❌ "Rate limit exceeded" Error**
```javascript
// Check rate limit headers in response
const response = await fetch('https://rivo9.com/myapp/api/v1/secure/rivofetch', options);
const remaining = response.headers.get('x-ratelimit-remaining');
const resetTime = response.headers.get('x-ratelimit-reset');

console.log(`Remaining: ${remaining}, Reset: ${new Date(resetTime * 1000)}`);
```

**Fix:** Wait for rate limit reset or upgrade your plan.

### **❌ CORS Issues (Browser)**
```javascript
// For browser applications, make requests through your backend
// Don't make direct API calls from the browser to avoid CORS issues

// ✅ Good: Browser → Your Backend → JWT Auth API
fetch('/api/extract-brand', { // Your backend endpoint
  method: 'POST',
  body: JSON.stringify({ url: 'https://example.com' })
});

// ❌ Bad: Browser → Rivo9Fetch API (CORS issues)
fetch('https://rivo9.com/myapp/api/v1/secure/rivofetch', {
  // This will fail due to CORS
});
```

---

## 📊 Testing Your Integration

### **Test Checklist**

#### **✅ Basic Functionality**
```bash
# 1. Health check
curl -X GET "https://rivo9.com/myapp/api/v1/secure/health" \
  -H "x-api-key: sk-your-key" \
  -H "Origin: https://yourdomain.com"

# 2. Brand extraction
curl -X POST "https://rivo9.com/myapp/api/v1/secure/rivofetch" \
  -H "Content-Type: application/json" \
  -H "x-api-key: sk-your-key" \
  -H "Origin: https://yourdomain.com" \
  -d '{"url": "https://github.com"}'

# 3. Error handling
curl -X POST "https://rivo9.com/myapp/api/v1/secure/rivofetch" \
  -H "Content-Type: application/json" \
  -H "x-api-key: invalid-key" \
  -H "Origin: https://yourdomain.com" \
  -d '{"url": "https://github.com"}'
```

#### **✅ Rate Limiting**
```javascript
// Test rate limiting behavior
async function testRateLimit() {
  const promises = [];
  
  // Make multiple concurrent requests
  for (let i = 0; i < 10; i++) {
    promises.push(
      fetch('https://rivo9.com/myapp/api/v1/secure/rivofetch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': 'sk-your-key',
          'Origin': 'https://yourdomain.com'
        },
        body: JSON.stringify({ url: 'https://example.com' })
      })
    );
  }
  
  const responses = await Promise.all(promises);
  
  responses.forEach((response, index) => {
    const remaining = response.headers.get('x-ratelimit-remaining');
    console.log(`Request ${index + 1}: Status ${response.status}, Remaining: ${remaining}`);
  });
}
```

---

## 🔒 **Security Best Practices**

### **🔐 API Key Management**
- ✅ **Store securely**: Use environment variables, never hardcode keys
- ✅ **Rotate regularly**: Update API keys every 30-90 days
- ✅ **Monitor usage**: Check for unusual activity in your dashboard
- ✅ **Domain validation**: Always register your exact domain

### **🛡️ Implementation Security**
```javascript
// ✅ Good: Backend implementation
app.post('/api/extract-brand', async (req, res) => {
  // API key is safely stored on server
  const response = await fetch('https://rivo9.com/myapp/api/v1/secure/rivofetch', {
    headers: { 'x-api-key': process.env.RIVO9_API_KEY }
  });
});

// ❌ Bad: Frontend implementation
const response = await fetch('https://rivo9.com/myapp/api/v1/secure/rivofetch', {
  headers: { 'x-api-key': 'sk-exposed-key' } // Never do this!
});
```

### **📊 Rate Limit Management**
- ✅ **Implement backoff**: Use exponential backoff for retries
- ✅ **Cache results**: Store frequently requested brand data
- ✅ **Monitor limits**: Track usage to avoid hitting limits
- ✅ **Plan accordingly**: Upgrade plan before hitting limits

---

## 📊 **Monitoring & Usage**

### **📈 Usage Dashboard**
Monitor your API usage in real-time:
- **Dashboard URL**: https://rivo9.in/dashboard/analytics
- **Available Metrics**: Request count, success rate, response times, error breakdown
- **Plan Tiers**: FREE (100/month), PRO (1000/month), BUSINESS (unlimited)

### **🔍 Usage Tracking in Code**
```javascript
// Track API usage in your applications
const trackApiUsage = (response) => {
  const usage = {
    remaining: response.headers.get('x-ratelimit-remaining'),
    resetTime: response.headers.get('x-ratelimit-reset'),
    responseTime: response.headers.get('x-response-time')
  };
  
  console.log('API Usage:', usage);
  
  // Alert when approaching limits
  if (parseInt(usage.remaining) < 10) {
    console.warn('⚠️ Approaching rate limit!');
  }
};
```

### **⚠️ Alert Setup**
Set up monitoring alerts in your dashboard:
- **Rate Limit Warnings**: 80% of daily limit reached
- **Error Rate Alerts**: >5% error rate over 10 minutes
- **Performance Alerts**: Average response time >5 seconds

---

## 🎯 Next Steps

### **Now that you're up and running:**

1. **📈 Monitor Usage**: Check your API usage in the dashboard
2. **🔒 Secure Your Keys**: Move API keys to environment variables
3. **⚡ Optimize Performance**: Implement caching and error handling
4. **📊 Add Analytics**: Track brand extraction success rates
5. **🚀 Scale Up**: Consider upgrading to PRO plan for higher limits

### **Advanced Features to Explore:**

- **🎨 Custom Brand Analysis**: Build custom logic around extracted data
- **📱 Mobile Integration**: Add brand extraction to mobile apps
- **🤖 Automation**: Set up automated brand monitoring
- **📊 Dashboard Integration**: Create brand analytics dashboards

---

## 📞 Need Help?

### **Quick Support Options:**

- **📧 Email**: support@yourcompany.com
- **💬 Live Chat**: Available in your dashboard
- **📚 Documentation**: [Full API Documentation](./ENHANCED_DEVELOPER_DOCUMENTATION.md)
- **🎥 Video Tutorials**: https://learn.yourcompany.com

### **Community Resources:**

- **👥 Developer Community**: https://community.yourcompany.com
- **📖 Code Examples**: https://github.com/yourcompany/api-examples
- **🔧 Postman Collection**: [Download Here](https://api.yourcompany.com/postman)

---

**🎉 Congratulations!** You've successfully integrated the Rivo9Fetch Brand Extraction API. Your application can now extract comprehensive brand data from any website in seconds.

*Happy coding! 🚀*
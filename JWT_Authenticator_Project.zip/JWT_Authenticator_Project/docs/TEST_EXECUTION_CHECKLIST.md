# Test Execution Checklist - JWT Authenticator API with Prefix Support

## Pre-Testing Setup ✅

### **Environment Preparation**
- [ ] Application is running on `http://localhost:8080`
- [ ] Database is connected and initialized
- [ ] Test user exists in database (`testuser` / `password123`)
- [ ] Postman collection imported successfully
- [ ] Environment variables configured

### **Collection Variables Setup**
- [ ] `base_url` set to `http://localhost:8080`
- [ ] All other variables are empty (will be auto-populated)

## Phase 1: Authentication Testing ✅

### **1.1 Login Flow**
- [ ] **Login - Get JWT Token**
  - [ ] Request succeeds (200 OK)
  - [ ] JWT token is returned
  - [ ] Token is automatically saved to `jwt_token` variable
  - [ ] User ID is saved to `user_id` variable
  - [ ] Token format is valid (starts with `eyJ`)

**Expected Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "userId": "testuser01",
  "expiresIn": 3600,
  "tokenType": "Bearer"
}
```

## Phase 2: API Key Creation - All Rate Limit Tiers with Prefixes ✅

### **2.1 BASIC Tier with 'sk' Prefix**
- [ ] **Create API Key - BASIC Tier (Complete Payload with Prefix)**
  - [ ] Request succeeds (201 Created)
  - [ ] All fields are properly processed
  - [ ] API key starts with `sk-`
  - [ ] Rate limit tier is set to `BASIC`
  - [ ] All optional fields are preserved
  - [ ] API key is saved to `api_key_basic` variable
  - [ ] API key ID is saved to `api_key_id` variable

**Validation Points:**
- [ ] `name`: "BASIC Tier API Key - Complete"
- [ ] `registeredDomain`: "api.basic.example.com"
- [ ] `keyValue`: Starts with "sk-"
- [ ] `prefix`: "sk" (if returned in response)
- [ ] `allowedIps`: Contains 2 IP addresses
- [ ] `allowedDomains`: Contains 2 domains
- [ ] `rateLimitTier`: "BASIC"
- [ ] `scopes`: Contains 3 specified scopes
- [ ] `expiresAt`: "2024-12-31T23:59:59"

### **2.2 STANDARD Tier with 'std' Prefix**
- [ ] **Create API Key - STANDARD Tier (Complete Payload with Prefix)**
  - [ ] Request succeeds (201 Created)
  - [ ] API key starts with `std-`
  - [ ] Rate limit tier is set to `STANDARD`
  - [ ] API key is saved to `api_key_standard` variable

**Validation Points:**
- [ ] `keyValue`: Starts with "std-"
- [ ] `rateLimitTier`: "STANDARD"
- [ ] `allowedIps`: Contains 3 IP addresses
- [ ] `scopes`: Contains 6 specified scopes

### **2.3 PREMIUM Tier with 'prem' Prefix**
- [ ] **Create API Key - PREMIUM Tier (Complete Payload with Prefix)**
  - [ ] Request succeeds (201 Created)
  - [ ] API key starts with `prem-`
  - [ ] Rate limit tier is set to `PREMIUM`
  - [ ] API key is saved to `api_key_premium` variable

**Validation Points:**
- [ ] `keyValue`: Starts with "prem-"
- [ ] `rateLimitTier`: "PREMIUM"
- [ ] `allowedIps`: Contains 4 IP addresses
- [ ] `scopes`: Contains 9 specified scopes including write permissions

### **2.4 ENTERPRISE Tier with 'ent' Prefix**
- [ ] **Create API Key - ENTERPRISE Tier (Complete Payload with Prefix)**
  - [ ] Request succeeds (201 Created)
  - [ ] API key starts with `ent-`
  - [ ] Rate limit tier is set to `ENTERPRISE`
  - [ ] API key is saved to `api_key_enterprise` variable

**Validation Points:**
- [ ] `keyValue`: Starts with "ent-"
- [ ] `rateLimitTier`: "ENTERPRISE"
- [ ] `allowedIps`: Contains 5 IP addresses/CIDR blocks
- [ ] `scopes`: Contains 15 comprehensive scopes

### **2.5 UNLIMITED Tier with 'unlim' Prefix**
- [ ] **Create API Key - UNLIMITED Tier (Complete Payload with Prefix)**
  - [ ] Request succeeds (201 Created)
  - [ ] API key starts with `unlim-`
  - [ ] Rate limit tier is set to `UNLIMITED`
  - [ ] API key is saved to `api_key_unlimited` variable

**Validation Points:**
- [ ] `keyValue`: Starts with "unlim-"
- [ ] `rateLimitTier`: "UNLIMITED"
- [ ] `allowedIps`: Contains 5 CIDR blocks
- [ ] `scopes`: Contains "FULL_ACCESS" scope

## Phase 3: Environment-Specific API Key Creation with Prefixes ✅

### **3.1 Development Environment with 'dev' Prefix**
- [ ] **Create API Key - Development Environment (Complete with Prefix)**
  - [ ] Request succeeds (201 Created)
  - [ ] API key starts with `dev-`
  - [ ] Environment is set to `development`
  - [ ] Localhost domains are properly handled

**Validation Points:**
- [ ] `keyValue`: Starts with "dev-"
- [ ] `registeredDomain`: "localhost:3000"
- [ ] `allowedDomains`: Contains localhost variations
- [ ] `rateLimitTier`: "BASIC"

### **3.2 Staging Environment with 'stg' Prefix**
- [ ] **Create API Key - Staging Environment (Complete with Prefix)**
  - [ ] Request succeeds (201 Created)
  - [ ] API key starts with `stg-`
  - [ ] Environment is set to `staging`
  - [ ] Staging-specific configurations applied

**Validation Points:**
- [ ] `keyValue`: Starts with "stg-"
- [ ] `registeredDomain`: "api.staging.example.com"
- [ ] `rateLimitTier`: "STANDARD"

## Phase 4: Enhanced API Key Creation (Rivo) with Prefix ✅

### **4.1 Rivo Endpoint with 'rivo' Prefix**
- [ ] **Create Enhanced API Key - Rivo Endpoint (Complete with Prefix)**
  - [ ] Request succeeds (201 Created)
  - [ ] API key starts with `rivo-`
  - [ ] Enhanced features are enabled
  - [ ] Enterprise tier permissions applied

**Validation Points:**
- [ ] `keyValue`: Starts with "rivo-"
- [ ] `rateLimitTier`: "ENTERPRISE"
- [ ] `scopes`: Contains all 16 enterprise scopes
- [ ] AI capabilities included

## Phase 5: Prefix Variations Testing ✅

### **5.1 Custom Prefix 'admin'**
- [ ] **Create API Key - Custom Prefix 'admin'**
  - [ ] Request succeeds (201 Created)
  - [ ] API key starts with `admin-`
  - [ ] Administrative permissions applied

**Validation Points:**
- [ ] `keyValue`: Starts with "admin-"
- [ ] `registeredDomain`: "admin.example.com"
- [ ] `rateLimitTier`: "PREMIUM"

### **5.2 Custom Prefix 'biz'**
- [ ] **Create API Key - Custom Prefix 'biz'**
  - [ ] Request succeeds (201 Created)
  - [ ] API key starts with `biz-`
  - [ ] Business permissions applied

**Validation Points:**
- [ ] `keyValue`: Starts with "biz-"
- [ ] `registeredDomain`: "biz.example.com"
- [ ] `rateLimitTier`: "ENTERPRISE"

### **5.3 No Prefix (Default)**
- [ ] **Create API Key - No Prefix (Default)**
  - [ ] Request succeeds (201 Created)
  - [ ] API key uses default prefix format
  - [ ] System handles missing prefix correctly

**Validation Points:**
- [ ] `keyValue`: Uses default format (likely starts with generated prefix)
- [ ] `registeredDomain`: "noprefix.example.com"
- [ ] `rateLimitTier`: "STANDARD"

## Phase 6: Scope Combinations Testing with Prefixes ✅

### **6.1 Basic Read Scopes with 'read' Prefix**
- [ ] **Create API Key - Basic Read Scopes Only**
  - [ ] Request succeeds (201 Created)
  - [ ] API key starts with `read-`
  - [ ] Only basic read permissions granted

### **6.2 Domain Management with 'domain' Prefix**
- [ ] **Create API Key - Domain Management Scopes**
  - [ ] Request succeeds (201 Created)
  - [ ] API key starts with `domain-`
  - [ ] Domain-specific scopes applied

### **6.3 Write Permissions with 'write' Prefix**
- [ ] **Create API Key - Write Permissions Scopes**
  - [ ] Request succeeds (201 Created)
  - [ ] API key starts with `write-`
  - [ ] Write capabilities enabled

### **6.4 Analytics with 'analytics' Prefix**
- [ ] **Create API Key - Analytics Scopes**
  - [ ] Request succeeds (201 Created)
  - [ ] API key starts with `analytics-`
  - [ ] Analytics permissions granted

## Phase 7: Secure Endpoint Testing with Prefixed Keys ✅

### **7.1 RivoFetch - BASIC Tier (sk- prefix)**
- [ ] **RivoFetch - BASIC Tier API Key**
  - [ ] Request succeeds (200 OK)
  - [ ] Target URL is fetched successfully
  - [ ] Rate limit headers are present
  - [ ] Usage information is returned

### **7.2 RivoFetch - STANDARD Tier (std- prefix)**
- [ ] **RivoFetch - STANDARD Tier API Key**
  - [ ] Request succeeds (200 OK)
  - [ ] Enhanced features available
  - [ ] Higher rate limits applied

### **7.3 RivoFetch - PREMIUM Tier (prem- prefix)**
- [ ] **RivoFetch - PREMIUM Tier API Key**
  - [ ] Request succeeds (200 OK)
  - [ ] Advanced features available
  - [ ] Premium rate limits applied

## Phase 8: API Key Management Operations with Prefix Support ✅

### **8.1 Get All API Keys**
- [ ] **Get All API Keys (Paginated)**
  - [ ] Request succeeds (200 OK)
  - [ ] All created keys are listed with correct prefixes
  - [ ] Pagination works correctly
  - [ ] Sorting is applied

### **8.2 Get API Key by ID**
- [ ] **Get API Key by ID**
  - [ ] Request succeeds (200 OK)
  - [ ] Correct API key is returned
  - [ ] Prefix information is preserved (if included in response)

### **8.3 Update API Key with Prefix**
- [ ] **Update API Key (Complete Payload with Prefix)**
  - [ ] Request succeeds (200 OK)
  - [ ] All updatable fields are modified
  - [ ] Prefix changes are handled correctly (if supported)
  - [ ] Changes are persisted

### **8.4 Get Plan Usage**
- [ ] **Get Plan Usage**
  - [ ] Request succeeds (200 OK)
  - [ ] Current usage includes all prefixed keys
  - [ ] Limits are correctly displayed

## Phase 9: Error Scenarios Testing with Prefix Validation ✅

### **9.1 Prefix Validation Errors**
- [ ] **Invalid Prefix Format**
  - [ ] Request fails (400 Bad Request)
  - [ ] Prefix validation error message
  - [ ] Error code is provided
  - [ ] Allowed pattern is specified

- [ ] **Prefix Too Long**
  - [ ] Request fails (400 Bad Request)
  - [ ] Length validation error
  - [ ] Maximum length specified (10 characters)

### **9.2 Standard Validation Errors**
- [ ] **Missing Required Fields - Name**
  - [ ] Request fails (400 Bad Request)
  - [ ] Appropriate error message
  - [ ] Error code is provided

- [ ] **Missing Required Fields - Domain**
  - [ ] Request fails (400 Bad Request)
  - [ ] Domain validation error
  - [ ] Helpful error message

- [ ] **Invalid Domain Format**
  - [ ] Request fails (400 Bad Request)
  - [ ] Format validation error
  - [ ] Suggestions provided (if applicable)

- [ ] **Invalid Rate Limit Tier**
  - [ ] Request fails (400 Bad Request)
  - [ ] Enum validation error
  - [ ] Valid options listed

- [ ] **Duplicate Domain**
  - [ ] Request fails (409 Conflict)
  - [ ] Conflict error message
  - [ ] Alternative suggestions

## Phase 10: Edge Cases and Boundary Testing with Prefixes ✅

### **10.1 Maximum Field Lengths with Prefix**
- [ ] **Create API Key - Maximum Field Lengths with Prefix**
  - [ ] Request succeeds or fails appropriately
  - [ ] Boundary conditions handled
  - [ ] Prefix length validation works
  - [ ] No system errors occur

### **10.2 Empty Optional Fields with Prefix**
- [ ] **Create API Key - Empty Optional Fields with Prefix**
  - [ ] Request succeeds (201 Created)
  - [ ] Prefix is properly applied
  - [ ] Default values applied for empty fields
  - [ ] System handles empty arrays/strings

### **10.3 Special Characters with Valid Prefix**
- [ ] **Create API Key - Special Characters with Prefix**
  - [ ] Request succeeds (201 Created)
  - [ ] Valid prefix characters work correctly
  - [ ] Special characters in name/description preserved
  - [ ] Unicode support verified

## Post-Testing Validation ✅

### **Data Integrity Checks**
- [ ] All created API keys exist in database with correct prefixes
- [ ] All fields are correctly stored
- [ ] Prefix information is properly maintained
- [ ] Relationships are properly maintained
- [ ] No data corruption occurred

### **Prefix Functionality Validation**
- [ ] All API keys have correct prefixes based on request
- [ ] Prefix validation rules are enforced
- [ ] Default behavior works when no prefix specified
- [ ] Custom prefixes are properly applied
- [ ] Prefix information is preserved in management operations

### **Security Validation**
- [ ] API keys with prefixes are properly encrypted/hashed
- [ ] Prefix doesn't compromise security
- [ ] Access controls work with all prefix variations
- [ ] Rate limiting is functional for all prefixed keys

### **Performance Metrics**
- [ ] Average response time < 2 seconds (including prefix processing)
- [ ] No memory leaks detected
- [ ] Database connections properly managed
- [ ] Error rate < 1%

## Cleanup Tasks ✅

### **Test Data Cleanup**
- [ ] Remove test API keys with various prefixes (optional)
- [ ] Clear collection variables
- [ ] Reset test environment
- [ ] Document any prefix-related issues found

## Prefix-Specific Issue Tracking Template

For any prefix-related failed tests, document:

**Test Case:** [Test name with prefix]
**Expected Prefix:** [Expected prefix format]
**Actual Result:** [What actually happened with prefix]
**Prefix Validation:** [Was prefix validation correct?]
**Error Details:** [Error messages, logs]
**Reproduction Steps:** [How to reproduce]
**Priority:** [High/Medium/Low]
**Status:** [Open/In Progress/Resolved]

## Success Criteria Summary

✅ **All authentication flows work correctly**
✅ **All API key creation scenarios succeed with proper prefix validation**
✅ **All rate limit tiers create keys with correct prefixes**
✅ **All environment configurations handle prefixes correctly**
✅ **All custom prefix variations work as expected**
✅ **All scope combinations work with prefixed keys**
✅ **All secure endpoints validate prefixed API keys correctly**
✅ **All management operations preserve prefix information**
✅ **All error scenarios return appropriate prefix validation responses**
✅ **All edge cases handle prefixes gracefully**
✅ **Performance requirements are met with prefix functionality**

## Final Sign-off

**Tester:** _________________ **Date:** _________________
**Reviewer:** _________________ **Date:** _________________
**Status:** ✅ PASSED / ❌ FAILED / ⚠️ PASSED WITH ISSUES

**Prefix Functionality Notes:**
_________________________________________________
_________________________________________________

**General Notes:**
_________________________________________________
_________________________________________________
_________________________________________________
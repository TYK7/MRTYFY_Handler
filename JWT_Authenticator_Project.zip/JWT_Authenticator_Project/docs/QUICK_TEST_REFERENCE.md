# Quick Test Reference - JWT Authenticator API with Prefix Support

## 🚀 Quick Start Testing (5 Minutes)

### **1. Essential Setup**
```bash
# 1. Import Postman collection
# 2. Set base_url = http://localhost:8080
# 3. Run these 5 critical tests:
```

### **2. Critical Test Sequence**
1. **Login** → Get JWT Token
2. **Create BASIC API Key with 'sk' prefix** → Get API key
3. **Test RivoFetch** → Verify functionality
4. **Get Plan Usage** → Check limits
5. **Test Prefix Error Scenario** → Verify validation

## 📋 Complete Field Testing Checklist with Prefix

### **API Key Creation - All Fields Including Prefix**
```json
{
  "name": "Complete Test API Key",                    // ✅ Required
  "description": "Full field testing with prefix",   // ✅ Optional
  "registeredDomain": "api.test.example.com",        // ✅ Required
  "prefix": "test",                                   // ✅ Optional (1-10 chars, alphanumeric + _ + -)
  "allowedIps": ["192.168.1.100", "10.0.0.50"],    // ✅ Optional
  "allowedDomains": ["backup.test.example.com"],     // ✅ Optional
  "rateLimitTier": "STANDARD",                       // ✅ Optional
  "scopes": ["READ_BASIC", "DOMAIN_HEALTH"],         // ✅ Optional
  "expiresAt": "2024-12-31T23:59:59"                // ✅ Optional (LocalDateTime format)
}
```

## 🎯 Rate Limit Tier Testing Matrix with Prefixes

| Tier | Prefix | Domain Example | Scopes | Purpose |
|------|--------|----------------|---------|---------|
| **BASIC** | `sk` | `api.basic.com` | Basic Read | Entry level |
| **STANDARD** | `std` | `api.standard.com` | Enhanced Read | Professional |
| **PREMIUM** | `prem` | `api.premium.com` | Read + Write | Business |
| **ENTERPRISE** | `ent` | `api.enterprise.com` | Full Access | Enterprise |
| **UNLIMITED** | `unlim` | `api.unlimited.com` | Unrestricted | High Volume |

## 🔑 Prefix Validation Rules

### **Valid Prefix Examples**
```json
{
  "prefix": "sk"          // ✅ Standard
}
```

```json
{
  "prefix": "admin"       // ✅ Custom admin
}
```

```json
{
  "prefix": "biz_v2"      // ✅ With underscore and number
}
```

```json
{
  "prefix": "api-test"    // ✅ With hyphen
}
```

### **Invalid Prefix Examples**
```json
{
  "prefix": "invalid@!"   // ❌ Special characters
}
```

```json
{
  "prefix": "verylongprefix"  // ❌ Too long (>10 chars)
}
```

```json
{
  "prefix": ""            // ❌ Empty string (use null instead)
}
```

## 🎨 Rate Limit Tier Payloads with Prefixes

### **BASIC Tier**
```json
{
  "name": "BASIC Tier API Key",
  "registeredDomain": "api.basic.example.com",
  "prefix": "sk",
  "rateLimitTier": "BASIC",
  "scopes": ["READ_BASIC", "DOMAIN_HEALTH", "READ_BRANDS"],
  "expiresAt": "2024-12-31T23:59:59"
}
```

### **STANDARD Tier**
```json
{
  "name": "STANDARD Tier API Key",
  "registeredDomain": "api.standard.example.com",
  "prefix": "std",
  "rateLimitTier": "STANDARD",
  "scopes": ["READ_BASIC", "READ_ADVANCED", "DOMAIN_HEALTH", "DOMAIN_INSIGHTS"],
  "expiresAt": "2024-09-30T23:59:59"
}
```

### **PREMIUM Tier**
```json
{
  "name": "PREMIUM Tier API Key",
  "registeredDomain": "api.premium.example.com",
  "prefix": "prem",
  "rateLimitTier": "PREMIUM",
  "scopes": ["READ_BASIC", "READ_ADVANCED", "WRITE_BASIC", "DOMAIN_HEALTH"],
  "expiresAt": "2025-03-31T23:59:59"
}
```

### **ENTERPRISE Tier**
```json
{
  "name": "ENTERPRISE Tier API Key",
  "registeredDomain": "api.enterprise.example.com",
  "prefix": "ent",
  "rateLimitTier": "ENTERPRISE",
  "scopes": ["READ_BASIC", "READ_ADVANCED", "WRITE_BASIC", "WRITE_ADVANCED", "DOMAIN_MANAGEMENT"],
  "expiresAt": "2025-12-31T23:59:59"
}
```

### **UNLIMITED Tier**
```json
{
  "name": "UNLIMITED Tier API Key",
  "registeredDomain": "api.unlimited.example.com",
  "prefix": "unlim",
  "rateLimitTier": "UNLIMITED",
  "scopes": ["FULL_ACCESS"],
  "expiresAt": "2026-12-31T23:59:59"
}
```

## 🌍 Environment-Specific Testing with Prefixes

### **Development Environment**
```json
{
  "name": "Development API Key",
  "registeredDomain": "localhost:3000",
  "prefix": "dev",
  "rateLimitTier": "BASIC",
  "scopes": ["READ_BASIC", "DOMAIN_HEALTH"]
}
```

### **Staging Environment**
```json
{
  "name": "Staging API Key",
  "registeredDomain": "api.staging.example.com",
  "prefix": "stg",
  "rateLimitTier": "STANDARD",
  "scopes": ["READ_BASIC", "READ_ADVANCED", "DOMAIN_HEALTH"]
}
```

## 🎯 Custom Prefix Scenarios

### **Administrative Prefix**
```json
{
  "name": "Admin API Key",
  "registeredDomain": "admin.example.com",
  "prefix": "admin",
  "rateLimitTier": "PREMIUM",
  "scopes": ["READ_BASIC", "READ_ADVANCED", "WRITE_BASIC", "DOMAIN_MANAGEMENT"]
}
```

### **Business Prefix**
```json
{
  "name": "Business API Key",
  "registeredDomain": "biz.example.com",
  "prefix": "biz",
  "rateLimitTier": "ENTERPRISE",
  "scopes": ["BUSINESS_READ", "BUSINESS_WRITE", "ANALYTICS_READ", "ANALYTICS_WRITE"]
}
```

### **No Prefix (Default)**
```json
{
  "name": "Default API Key",
  "registeredDomain": "default.example.com",
  "rateLimitTier": "STANDARD",
  "scopes": ["READ_BASIC", "DOMAIN_HEALTH"]
}
```

## ⚠️ Critical Error Scenarios with Prefix

### **1. Invalid Prefix Format**
```json
{
  "name": "Invalid Prefix Test",
  "registeredDomain": "test.com",
  "prefix": "invalid@prefix!"
}
// Expected: 400 Bad Request
// Error: "Prefix can only contain letters, numbers, hyphens, and underscores"
```

### **2. Prefix Too Long**
```json
{
  "name": "Long Prefix Test",
  "registeredDomain": "test.com",
  "prefix": "verylongprefix"
}
// Expected: 400 Bad Request
// Error: "Prefix cannot exceed 10 characters"
```

### **3. Missing Required Fields**
```json
{
  "description": "Missing name",
  "registeredDomain": "test.com",
  "prefix": "test"
}
// Expected: 400 Bad Request
// Error: "Key name cannot be blank"
```

### **4. Invalid Domain Format**
```json
{
  "name": "Invalid Domain Test",
  "registeredDomain": "invalid-domain",
  "prefix": "test"
}
// Expected: 400 Bad Request
// Error: "Invalid domain format"
```

### **5. Invalid Rate Limit Tier**
```json
{
  "name": "Invalid Tier Test",
  "registeredDomain": "test.com",
  "prefix": "test",
  "rateLimitTier": "INVALID_TIER"
}
// Expected: 400 Bad Request
// Error: "Rate limit tier must be one of: BASIC, STANDARD, PREMIUM, ENTERPRISE, UNLIMITED"
```

## 🔍 Response Validation Checklist with Prefix

### **Successful API Key Creation (201)**
```json
{
  "id": "uuid",                           // ✅ Check format
  "name": "Expected Name",                // ✅ Matches request
  "keyValue": "prefix-abcd1234...",       // ✅ Starts with specified prefix
  "registeredDomain": "api.test.com",     // ✅ Matches request
  "mainDomain": "test.com",               // ✅ Auto-extracted
  "environment": "production",            // ✅ Matches query param
  "rateLimitTier": "STANDARD",           // ✅ Matches request
  "scopes": "READ_BASIC,DOMAIN_HEALTH",  // ✅ Comma-separated
  "isActive": true,                       // ✅ Default true
  "createdAt": "2024-01-15T10:30:00Z"    // ✅ ISO format
}
```

### **Prefix Validation Error Response**
```json
{
  "success": false,                       // ✅ Always false
  "error": "Prefix validation message",   // ✅ Human readable
  "errorCode": "INVALID_PREFIX_FORMAT",   // ✅ Machine readable
  "timestamp": "2024-01-15T10:30:00Z",   // ✅ ISO format
  "requestId": "req_123456789",           // ✅ For tracking
  "details": {
    "field": "prefix",                    // ✅ Field name
    "value": "invalid@prefix!",           // ✅ Invalid value
    "allowedPattern": "^[a-zA-Z0-9_-]*$", // ✅ Validation pattern
    "maxLength": 10                       // ✅ Length limit
  }
}
```

## 🧪 Edge Case Testing with Prefixes

### **Maximum Prefix Length (10 characters)**
```json
{
  "name": "Max Prefix Test",
  "registeredDomain": "maxprefix.com",
  "prefix": "maxlength"  // Exactly 10 characters
}
```

### **Special Characters in Name/Description with Valid Prefix**
```json
{
  "name": "Special: @#$%^&*()_+-=[]{}|;':,.<>?",
  "description": "Unicode: αβγδε 中文 العربية русский 🚀🔑💻",
  "registeredDomain": "special.com",
  "prefix": "spec_123"  // Valid prefix with underscore and numbers
}
```

### **Empty Optional Fields with Prefix**
```json
{
  "name": "Minimal Test",
  "registeredDomain": "minimal.com",
  "prefix": "min",
  "description": "",
  "allowedIps": [],
  "allowedDomains": [],
  "scopes": []
}
```

## 📊 Performance Benchmarks with Prefix

### **Response Time Targets**
- **Authentication**: < 1 second
- **API Key Creation with Prefix**: < 2 seconds
- **RivoFetch with Prefixed Key**: < 3 seconds
- **Management Operations**: < 1 second

### **Prefix Processing**
- **Prefix Validation**: < 100ms
- **Key Generation with Prefix**: < 500ms
- **Prefix Pattern Matching**: < 50ms

## 🔧 Debugging Quick Tips for Prefix Issues

### **Common Prefix Issues**
1. **Invalid Characters**: Check for special characters not allowed
2. **Length Exceeded**: Verify prefix is ≤ 10 characters
3. **Empty String**: Use `null` instead of empty string `""`
4. **Case Sensitivity**: Prefixes are case-sensitive

### **Prefix Validation Check**
```javascript
// In Postman Tests tab - Check prefix in response
if (pm.response.code === 201) {
    const response = pm.response.json();
    const requestBody = JSON.parse(pm.request.body.raw);
    
    if (requestBody.prefix && response.keyValue) {
        console.log('Expected prefix:', requestBody.prefix);
        console.log('Actual key value:', response.keyValue);
        console.log('Prefix match:', response.keyValue.startsWith(requestBody.prefix + '-'));
    }
}
```

### **Request Debugging with Prefix**
```javascript
// Log prefix-specific request details
const requestBody = JSON.parse(pm.request.body.raw);
console.log('Request Prefix:', requestBody.prefix);
console.log('Request Name:', requestBody.name);
console.log('Request Domain:', requestBody.registeredDomain);
```

## 🎯 Success Criteria Summary with Prefix

### **Must Pass (Critical)**
- [ ] Authentication works
- [ ] API key creation with prefixes succeeds
- [ ] Prefix validation rules are enforced
- [ ] Generated keys have correct prefixes
- [ ] RivoFetch endpoint works with prefixed keys

### **Should Pass (Important)**
- [ ] All rate limit tiers work with their prefixes
- [ ] All environments work with custom prefixes
- [ ] All custom prefix variations work
- [ ] Management operations preserve prefix info
- [ ] Error handling includes prefix validation

### **Could Pass (Nice to Have)**
- [ ] Performance benchmarks met with prefix processing
- [ ] Load testing passes with various prefixes
- [ ] Special characters handled in names with valid prefixes
- [ ] Maximum field lengths work with maximum prefix length

## 📞 Quick Support for Prefix Issues

### **If Prefix Tests Fail**
1. Check prefix format (alphanumeric + _ + - only)
2. Verify prefix length (≤ 10 characters)
3. Confirm prefix is not empty string
4. Check API key response format
5. Verify prefix validation error messages

### **Common Prefix Fixes**
- **Invalid Characters**: Use only letters, numbers, hyphens, underscores
- **Too Long**: Reduce to 10 characters or less
- **Empty String**: Use `null` or omit field entirely
- **Case Issues**: Check if system is case-sensitive

## 🚀 Quick Prefix Testing Sequence

1. **Basic with 'sk' prefix** → Verify `sk-` in key
2. **Custom 'admin' prefix** → Verify `admin-` in key
3. **Invalid '@' prefix** → Verify 400 error
4. **Long prefix** → Verify length validation
5. **No prefix** → Verify default behavior

This quick reference covers all essential testing scenarios for the JWT Authenticator API Key system with comprehensive prefix support! 🔑
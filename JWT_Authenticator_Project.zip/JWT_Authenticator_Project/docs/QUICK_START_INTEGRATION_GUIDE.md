# 🚀 Rivo9Fetch API - Quick Start Integration Guide

> **Extract comprehensive brand data from any website in under 5 minutes**

[![API Status](https://img.shields.io/badge/API-Live-green)](https://rivo9.com/myapp)
[![Version](https://img.shields.io/badge/Version-v1.0-blue)](https://rivo9.com/myapp/v3/api-docs)
[![Support](https://img.shields.io/badge/Support-24%2F7-orange)](https://rivo9.in)

---

## 📋 **Table of Contents**
- [🎯 What This API Does](#-what-this-api-does)
- [🧩 Common Use Cases](#-common-use-cases)
- [🔑 Getting Your API Key](#-getting-your-api-key)
- [⚡ Quick Start (5 Minutes)](#-quick-start-5-minutes)
- [🛡️ API Reference](#️-api-reference)
- [💻 Integration Examples](#-integration-examples)
- [🔒 Security Best Practices](#-security-best-practices)
- [📊 Monitoring & Analytics](#-monitoring--analytics)
- [🚨 Troubleshooting](#-troubleshooting)
- [📞 Support](#-support)

---

## 🎯 **What This API Does**

**Rivo9Fetch** extracts comprehensive brand information from any website URL in seconds:

| **Data Type** | **What You Get** |
|---------------|------------------|
| **🎨 Visual Assets** | Logos, icons, banners, brand colors |
| **🏢 Company Info** | Name, description, industry, location |
| **📱 Design Elements** | Fonts, color palettes, images |
| **🔗 Social Links** | LinkedIn, Twitter, Facebook profiles |
| **⚡ Performance** | Average response time: 2-4 seconds |

---

## 🧩 **Common Use Cases**

### **🎨 SaaS Auto-Branding**
Automatically style user dashboards with their company branding:
```javascript
const brandData = await rivo9fetch('https://usercompany.com');
const theme = {
  logo: brandData.Logo?.Logo,
  primaryColor: brandData.Colors?.[0]?.hex,
  companyName: brandData.Company?.Name
};
```

### **🤝 Sales Lead Enrichment**
Enrich prospect data for sales teams:
```javascript
const prospectData = await rivo9fetch('https://prospect.com');
const leadInfo = {
  company: prospectData.Company?.Name,
  industry: prospectData.Company?.Industry,
  employees: prospectData.Company?.Employees,
  socialLinks: prospectData.Company?.SocialLinks
};
```

### **📊 Brand Monitoring**
Monitor brand consistency across digital properties:
```javascript
const websites = ['main-site.com', 'subdomain.com'];
const brandConsistency = await Promise.all(
  websites.map(site => rivo9fetch(`https://${site}`))
);
```

### **🏢 Company Database Building**
Build comprehensive company profiles:
```javascript
const companyProfile = await rivo9fetch('https://company.com');
const profile = {
  branding: companyProfile.Logo,
  colors: companyProfile.Colors,
  companyInfo: companyProfile.Company
};
```

---

## 🔑 **Getting Your API Key**

### **Step 1: Create Account**
1. Visit **[https://rivo9.in](https://rivo9.in)**
2. Sign up or log in to your account
3. Navigate to **"API Keys"** section

### **Step 2: Generate API Key**
1. Click **"Create New API Key"**
2. Enter your **domain** (e.g., `yourdomain.com`)
3. Select your **plan tier**:
   - **FREE**: 100 requests/month
   - **PRO**: 1,000 requests/month  
   - **BUSINESS**: Unlimited requests
4. Copy your API key: `sk-1234567890abcdef...`

> **⚠️ Important**: Store your API key securely and never expose it in frontend code.

---

## ⚡ **Quick Start (5 Minutes)**

### **Step 1: Test Connection (1 minute)**
```bash
curl -X GET "https://rivo9.com/myapp/api/v1/secure/health" \
  -H "x-api-key: YOUR_API_KEY" \
  -H "Origin: https://yourdomain.com"

# Expected: {"status":"healthy","timestamp":"2024-01-15T10:30:00Z"}
```

### **Step 2: Extract Brand Data (2 minutes)**
```bash
curl -X POST "https://rivo9.com/myapp/api/v1/secure/rivofetch" \
  -H "Content-Type: application/json" \
  -H "x-api-key: YOUR_API_KEY" \
  -H "Origin: https://yourdomain.com" \
  -d '{"url": "https://github.com"}'
```

### **Step 3: Integrate Into Your App (2 minutes)**
```javascript
const extractBrand = async (url) => {
  const response = await fetch('/api/extract-brand', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url })
  });
  return response.json();
};

// Usage
const brandData = await extractBrand('https://example.com');
console.log(brandData.Company?.Name); // Company name
```

---

## 🛡️ **API Reference**

### **Base URL**
```
https://rivo9.com/myapp
```

### **Endpoint**
```http
POST /api/v1/secure/rivofetch
```

### **Headers**
| Header | Required | Description | Example |
|--------|----------|-------------|---------|
| `x-api-key` | ✅ | Your API key | `sk-1234567890abcdef...` |
| `Origin` | ✅ | Your registered domain | `https://yourdomain.com` |
| `Content-Type` | ✅ | Request content type | `application/json` |

### **Request Body**
```json
{
  "url": "https://example.com"
}
```

### **Success Response (200)**
```json
{
  "Logo": {
    "Logo": "https://example.com/logo.png",
    "Icon": "https://example.com/favicon.ico",
    "Symbol": "https://example.com/symbol.svg"
  },
  "Colors": [
    {
      "hex": "#1a73e8",
      "rgb": "rgb(26, 115, 232)",
      "name": "Primary Blue",
      "brightness": 128
    }
  ],
  "Company": {
    "Name": "Example Company",
    "Description": "Leading technology company...",
    "Industry": "Technology",
    "Location": "San Francisco, CA",
    "Website": "https://example.com",
    "SocialLinks": {
      "linkedin": "https://linkedin.com/company/example",
      "twitter": "https://twitter.com/example"
    }
  },
  "Fonts": [
    {
      "name": "Roboto",
      "type": "sans-serif",
      "stack": "Roboto, Arial, sans-serif"
    }
  ],
  "_performance": {
    "extractionTimeSeconds": 2.34,
    "timestamp": "2024-01-15T10:30:00Z"
  }
}
```

### **Error Responses**

| Code | Error | Description | Solution |
|------|-------|-------------|----------|
| `401` | Invalid API Key | API key is invalid or expired | Check your API key in dashboard |
| `403` | Domain Validation Failed | Origin header doesn't match registered domain | Verify your registered domain |
| `400` | Invalid URL | URL format is incorrect | Use valid HTTP/HTTPS URL |
| `429` | Rate Limit Exceeded | Too many requests | Wait for rate limit reset |
| `502` | Extraction Failed | Website couldn't be processed | Try again or contact support |

---

## 💻 **Integration Examples**

### **JavaScript/React**
```javascript
// React Hook for brand extraction
import { useState } from 'react';

const useBrandExtraction = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const extractBrand = async (url) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/api/extract-brand', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      setLoading(false);
      return data;
    } catch (err) {
      setError(err.message);
      setLoading(false);
      throw err;
    }
  };

  return { extractBrand, loading, error };
};

// Component usage
const BrandExtractor = () => {
  const { extractBrand, loading, error } = useBrandExtraction();
  const [brandData, setBrandData] = useState(null);

  const handleExtract = async (url) => {
    try {
      const data = await extractBrand(url);
      setBrandData(data);
    } catch (err) {
      console.error('Extraction failed:', err);
    }
  };

  return (
    <div>
      {loading && <p>Extracting brand data...</p>}
      {error && <p>Error: {error}</p>}
      {brandData && (
        <div>
          <h3>{brandData.Company?.Name}</h3>
          {brandData.Logo?.Logo && (
            <img src={brandData.Logo.Logo} alt="Logo" style={{maxHeight: '100px'}} />
          )}
        </div>
      )}
    </div>
  );
};
```

### **Node.js/Express Backend**
```javascript
const express = require('express');
const fetch = require('node-fetch');
require('dotenv').config();

const app = express();
app.use(express.json());

// Environment configuration
const config = {
  apiKey: process.env.RIVO9_API_KEY,
  baseUrl: process.env.RIVO9_BASE_URL || 'https://rivo9.com/myapp',
  origin: process.env.RIVO9_ORIGIN || 'https://yourdomain.com'
};

// Brand extraction endpoint
app.post('/api/extract-brand', async (req, res) => {
  try {
    const { url } = req.body;

    if (!url) {
      return res.status(400).json({ error: 'URL is required' });
    }

    const response = await fetch(`${config.baseUrl}/api/v1/secure/rivofetch`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': config.apiKey,
        'Origin': config.origin
      },
      body: JSON.stringify({ url })
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json(data);
    }

    // Transform response for frontend
    const transformedData = {
      company: data.Company,
      branding: {
        logo: data.Logo?.Logo,
        colors: data.Colors?.slice(0, 5), // Limit to 5 colors
        fonts: data.Fonts
      },
      performance: data._performance
    };

    res.json(transformedData);
  } catch (error) {
    console.error('Brand extraction error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Health check
app.get('/api/health', async (req, res) => {
  try {
    const response = await fetch(`${config.baseUrl}/api/v1/secure/health`, {
      headers: {
        'x-api-key': config.apiKey,
        'Origin': config.origin
      }
    });
    
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Health check failed' });
  }
});

app.listen(3000, () => {
  console.log('Server running on port 3000');
});
```

### **Python/Flask**
```python
from flask import Flask, request, jsonify
import requests
import os
from datetime import datetime

app = Flask(__name__)

# Configuration
config = {
    'api_key': os.getenv('RIVO9_API_KEY'),
    'base_url': os.getenv('RIVO9_BASE_URL', 'https://rivo9.com/myapp'),
    'origin': os.getenv('RIVO9_ORIGIN', 'https://yourdomain.com')
}

@app.route('/api/extract-brand', methods=['POST'])
def extract_brand():
    try:
        data = request.get_json()
        url = data.get('url')
        
        if not url:
            return jsonify({'error': 'URL is required'}), 400

        headers = {
            'Content-Type': 'application/json',
            'x-api-key': config['api_key'],
            'Origin': config['origin']
        }

        response = requests.post(
            f"{config['base_url']}/api/v1/secure/rivofetch",
            json={'url': url},
            headers=headers,
            timeout=30
        )

        if response.status_code != 200:
            return jsonify(response.json()), response.status_code

        brand_data = response.json()
        
        # Transform response
        result = {
            'company': brand_data.get('Company', {}),
            'branding': {
                'logo': brand_data.get('Logo', {}).get('Logo'),
                'colors': brand_data.get('Colors', [])[:5],  # Limit colors
                'fonts': brand_data.get('Fonts', [])
            },
            'performance': brand_data.get('_performance', {})
        }

        return jsonify(result)

    except requests.exceptions.Timeout:
        return jsonify({'error': 'Request timeout'}), 504
    except requests.exceptions.RequestException as e:
        return jsonify({'error': f'Request failed: {str(e)}'}), 500
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    try:
        headers = {
            'x-api-key': config['api_key'],
            'Origin': config['origin']
        }
        
        response = requests.get(
            f"{config['base_url']}/api/v1/secure/health",
            headers=headers,
            timeout=10
        )
        
        return jsonify(response.json()), response.status_code
    except Exception as e:
        return jsonify({'error': 'Health check failed'}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
```

### **Java/Spring Boot**
```java
@RestController
@RequestMapping("/api")
@Slf4j
public class BrandExtractionController {

    @Value("${rivo9.api.key}")
    private String apiKey;

    @Value("${rivo9.base.url:https://rivo9.com/myapp}")
    private String baseUrl;

    @Value("${rivo9.origin:https://yourdomain.com}")
    private String origin;

    private final RestTemplate restTemplate;

    public BrandExtractionController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @PostMapping("/extract-brand")
    public ResponseEntity<?> extractBrand(@RequestBody BrandExtractionRequest request) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("x-api-key", apiKey);
            headers.set("Origin", origin);

            HttpEntity<BrandExtractionRequest> entity = new HttpEntity<>(request, headers);

            ResponseEntity<BrandExtractionResponse> response = restTemplate.postForEntity(
                baseUrl + "/api/v1/secure/rivofetch",
                entity,
                BrandExtractionResponse.class
            );

            // Transform response
            BrandDataDto result = BrandDataDto.builder()
                .company(response.getBody().getCompany())
                .branding(BrandingDto.builder()
                    .logo(response.getBody().getLogo() != null ? 
                          response.getBody().getLogo().getLogo() : null)
                    .colors(response.getBody().getColors() != null ? 
                           response.getBody().getColors().stream()
                               .limit(5)
                               .collect(Collectors.toList()) : null)
                    .fonts(response.getBody().getFonts())
                    .build())
                .performance(response.getBody().getPerformance())
                .build();

            return ResponseEntity.ok(result);

        } catch (HttpClientErrorException e) {
            log.error("Client error during brand extraction: {}", e.getMessage());
            return ResponseEntity.status(e.getStatusCode())
                .body(Map.of("error", e.getResponseBodyAsString()));
        } catch (Exception e) {
            log.error("Error during brand extraction", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Internal server error"));
        }
    }

    @GetMapping("/health")
    public ResponseEntity<?> healthCheck() {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("x-api-key", apiKey);
            headers.set("Origin", origin);

            HttpEntity<String> entity = new HttpEntity<>(headers);

            ResponseEntity<Map> response = restTemplate.exchange(
                baseUrl + "/api/v1/secure/health",
                HttpMethod.GET,
                entity,
                Map.class
            );

            return ResponseEntity.ok(response.getBody());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(Map.of("error", "Health check failed"));
        }
    }
}

// DTOs
@Data
@Builder
public class BrandDataDto {
    private CompanyData company;
    private BrandingDto branding;
    private PerformanceData performance;
}

@Data
@Builder
public class BrandingDto {
    private String logo;
    private List<ColorData> colors;
    private List<FontData> fonts;
}
```

### **Angular**
```typescript
// brand-extraction.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class BrandExtractionService {
  private apiUrl = '/api/extract-brand';

  constructor(private http: HttpClient) {}

  extractBrand(url: string): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    return this.http.post(this.apiUrl, { url }, { headers })
      .pipe(
        retry(2),
        catchError(this.handleError)
      );
  }

  healthCheck(): Observable<any> {
    return this.http.get('/api/health')
      .pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'An error occurred';
    
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = error.error?.error || `HTTP ${error.status}: ${error.statusText}`;
    }
    
    return throwError(() => new Error(errorMessage));
  }
}

// brand-extraction.component.ts
import { Component } from '@angular/core';
import { BrandExtractionService } from './brand-extraction.service';

@Component({
  selector: 'app-brand-extraction',
  template: `
    <div class="brand-extraction-container">
      <div class="input-section">
        <input 
          [(ngModel)]="url" 
          placeholder="Enter website URL (e.g., https://github.com)"
          type="url"
          class="url-input"
          [disabled]="loading">
        <button 
          (click)="extractBrand()" 
          [disabled]="loading || !isValidUrl()"
          class="extract-btn">
          {{loading ? 'Extracting...' : 'Extract Brand'}}
        </button>
      </div>
      
      <div *ngIf="error" class="error-message">
        <strong>Error:</strong> {{error}}
      </div>
      
      <div *ngIf="brandData" class="results-section">
        <div class="company-info">
          <h2>{{brandData.company?.Name}}</h2>
          <p *ngIf="brandData.company?.Description">{{brandData.company.Description}}</p>
          <div class="company-details">
            <span *ngIf="brandData.company?.Industry" class="industry">
              {{brandData.company.Industry}}
            </span>
            <span *ngIf="brandData.company?.Location" class="location">
              📍 {{brandData.company.Location}}
            </span>
          </div>
        </div>
        
        <div *ngIf="brandData.branding?.logo" class="logo-section">
          <h3>Logo</h3>
          <img [src]="brandData.branding.logo" 
               alt="Company Logo"
               class="company-logo">
        </div>
        
        <div *ngIf="brandData.branding?.colors?.length" class="colors-section">
          <h3>Brand Colors</h3>
          <div class="color-palette">
            <div *ngFor="let color of brandData.branding.colors" 
                 class="color-swatch"
                 [style.background-color]="color.hex"
                 [title]="color.name || color.hex">
              <span class="color-hex">{{color.hex}}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .brand-extraction-container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
    }
    
    .input-section {
      display: flex;
      gap: 10px;
      margin-bottom: 20px;
    }
    
    .url-input {
      flex: 1;
      padding: 12px;
      border: 2px solid #e1e5e9;
      border-radius: 6px;
      font-size: 16px;
    }
    
    .extract-btn {
      padding: 12px 24px;
      background: #1a73e8;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 16px;
    }
    
    .extract-btn:disabled {
      background: #ccc;
      cursor: not-allowed;
    }
    
    .error-message {
      background: #fee;
      border: 1px solid #fcc;
      padding: 12px;
      border-radius: 6px;
      color: #c33;
      margin-bottom: 20px;
    }
    
    .results-section {
      border: 1px solid #e1e5e9;
      border-radius: 8px;
      padding: 20px;
    }
    
    .company-info h2 {
      margin: 0 0 10px 0;
      color: #333;
    }
    
    .company-details {
      display: flex;
      gap: 20px;
      margin: 10px 0;
    }
    
    .industry, .location {
      background: #f1f3f4;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 14px;
    }
    
    .logo-section, .colors-section {
      margin-top: 20px;
      padding-top: 20px;
      border-top: 1px solid #e1e5e9;
    }
    
    .company-logo {
      max-height: 100px;
      max-width: 200px;
    }
    
    .color-palette {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
    }
    
    .color-swatch {
      width: 80px;
      height: 80px;
      border-radius: 8px;
      display: flex;
      align-items: end;
      justify-content: center;
      position: relative;
      border: 1px solid #e1e5e9;
    }
    
    .color-hex {
      background: rgba(0,0,0,0.7);
      color: white;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 12px;
      margin-bottom: 4px;
    }
  `]
})
export class BrandExtractionComponent {
  url = '';
  brandData: any = null;
  loading = false;
  error: string | null = null;

  constructor(private brandService: BrandExtractionService) {}

  extractBrand() {
    if (!this.isValidUrl()) return;
    
    this.loading = true;
    this.error = null;
    this.brandData = null;
    
    this.brandService.extractBrand(this.url).subscribe({
      next: (data) => {
        this.brandData = data;
        this.loading = false;
      },
      error: (error) => {
        console.error('Brand extraction failed:', error);
        this.error = error.message;
        this.loading = false;
      }
    });
  }

  isValidUrl(): boolean {
    if (!this.url) return false;
    try {
      new URL(this.url);
      return true;
    } catch {
      return false;
    }
  }
}
```

---

## 🔒 **Security Best Practices**

### **🔐 API Key Management**
- ✅ **Environment Variables**: Store keys in `.env` files, never in code
- ✅ **Regular Rotation**: Rotate API keys every 30-90 days
- ✅ **Domain Validation**: Always register your exact domain
- ✅ **Monitor Usage**: Check for unusual activity in dashboard

### **🛡️ Implementation Security**
```javascript
// ✅ SECURE: Backend proxy pattern
app.post('/api/extract-brand', async (req, res) => {
  // API key safely stored on server
  const response = await fetch('https://rivo9.com/myapp/api/v1/secure/rivofetch', {
    headers: { 'x-api-key': process.env.RIVO9_API_KEY }
  });
});

// ❌ INSECURE: Frontend direct calls
const response = await fetch('https://rivo9.com/myapp/api/v1/secure/rivofetch', {
  headers: { 'x-api-key': 'sk-exposed-key' } // Never do this!
});
```

### **📊 Rate Limit Management**
```javascript
// Implement exponential backoff
const extractWithRetry = async (url, maxRetries = 3) => {
  for (let i = 0; i < maxRetries; i++) {
    try {
      const response = await fetch('/api/extract-brand', {
        method: 'POST',
        body: JSON.stringify({ url })
      });
      
      if (response.status === 429) {
        const retryAfter = response.headers.get('retry-after') || Math.pow(2, i);
        await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
        continue;
      }
      
      return response.json();
    } catch (error) {
      if (i === maxRetries - 1) throw error;
    }
  }
};
```

---

## 📊 **Monitoring & Analytics**

### **📈 Usage Dashboard**
Monitor your API usage in real-time:
- **Dashboard**: [https://rivo9.in/dashboard](https://rivo9.in/dashboard)
- **Analytics**: Request count, success rate, response times
- **Alerts**: Rate limit warnings, error notifications

### **🔍 Usage Tracking**
```javascript
// Track API performance in your application
const trackApiUsage = (response) => {
  const metrics = {
    remaining: response.headers.get('x-ratelimit-remaining'),
    resetTime: response.headers.get('x-ratelimit-reset'),
    responseTime: response.headers.get('x-response-time')
  };
  
  // Log metrics
  console.log('API Metrics:', metrics);
  
  // Alert on low remaining requests
  if (parseInt(metrics.remaining) < 10) {
    console.warn('⚠️ Approaching rate limit!');
    // Send alert to monitoring system
  }
};
```

### **📊 Plan Tiers**
| Plan | Requests/Month | Rate Limit | Price |
|------|----------------|------------|-------|
| **FREE** | 100 | 10/hour | Free |
| **PRO** | 1,000 | 100/hour | $29/month |
| **BUSINESS** | Unlimited | 1000/hour | $99/month |

---

## 🚨 **Troubleshooting**

### **Common Issues & Solutions**

#### **❌ "Invalid API key" (401)**
```bash
# Test your API key
curl -X GET "https://rivo9.com/myapp/api/v1/secure/health" \
  -H "x-api-key: YOUR_API_KEY" \
  -H "Origin: https://yourdomain.com"
```
**Solutions:**
- Verify API key in dashboard
- Check for extra spaces or characters
- Ensure key hasn't expired

#### **❌ "Domain validation failed" (403)**
```javascript
// Ensure Origin header matches registered domain exactly
const response = await fetch('https://rivo9.com/myapp/api/v1/secure/rivofetch', {
  headers: {
    'Origin': 'https://yourdomain.com' // Must match exactly!
  }
});
```
**Solutions:**
- Check registered domain in dashboard
- Verify Origin header format
- Ensure protocol (http/https) matches

#### **❌ "Rate limit exceeded" (429)**
```javascript
// Check rate limit headers
const response = await fetch('/api/extract-brand', options);
const remaining = response.headers.get('x-ratelimit-remaining');
const resetTime = response.headers.get('x-ratelimit-reset');

console.log(`Remaining: ${remaining}, Reset: ${new Date(resetTime * 1000)}`);
```
**Solutions:**
- Wait for rate limit reset
- Implement request queuing
- Upgrade to higher plan tier

#### **❌ "Extraction failed" (502)**
**Common causes:**
- Website blocks automated requests
- Website requires JavaScript rendering
- Network connectivity issues

**Solutions:**
- Try again after a few minutes
- Check if website is accessible
- Contact support for persistent issues

### **🔧 Environment Setup**
```bash
# .env file
RIVO9_API_KEY=sk-your-api-key-here
RIVO9_BASE_URL=https://rivo9.com/myapp
RIVO9_ORIGIN=https://yourdomain.com

# Optional settings
RIVO9_TIMEOUT=30000
RIVO9_RETRY_ATTEMPTS=3
```

### **🧪 Testing Checklist**
```bash
# 1. Health check
curl -X GET "https://rivo9.com/myapp/api/v1/secure/health" \
  -H "x-api-key: YOUR_API_KEY" \
  -H "Origin: https://yourdomain.com"

# 2. Basic extraction
curl -X POST "https://rivo9.com/myapp/api/v1/secure/rivofetch" \
  -H "Content-Type: application/json" \
  -H "x-api-key: YOUR_API_KEY" \
  -H "Origin: https://yourdomain.com" \
  -d '{"url": "https://github.com"}'

# 3. Error handling
curl -X POST "https://rivo9.com/myapp/api/v1/secure/rivofetch" \
  -H "Content-Type: application/json" \
  -H "x-api-key: invalid-key" \
  -H "Origin: https://yourdomain.com" \
  -d '{"url": "https://github.com"}'
```

---

## 📞 **Support**

### **📧 Contact Options**
- **Technical Support**: [support@rivo9.com](mailto:support@rivo9.com)
- **Dashboard**: [https://rivo9.in/support](https://rivo9.in/support)
- **Documentation**: [https://rivo9.com/myapp/swagger-ui.html](https://rivo9.com/myapp/swagger-ui.html)

### **📚 Additional Resources**
- **API Documentation**: [Enhanced Developer Documentation](./ENHANCED_DEVELOPER_DOCUMENTATION.md)
- **Status Page**: [https://status.rivo9.com](https://status.rivo9.com)
- **Changelog**: [https://rivo9.in/changelog](https://rivo9.in/changelog)

### **🚀 Getting Help**
1. **Check this guide** for common solutions
2. **Test with curl** to isolate issues
3. **Check dashboard** for usage and errors
4. **Contact support** with specific error messages

---

**🎉 Congratulations!** You've successfully integrated the Rivo9Fetch Brand Extraction API. Your application can now extract comprehensive brand data from any website in seconds.

*Happy coding! 🚀*

---

<div align="center">
  <strong>Rivo9Fetch API v1.0</strong><br>
  Built with ❤️ for developers
</div>
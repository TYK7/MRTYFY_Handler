# 🔧 Handling Missing Domain Header Scenarios

## 🎯 **Problem Solved**

Instead of throwing `MISSING_DOMAIN_HEADER` errors, the system now uses **intelligent fallback strategies** to handle legitimate scenarios where domain headers are missing.

## 🚀 **Fallback Strategies Implemented**

### **Strategy 1: IP-Based Validation Fallback**

When domain headers are missing, the system falls back to IP validation if the API key has IP restrictions configured.

#### **How to Configure:**
```bash
# Create API key with IP restrictions
curl -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Server API Key",
    "description": "For server-to-server communication",
    "registeredDomain": "api.company.com",
    "allowedIps": ["192.168.1.100", "10.0.0.0/8", "203.0.113.0/24"],
    "rateLimitTier": "ENTERPRISE"
  }'
```

#### **Usage (No Domain Headers Required):**
```bash
# This will work even without Origin/Referer headers
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: sk-your-server-key" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://external-api.com/data"}'
# ✅ Success: Falls back to IP validation
```

### **Strategy 2: Server-to-Server API Keys**

API keys with server-to-server indicators automatically bypass domain validation.

#### **Auto-Detection Criteria:**
- **Scopes**: Contains `SERVER`, `S2S`, `BACKEND`, `SERVICE`, `SYSTEM`
- **Names**: Contains `server`, `backend`, `service`, `cron`, `job`, `worker`
- **Prefixes**: `srv-`, `svc-`, `s2s-`, `sys-`

#### **Example:**
```bash
# Create server-to-server API key
curl -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Backend Service Key",
    "description": "For microservice communication",
    "prefix": "srv-",
    "registeredDomain": "internal.company.com",
    "scopes": ["SERVER_ACCESS", "BACKEND_API"],
    "rateLimitTier": "UNLIMITED"
  }'
```

#### **Usage:**
```python
# Python server-to-server call
import requests

response = requests.post(
    'http://localhost:8080/myapp/api/secure/forward',
    headers={'x-api-key': 'srv-your-server-key'},
    json={'url': 'https://internal-api.company.com/data'}
)
# ✅ Success: Server-to-server bypass
```

### **Strategy 3: Special Scopes Bypass**

API keys with special administrative scopes bypass domain validation.

#### **Special Scopes:**
- `FULL_ACCESS`
- `ADMIN_ACCESS`
- `SYSTEM_ACCESS`
- `DOMAINLESS_ACCESS`

#### **Example:**
```bash
# Create admin API key
curl -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Admin API Key",
    "description": "Full system access",
    "registeredDomain": "admin.company.com",
    "scopes": ["FULL_ACCESS"],
    "rateLimitTier": "UNLIMITED"
  }'
```

### **Strategy 4: Development Environment Bypass**

In development environments, testing API keys automatically bypass domain validation.

#### **Auto-Detection:**
- **Environment**: `dev`, `test`, `local`, `development` profiles
- **Key Names**: Contains `test`, `dev`, `demo`, `local`

#### **Configuration:**
```yaml
# application-dev.yml
app:
  api-key:
    validation:
      fallback:
        enable-development-bypass: true
      development:
        allow-domainless-access: true
        testing-key-patterns: ["test", "dev", "demo", "local"]
```

## 📋 **Configuration Options**

### **Complete Configuration:**
```yaml
# application.yml
app:
  api-key:
    validation:
      domain-validation-enabled: true
      
      fallback:
        enable-ip-fallback: true
        enable-server-to-server-bypass: true
        enable-special-scopes-bypass: true
        enable-development-bypass: true
        strict-mode: false  # Set to true to disable all fallbacks
      
      development:
        allow-domainless-access: true
        development-profiles: ["dev", "test", "local", "development"]
        testing-key-patterns: ["test", "dev", "demo", "local"]
      
      server-to-server:
        enable-auto-detection: true
        server-scopes: ["SERVER", "S2S", "BACKEND", "SERVICE", "SYSTEM"]
        server-name-patterns: ["server", "backend", "service", "cron", "job", "worker"]
        server-prefixes: ["srv", "svc", "s2s", "sys"]
```

## 🧪 **Testing Different Scenarios**

### **Scenario 1: cURL Testing (IP Fallback)**
```bash
# Step 1: Create API key with IP restrictions
API_KEY=$(curl -s -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test IP Fallback",
    "registeredDomain": "test.com",
    "allowedIps": ["127.0.0.1", "192.168.0.0/16"]
  }' | jq -r '.keyValue')

# Step 2: Test without domain headers (should work with IP fallback)
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://httpbin.org/json"}'
# ✅ Success: IP fallback validation
```

### **Scenario 2: Server-to-Server (Auto-Bypass)**
```bash
# Step 1: Create server API key
SERVER_KEY=$(curl -s -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Backend Service",
    "prefix": "srv-",
    "registeredDomain": "backend.company.com",
    "scopes": ["SERVER_ACCESS"]
  }' | jq -r '.keyValue')

# Step 2: Test server-to-server call (should auto-bypass)
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: $SERVER_KEY" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://internal-api.com/data"}'
# ✅ Success: Server-to-server bypass
```

### **Scenario 3: Mobile App (IP + Domain)**
```javascript
// React Native example
const makeApiCall = async () => {
  try {
    const response = await fetch('http://localhost:8080/myapp/api/secure/forward', {
      method: 'POST',
      headers: {
        'x-api-key': 'sk-mobile-app-key',
        'Content-Type': 'application/json',
        // Add Origin header for mobile apps
        'Origin': 'https://mobileapp.company.com'
      },
      body: JSON.stringify({
        url: 'https://api.company.com/mobile-data'
      })
    });
    
    const data = await response.json();
    console.log('Success:', data);
  } catch (error) {
    console.error('Error:', error);
  }
};
```

### **Scenario 4: Microservice Communication**
```java
// Spring Boot microservice
@Service
public class ExternalApiService {
    
    @Value("${app.api-key}")
    private String apiKey;
    
    public ResponseEntity<String> callExternalApi(String url) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("x-api-key", apiKey);
        headers.set("Content-Type", "application/json");
        // No Origin header needed for server-to-server keys
        
        HttpEntity<Map<String, String>> entity = new HttpEntity<>(
            Map.of("url", url), headers
        );
        
        return restTemplate.postForEntity(
            "http://localhost:8080/myapp/api/secure/forward",
            entity,
            String.class
        );
        // ✅ Success: Server-to-server bypass or IP fallback
    }
}
```

## 🔒 **Security Considerations**

### **Maintained Security:**
1. **IP Validation**: When domain headers are missing, IP restrictions are enforced
2. **Scope Validation**: All existing scope validations remain active
3. **Rate Limiting**: Professional rate limiting still applies
4. **Audit Logging**: All fallback validations are logged

### **Security Levels:**
```
Level 1: Domain + IP + Scopes + Rate Limiting (Highest)
Level 2: IP + Scopes + Rate Limiting (High)
Level 3: Server-to-Server + Scopes + Rate Limiting (Medium-High)
Level 4: Special Scopes + Rate Limiting (Medium)
Level 5: Development Bypass (Lowest - Dev only)
```

## 📊 **Response Examples**

### **Success with IP Fallback:**
```json
{
  "data": "forwarded response data",
  "headers": {
    "X-RateLimit-Limit": "5000",
    "X-RateLimit-Remaining": "4999",
    "X-Validation-Type": "IP_FALLBACK"
  }
}
```

### **Success with Server-to-Server Bypass:**
```json
{
  "data": "forwarded response data",
  "headers": {
    "X-RateLimit-Limit": "100000",
    "X-RateLimit-Remaining": "99999",
    "X-Validation-Type": "SERVER_TO_SERVER"
  }
}
```

### **Still Blocked (No Fallback Available):**
```json
{
  "error": "Could not determine request domain. Configure IP restrictions or use appropriate headers (Origin, Referer, Host).",
  "status": 403,
  "errorCode": "MISSING_DOMAIN_NO_FALLBACK",
  "timestamp": "2024-01-15T10:30:00Z",
  "suggestions": [
    "Add IP restrictions to your API key for server-to-server usage",
    "Include Origin or Referer header in your requests",
    "Use server-to-server naming conventions (srv-, backend, service)",
    "Configure special scopes for administrative access"
  ]
}
```

## 🎯 **Summary**

The system now intelligently handles missing domain headers through:

1. **✅ IP Fallback**: Uses IP validation when domain headers are missing
2. **✅ Server-to-Server Detection**: Auto-bypasses for appropriate API keys
3. **✅ Special Scopes**: Admin/system keys bypass domain validation
4. **✅ Development Mode**: Testing keys work without domains in dev environments
5. **✅ Configurable**: All strategies can be enabled/disabled via configuration

**Result**: No more `MISSING_DOMAIN_HEADER` errors for legitimate use cases while maintaining security through alternative validation methods.

---

**Last Updated**: January 2024  
**Version**: 2.0.0
# API Key Functionality - Execution Flow Documentation

## Overview
This document outlines the complete execution flow for API key functionality in the JWT Authenticator Project, including creation, validation, and usage across secure endpoints.

## Table of Contents
1. [API Key Creation Flow](#api-key-creation-flow)
2. [API Key Validation Flow](#api-key-validation-flow)
3. [Secure Endpoint Access Flow](#secure-endpoint-access-flow)
4. [Plan-Based Validation Flow](#plan-based-validation-flow)
5. [Domain Management Flow](#domain-management-flow)
6. [Error Handling Flow](#error-handling-flow)

---

## 1. API Key Creation Flow

### 1.1 Standard API Key Creation (`POST /api/v1/api-keys`)

```mermaid
graph TD
    A[Client Request] --> B[JWT Authentication]
    B --> C[Extract User ID]
    C --> D[Parse Environment Parameter]
    D --> E[Enhanced API Key Service]
    E --> F[Plan Validation Service]
    F --> G{Check API Key Limits}
    G -->|Limit Exceeded| H[Return 403 Forbidden]
    G -->|Within Limits| I[Domain Management Service]
    I --> J[Domain Processing & Validation]
    J --> K{Domain Available?}
    K -->|No| L[Return 409 Conflict]
    K -->|Yes| M[Generate API Key]
    M --> N[Assign Scopes Based on Plan]
    N --> O[Set Rate Limit Tier]
    O --> P[Save to Database]
    P --> Q[Initialize Usage Tracking]
    Q --> R[Return 201 Created]
```

#### Step-by-Step Execution:

1. **Authentication & Authorization**
   - JWT token validation
   - Extract user ID from token
   - Verify user exists in database

2. **Request Validation**
   - Validate request DTO fields
   - Parse environment parameter (production/development/staging)
   - Check required fields (name, registeredDomain)

3. **Plan-Based Validation**
   - Get user's current plan (FREE/PRO/BUSINESS)
   - Check current API key count vs plan limits
   - Check current domain count vs plan limits
   - Validate if user can create more API keys

4. **Domain Processing**
   - Extract main domain from registered domain
   - Generate subdomain pattern
   - Validate domain format and availability
   - Check domain uniqueness across system

5. **API Key Generation**
   - Generate secure API key with prefix `sk-`
   - Create SHA-256 hash for storage
   - Assign default scopes based on user plan
   - Set rate limit tier based on user plan

6. **Database Operations**
   - Save API key entity
   - Initialize monthly usage tracking
   - Record creation in audit logs

7. **Response Generation**
   - Return comprehensive response with all API key details
   - Include raw API key (shown only once)

### 1.2 Enhanced API Key Creation (`POST /api/v1/api-keys/rivo-create-api`)

**Note**: This endpoint uses the exact same flow as the standard creation endpoint. Both endpoints call `createApiKeyWithPlanValidation()` method, ensuring identical functionality and validation.

---

## 2. API Key Validation Flow

### 2.1 Request Validation Flow

```mermaid
graph TD
    A[Incoming Request] --> B[Extract API Key]
    B --> C{API Key Present?}
    C -->|No| D[Return 401 Unauthorized]
    C -->|Yes| E[Hash API Key]
    E --> F[Database Lookup]
    F --> G{API Key Found?}
    G -->|No| H[Return 401 Invalid Key]
    G -->|Yes| I[Check Active Status]
    I --> J{Is Active?}
    J -->|No| K[Return 401 Inactive]
    J -->|Yes| L[Check Expiration]
    L --> M{Is Expired?}
    M -->|Yes| N[Return 401 Expired]
    M -->|No| O[Domain Validation]
    O --> P[Plan Validation]
    P --> Q[Rate Limit Check]
    Q --> R[Monthly Quota Check]
    R --> S[Scope Validation]
    S --> T[Allow Request]
```

#### Validation Steps:

1. **API Key Extraction**
   - Check `x-api-key` header
   - Check `Authorization: Bearer` header
   - Check query parameter `api_key`

2. **API Key Verification**
   - Hash the provided key using SHA-256
   - Look up in database by hash
   - Verify key exists and belongs to active user

3. **Status Checks**
   - Verify API key is active (`isActive = true`)
   - Check expiration date (`expiresAt`)
   - Verify not revoked (`revokedAt = null`)

4. **Domain Validation**
   - Extract request domain from `Origin` or `Referer` headers
   - Check against registered domain
   - Validate subdomain patterns if applicable
   - Handle localhost and development domains

5. **Plan & Quota Validation**
   - Check user's current plan limits
   - Verify monthly API call quota
   - Check rate limiting based on tier

6. **Scope Validation**
   - Extract required scopes for endpoint
   - Verify API key has necessary permissions
   - Check hierarchical scope permissions

---

## 3. Secure Endpoint Access Flow

### 3.1 RivoFetch Endpoint (`POST /api/v1/secure/rivofetch`)

```mermaid
graph TD
    A[Client Request] --> B[API Key Extraction]
    B --> C[Enhanced Validation Service]
    C --> D[Comprehensive Validation]
    D --> E{Validation Success?}
    E -->|No| F[Return Error Response]
    E -->|Yes| G[Professional Rate Limiting]
    G --> H{Rate Limit OK?}
    H -->|No| I[Return 429 Too Many Requests]
    H -->|Yes| J[Forward Service]
    J --> K[External API Call]
    K --> L[Process Response]
    L --> M[Usage Tracking]
    M --> N[Return Success Response]
```

#### Execution Steps:

1. **Request Processing**
   - Extract API key from headers
   - Parse request body (URL to fetch)
   - Log request details

2. **Enhanced Validation**
   - Complete API key validation
   - Domain validation with origin checking
   - Plan-based quota validation
   - Scope permission checking

3. **Rate Limiting**
   - Check professional rate limits
   - Apply tier-based restrictions
   - Return rate limit headers

4. **External API Call**
   - Forward request to target URL
   - Handle response processing
   - Apply timeout and error handling

5. **Usage Tracking**
   - Record API call in monthly usage
   - Update usage statistics
   - Log request details for analytics

6. **Response Processing**
   - Format response data
   - Add metadata and timing
   - Return structured response

---

## 4. Plan-Based Validation Flow

### 4.1 Plan Limits Enforcement

```mermaid
graph TD
    A[User Request] --> B[Get User Plan]
    B --> C{Plan Type}
    C -->|FREE| D[FREE Limits]
    C -->|PRO| E[PRO Limits]
    C -->|BUSINESS| F[BUSINESS Limits]
    D --> G[Max 1 API Key<br/>Max 1 Domain<br/>100 Monthly Calls]
    E --> H[Max 3 API Keys<br/>Max 3 Domains<br/>1,000 Monthly Calls]
    F --> I[Max 10 API Keys<br/>Max 10 Domains<br/>Unlimited Calls]
    G --> J[Check Current Usage]
    H --> J
    I --> J
    J --> K{Within Limits?}
    K -->|No| L[Return Plan Limit Error]
    K -->|Yes| M[Proceed with Request]
```

#### Plan Specifications:

**FREE Plan:**
- API Keys: 1 maximum
- Domains: 1 maximum  
- Monthly API Calls: 100
- Rate Limit: 50 requests/day
- Scopes: `READ_BASIC,DOMAIN_HEALTH,READ_BRANDS`

**PRO Plan:**
- API Keys: 3 maximum
- Domains: 3 maximum
- Monthly API Calls: 1,000
- Rate Limit: 200 requests/day
- Scopes: `READ_BASIC,READ_ADVANCED,DOMAIN_HEALTH,DOMAIN_INSIGHTS,READ_BRANDS,READ_CATEGORIES,ANALYTICS_READ`

**BUSINESS Plan:**
- API Keys: 10 maximum
- Domains: 10 maximum
- Monthly API Calls: Unlimited
- Rate Limit: 1,000 requests/day
- Scopes: All available scopes including write permissions

---

## 5. Domain Management Flow

### 5.1 Domain Processing and Validation

```mermaid
graph TD
    A[Domain Input] --> B[Domain Normalization]
    B --> C[Extract Main Domain]
    C --> D[Generate Subdomain Pattern]
    D --> E[Format Validation]
    E --> F{Valid Format?}
    F -->|No| G[Return Format Error]
    F -->|Yes| H[Uniqueness Check]
    H --> I{Domain Available?}
    I -->|No| J[Generate Suggestions]
    I -->|Yes| K[Domain Processing Complete]
    J --> L[Return Conflict with Suggestions]
    K --> M[Proceed with Creation]
```

#### Domain Processing Steps:

1. **Domain Normalization**
   - Convert to lowercase
   - Remove protocol prefixes
   - Trim whitespace
   - Validate basic format

2. **Main Domain Extraction**
   - Extract root domain from subdomain
   - Handle special cases (localhost, IP addresses)
   - Generate main domain for pattern matching

3. **Subdomain Pattern Generation**
   - Create wildcard patterns for subdomains
   - Handle development domains
   - Set up pattern matching rules

4. **Validation Checks**
   - Format validation using regex
   - DNS resolution check (optional)
   - Blacklist checking
   - Uniqueness verification

5. **Suggestion Generation**
   - Generate alternative domains if unavailable
   - Suggest variations with prefixes/suffixes
   - Provide user-friendly alternatives

---

## 6. Error Handling Flow

### 6.1 Comprehensive Error Response System

```mermaid
graph TD
    A[Error Occurs] --> B{Error Type}
    B -->|Validation Error| C[400 Bad Request]
    B -->|Authentication Error| D[401 Unauthorized]
    B -->|Plan Limit Error| E[403 Forbidden]
    B -->|Domain Conflict| F[409 Conflict]
    B -->|Rate Limit Error| G[429 Too Many Requests]
    B -->|Server Error| H[500 Internal Server Error]
    C --> I[Format Validation Response]
    D --> I
    E --> I
    F --> I
    G --> I
    H --> I
    I --> J[Add Error Details]
    J --> K[Add Timestamp]
    K --> L[Add Request ID]
    L --> M[Return Structured Error]
```

#### Error Response Format:

```json
{
  "success": false,
  "error": "Detailed error message",
  "errorCode": "ERROR_CODE",
  "timestamp": "2024-01-15T10:30:00Z",
  "requestId": "req_123456789",
  "details": {
    "field": "registeredDomain",
    "value": "example.com",
    "suggestions": ["api.example.com", "app.example.com"]
  }
}
```

#### Common Error Codes:

- `MISSING_API_KEY`: API key not provided
- `INVALID_API_KEY`: API key not found or invalid
- `API_KEY_INACTIVE`: API key is deactivated
- `API_KEY_EXPIRED`: API key has expired
- `DOMAIN_VALIDATION_FAILED`: Domain format invalid
- `DOMAIN_ALREADY_EXISTS`: Domain already registered
- `API_KEY_LIMIT_EXCEEDED`: Plan API key limit reached
- `DOMAIN_LIMIT_EXCEEDED`: Plan domain limit reached
- `MONTHLY_QUOTA_EXCEEDED`: Monthly API call limit reached
- `RATE_LIMIT_EXCEEDED`: Rate limit exceeded
- `INSUFFICIENT_PERMISSIONS`: Missing required scopes

---

## Performance Considerations

### Caching Strategy
- API key validation results cached for 5 minutes
- Domain validation results cached for 1 hour
- Plan limits cached for 15 minutes
- Rate limit counters use Redis with TTL

### Database Optimization
- Indexed fields: `keyHash`, `userFkId`, `registeredDomain`
- Connection pooling for high concurrency
- Read replicas for validation queries

### Monitoring and Alerting
- API key usage metrics
- Plan limit approaching alerts
- Domain validation failure tracking
- Rate limit breach notifications

---

## Security Considerations

### API Key Security
- Keys stored as SHA-256 hashes
- Raw keys never logged or stored
- Secure random generation (256-bit entropy)
- Regular key rotation recommendations

### Domain Security
- Origin header validation
- Referer header checking
- CORS policy enforcement
- Development domain restrictions

### Rate Limiting Security
- Distributed rate limiting with Redis
- IP-based fallback limits
- Burst protection mechanisms
- DDoS mitigation strategies

---

This execution flow ensures robust, secure, and scalable API key management with comprehensive validation and error handling.
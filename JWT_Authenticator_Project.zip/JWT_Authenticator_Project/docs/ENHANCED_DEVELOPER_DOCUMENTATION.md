# JWT Authenticator API - Professional Developer Documentation

> **Enterprise-Grade Brand Extraction & API Key Management Platform**

[![API Version](https://img.shields.io/badge/API%20Version-v1-blue)](https://api.yourcompany.com/v1)
[![Documentation](https://img.shields.io/badge/Documentation-Complete-green)](https://docs.yourcompany.com)
[![Support](https://img.shields.io/badge/Support-24%2F7-orange)](mailto:support@yourcompany.com)

---

## 📋 Table of Contents

### **Getting Started**
1. [🚀 Quick Start Guide](#-quick-start-guide)
2. [🔧 Integration Workflow](#-integration-workflow)
3. [🏗️ Post-Creation Setup](#️-post-creation-setup)

### **Core Features**
4. [🔑 API Key Management](#-api-key-management)
5. [🛡️ Brand Extraction (RivoFetch)](#️-brand-extraction-rivofetch)
6. [🔒 Authentication & Security](#-authentication--security)

### **Advanced Topics**
7. [📊 Plan-Based Access Control](#-plan-based-access-control)
8. [🌐 Domain Management](#-domain-management)
9. [⚡ Rate Limiting & Performance](#-rate-limiting--performance)
10. [🚨 Error Handling & Troubleshooting](#-error-handling--troubleshooting)

### **Implementation Guides**
11. [💻 SDK Examples & Code Samples](#-sdk-examples--code-samples)
12. [🏭 Production Deployment](#-production-deployment)
13. [📈 Monitoring & Analytics](#-monitoring--analytics)
14. [✅ Best Practices](#-best-practices)

---

## 🚀 Quick Start Guide

### **What is JWT Authenticator API?**

JWT Authenticator API is an enterprise-grade platform that provides:
- **🔑 Secure API Key Management** with domain-based validation
- **🎨 Brand Extraction Services** via RivoFetch endpoint
- **📊 Usage Analytics & Rate Limiting** 
- **🛡️ Multi-tier Security** with professional access controls

### **5-Minute Integration**

#### Step 1: Get Your Account
```bash
# Register and login to get JWT token
curl -X POST "https://api.yourcompany.com/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "your-username",
    "password": "your-password"
  }'
```

#### Step 2: Create API Key
```bash
# Create your first API key
curl -X POST "https://api.yourcompany.com/api/v1/api-keys" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "name": "Production API Key",
    "description": "Main API key for brand extraction",
    "registeredDomain": "yourdomain.com"
  }'
```

#### Step 3: Start Extracting Brand Data
```bash
# Extract brand information from any website
curl -X POST "https://api.yourcompany.com/api/v1/secure/rivofetch" \
  -H "Content-Type: application/json" \
  -H "x-api-key: sk-your-api-key" \
  -H "Origin: https://yourdomain.com" \
  -d '{
    "url": "https://example.com"
  }'
```

---

## 🔧 Integration Workflow

### **Complete Integration Process**

```mermaid
graph TD
    A[Register Account] --> B[Login & Get JWT]
    B --> C[Create API Key]
    C --> D[Configure Domain]
    D --> E[Test Connection]
    E --> F[Implement in Application]
    F --> G[Deploy to Production]
    G --> H[Monitor Usage]
```

### **1. Account Setup & Authentication**

**Prerequisites:**
- Valid email address
- Domain ownership verification
- Development environment setup

**Authentication Flow:**
```javascript
// 1. Login to get JWT token
const loginResponse = await fetch('/api/v1/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    username: 'your-username',
    password: 'your-password'
  })
});

const { token, userId, expiresIn } = await loginResponse.json();

// Store token securely
localStorage.setItem('jwt_token', token);
```

### **2. API Key Creation Strategy**

**Environment-Based Key Management:**
```javascript
// Recommended: Create separate keys for each environment
const environments = [
  {
    name: 'Development API Key',
    domain: 'localhost:3000',
    environment: 'development'
  },
  {
    name: 'Staging API Key', 
    domain: 'staging.yourdomain.com',
    environment: 'staging'
  },
  {
    name: 'Production API Key',
    domain: 'yourdomain.com', 
    environment: 'production'
  }
];
```

---

## 🏗️ Post-Creation Setup

### **Immediate Steps After API Key Creation**

#### ✅ **Step 1: Secure Key Storage**
```bash
# Environment Variables (Recommended)
export JWT_AUTH_API_KEY="sk-your-production-key"
export JWT_AUTH_BASE_URL="https://api.yourcompany.com"
export JWT_AUTH_ORIGIN="https://yourdomain.com"
```

```javascript
// .env file
JWT_AUTH_API_KEY_DEV=sk-dev-key-123...
JWT_AUTH_API_KEY_STAGING=sk-staging-key-456...
JWT_AUTH_API_KEY_PROD=sk-prod-key-789...
```

#### ✅ **Step 2: Domain Configuration**
```json
{
  "registeredDomain": "yourdomain.com",
  "allowedDomains": [
    "app.yourdomain.com",
    "api.yourdomain.com", 
    "admin.yourdomain.com"
  ],
  "allowedIps": [
    "192.168.1.100",
    "10.0.0.50"
  ]
}
```

#### ✅ **Step 3: Test Connection**
```javascript
// Health check to verify setup
async function testConnection() {
  try {
    const response = await fetch('/api/v1/secure/health', {
      headers: {
        'x-api-key': process.env.JWT_AUTH_API_KEY,
        'Origin': process.env.JWT_AUTH_ORIGIN
      }
    });
    
    if (response.ok) {
      console.log('✅ API Key configured successfully');
      return await response.json();
    }
  } catch (error) {
    console.error('❌ Configuration error:', error);
  }
}
```

#### ✅ **Step 4: Integration Template**
```javascript
// Complete integration template
class BrandExtractionClient {
  constructor(config) {
    this.apiKey = config.apiKey;
    this.baseUrl = config.baseUrl;
    this.origin = config.origin;
    this.retryAttempts = config.retryAttempts || 3;
  }

  async extractBrandData(url, options = {}) {
    const requestConfig = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': this.apiKey,
        'Origin': this.origin,
        ...options.headers
      },
      body: JSON.stringify({ url })
    };

    return this.makeRequestWithRetry(
      `${this.baseUrl}/api/v1/secure/rivofetch`,
      requestConfig
    );
  }

  async makeRequestWithRetry(url, config, attempt = 1) {
    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      if (attempt < this.retryAttempts) {
        await this.delay(Math.pow(2, attempt) * 1000); // Exponential backoff
        return this.makeRequestWithRetry(url, config, attempt + 1);
      }
      throw error;
    }
  }

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
```

---

## 🔑 API Key Management

### **Complete API Key Lifecycle**

#### **Create API Key**
```bash
POST /api/v1/api-keys
```

**Enhanced Request Body:**
```json
{
  "name": "Production Brand Extractor",
  "description": "Main API key for extracting brand data from customer websites",
  "registeredDomain": "yourdomain.com",
  "environment": "production",
  "allowedDomains": [
    "app.yourdomain.com",
    "dashboard.yourdomain.com"
  ],
  "allowedIps": [
    "192.168.1.100",
    "10.0.0.50"
  ],
  "rateLimitTier": "PRO_TIER",
  "scopes": [
    "READ_BASIC",
    "READ_BRANDS", 
    "DOMAIN_HEALTH"
  ],
  "expiresAt": "2024-12-31T23:59:59Z"
}
```

**Success Response:**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "Production Brand Extractor",
  "keyValue": "sk-1234567890abcdef1234567890abcdef12345678",
  "registeredDomain": "yourdomain.com",
  "mainDomain": "yourdomain.com",
  "subdomainPattern": "*.yourdomain.com",
  "environment": "production",
  "allowedDomains": "app.yourdomain.com,dashboard.yourdomain.com",
  "allowedIps": "192.168.1.100,10.0.0.50",
  "scopes": "READ_BASIC,READ_BRANDS,DOMAIN_HEALTH",
  "rateLimitTier": "PRO_TIER",
  "isActive": true,
  "expiresAt": "2024-12-31T23:59:59Z",
  "createdAt": "2024-01-15T10:30:00Z",
  "usage": {
    "totalRequests": 0,
    "monthlyRequests": 0,
    "lastUsed": null
  }
}
```

#### **Monitor API Key Usage**
```bash
GET /api/v1/api-keys/plan-usage
```

**Response:**
```json
{
  "success": true,
  "plan": "PRO",
  "planDisplayName": "Pro Plan",
  "currentApiKeys": 2,
  "maxApiKeys": 3,
  "remainingApiKeys": 1,
  "currentDomains": 2,
  "maxDomains": 3,
  "remainingDomains": 1,
  "canCreateApiKey": true,
  "canClaimDomain": true,
  "monthlyApiCalls": 1000,
  "usedApiCalls": 245,
  "remainingApiCalls": 755,
  "price": "$25/month",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

---

## 🛡️ Brand Extraction (RivoFetch)

### **What is RivoFetch?**

RivoFetch is our flagship brand extraction service that analyzes websites and extracts comprehensive brand information including:

- **🎨 Visual Assets**: Logos, icons, banners, color palettes
- **🏢 Company Information**: Name, description, industry, location
- **📱 Social Media**: LinkedIn profiles, social links
- **🎯 Brand Elements**: Fonts, images, design patterns

### **Business Use Cases**

1. **🎨 Design Agencies**: Extract client brand assets for design projects
2. **📊 Market Research**: Analyze competitor branding and positioning  
3. **🤝 Sales Teams**: Gather prospect company information automatically
4. **💼 CRM Integration**: Enrich customer profiles with brand data
5. **🔍 Brand Monitoring**: Track brand consistency across digital properties

### **RivoFetch API Reference**

#### **Endpoint**
```
POST /api/v1/secure/rivofetch
```

#### **Request Headers**
```http
Content-Type: application/json
x-api-key: sk-your-api-key-here
Origin: https://yourdomain.com
```

#### **Request Body**
```json
{
  "url": "https://target-website.com"
}
```

#### **Success Response (200)**
```json
{
  "Logo": {
    "Logo": "https://target-website.com/logo.png",
    "Symbol": "https://target-website.com/symbol.svg", 
    "Icon": "https://target-website.com/favicon.ico",
    "Banner": "https://target-website.com/banner.jpg",
    "LinkedInBanner": "https://media.licdn.com/banner.jpg",
    "LinkedInLogo": "https://media.licdn.com/logo.png"
  },
  "Colors": [
    {
      "hex": "#1a73e8",
      "rgb": "rgb(26, 115, 232)",
      "brightness": 128,
      "name": "Primary Blue"
    },
    {
      "hex": "#34a853", 
      "rgb": "rgb(52, 168, 83)",
      "brightness": 145,
      "name": "Success Green"
    }
  ],
  "Fonts": [
    {
      "name": "Roboto",
      "type": "sans-serif",
      "stack": "Roboto, Arial, sans-serif"
    }
  ],
  "Images": [
    {
      "src": "https://target-website.com/hero-image.jpg",
      "alt": "Company hero image"
    }
  ],
  "Company": {
    "Name": "Target Company Inc.",
    "Description": "Leading provider of innovative solutions...",
    "Industry": "Technology",
    "Location": "San Francisco, CA",
    "Founded": "2010",
    "CompanyType": "Private",
    "Employees": "1,001-5,000",
    "Website": "https://target-website.com",
    "SocialLinks": {
      "linkedin": "https://linkedin.com/company/target-company",
      "twitter": "https://twitter.com/targetcompany"
    },
    "CompanySize": "Large",
    "Headquarters": "San Francisco, California",
    "Type": "Technology Company",
    "Specialties": [
      "Software Development",
      "Cloud Services", 
      "AI/ML Solutions"
    ],
    "Locations": [
      "San Francisco, CA",
      "New York, NY",
      "London, UK"
    ]
  },
  "_performance": {
    "extractionTimeSeconds": 2.45,
    "timestamp": "2024-01-15T10:30:00Z"
  },
  "_message": "Brand extraction completed successfully"
}
```

### **Integration Examples**

#### **React/Next.js Integration**
```javascript
import { useState } from 'react';

function BrandExtractor() {
  const [brandData, setBrandData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const extractBrand = async (url) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/api/v1/secure/rivofetch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': process.env.NEXT_PUBLIC_API_KEY,
          'Origin': window.location.origin
        },
        body: JSON.stringify({ url })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to extract brand data');
      }

      const data = await response.json();
      setBrandData(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="brand-extractor">
      <input 
        type="url" 
        placeholder="Enter website URL"
        onKeyPress={(e) => e.key === 'Enter' && extractBrand(e.target.value)}
      />
      
      {loading && <div>Extracting brand data...</div>}
      {error && <div className="error">Error: {error}</div>}
      
      {brandData && (
        <div className="brand-results">
          <h3>{brandData.Company?.Name}</h3>
          <img src={brandData.Logo?.Logo} alt="Company Logo" />
          <p>{brandData.Company?.Description}</p>
          
          <div className="colors">
            {brandData.Colors?.map((color, index) => (
              <div 
                key={index}
                style={{ backgroundColor: color.hex }}
                title={color.name}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
```

#### **Node.js Backend Integration**
```javascript
const express = require('express');
const fetch = require('node-fetch');

const app = express();

class BrandExtractionService {
  constructor(apiKey, baseUrl, origin) {
    this.apiKey = apiKey;
    this.baseUrl = baseUrl;
    this.origin = origin;
  }

  async extractBrandData(url) {
    const response = await fetch(`${this.baseUrl}/api/v1/secure/rivofetch`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': this.apiKey,
        'Origin': this.origin
      },
      body: JSON.stringify({ url })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`Brand extraction failed: ${error.error}`);
    }

    return await response.json();
  }

  // Extract and format for CRM integration
  async extractForCRM(url) {
    const brandData = await this.extractBrandData(url);
    
    return {
      companyName: brandData.Company?.Name,
      industry: brandData.Company?.Industry,
      website: brandData.Company?.Website,
      description: brandData.Company?.Description,
      logo: brandData.Logo?.Logo,
      primaryColor: brandData.Colors?.[0]?.hex,
      socialLinks: brandData.Company?.SocialLinks,
      extractedAt: new Date().toISOString()
    };
  }
}

// Usage
const brandService = new BrandExtractionService(
  process.env.JWT_AUTH_API_KEY,
  process.env.JWT_AUTH_BASE_URL,
  process.env.JWT_AUTH_ORIGIN
);

app.post('/extract-brand', async (req, res) => {
  try {
    const { url } = req.body;
    const brandData = await brandService.extractForCRM(url);
    res.json({ success: true, data: brandData });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});
```

---

## 🔒 Authentication & Security

### **Security Architecture**

```mermaid
graph TD
    A[Client Request] --> B[API Key Validation]
    B --> C[Domain Verification]
    C --> D[Rate Limit Check]
    D --> E[Scope Authorization]
    E --> F[Request Processing]
    F --> G[Response + Headers]
```

### **Multi-Layer Security**

#### **1. API Key Authentication**
```javascript
// Recommended: Header-based authentication
const headers = {
  'x-api-key': 'sk-your-api-key',
  'Origin': 'https://yourdomain.com'
};

// Alternative: Bearer token
const headers = {
  'Authorization': 'Bearer sk-your-api-key',
  'Origin': 'https://yourdomain.com'  
};
```

#### **2. Domain-Based Access Control**
```json
{
  "registeredDomain": "yourdomain.com",
  "allowedDomains": [
    "app.yourdomain.com",
    "api.yourdomain.com"
  ],
  "subdomainPattern": "*.yourdomain.com"
}
```

#### **3. IP Whitelisting**
```json
{
  "allowedIps": [
    "192.168.1.100",
    "10.0.0.0/24",
    "203.0.113.0/24"
  ]
}
```

### **Security Best Practices**

#### **✅ DO's**
- Store API keys in environment variables
- Use HTTPS in production
- Implement proper CORS policies
- Rotate keys regularly (every 90 days)
- Monitor for unusual usage patterns
- Use different keys for different environments

#### **❌ DON'Ts**
- Never commit API keys to version control
- Don't use API keys in client-side code
- Avoid query parameter authentication
- Don't share keys between applications
- Never log API keys in application logs

---

## 📊 Plan-Based Access Control

### **Plan Comparison Matrix**

| Feature | FREE | PRO | BUSINESS | ENTERPRISE |
|---------|------|-----|----------|------------|
| **API Keys** | 1 | 3 | 10 | Unlimited |
| **Domains** | 1 | 3 | 10 | Unlimited |
| **Monthly Calls** | 100 | 1,000 | 10,000 | Unlimited |
| **Rate Limit** | 50/day | 200/day | 1,000/day | Custom |
| **Brand Extraction** | ✅ | ✅ | ✅ | ✅ |
| **Advanced Analytics** | ❌ | ✅ | ✅ | ✅ |
| **Webhook Support** | ❌ | ❌ | ✅ | ✅ |
| **Priority Support** | ❌ | ❌ | ✅ | ✅ |
| **SLA** | None | 99.5% | 99.9% | 99.99% |
| **Custom Integration** | ❌ | ❌ | ❌ | ✅ |

### **Scope-Based Permissions**

#### **Basic Scopes (All Plans)**
```javascript
const basicScopes = [
  'READ_BASIC',      // Basic read access to public data
  'DOMAIN_HEALTH',   // Access domain health monitoring  
  'READ_BRANDS'      // Read brand information via RivoFetch
];
```

#### **Advanced Scopes (PRO+)**
```javascript
const advancedScopes = [
  'READ_ADVANCED',    // Advanced read access to detailed data
  'DOMAIN_INSIGHTS',  // Access domain analytics and insights
  'READ_CATEGORIES',  // Read category hierarchy
  'ANALYTICS_READ'    // Read analytics data
];
```

#### **Business Scopes (BUSINESS+)**
```javascript
const businessScopes = [
  'WRITE_BASIC',      // Basic write access to user data
  'WRITE_BRANDS',     // Create and update brand information
  'AI_SUMMARIES',     // Access AI-generated summaries
  'ANALYTICS_WRITE',  // Write analytics data
  'WEBHOOK_ACCESS'    // Configure webhooks
];
```

---

## 🌐 Domain Management

### **Domain Configuration Strategy**

#### **Production Setup**
```json
{
  "registeredDomain": "yourdomain.com",
  "allowedDomains": [
    "app.yourdomain.com",
    "dashboard.yourdomain.com",
    "api.yourdomain.com"
  ],
  "environment": "production"
}
```

#### **Development Setup**
```json
{
  "registeredDomain": "localhost:3000",
  "allowedDomains": [
    "127.0.0.1:3000",
    "dev.localhost",
    "localhost:8080"
  ],
  "environment": "development"
}
```

### **Domain Validation Process**

1. **Request Analysis**: Extract Origin/Referer headers
2. **Pattern Matching**: Check against registered domains
3. **Subdomain Support**: Validate wildcard patterns
4. **Environment Context**: Apply environment-specific rules

---

## ⚡ Rate Limiting & Performance

### **Rate Limiting Headers**

Every API response includes comprehensive rate limiting information:

```http
X-RateLimit-Limit: 200
X-RateLimit-Remaining: 195
X-RateLimit-Reset: 1642291200
X-RateLimit-Window: 86400
X-RateLimit-Tier: PRO_TIER
X-RateLimit-Total-Remaining: 195
X-RateLimit-Additional-Available: 50
```

### **Handling Rate Limits**

#### **Client-Side Rate Limit Management**
```javascript
class RateLimitManager {
  constructor() {
    this.requestQueue = [];
    this.isProcessing = false;
  }

  async makeRequest(requestFn) {
    return new Promise((resolve, reject) => {
      this.requestQueue.push({ requestFn, resolve, reject });
      this.processQueue();
    });
  }

  async processQueue() {
    if (this.isProcessing || this.requestQueue.length === 0) return;
    
    this.isProcessing = true;
    
    while (this.requestQueue.length > 0) {
      const { requestFn, resolve, reject } = this.requestQueue.shift();
      
      try {
        const response = await requestFn();
        
        // Check rate limit headers
        const remaining = parseInt(response.headers.get('x-ratelimit-remaining'));
        const resetTime = parseInt(response.headers.get('x-ratelimit-reset'));
        
        if (remaining < 5) {
          const waitTime = (resetTime * 1000) - Date.now();
          if (waitTime > 0) {
            await this.delay(waitTime);
          }
        }
        
        resolve(response);
      } catch (error) {
        if (error.status === 429) {
          const retryAfter = error.headers.get('retry-after');
          await this.delay(retryAfter * 1000);
          this.requestQueue.unshift({ requestFn, resolve, reject });
        } else {
          reject(error);
        }
      }
    }
    
    this.isProcessing = false;
  }

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
```

---

## 🚨 Error Handling & Troubleshooting

### **Comprehensive Error Codes**

| Code | HTTP Status | Description | Solution |
|------|-------------|-------------|----------|
| `MISSING_API_KEY` | 401 | API key not provided | Add `x-api-key` header |
| `INVALID_API_KEY` | 401 | API key not found/invalid | Verify key value |
| `API_KEY_INACTIVE` | 401 | API key deactivated | Reactivate in dashboard |
| `API_KEY_EXPIRED` | 401 | API key expired | Create new key |
| `DOMAIN_NOT_ALLOWED` | 403 | Domain not registered | Add domain to key |
| `MISSING_DOMAIN_HEADER` | 403 | Origin header missing | Add Origin header |
| `RATE_LIMIT_EXCEEDED` | 429 | Rate limit exceeded | Wait or upgrade plan |
| `MONTHLY_QUOTA_EXCEEDED` | 403 | Monthly limit reached | Upgrade plan |
| `INSUFFICIENT_PERMISSIONS` | 403 | Missing required scopes | Update key scopes |
| `EXTERNAL_API_ERROR` | 502 | Target URL unreachable | Check target URL |
| `TIMEOUT_ERROR` | 504 | Request timed out | Retry with backoff |
| `PARSE_ERROR` | 500 | Response parsing failed | Contact support |

### **Error Response Format**
```json
{
  "error": "Domain validation failed",
  "status": 403,
  "errorCode": "DOMAIN_NOT_ALLOWED",
  "timestamp": "2024-01-15T10:30:00Z",
  "requestDomain": "unauthorized.com",
  "expectedDomain": "yourdomain.com",
  "suggestions": [
    "Ensure your request includes Origin or Referer header",
    "Verify your domain is registered for this API key",
    "Check that your domain format is correct"
  ]
}
```

### **Advanced Error Handling**

#### **Retry Strategy with Exponential Backoff**
```javascript
class ApiClient {
  async makeRequestWithRetry(url, options, maxRetries = 3) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        const response = await fetch(url, options);
        
        if (response.ok) {
          return await response.json();
        }
        
        const errorData = await response.json();
        
        // Don't retry client errors (4xx) except rate limits
        if (response.status >= 400 && response.status < 500 && response.status !== 429) {
          throw new ApiError(errorData, response.status);
        }
        
        // Retry server errors (5xx) and rate limits (429)
        if (attempt === maxRetries) {
          throw new ApiError(errorData, response.status);
        }
        
        // Exponential backoff
        const delay = Math.pow(2, attempt) * 1000;
        await this.sleep(delay);
        
      } catch (error) {
        if (attempt === maxRetries) throw error;
        await this.sleep(Math.pow(2, attempt) * 1000);
      }
    }
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

class ApiError extends Error {
  constructor(errorData, status) {
    super(errorData.error);
    this.name = 'ApiError';
    this.status = status;
    this.errorCode = errorData.errorCode;
    this.timestamp = errorData.timestamp;
    this.suggestions = errorData.suggestions;
  }
}
```

### **Troubleshooting Guide**

#### **🔍 Common Issues & Solutions**

**1. "Invalid API key" Error**
```bash
# Check if key is correct
curl -X GET "https://api.yourcompany.com/api/v1/secure/health" \
  -H "x-api-key: sk-your-key-here" \
  -H "Origin: https://yourdomain.com"

# Expected: 200 OK with health status
# If 401: Key is invalid or inactive
```

**2. "Domain validation failed" Error**
```javascript
// Ensure Origin header matches registered domain
const response = await fetch('/api/v1/secure/rivofetch', {
  headers: {
    'x-api-key': 'sk-your-key',
    'Origin': 'https://yourdomain.com', // Must match registered domain
    'Content-Type': 'application/json'
  }
});
```

**3. Rate Limit Issues**
```javascript
// Monitor rate limit headers
const response = await fetch('/api/v1/secure/rivofetch', options);
const remaining = response.headers.get('x-ratelimit-remaining');
const resetTime = response.headers.get('x-ratelimit-reset');

console.log(`Remaining requests: ${remaining}`);
console.log(`Reset time: ${new Date(resetTime * 1000)}`);
```

---

## 💻 SDK Examples & Code Samples

### **Production-Ready JavaScript SDK**

```javascript
/**
 * JWT Authenticator API Client
 * Production-ready SDK with comprehensive error handling
 */
class JWTAuthenticatorClient {
  constructor(config) {
    this.apiKey = config.apiKey;
    this.baseUrl = config.baseUrl || 'https://api.yourcompany.com';
    this.origin = config.origin;
    this.timeout = config.timeout || 30000;
    this.retryAttempts = config.retryAttempts || 3;
    this.rateLimitManager = new RateLimitManager();
  }

  /**
   * Extract brand data from a website
   * @param {string} url - Target website URL
   * @param {Object} options - Additional options
   * @returns {Promise<Object>} Brand extraction data
   */
  async extractBrand(url, options = {}) {
    const requestConfig = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': this.apiKey,
        'Origin': this.origin,
        ...options.headers
      },
      body: JSON.stringify({ url }),
      signal: AbortSignal.timeout(this.timeout)
    };

    return this.rateLimitManager.makeRequest(async () => {
      return this.makeRequestWithRetry(
        `${this.baseUrl}/api/v1/secure/rivofetch`,
        requestConfig
      );
    });
  }

  /**
   * Health check endpoint
   * @returns {Promise<Object>} Health status
   */
  async healthCheck() {
    const response = await fetch(`${this.baseUrl}/api/v1/secure/health`, {
      headers: {
        'x-api-key': this.apiKey,
        'Origin': this.origin
      }
    });

    if (!response.ok) {
      throw new ApiError(await response.json(), response.status);
    }

    return response.json();
  }

  /**
   * Make request with retry logic
   */
  async makeRequestWithRetry(url, config, attempt = 1) {
    try {
      const response = await fetch(url, config);
      
      if (response.ok) {
        return await response.json();
      }
      
      const errorData = await response.json();
      
      // Don't retry client errors except rate limits
      if (response.status >= 400 && response.status < 500 && response.status !== 429) {
        throw new ApiError(errorData, response.status);
      }
      
      // Retry server errors and rate limits
      if (attempt < this.retryAttempts) {
        const delay = Math.pow(2, attempt) * 1000;
        await this.delay(delay);
        return this.makeRequestWithRetry(url, config, attempt + 1);
      }
      
      throw new ApiError(errorData, response.status);
      
    } catch (error) {
      if (error instanceof ApiError) throw error;
      
      if (attempt < this.retryAttempts) {
        const delay = Math.pow(2, attempt) * 1000;
        await this.delay(delay);
        return this.makeRequestWithRetry(url, config, attempt + 1);
      }
      
      throw error;
    }
  }

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Usage Example
const client = new JWTAuthenticatorClient({
  apiKey: process.env.JWT_AUTH_API_KEY,
  baseUrl: process.env.JWT_AUTH_BASE_URL,
  origin: process.env.JWT_AUTH_ORIGIN,
  timeout: 30000,
  retryAttempts: 3
});

// Extract brand data
try {
  const brandData = await client.extractBrand('https://example.com');
  console.log('Company:', brandData.Company?.Name);
  console.log('Logo:', brandData.Logo?.Logo);
  console.log('Colors:', brandData.Colors?.map(c => c.hex));
} catch (error) {
  console.error('Brand extraction failed:', error.message);
  if (error.suggestions) {
    console.log('Suggestions:', error.suggestions);
  }
}
```

### **Python SDK**

```python
import requests
import time
import json
from typing import Optional, Dict, Any
from dataclasses import dataclass

@dataclass
class ApiConfig:
    api_key: str
    base_url: str = "https://api.yourcompany.com"
    origin: str = None
    timeout: int = 30
    retry_attempts: int = 3

class ApiError(Exception):
    def __init__(self, message: str, status_code: int, error_code: str = None, suggestions: list = None):
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code
        self.suggestions = suggestions or []

class JWTAuthenticatorClient:
    def __init__(self, config: ApiConfig):
        self.config = config
        self.session = requests.Session()
        self.session.headers.update({
            'x-api-key': config.api_key,
            'Content-Type': 'application/json'
        })
        if config.origin:
            self.session.headers.update({'Origin': config.origin})

    def extract_brand(self, url: str, **kwargs) -> Dict[Any, Any]:
        """
        Extract brand data from a website
        
        Args:
            url: Target website URL
            **kwargs: Additional request parameters
            
        Returns:
            Dict containing brand extraction data
            
        Raises:
            ApiError: If the request fails
        """
        payload = {'url': url}
        return self._make_request_with_retry(
            'POST',
            f'{self.config.base_url}/api/v1/secure/rivofetch',
            json=payload,
            **kwargs
        )

    def health_check(self) -> Dict[Any, Any]:
        """Check API health status"""
        return self._make_request_with_retry(
            'GET',
            f'{self.config.base_url}/api/v1/secure/health'
        )

    def _make_request_with_retry(self, method: str, url: str, attempt: int = 1, **kwargs) -> Dict[Any, Any]:
        """Make HTTP request with retry logic"""
        try:
            response = self.session.request(
                method, 
                url, 
                timeout=self.config.timeout,
                **kwargs
            )
            
            if response.ok:
                return response.json()
            
            error_data = response.json()
            
            # Don't retry client errors except rate limits
            if 400 <= response.status_code < 500 and response.status_code != 429:
                raise ApiError(
                    error_data.get('error', 'Client error'),
                    response.status_code,
                    error_data.get('errorCode'),
                    error_data.get('suggestions', [])
                )
            
            # Retry server errors and rate limits
            if attempt < self.config.retry_attempts:
                delay = 2 ** attempt
                time.sleep(delay)
                return self._make_request_with_retry(method, url, attempt + 1, **kwargs)
            
            raise ApiError(
                error_data.get('error', 'Server error'),
                response.status_code,
                error_data.get('errorCode'),
                error_data.get('suggestions', [])
            )
            
        except requests.RequestException as e:
            if attempt < self.config.retry_attempts:
                delay = 2 ** attempt
                time.sleep(delay)
                return self._make_request_with_retry(method, url, attempt + 1, **kwargs)
            raise ApiError(f"Request failed: {str(e)}", 0)

# Usage Example
config = ApiConfig(
    api_key=os.getenv('JWT_AUTH_API_KEY'),
    base_url=os.getenv('JWT_AUTH_BASE_URL', 'https://api.yourcompany.com'),
    origin=os.getenv('JWT_AUTH_ORIGIN')
)

client = JWTAuthenticatorClient(config)

try:
    brand_data = client.extract_brand('https://example.com')
    print(f"Company: {brand_data.get('Company', {}).get('Name')}")
    print(f"Logo: {brand_data.get('Logo', {}).get('Logo')}")
    print(f"Colors: {[c.get('hex') for c in brand_data.get('Colors', [])]}")
except ApiError as e:
    print(f"Error: {e}")
    if e.suggestions:
        print(f"Suggestions: {', '.join(e.suggestions)}")
```

---

## 🏭 Production Deployment

### **Pre-Deployment Checklist**

#### **✅ Security**
- [ ] API keys stored in secure environment variables
- [ ] HTTPS enabled for all endpoints
- [ ] CORS policies configured correctly
- [ ] Domain validation tested
- [ ] IP whitelisting configured (if required)
- [ ] Rate limiting tested

#### **✅ Configuration**
- [ ] Production API keys created
- [ ] Environment-specific configurations
- [ ] Error handling implemented
- [ ] Retry logic with exponential backoff
- [ ] Timeout configurations set
- [ ] Logging and monitoring configured

#### **✅ Testing**
- [ ] Health check endpoint tested
- [ ] Brand extraction functionality verified
- [ ] Error scenarios tested
- [ ] Rate limiting behavior verified
- [ ] Load testing completed
- [ ] Failover scenarios tested

### **Environment Configuration**

#### **Production Environment Variables**
```bash
# API Configuration
JWT_AUTH_API_KEY=sk-prod-1234567890abcdef...
JWT_AUTH_BASE_URL=https://api.yourcompany.com
JWT_AUTH_ORIGIN=https://yourdomain.com

# Performance Settings
JWT_AUTH_TIMEOUT=30000
JWT_AUTH_RETRY_ATTEMPTS=3
JWT_AUTH_RATE_LIMIT_BUFFER=10

# Monitoring
JWT_AUTH_LOG_LEVEL=info
JWT_AUTH_METRICS_ENABLED=true
```

#### **Docker Configuration**
```dockerfile
FROM node:18-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./
RUN npm ci --only=production

# Copy application code
COPY . .

# Set environment variables
ENV NODE_ENV=production
ENV JWT_AUTH_BASE_URL=https://api.yourcompany.com

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD curl -f http://localhost:3000/health || exit 1

EXPOSE 3000

CMD ["npm", "start"]
```

#### **Kubernetes Deployment**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: brand-extractor-app
spec:
  replicas: 3
  selector:
    matchLabels:
      app: brand-extractor
  template:
    metadata:
      labels:
        app: brand-extractor
    spec:
      containers:
      - name: app
        image: your-registry/brand-extractor:latest
        ports:
        - containerPort: 3000
        env:
        - name: JWT_AUTH_API_KEY
          valueFrom:
            secretKeyRef:
              name: api-secrets
              key: jwt-auth-api-key
        - name: JWT_AUTH_BASE_URL
          value: "https://api.yourcompany.com"
        - name: JWT_AUTH_ORIGIN
          value: "https://yourdomain.com"
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 3000
          initialDelaySeconds: 5
          periodSeconds: 5
---
apiVersion: v1
kind: Secret
metadata:
  name: api-secrets
type: Opaque
data:
  jwt-auth-api-key: <base64-encoded-api-key>
```

---

## 📈 Monitoring & Analytics

### **Key Metrics to Monitor**

#### **API Performance Metrics**
```javascript
// Custom metrics collection
class ApiMetrics {
  constructor() {
    this.metrics = {
      totalRequests: 0,
      successfulRequests: 0,
      failedRequests: 0,
      averageResponseTime: 0,
      rateLimitHits: 0,
      errorsByType: {}
    };
  }

  recordRequest(duration, success, errorCode = null) {
    this.metrics.totalRequests++;
    
    if (success) {
      this.metrics.successfulRequests++;
    } else {
      this.metrics.failedRequests++;
      if (errorCode) {
        this.metrics.errorsByType[errorCode] = 
          (this.metrics.errorsByType[errorCode] || 0) + 1;
      }
    }
    
    // Update average response time
    this.metrics.averageResponseTime = 
      (this.metrics.averageResponseTime + duration) / 2;
  }

  recordRateLimitHit() {
    this.metrics.rateLimitHits++;
  }

  getMetrics() {
    return {
      ...this.metrics,
      successRate: this.metrics.successfulRequests / this.metrics.totalRequests,
      errorRate: this.metrics.failedRequests / this.metrics.totalRequests
    };
  }
}
```

#### **Health Check Implementation**
```javascript
// Comprehensive health check
app.get('/health', async (req, res) => {
  const healthCheck = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    version: process.env.npm_package_version,
    environment: process.env.NODE_ENV,
    services: {}
  };

  try {
    // Check JWT Auth API connectivity
    const apiHealth = await client.healthCheck();
    healthCheck.services.jwtAuthApi = {
      status: 'healthy',
      responseTime: apiHealth.responseTime || 'N/A'
    };
  } catch (error) {
    healthCheck.status = 'unhealthy';
    healthCheck.services.jwtAuthApi = {
      status: 'unhealthy',
      error: error.message
    };
  }

  const statusCode = healthCheck.status === 'healthy' ? 200 : 503;
  res.status(statusCode).json(healthCheck);
});
```

### **Alerting Configuration**

#### **Critical Alerts**
```yaml
# Prometheus alerting rules
groups:
- name: jwt-auth-api
  rules:
  - alert: HighErrorRate
    expr: rate(api_requests_failed_total[5m]) / rate(api_requests_total[5m]) > 0.1
    for: 2m
    labels:
      severity: critical
    annotations:
      summary: "High error rate detected"
      description: "Error rate is {{ $value | humanizePercentage }}"

  - alert: RateLimitExceeded
    expr: increase(api_rate_limit_hits_total[1h]) > 100
    for: 1m
    labels:
      severity: warning
    annotations:
      summary: "Rate limit frequently exceeded"
      description: "Rate limit hit {{ $value }} times in the last hour"

  - alert: SlowResponseTime
    expr: histogram_quantile(0.95, rate(api_request_duration_seconds_bucket[5m])) > 5
    for: 3m
    labels:
      severity: warning
    annotations:
      summary: "Slow API response times"
      description: "95th percentile response time is {{ $value }}s"
```

---

## ✅ Best Practices

### **🔒 Security Best Practices**

#### **1. API Key Management**
```javascript
// ✅ Good: Environment-based configuration
const config = {
  apiKey: process.env.JWT_AUTH_API_KEY,
  baseUrl: process.env.JWT_AUTH_BASE_URL,
  origin: process.env.JWT_AUTH_ORIGIN
};

// ❌ Bad: Hardcoded keys
const config = {
  apiKey: 'sk-1234567890abcdef...',  // Never do this!
  baseUrl: 'https://api.yourcompany.com'
};
```

#### **2. Request Security**
```javascript
// ✅ Good: Proper headers and validation
const makeSecureRequest = async (url) => {
  const response = await fetch('/api/v1/secure/rivofetch', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.JWT_AUTH_API_KEY,
      'Origin': window.location.origin,  // Automatic domain validation
      'X-Requested-With': 'XMLHttpRequest'  // CSRF protection
    },
    body: JSON.stringify({ url: sanitizeUrl(url) })  // Input sanitization
  });
  
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
  }
  
  return response.json();
};

function sanitizeUrl(url) {
  try {
    const parsed = new URL(url);
    // Only allow HTTP/HTTPS protocols
    if (!['http:', 'https:'].includes(parsed.protocol)) {
      throw new Error('Invalid protocol');
    }
    return parsed.toString();
  } catch (error) {
    throw new Error('Invalid URL format');
  }
}
```

### **⚡ Performance Best Practices**

#### **1. Connection Pooling**
```javascript
// ✅ Good: Reuse HTTP connections
const https = require('https');

const agent = new https.Agent({
  keepAlive: true,
  maxSockets: 50,
  maxFreeSockets: 10,
  timeout: 60000,
  freeSocketTimeout: 30000
});

const client = new JWTAuthenticatorClient({
  apiKey: process.env.JWT_AUTH_API_KEY,
  httpAgent: agent
});
```

#### **2. Response Caching**
```javascript
// ✅ Good: Cache brand data to reduce API calls
class CachedBrandExtractor {
  constructor(client, cacheOptions = {}) {
    this.client = client;
    this.cache = new Map();
    this.cacheTTL = cacheOptions.ttl || 3600000; // 1 hour default
    this.maxCacheSize = cacheOptions.maxSize || 1000;
  }

  async extractBrand(url) {
    const cacheKey = this.getCacheKey(url);
    const cached = this.cache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < this.cacheTTL) {
      return cached.data;
    }
    
    const brandData = await this.client.extractBrand(url);
    
    // Implement LRU cache eviction
    if (this.cache.size >= this.maxCacheSize) {
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }
    
    this.cache.set(cacheKey, {
      data: brandData,
      timestamp: Date.now()
    });
    
    return brandData;
  }

  getCacheKey(url) {
    return Buffer.from(url).toString('base64');
  }
}
```

### **🔄 Error Handling Best Practices**

#### **1. Comprehensive Error Handling**
```javascript
// ✅ Good: Detailed error handling with user-friendly messages
class BrandExtractionService {
  async extractBrand(url) {
    try {
      const brandData = await this.client.extractBrand(url);
      return {
        success: true,
        data: brandData,
        message: 'Brand data extracted successfully'
      };
    } catch (error) {
      return this.handleError(error, url);
    }
  }

  handleError(error, url) {
    const baseResponse = {
      success: false,
      data: null,
      url: url,
      timestamp: new Date().toISOString()
    };

    if (error instanceof ApiError) {
      switch (error.errorCode) {
        case 'INVALID_API_KEY':
          return {
            ...baseResponse,
            message: 'Authentication failed. Please check your API key.',
            userAction: 'Verify your API key in the dashboard',
            supportContact: 'support@yourcompany.com'
          };
          
        case 'DOMAIN_NOT_ALLOWED':
          return {
            ...baseResponse,
            message: 'Domain validation failed. This domain is not authorized.',
            userAction: 'Add your domain to the API key configuration',
            suggestions: error.suggestions
          };
          
        case 'RATE_LIMIT_EXCEEDED':
          return {
            ...baseResponse,
            message: 'Rate limit exceeded. Please try again later.',
            userAction: 'Wait for rate limit reset or upgrade your plan',
            retryAfter: error.retryAfter
          };
          
        case 'EXTERNAL_API_ERROR':
          return {
            ...baseResponse,
            message: 'Unable to extract data from the target website.',
            userAction: 'Verify the URL is accessible and try again',
            technicalDetails: 'Target website may be blocking requests or temporarily unavailable'
          };
          
        default:
          return {
            ...baseResponse,
            message: 'An unexpected error occurred during brand extraction.',
            userAction: 'Please try again or contact support if the issue persists',
            errorCode: error.errorCode
          };
      }
    }

    // Network or other errors
    return {
      ...baseResponse,
      message: 'Network error occurred. Please check your connection.',
      userAction: 'Verify your internet connection and try again',
      technicalDetails: error.message
    };
  }
}
```

### **📊 Monitoring Best Practices**

#### **1. Structured Logging**
```javascript
// ✅ Good: Structured logging with context
const winston = require('winston');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  defaultMeta: { service: 'brand-extractor' },
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' })
  ]
});

// Usage
logger.info('Brand extraction started', {
  url: targetUrl,
  apiKeyId: 'key-123',
  userId: 'user-456',
  requestId: 'req-789'
});

logger.error('Brand extraction failed', {
  url: targetUrl,
  error: error.message,
  errorCode: error.errorCode,
  duration: responseTime,
  requestId: 'req-789'
});
```

---

## 🎯 Migration & Upgrade Guide

### **Upgrading from Basic to Professional Plans**

#### **Plan Upgrade Process**
1. **Review Current Usage**: Check your current API usage and limits
2. **Plan Selection**: Choose the appropriate plan for your needs
3. **API Key Migration**: Update existing keys or create new ones
4. **Feature Activation**: Enable new features like advanced analytics
5. **Testing**: Verify all functionality works with the new plan

#### **Code Changes for Advanced Features**
```javascript
// Before: Basic plan usage
const basicClient = new JWTAuthenticatorClient({
  apiKey: 'sk-basic-key',
  baseUrl: 'https://api.yourcompany.com'
});

// After: Professional plan with advanced features
const proClient = new JWTAuthenticatorClient({
  apiKey: 'sk-pro-key',
  baseUrl: 'https://api.yourcompany.com',
  features: {
    analytics: true,
    advancedScopes: ['READ_ADVANCED', 'DOMAIN_INSIGHTS'],
    webhooks: true
  }
});
```

---

## 📞 Support & Resources

### **Getting Help**

#### **📧 Contact Information**
- **Technical Support**: support@yourcompany.com
- **Sales Inquiries**: sales@yourcompany.com
- **Emergency Support**: +1-800-XXX-XXXX (Business+ plans)

#### **📚 Additional Resources**
- **API Status Page**: https://status.yourcompany.com
- **Developer Community**: https://community.yourcompany.com
- **GitHub Examples**: https://github.com/yourcompany/api-examples
- **Postman Collection**: [Download Collection](https://api.yourcompany.com/postman)

#### **🎓 Learning Resources**
- **Video Tutorials**: https://learn.yourcompany.com
- **Webinar Series**: Monthly developer webinars
- **Best Practices Guide**: https://docs.yourcompany.com/best-practices
- **Case Studies**: Real-world implementation examples

---

## 📝 Changelog & Roadmap

### **Recent Updates**

#### **v1.2.0 (Latest)**
- ✅ Enhanced brand extraction accuracy
- ✅ Improved rate limiting headers
- ✅ Added health check endpoint
- ✅ Better error messages with suggestions
- ✅ Performance optimizations

#### **v1.1.0**
- ✅ Domain validation improvements
- ✅ Added IP whitelisting support
- ✅ Enhanced security features
- ✅ Better documentation

### **Upcoming Features**

#### **Q2 2024**
- 🔄 Webhook support for real-time notifications
- 🔄 Batch processing for multiple URLs
- 🔄 Advanced analytics dashboard
- 🔄 GraphQL API support

#### **Q3 2024**
- 🔄 AI-powered brand insights
- 🔄 Custom extraction rules
- 🔄 Enterprise SSO integration
- 🔄 Advanced caching options

---

*This documentation is maintained by the JWT Authenticator API team. Last updated: January 2024*

**Need help?** Contact our support team at support@yourcompany.com or visit our [developer community](https://community.yourcompany.com).
# 📚 JWT Authenticator API Reference

> **Complete API Reference for Brand Extraction & API Key Management**

[![API Version](https://img.shields.io/badge/API%20Version-v1-blue)](https://api.yourcompany.com/v1)
[![OpenAPI](https://img.shields.io/badge/OpenAPI-3.0-green)](https://api.yourcompany.com/swagger-ui)

---

## 🌐 Base URL

```
https://api.yourcompany.com/api/v1
```

## 🔐 Authentication

All API endpoints require authentication using one of these methods:

### **API Key Authentication (Recommended)**
```http
x-api-key: sk-your-api-key-here
```

### **Bearer Token Authentication**
```http
Authorization: Bearer sk-your-api-key-here
```

### **JWT Token Authentication (Management endpoints)**
```http
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

---

## 📋 Table of Contents

1. [🔒 Authentication Endpoints](#-authentication-endpoints)
2. [🔑 API Key Management](#-api-key-management)
3. [🛡️ Secure Brand Extraction](#️-secure-brand-extraction)
4. [📊 Analytics & Usage](#-analytics--usage)
5. [🚨 Error Responses](#-error-responses)
6. [📈 Rate Limiting](#-rate-limiting)

---

## 🔒 Authentication Endpoints

### **Login**

Authenticate user and receive JWT token for API key management.

```http
POST /auth/login
```

#### **Request Body**
```json
{
  "username": "string",
  "password": "string"
}
```

#### **Response (200 OK)**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "userId": "550e8400-e29b-41d4-a716-446655440000",
  "expiresIn": 3600,
  "tokenType": "Bearer"
}
```

#### **Example**
```bash
curl -X POST "https://api.yourcompany.com/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "john.doe@example.com",
    "password": "securePassword123"
  }'
```

---

## 🔑 API Key Management

### **Create API Key**

Create a new API key with domain validation and access controls.

```http
POST /api-keys
```

#### **Headers**
```http
Authorization: Bearer {jwt_token}
Content-Type: application/json
```

#### **Query Parameters**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `environment` | string | `production` | Environment: `production`, `development`, `staging` |

#### **Request Body**
```json
{
  "name": "string",
  "description": "string (optional)",
  "registeredDomain": "string",
  "allowedIps": ["string"] (optional),
  "allowedDomains": ["string"] (optional),
  "rateLimitTier": "string (optional)",
  "scopes": ["string"] (optional),
  "expiresAt": "string (ISO 8601, optional)"
}
```

#### **Response (201 Created)**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "Production API Key",
  "description": "Main API key for brand extraction",
  "keyValue": "sk-1234567890abcdef1234567890abcdef12345678",
  "registeredDomain": "yourdomain.com",
  "mainDomain": "yourdomain.com",
  "subdomainPattern": "*.yourdomain.com",
  "environment": "production",
  "allowedDomains": "app.yourdomain.com,dashboard.yourdomain.com",
  "allowedIps": "192.168.1.100,10.0.0.50",
  "scopes": "READ_BASIC,READ_BRANDS,DOMAIN_HEALTH",
  "rateLimitTier": "PRO_TIER",
  "isActive": true,
  "expiresAt": "2024-12-31T23:59:59Z",
  "createdAt": "2024-01-15T10:30:00Z",
  "lastUsed": null,
  "usage": {
    "totalRequests": 0,
    "monthlyRequests": 0,
    "lastRequestAt": null
  }
}
```

#### **Example**
```bash
curl -X POST "https://api.yourcompany.com/api/v1/api-keys" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." \
  -d '{
    "name": "Production Brand Extractor",
    "description": "Main API key for extracting brand data from customer websites",
    "registeredDomain": "yourdomain.com",
    "allowedDomains": ["app.yourdomain.com", "dashboard.yourdomain.com"],
    "allowedIps": ["192.168.1.100"],
    "rateLimitTier": "PRO_TIER",
    "scopes": ["READ_BASIC", "READ_BRANDS", "DOMAIN_HEALTH"]
  }'
```

### **Get All API Keys**

Retrieve all API keys for the authenticated user with pagination.

```http
GET /api-keys
```

#### **Headers**
```http
Authorization: Bearer {jwt_token}
```

#### **Query Parameters**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `page` | integer | `0` | Page number (0-based) |
| `size` | integer | `20` | Page size (max: 100) |
| `sort` | string | `createdAt,desc` | Sort criteria |
| `environment` | string | `all` | Filter by environment |
| `active` | boolean | `all` | Filter by active status |

#### **Response (200 OK)**
```json
{
  "content": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "name": "Production API Key",
      "description": "Main API key for brand extraction",
      "registeredDomain": "yourdomain.com",
      "environment": "production",
      "scopes": "READ_BASIC,READ_BRANDS,DOMAIN_HEALTH",
      "rateLimitTier": "PRO_TIER",
      "isActive": true,
      "createdAt": "2024-01-15T10:30:00Z",
      "lastUsed": "2024-01-15T15:45:00Z",
      "usage": {
        "totalRequests": 1250,
        "monthlyRequests": 89,
        "lastRequestAt": "2024-01-15T15:45:00Z"
      }
    }
  ],
  "totalElements": 3,
  "totalPages": 1,
  "size": 20,
  "number": 0,
  "first": true,
  "last": true
}
```

#### **Example**
```bash
curl -X GET "https://api.yourcompany.com/api/v1/api-keys?page=0&size=10&sort=createdAt,desc" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

### **Get API Key by ID**

Retrieve detailed information about a specific API key.

```http
GET /api-keys/{keyId}
```

#### **Path Parameters**
| Parameter | Type | Description |
|-----------|------|-------------|
| `keyId` | string (UUID) | API key identifier |

#### **Headers**
```http
Authorization: Bearer {jwt_token}
```

#### **Response (200 OK)**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "Production API Key",
  "description": "Main API key for brand extraction",
  "registeredDomain": "yourdomain.com",
  "mainDomain": "yourdomain.com",
  "subdomainPattern": "*.yourdomain.com",
  "environment": "production",
  "allowedDomains": "app.yourdomain.com,dashboard.yourdomain.com",
  "allowedIps": "192.168.1.100,10.0.0.50",
  "scopes": "READ_BASIC,READ_BRANDS,DOMAIN_HEALTH",
  "rateLimitTier": "PRO_TIER",
  "isActive": true,
  "expiresAt": "2024-12-31T23:59:59Z",
  "createdAt": "2024-01-15T10:30:00Z",
  "lastUsed": "2024-01-15T15:45:00Z",
  "usage": {
    "totalRequests": 1250,
    "monthlyRequests": 89,
    "dailyRequests": 12,
    "lastRequestAt": "2024-01-15T15:45:00Z",
    "averageResponseTime": 245
  }
}
```

### **Update API Key**

Update API key properties (name, description, status, etc.).

```http
PUT /api-keys/{keyId}
```

#### **Path Parameters**
| Parameter | Type | Description |
|-----------|------|-------------|
| `keyId` | string (UUID) | API key identifier |

#### **Headers**
```http
Authorization: Bearer {jwt_token}
Content-Type: application/json
```

#### **Request Body**
```json
{
  "name": "string (optional)",
  "description": "string (optional)",
  "isActive": "boolean (optional)",
  "allowedIps": ["string"] (optional),
  "allowedDomains": ["string"] (optional),
  "expiresAt": "string (ISO 8601, optional)"
}
```

#### **Response (200 OK)**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "Updated Production API Key",
  "description": "Updated description",
  "isActive": true,
  "updatedAt": "2024-01-15T16:30:00Z"
}
```

### **Revoke API Key**

Deactivate an API key (can be reactivated later).

```http
PATCH /api-keys/{keyId}/revoke
```

#### **Response (204 No Content)**

### **Delete API Key**

Permanently delete an API key (cannot be undone).

```http
DELETE /api-keys/{keyId}
```

#### **Response (204 No Content)**

### **Get Plan Usage**

Get current plan usage and limits for the authenticated user.

```http
GET /api-keys/plan-usage
```

#### **Headers**
```http
Authorization: Bearer {jwt_token}
```

#### **Response (200 OK)**
```json
{
  "success": true,
  "plan": "PRO",
  "planDisplayName": "Pro Plan",
  "currentApiKeys": 2,
  "maxApiKeys": 3,
  "remainingApiKeys": 1,
  "currentDomains": 2,
  "maxDomains": 3,
  "remainingDomains": 1,
  "canCreateApiKey": true,
  "canClaimDomain": true,
  "monthlyApiCalls": 1000,
  "usedApiCalls": 245,
  "remainingApiCalls": 755,
  "resetDate": "2024-02-01T00:00:00Z",
  "price": "$25/month",
  "features": [
    "Advanced Analytics",
    "Priority Support",
    "Custom Rate Limits"
  ],
  "timestamp": "2024-01-15T10:30:00Z"
}
```

---

## 🛡️ Secure Brand Extraction

### **RivoFetch - Brand Extraction**

Extract comprehensive brand information from any website including logos, colors, fonts, and company data.

```http
POST /secure/rivofetch
```

#### **Headers**
```http
x-api-key: sk-your-api-key-here
Origin: https://yourdomain.com
Content-Type: application/json
```

#### **Request Body**
```json
{
  "url": "string (required, valid URL)"
}
```

#### **Response (200 OK)**
```json
{
  "Logo": {
    "Logo": "https://target-website.com/logo.png",
    "Symbol": "https://target-website.com/symbol.svg",
    "Icon": "https://target-website.com/favicon.ico",
    "Banner": "https://target-website.com/banner.jpg",
    "LinkedInBanner": "https://media.licdn.com/banner.jpg",
    "LinkedInLogo": "https://media.licdn.com/logo.png"
  },
  "Colors": [
    {
      "hex": "#1a73e8",
      "rgb": "rgb(26, 115, 232)",
      "brightness": 128,
      "name": "Primary Blue",
      "width": null,
      "height": null,
      "colors": null
    },
    {
      "hex": "#34a853",
      "rgb": "rgb(52, 168, 83)",
      "brightness": 145,
      "name": "Success Green",
      "width": 200,
      "height": 100,
      "colors": ["#34a853", "#2d7d32"]
    }
  ],
  "Fonts": [
    {
      "name": "Roboto",
      "type": "sans-serif",
      "stack": "Roboto, Arial, sans-serif"
    },
    {
      "name": "Open Sans",
      "type": "sans-serif",
      "stack": "Open Sans, Helvetica, sans-serif"
    }
  ],
  "Images": [
    {
      "src": "https://target-website.com/hero-image.jpg",
      "alt": "Company hero image showcasing products"
    },
    {
      "src": "https://target-website.com/team-photo.jpg",
      "alt": "Team photo"
    }
  ],
  "Company": {
    "Name": "Target Company Inc.",
    "Description": "Leading provider of innovative technology solutions for modern businesses.",
    "Industry": "Technology",
    "Location": "San Francisco, CA",
    "Founded": "2010",
    "CompanyType": "Private",
    "Employees": "1,001-5,000",
    "Website": "https://target-website.com",
    "SocialLinks": {
      "linkedin": "https://linkedin.com/company/target-company",
      "twitter": "https://twitter.com/targetcompany",
      "facebook": "https://facebook.com/targetcompany"
    },
    "LinkedInError": null,
    "CompanySize": "Large",
    "Headquarters": "San Francisco, California",
    "Type": "Technology Company",
    "Specialties": [
      "Software Development",
      "Cloud Services",
      "AI/ML Solutions",
      "Data Analytics"
    ],
    "Locations": [
      "San Francisco, CA",
      "New York, NY",
      "London, UK",
      "Tokyo, Japan"
    ]
  },
  "_performance": {
    "extractionTimeSeconds": 2.45,
    "timestamp": "2024-01-15T10:30:00Z"
  },
  "_message": "Brand extraction completed successfully"
}
```

#### **Example**
```bash
curl -X POST "https://api.yourcompany.com/api/v1/secure/rivofetch" \
  -H "Content-Type: application/json" \
  -H "x-api-key: sk-1234567890abcdef1234567890abcdef12345678" \
  -H "Origin: https://yourdomain.com" \
  -d '{
    "url": "https://github.com"
  }'
```

#### **Response Headers**
```http
X-RateLimit-Limit: 200
X-RateLimit-Remaining: 195
X-RateLimit-Reset: 1642291200
X-RateLimit-Window: 86400
X-RateLimit-Tier: PRO_TIER
X-RateLimit-Total-Remaining: 195
```

### **Health Check**

Verify API key validity and connection status.

```http
GET /secure/health
```

#### **Headers**
```http
x-api-key: sk-your-api-key-here
Origin: https://yourdomain.com
```

#### **Response (200 OK)**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-15T10:30:00Z",
  "apiKeyId": "550e8400-e29b-41d4-a716-446655440000",
  "userId": "user-123",
  "requestDomain": "yourdomain.com",
  "matchedDomain": "yourdomain.com",
  "validationType": "EXACT_MATCH",
  "rateLimitInfo": {
    "tier": "PRO_TIER",
    "remaining": 195,
    "resetTime": "2024-01-16T00:00:00Z"
  }
}
```

#### **Example**
```bash
curl -X GET "https://api.yourcompany.com/api/v1/secure/health" \
  -H "x-api-key: sk-1234567890abcdef1234567890abcdef12345678" \
  -H "Origin: https://yourdomain.com"
```

---

## 📊 Analytics & Usage

### **Get API Key Statistics**

Retrieve detailed usage statistics for a specific API key.

```http
GET /api-keys/{keyId}/statistics
```

#### **Headers**
```http
Authorization: Bearer {jwt_token}
```

#### **Query Parameters**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `period` | string | `30d` | Time period: `1d`, `7d`, `30d`, `90d` |
| `granularity` | string | `day` | Data granularity: `hour`, `day`, `week` |

#### **Response (200 OK)**
```json
{
  "keyId": "550e8400-e29b-41d4-a716-446655440000",
  "period": "30d",
  "summary": {
    "totalRequests": 1250,
    "successfulRequests": 1198,
    "failedRequests": 52,
    "successRate": 0.958,
    "averageResponseTime": 245,
    "uniqueUrls": 89,
    "topErrorCodes": [
      {"code": "EXTERNAL_API_ERROR", "count": 32},
      {"code": "TIMEOUT_ERROR", "count": 20}
    ]
  },
  "timeSeries": [
    {
      "date": "2024-01-01",
      "requests": 45,
      "successful": 43,
      "failed": 2,
      "averageResponseTime": 234
    },
    {
      "date": "2024-01-02",
      "requests": 52,
      "successful": 50,
      "failed": 2,
      "averageResponseTime": 267
    }
  ],
  "topDomains": [
    {"domain": "github.com", "requests": 156},
    {"domain": "stackoverflow.com", "requests": 89},
    {"domain": "medium.com", "requests": 67}
  ]
}
```

---

## 🚨 Error Responses

### **Error Response Format**

All error responses follow a consistent format:

```json
{
  "error": "Detailed error message",
  "status": 400,
  "errorCode": "ERROR_CODE",
  "timestamp": "2024-01-15T10:30:00Z",
  "requestId": "req_123456789",
  "requestDomain": "unauthorized.com",
  "expectedDomain": "yourdomain.com",
  "suggestions": [
    "Ensure your request includes Origin or Referer header",
    "Verify your domain is registered for this API key"
  ]
}
```

### **Error Codes Reference**

#### **Authentication Errors (401)**
| Code | Description | Solution |
|------|-------------|----------|
| `MISSING_API_KEY` | API key not provided | Add `x-api-key` header |
| `INVALID_API_KEY` | API key not found or invalid | Verify API key value |
| `API_KEY_INACTIVE` | API key is deactivated | Reactivate API key |
| `API_KEY_EXPIRED` | API key has expired | Create new API key |

#### **Authorization Errors (403)**
| Code | Description | Solution |
|------|-------------|----------|
| `DOMAIN_NOT_ALLOWED` | Domain not registered for API key | Add domain to API key |
| `MISSING_DOMAIN_HEADER` | Origin/Referer header missing | Add Origin header |
| `INSUFFICIENT_PERMISSIONS` | Missing required scopes | Update API key scopes |
| `MONTHLY_QUOTA_EXCEEDED` | Monthly API call limit reached | Upgrade plan |
| `API_KEY_LIMIT_EXCEEDED` | Plan API key limit reached | Upgrade plan or remove unused keys |

#### **Rate Limiting Errors (429)**
| Code | Description | Solution |
|------|-------------|----------|
| `RATE_LIMIT_EXCEEDED` | Daily rate limit exceeded | Wait for reset or upgrade plan |

#### **Client Errors (400)**
| Code | Description | Solution |
|------|-------------|----------|
| `INVALID_URL` | URL format is invalid | Provide valid HTTP/HTTPS URL |
| `DOMAIN_VALIDATION_FAILED` | Domain format validation failed | Use valid domain format |

#### **Server Errors (5xx)**
| Code | Description | Solution |
|------|-------------|----------|
| `EXTERNAL_API_ERROR` | Target website unreachable | Verify target URL accessibility |
| `TIMEOUT_ERROR` | Request timed out | Retry with exponential backoff |
| `PARSE_ERROR` | Response parsing failed | Contact support |
| `INTERNAL_ERROR` | Internal server error | Contact support |

### **Example Error Responses**

#### **Invalid API Key (401)**
```json
{
  "error": "API key not found or invalid",
  "status": 401,
  "errorCode": "INVALID_API_KEY",
  "timestamp": "2024-01-15T10:30:00Z",
  "suggestions": [
    "Verify your API key is correct",
    "Check if the API key is active",
    "Ensure the API key hasn't expired"
  ]
}
```

#### **Domain Validation Failed (403)**
```json
{
  "error": "Domain validation failed. Request domain 'unauthorized.com' is not allowed for this API key.",
  "status": 403,
  "errorCode": "DOMAIN_NOT_ALLOWED",
  "timestamp": "2024-01-15T10:30:00Z",
  "requestDomain": "unauthorized.com",
  "expectedDomain": "yourdomain.com",
  "suggestions": [
    "Ensure your request includes Origin or Referer header",
    "Verify your domain is registered for this API key",
    "Check that your domain format is correct"
  ]
}
```

#### **Rate Limit Exceeded (429)**
```json
{
  "error": "Rate limit exceeded. You have made 200/200 requests in the current window.",
  "status": 429,
  "errorCode": "RATE_LIMIT_EXCEEDED",
  "timestamp": "2024-01-15T10:30:00Z",
  "rateLimitInfo": {
    "limit": 200,
    "remaining": 0,
    "resetTime": "2024-01-16T00:00:00Z",
    "tier": "PRO_TIER"
  },
  "suggestions": [
    "Wait for rate limit reset",
    "Implement exponential backoff",
    "Consider upgrading to a higher plan"
  ]
}
```

---

## 📈 Rate Limiting

### **Rate Limit Headers**

All API responses include comprehensive rate limiting information:

```http
X-RateLimit-Limit: 200
X-RateLimit-Remaining: 195
X-RateLimit-Reset: 1642291200
X-RateLimit-Window: 86400
X-RateLimit-Tier: PRO_TIER
X-RateLimit-Total-Remaining: 195
X-RateLimit-Additional-Available: 50
X-RateLimit-Used-AddOn: false
```

### **Rate Limit Tiers**

| Tier | Requests/Day | Window | Plans | Burst Limit |
|------|--------------|--------|-------|-------------|
| `FREE_TIER` | 50 | 24 hours | FREE | 10/minute |
| `PRO_TIER` | 200 | 24 hours | PRO | 30/minute |
| `BUSINESS_TIER` | 1,000 | 24 hours | BUSINESS | 100/minute |
| `ENTERPRISE_TIER` | Custom | Custom | ENTERPRISE | Custom |

### **Rate Limit Handling**

#### **Best Practices**
1. **Monitor Headers**: Always check rate limit headers in responses
2. **Implement Backoff**: Use exponential backoff for retries
3. **Cache Responses**: Cache brand data to reduce API calls
4. **Batch Requests**: Group multiple URLs when possible

#### **Example Implementation**
```javascript
async function handleRateLimit(response) {
  const remaining = parseInt(response.headers.get('x-ratelimit-remaining'));
  const resetTime = parseInt(response.headers.get('x-ratelimit-reset'));
  
  if (remaining < 5) {
    const waitTime = (resetTime * 1000) - Date.now();
    if (waitTime > 0) {
      console.log(`Rate limit approaching. Waiting ${waitTime}ms`);
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }
  }
  
  if (response.status === 429) {
    const retryAfter = response.headers.get('retry-after');
    const waitTime = retryAfter ? parseInt(retryAfter) * 1000 : 60000;
    
    console.log(`Rate limit exceeded. Retrying after ${waitTime}ms`);
    await new Promise(resolve => setTimeout(resolve, waitTime));
    
    // Retry the request
    return true; // Indicates retry needed
  }
  
  return false; // No retry needed
}
```

---

## 🔧 SDK & Integration Examples

### **Official SDKs**

- **JavaScript/Node.js**: `npm install @yourcompany/jwt-auth-sdk`
- **Python**: `pip install jwt-auth-sdk`
- **PHP**: `composer require yourcompany/jwt-auth-sdk`
- **Go**: `go get github.com/yourcompany/jwt-auth-sdk-go`

### **Postman Collection**

Import our comprehensive Postman collection for easy testing:

```bash
# Download Postman collection
curl -o jwt-auth-api.postman_collection.json \
  https://api.yourcompany.com/postman/collection
```

### **OpenAPI Specification**

Access our OpenAPI 3.0 specification:

```bash
# Download OpenAPI spec
curl -o openapi.yaml \
  https://api.yourcompany.com/openapi.yaml
```

---

## 📞 Support & Resources

### **API Status**
- **Status Page**: https://status.yourcompany.com
- **Uptime**: 99.9% SLA (Business+ plans)

### **Support Channels**
- **Email**: api-support@yourcompany.com
- **Documentation**: https://docs.yourcompany.com
- **Community**: https://community.yourcompany.com

### **Rate Limits for Support**
- **Free Plan**: Community support only
- **Pro Plan**: Email support (48h response)
- **Business Plan**: Priority support (24h response)
- **Enterprise Plan**: Dedicated support (4h response)

---

*API Reference last updated: January 2024*
*For the most up-to-date information, visit: https://docs.yourcompany.com*
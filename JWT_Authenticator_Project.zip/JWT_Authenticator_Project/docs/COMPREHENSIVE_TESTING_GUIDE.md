# Comprehensive Testing Guide - JWT Authenticator API with Prefix Support

## Overview

This guide provides comprehensive testing scenarios for the JWT Authenticator API Key system with full prefix support. The accompanying Postman collection covers every possible field, environment, rate limit tier, scope combination, prefix variation, and error scenario.

## Testing Collection Structure

### **1. Authentication Setup**
- **Login - Get JWT Token**: Authenticates and sets up JWT token for subsequent requests

### **2. API Key Creation - All Rate Limit Tiers**
- **BASIC Tier**: Basic permissions with `sk` prefix
- **STANDARD Tier**: Enhanced permissions with `std` prefix  
- **PREMIUM Tier**: Advanced permissions with `prem` prefix
- **ENTERPRISE Tier**: Full permissions with `ent` prefix
- **UNLIMITED Tier**: Unrestricted access with `unlim` prefix

### **3. Environment-Specific API Key Creation**
- **Development Environment**: Localhost domains with `dev` prefix
- **Staging Environment**: Staging configurations with `stg` prefix

### **4. Enhanced API Key Creation (Rivo)**
- **Rivo Endpoint**: Advanced features with `rivo` prefix

### **5. Prefix Variations Testing**
- **Custom Prefix 'admin'**: Administrative operations
- **Custom Prefix 'biz'**: Business operations
- **No Prefix**: Default behavior testing

### **6. Scope Combinations Testing**
- **Basic Read Scopes**: Minimal access with `read` prefix
- **Domain Management**: Domain permissions with `domain` prefix
- **Write Permissions**: Data modification with `write` prefix
- **Analytics Scopes**: Analytics access with `analytics` prefix

### **7. Secure Endpoint Testing**
- **RivoFetch with Different Tiers**: Testing with various API key prefixes

### **8. API Key Management Operations**
- **CRUD Operations**: Complete management with prefix support

### **9. Error Scenarios Testing**
- **Prefix Validation**: Invalid prefix formats and lengths
- **Standard Validation**: Missing fields, invalid formats

### **10. Edge Cases and Boundary Testing**
- **Maximum Field Lengths**: Including prefix boundary testing
- **Special Characters**: Unicode and special character handling in prefixes

## Complete Field Coverage with Prefix Support

### API Key Creation Request Fields

#### **Required Fields**
```json
{
  "name": "string (1-255 characters)",
  "registeredDomain": "string (valid domain format)"
}
```

#### **Optional Fields**
```json
{
  "description": "string (0-1000 characters)",
  "prefix": "string (1-10 characters, alphanumeric + hyphens + underscores)",
  "allowedIps": ["string array (IP addresses/CIDR blocks)"],
  "allowedDomains": ["string array (domain names)"],
  "rateLimitTier": "enum (BASIC|STANDARD|PREMIUM|ENTERPRISE|UNLIMITED)",
  "scopes": ["string array (permission scopes)"],
  "expiresAt": "LocalDateTime string (YYYY-MM-DDTHH:mm:ss)"
}
```

#### **Query Parameters**
```
environment: production|development|staging (default: production)
```

## Rate Limit Tier Testing with Prefixes

### **BASIC Tier**
```json
{
  "name": "BASIC Tier API Key - Complete",
  "description": "Complete BASIC tier API key with all fields populated",
  "registeredDomain": "api.basic.example.com",
  "prefix": "sk",
  "allowedIps": ["192.168.1.100", "203.0.113.10"],
  "allowedDomains": ["backup.basic.example.com", "cdn.basic.example.com"],
  "rateLimitTier": "BASIC",
  "scopes": ["READ_BASIC", "DOMAIN_HEALTH", "READ_BRANDS"],
  "expiresAt": "2024-12-31T23:59:59"
}
```

### **STANDARD Tier**
```json
{
  "name": "STANDARD Tier API Key - Complete",
  "description": "Complete STANDARD tier API key with enhanced permissions",
  "registeredDomain": "api.standard.example.com",
  "prefix": "std",
  "allowedIps": ["192.168.2.100", "203.0.113.20", "198.51.100.30"],
  "allowedDomains": ["backup.standard.example.com", "cdn.standard.example.com"],
  "rateLimitTier": "STANDARD",
  "scopes": ["READ_BASIC", "READ_ADVANCED", "DOMAIN_HEALTH", "DOMAIN_INSIGHTS"],
  "expiresAt": "2024-09-30T23:59:59"
}
```

### **PREMIUM Tier**
```json
{
  "name": "PREMIUM Tier API Key - Complete",
  "description": "Complete PREMIUM tier API key with advanced features",
  "registeredDomain": "api.premium.example.com",
  "prefix": "prem",
  "allowedIps": ["192.168.3.100", "203.0.113.30", "198.51.100.40"],
  "allowedDomains": ["backup.premium.example.com", "cdn.premium.example.com"],
  "rateLimitTier": "PREMIUM",
  "scopes": ["READ_BASIC", "READ_ADVANCED", "WRITE_BASIC", "DOMAIN_HEALTH"],
  "expiresAt": "2025-03-31T23:59:59"
}
```

### **ENTERPRISE Tier**
```json
{
  "name": "ENTERPRISE Tier API Key - Complete",
  "description": "Complete ENTERPRISE tier API key with maximum permissions",
  "registeredDomain": "api.enterprise.example.com",
  "prefix": "ent",
  "allowedIps": ["203.0.113.0/24", "198.51.100.0/24", "192.0.2.100"],
  "allowedDomains": ["backup.enterprise.example.com", "cdn.enterprise.example.com"],
  "rateLimitTier": "ENTERPRISE",
  "scopes": ["READ_BASIC", "READ_ADVANCED", "WRITE_BASIC", "WRITE_ADVANCED"],
  "expiresAt": "2025-12-31T23:59:59"
}
```

### **UNLIMITED Tier**
```json
{
  "name": "UNLIMITED Tier API Key - Complete",
  "description": "Complete UNLIMITED tier API key with unrestricted access",
  "registeredDomain": "api.unlimited.example.com",
  "prefix": "unlim",
  "allowedIps": ["203.0.113.0/24", "198.51.100.0/24", "192.0.2.0/24"],
  "allowedDomains": ["backup.unlimited.example.com", "cdn.unlimited.example.com"],
  "rateLimitTier": "UNLIMITED",
  "scopes": ["FULL_ACCESS"],
  "expiresAt": "2026-12-31T23:59:59"
}
```

## Prefix Validation Rules

### **Valid Prefix Formats**
- **Length**: 1-10 characters
- **Characters**: Letters (a-z, A-Z), numbers (0-9), hyphens (-), underscores (_)
- **Examples**: `sk`, `admin`, `biz-1`, `dev_test`, `api_v2`

### **Invalid Prefix Examples**
```json
{
  "prefix": "invalid@prefix!"  // Special characters not allowed
}
```

```json
{
  "prefix": "verylongprefix"  // Exceeds 10 character limit
}
```

```json
{
  "prefix": ""  // Empty string (should be null instead)
}
```

## Environment-Specific Testing with Prefixes

### **Development Environment**
```json
{
  "name": "Development API Key - Complete",
  "description": "Complete development API key with localhost domains",
  "registeredDomain": "localhost:3000",
  "prefix": "dev",
  "allowedIps": ["127.0.0.1", "192.168.1.0/24", "10.0.0.0/8"],
  "allowedDomains": ["127.0.0.1:3000", "dev.localhost", "test.localhost:8080"],
  "rateLimitTier": "BASIC",
  "scopes": ["READ_BASIC", "DOMAIN_HEALTH", "READ_BRANDS"],
  "expiresAt": "2024-06-30T23:59:59"
}
```

### **Staging Environment**
```json
{
  "name": "Staging API Key - Complete",
  "description": "Complete staging API key with staging-specific domains",
  "registeredDomain": "api.staging.example.com",
  "prefix": "stg",
  "allowedIps": ["172.16.0.0/12", "10.1.1.100"],
  "allowedDomains": ["staging.example.com", "test.staging.example.com"],
  "rateLimitTier": "STANDARD",
  "scopes": ["READ_BASIC", "READ_ADVANCED", "DOMAIN_HEALTH"],
  "expiresAt": "2024-09-30T23:59:59"
}
```

## Custom Prefix Testing Scenarios

### **Administrative Prefix**
```json
{
  "name": "Admin Prefix API Key",
  "description": "API key with custom admin prefix for administrative operations",
  "registeredDomain": "admin.example.com",
  "prefix": "admin",
  "rateLimitTier": "PREMIUM",
  "scopes": ["READ_BASIC", "READ_ADVANCED", "WRITE_BASIC", "DOMAIN_MANAGEMENT"]
}
```

### **Business Prefix**
```json
{
  "name": "Business Prefix API Key",
  "description": "API key with custom business prefix for business operations",
  "registeredDomain": "biz.example.com",
  "prefix": "biz",
  "rateLimitTier": "ENTERPRISE",
  "scopes": ["BUSINESS_READ", "BUSINESS_WRITE", "ANALYTICS_READ", "ANALYTICS_WRITE"]
}
```

### **No Prefix (Default Behavior)**
```json
{
  "name": "No Prefix API Key",
  "description": "API key without custom prefix to test default behavior",
  "registeredDomain": "noprefix.example.com",
  "rateLimitTier": "STANDARD",
  "scopes": ["READ_BASIC", "DOMAIN_HEALTH"]
}
```

## Error Scenarios with Prefix Validation

### **Prefix Validation Errors (400)**
1. **Invalid Prefix Characters**
   ```json
   {
     "name": "Invalid Prefix Test",
     "registeredDomain": "test.example.com",
     "prefix": "invalid@prefix!"
   }
   ```

2. **Prefix Too Long**
   ```json
   {
     "name": "Long Prefix Test",
     "registeredDomain": "test.example.com",
     "prefix": "verylongprefix"
   }
   ```

3. **Empty Prefix String**
   ```json
   {
     "name": "Empty Prefix Test",
     "registeredDomain": "test.example.com",
     "prefix": ""
   }
   ```

### **Standard Validation Errors**
1. **Missing Required Fields**
   - Missing `name` field
   - Missing `registeredDomain` field

2. **Invalid Field Formats**
   - Invalid domain format
   - Invalid rate limit tier
   - Invalid scopes

## Expected Response Formats with Prefix

### **Successful API Key Creation (201)**
```json
{
  "id": "uuid",
  "name": "API Key Name",
  "description": "Description",
  "keyValue": "prefix-abcd1234...",  // Note: prefix included in key value
  "registeredDomain": "api.example.com",
  "mainDomain": "example.com",
  "subdomainPattern": "*.example.com",
  "environment": "production",
  "allowedDomains": "backup.example.com",
  "allowedIps": "192.168.1.100,10.0.0.50",
  "scopes": "READ_BASIC,DOMAIN_HEALTH",
  "rateLimitTier": "STANDARD",
  "isActive": true,
  "expiresAt": "2024-12-31T23:59:59",
  "createdAt": "2024-01-15T10:30:00Z"
}
```

### **Prefix Validation Error Response**
```json
{
  "success": false,
  "error": "Prefix can only contain letters, numbers, hyphens, and underscores",
  "errorCode": "INVALID_PREFIX_FORMAT",
  "timestamp": "2024-01-15T10:30:00Z",
  "requestId": "req_123456789",
  "details": {
    "field": "prefix",
    "value": "invalid@prefix!",
    "allowedPattern": "^[a-zA-Z0-9_-]*$",
    "maxLength": 10
  }
}
```

## Testing Execution Guide

### **Step 1: Environment Setup**
1. Import the Postman collection
2. Set up environment variables:
   ```
   base_url: http://localhost:8080
   ```

### **Step 2: Authentication**
1. Run "Login - Get JWT Token"
2. Verify JWT token is automatically set in collection variables

### **Step 3: Rate Limit Tier Testing**
1. Test each tier (BASIC, STANDARD, PREMIUM, ENTERPRISE, UNLIMITED)
2. Verify correct prefix is applied to generated API keys
3. Confirm rate limit tiers are properly set

### **Step 4: Prefix Variation Testing**
1. Test custom prefixes (`admin`, `biz`)
2. Test no prefix scenario
3. Verify prefix validation rules

### **Step 5: Environment Testing**
1. Test development environment with `dev` prefix
2. Test staging environment with `stg` prefix
3. Verify environment-specific configurations

### **Step 6: Enhanced Creation Testing**
1. Test Rivo endpoint with `rivo` prefix
2. Verify enhanced features are enabled

### **Step 7: Error Scenario Testing**
1. Test invalid prefix formats
2. Test prefix length validation
3. Test standard validation errors

### **Step 8: Secure Endpoint Testing**
1. Test RivoFetch with different prefixed API keys
2. Verify domain validation works with all prefixes

### **Step 9: Management Operations**
1. Test CRUD operations on prefixed API keys
2. Verify prefix information is preserved in updates

### **Step 10: Edge Case Testing**
1. Test boundary conditions with prefixes
2. Test special characters in names/descriptions
3. Test maximum field lengths

## Automated Testing Features

### **Collection Variables**
The collection automatically manages these variables:
- `jwt_token`: Authentication token
- `api_key_basic`: BASIC tier API key (sk- prefix)
- `api_key_standard`: STANDARD tier API key (std- prefix)
- `api_key_premium`: PREMIUM tier API key (prem- prefix)
- `api_key_enterprise`: ENTERPRISE tier API key (ent- prefix)
- `api_key_unlimited`: UNLIMITED tier API key (unlim- prefix)
- `api_key_id`: Last created API key ID
- `user_id`: Authenticated user ID

### **Prefix Validation Scripts**
The collection includes automatic prefix validation:
```javascript
// Validate prefix in successful API key creation responses
if (pm.response.code === 201 && pm.request.url.path.includes('api-keys')) {
    try {
        const response = pm.response.json();
        if (response.keyValue) {
            const requestBody = JSON.parse(pm.request.body.raw);
            if (requestBody.prefix) {
                pm.test('API key has correct prefix', function () {
                    pm.expect(response.keyValue).to.match(new RegExp('^' + requestBody.prefix + '-'));
                });
            }
        }
    } catch (e) {
        console.log('Could not validate prefix in response');
    }
}
```

## Success Criteria

### **Prefix Functionality**
- [ ] All rate limit tiers create API keys with correct prefixes
- [ ] Custom prefixes are properly applied
- [ ] Prefix validation rules are enforced
- [ ] No prefix scenario works correctly
- [ ] Prefix information is preserved in management operations

### **Standard Functionality**
- [ ] All authentication flows work correctly
- [ ] All API key creation scenarios succeed
- [ ] All environment configurations are handled
- [ ] All rate limit tiers function properly
- [ ] All scope combinations are enforced
- [ ] All secure endpoints validate correctly
- [ ] All error scenarios return appropriate responses
- [ ] All edge cases are handled gracefully

This comprehensive testing approach ensures that every aspect of the JWT Authenticator API Key system, including the new prefix functionality, is thoroughly validated and ready for production use.
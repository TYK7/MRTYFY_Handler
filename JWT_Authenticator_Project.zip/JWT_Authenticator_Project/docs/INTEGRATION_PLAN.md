# 🔗 API Key Functionality - Complete Integration Plan

## 📋 **CURRENT SITUATION**

The Add-on Package System, Usage Statistics System, and Request Logging System are **already implemented** but **not integrated** with the core API key functionality. Here's how to properly integrate them:

---

## 🎯 **INTEGRATION STRATEGY**

### **Phase 1: Add-on Package System Integration**
### **Phase 2: Usage Statistics System Integration**  
### **Phase 3: Request Logging System Integration**
### **Phase 4: Complete System Testing**

---

## 🔧 **PHASE 1: ADD-ON PACKAGE SYSTEM INTEGRATION**

### **Current Status**: ✅ Implemented but not connected

### **What Exists:**
- `ApiKeyAddOn.java` - Add-on entity
- `ApiKeyAddOnService.java` - Add-on business logic
- `ApiKeyAddOnController.java` - REST endpoints
- `AddOnPackage.java` - Package types enum
- All DTOs for add-on management

### **Integration Points Needed:**

#### **1. Connect Add-ons to Rate Limiting**
```java
// Modify RateLimitService.java to consider add-ons
public class RateLimitService {
    
    @Autowired
    private ApiKeyAddOnService addOnService; // ADD THIS
    
    public boolean isAllowed(String apiKeyHash, RateLimitTier tier) {
        // Get base limit from tier
        int baseLimit = tier.getRequestsPerHour();
        
        // ADD: Get additional requests from active add-ons
        int additionalRequests = addOnService.getActiveAdditionalRequests(apiKeyHash);
        int totalLimit = baseLimit + additionalRequests;
        
        // Use totalLimit instead of baseLimit for rate limiting
        return checkRateLimit(apiKeyHash, totalLimit);
    }
}
```

#### **2. Update ApiKeyService to Include Add-on Info**
```java
// Modify ApiKeyService.java
public class ApiKeyService {
    
    @Autowired
    private ApiKeyAddOnService addOnService; // ADD THIS
    
    public ApiKeyResponseDTO getApiKeyByIdForUser(UUID keyId, String userId) {
        // Existing logic...
        ApiKeyResponseDTO response = convertToDTO(apiKey);
        
        // ADD: Include add-on information
        List<ApiKeyAddOn> activeAddOns = addOnService.getActiveAddOnsForApiKey(keyId.toString());
        response.setActiveAddOns(activeAddOns);
        response.setTotalAdditionalRequests(
            activeAddOns.stream().mapToInt(ApiKeyAddOn::getRequestsRemaining).sum()
        );
        
        return response;
    }
}
```

#### **3. Add Add-on Endpoints to SecurityConfig**
```java
// Modify SecurityConfig.java
.requestMatchers(
    // Existing endpoints...
    "/api/v1/api-keys/addons/**" // ADD THIS
).permitAll()
```

---

## 📊 **PHASE 2: USAGE STATISTICS SYSTEM INTEGRATION**

### **Current Status**: ✅ Implemented but not connected

### **What Exists:**
- `ApiKeyUsageStats.java` - Usage statistics entity
- `ApiKeyUsageStatsRepository.java` - Data access layer

### **Integration Points Needed:**

#### **1. Connect Statistics to API Key Authentication**
```java
// Modify ApiKeyAuthenticationFilter.java
public class ApiKeyAuthenticationFilter extends OncePerRequestFilter {
    
    @Autowired
    private UsageStatsService usageStatsService; // ADD THIS
    
    @Override
    protected void doFilterInternal(HttpServletRequest request, 
                                   HttpServletResponse response, 
                                   FilterChain filterChain) throws ServletException, IOException {
        
        // Existing authentication logic...
        
        if (apiKeyEntity.isPresent()) {
            // ADD: Record usage statistics
            usageStatsService.recordApiKeyUsage(
                apiKeyEntity.get().getId().toString(),
                request.getRequestURI(),
                request.getMethod(),
                getClientIp(request)
            );
        }
        
        filterChain.doFilter(request, response);
    }
}
```

#### **2. Create Usage Statistics Service**
```java
// Create new UsageStatsService.java
@Service
@RequiredArgsConstructor
public class UsageStatsService {
    
    private final ApiKeyUsageStatsRepository statsRepository;
    
    public void recordApiKeyUsage(String apiKeyId, String endpoint, String method, String clientIp) {
        // Create or update usage statistics
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime windowStart = now.withMinute(0).withSecond(0).withNano(0);
        LocalDateTime windowEnd = windowStart.plusHours(1);
        
        Optional<ApiKeyUsageStats> existingStats = statsRepository
            .findByApiKeyIdAndWindowStart(apiKeyId, windowStart);
            
        if (existingStats.isPresent()) {
            ApiKeyUsageStats stats = existingStats.get();
            stats.incrementRequestCount();
            statsRepository.save(stats);
        } else {
            // Create new stats window
            ApiKeyUsageStats newStats = ApiKeyUsageStats.builder()
                .apiKeyId(apiKeyId)
                .windowStart(windowStart)
                .windowEnd(windowEnd)
                .requestCount(1)
                .build();
            statsRepository.save(newStats);
        }
    }
    
    public List<ApiKeyUsageStats> getUsageStatsForApiKey(String apiKeyId, LocalDateTime from, LocalDateTime to) {
        return statsRepository.findByApiKeyIdAndWindowStartBetween(apiKeyId, from, to);
    }
}
```

#### **3. Add Usage Statistics Endpoints**
```java
// Add to ApiKeyController.java
@GetMapping("/{keyId}/usage-stats")
@Operation(summary = "Get usage statistics for API key")
public ResponseEntity<List<ApiKeyUsageStats>> getUsageStats(
        @PathVariable UUID keyId,
        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to,
        @AuthenticationPrincipal UserDetails userDetails) {
    
    String userFkId = getCurrentUserId(userDetails);
    
    // Validate API key belongs to user
    if (!apiKeyService.apiKeyBelongsToUser(keyId, userFkId)) {
        return ResponseEntity.notFound().build();
    }
    
    if (from == null) from = LocalDateTime.now().minusDays(30);
    if (to == null) to = LocalDateTime.now();
    
    List<ApiKeyUsageStats> stats = usageStatsService.getUsageStatsForApiKey(keyId.toString(), from, to);
    return ResponseEntity.ok(stats);
}
```

---

## 📝 **PHASE 3: REQUEST LOGGING SYSTEM INTEGRATION**

### **Current Status**: ✅ Implemented but not connected

### **What Exists:**
- `ApiKeyRequestLog.java` - Request log entity
- `ApiKeyRequestLogRepository.java` - Data access layer

### **Integration Points Needed:**

#### **1. Connect Logging to All API Key Usage**
```java
// Create RequestLoggingService.java
@Service
@RequiredArgsConstructor
@Async
public class RequestLoggingService {
    
    private final ApiKeyRequestLogRepository logRepository;
    
    @Async
    public void logApiKeyRequest(String apiKeyId, String userFkId, HttpServletRequest request, 
                                HttpServletResponse response, boolean success) {
        
        ApiKeyRequestLog log = ApiKeyRequestLog.builder()
            .apiKeyId(UUID.fromString(apiKeyId))
            .userFkId(userFkId)
            .clientIp(getClientIp(request))
            .domain(getDomain(request))
            .userAgent(request.getHeader("User-Agent"))
            .requestMethod(request.getMethod())
            .requestPath(request.getRequestURI())
            .requestTimestamp(LocalDateTime.now())
            .responseStatus(response.getStatus())
            .success(success)
            .build();
            
        logRepository.save(log);
    }
    
    private String getClientIp(HttpServletRequest request) {
        // Extract IP with proxy support
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
    
    private String getDomain(HttpServletRequest request) {
        String origin = request.getHeader("Origin");
        if (origin != null) return origin;
        
        String referer = request.getHeader("Referer");
        if (referer != null) {
            try {
                return new URL(referer).getHost();
            } catch (Exception e) {
                return referer;
            }
        }
        return null;
    }
}
```

#### **2. Integrate Logging into Filters**
```java
// Modify ApiKeyAuthenticationFilter.java
public class ApiKeyAuthenticationFilter extends OncePerRequestFilter {
    
    @Autowired
    private RequestLoggingService requestLoggingService; // ADD THIS
    
    @Override
    protected void doFilterInternal(HttpServletRequest request, 
                                   HttpServletResponse response, 
                                   FilterChain filterChain) throws ServletException, IOException {
        
        String apiKey = extractApiKey(request);
        boolean success = false;
        String apiKeyId = null;
        String userFkId = null;
        
        try {
            if (apiKey != null) {
                Optional<ApiKey> apiKeyEntity = apiKeyService.validateApiKey(apiKey);
                if (apiKeyEntity.isPresent()) {
                    success = true;
                    apiKeyId = apiKeyEntity.get().getId().toString();
                    userFkId = apiKeyEntity.get().getUserFkId();
                    
                    // Set authentication...
                }
            }
            
            filterChain.doFilter(request, response);
            
        } finally {
            // ADD: Log the request
            if (apiKeyId != null) {
                requestLoggingService.logApiKeyRequest(apiKeyId, userFkId, request, response, success);
            }
        }
    }
}
```

#### **3. Add Request Log Endpoints**
```java
// Add to ApiKeyController.java
@GetMapping("/{keyId}/request-logs")
@Operation(summary = "Get request logs for API key")
public ResponseEntity<Page<ApiKeyRequestLog>> getRequestLogs(
        @PathVariable UUID keyId,
        @RequestParam(defaultValue = "0") int page,
        @RequestParam(defaultValue = "50") int size,
        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to,
        @AuthenticationPrincipal UserDetails userDetails) {
    
    String userFkId = getCurrentUserId(userDetails);
    
    // Validate API key belongs to user
    if (!apiKeyService.apiKeyBelongsToUser(keyId, userFkId)) {
        return ResponseEntity.notFound().build();
    }
    
    if (from == null) from = LocalDateTime.now().minusDays(7);
    if (to == null) to = LocalDateTime.now();
    
    Pageable pageable = PageRequest.of(page, size, Sort.by("requestTimestamp").descending());
    Page<ApiKeyRequestLog> logs = requestLoggingService.getRequestLogsForApiKey(keyId, from, to, pageable);
    
    return ResponseEntity.ok(logs);
}
```

---

## 🔄 **PHASE 4: COMPLETE SYSTEM INTEGRATION**

### **1. Update DTOs to Include New Data**

#### **Enhanced ApiKeyResponseDTO**
```java
// Modify ApiKeyResponseDTO.java
@Data
public class ApiKeyResponseDTO {
    // Existing fields...
    
    // ADD: Add-on information
    private List<ApiKeyAddOnResponseDTO> activeAddOns;
    private Integer totalAdditionalRequests;
    private Double monthlyAddOnCost;
    
    // ADD: Usage statistics
    private ApiKeyUsageStatsDTO currentUsageStats;
    private Integer requestsUsedToday;
    private Integer requestsRemainingToday;
    
    // ADD: Recent activity
    private LocalDateTime lastRequestAt;
    private String lastRequestDomain;
    private Integer requestsLast24Hours;
}
```

#### **Create New DTOs**
```java
// Create ApiKeyAddOnResponseDTO.java
@Data
@Builder
public class ApiKeyAddOnResponseDTO {
    private String id;
    private AddOnPackage addOnPackage;
    private Integer additionalRequests;
    private Integer requestsUsed;
    private Integer requestsRemaining;
    private Double monthlyPrice;
    private LocalDateTime activatedAt;
    private LocalDateTime expiresAt;
    private Boolean isActive;
    private Double usagePercentage;
    private Long daysUntilExpiration;
}

// Create ApiKeyUsageStatsDTO.java
@Data
@Builder
public class ApiKeyUsageStatsDTO {
    private LocalDateTime windowStart;
    private LocalDateTime windowEnd;
    private Integer requestCount;
    private Integer requestLimit;
    private Integer remainingRequests;
    private Double usagePercentage;
    private Boolean isRateLimited;
    private LocalDateTime rateLimitResetAt;
}
```

### **2. Update SecurityConfig for New Endpoints**
```java
// Modify SecurityConfig.java
.requestMatchers(
    // Existing endpoints...
    "/api/v1/api-keys/*/addons/**",
    "/api/v1/api-keys/*/usage-stats",
    "/api/v1/api-keys/*/request-logs",
    "/api/v1/api-keys/addons/**"
).permitAll()
```

### **3. Create Comprehensive Service Integration**
```java
// Create ApiKeyIntegrationService.java
@Service
@RequiredArgsConstructor
public class ApiKeyIntegrationService {
    
    private final ApiKeyService apiKeyService;
    private final ApiKeyAddOnService addOnService;
    private final UsageStatsService usageStatsService;
    private final RequestLoggingService requestLoggingService;
    private final RateLimitService rateLimitService;
    
    /**
     * Get complete API key information including add-ons, stats, and logs
     */
    public CompleteApiKeyInfoDTO getCompleteApiKeyInfo(UUID keyId, String userId) {
        // Get base API key info
        ApiKeyResponseDTO apiKey = apiKeyService.getApiKeyByIdForUser(keyId, userId)
            .orElseThrow(() -> new IllegalArgumentException("API key not found"));
        
        // Get active add-ons
        List<ApiKeyAddOn> activeAddOns = addOnService.getActiveAddOnsForApiKey(keyId.toString());
        
        // Get current usage stats
        ApiKeyUsageStats currentStats = usageStatsService.getCurrentUsageStats(keyId.toString());
        
        // Get recent request logs (last 10)
        List<ApiKeyRequestLog> recentLogs = requestLoggingService.getRecentRequestLogs(keyId, 10);
        
        // Calculate total limits including add-ons
        int baseLimit = apiKey.getRateLimitTier().getRequestsPerHour();
        int additionalRequests = activeAddOns.stream()
            .mapToInt(ApiKeyAddOn::getRequestsRemaining)
            .sum();
        int totalLimit = baseLimit + additionalRequests;
        
        return CompleteApiKeyInfoDTO.builder()
            .apiKey(apiKey)
            .activeAddOns(activeAddOns)
            .currentUsageStats(currentStats)
            .recentRequestLogs(recentLogs)
            .totalRequestLimit(totalLimit)
            .requestsUsedToday(currentStats != null ? currentStats.getRequestCount() : 0)
            .requestsRemainingToday(totalLimit - (currentStats != null ? currentStats.getRequestCount() : 0))
            .build();
    }
    
    /**
     * Process API key request with full integration
     */
    public void processApiKeyRequest(String apiKeyId, String userFkId, HttpServletRequest request, 
                                   HttpServletResponse response, boolean success) {
        
        // Record usage statistics
        usageStatsService.recordApiKeyUsage(apiKeyId, request.getRequestURI(), 
                                          request.getMethod(), getClientIp(request));
        
        // Update add-on usage if applicable
        if (success) {
            addOnService.consumeAddOnRequests(apiKeyId, 1);
        }
        
        // Log the request
        requestLoggingService.logApiKeyRequest(apiKeyId, userFkId, request, response, success);
    }
}
```

---

## 🧪 **TESTING INTEGRATION**

### **1. Update Postman Collection**
Add new endpoints for:
- Add-on package management
- Usage statistics retrieval
- Request log viewing
- Complete API key information

### **2. Integration Test Scenarios**
```java
@Test
public void testCompleteApiKeyWorkflow() {
    // 1. Create API key
    // 2. Purchase add-on package
    // 3. Make API requests
    // 4. Verify usage statistics
    // 5. Check request logs
    // 6. Verify rate limiting with add-ons
}
```

---

## 📊 **EXPECTED RESULTS AFTER INTEGRATION**

### **Enhanced API Key Management:**
- ✅ **Add-on Packages** - Users can purchase additional request capacity
- ✅ **Usage Statistics** - Real-time usage tracking and analytics
- ✅ **Request Logging** - Complete audit trail of API usage
- ✅ **Integrated Rate Limiting** - Rate limits consider add-on packages
- ✅ **Comprehensive Monitoring** - Full visibility into API key usage

### **New API Endpoints:**
```
POST   /api/v1/api-keys/addons/purchase     - Purchase add-on package
GET    /api/v1/api-keys/addons/packages     - List available packages
GET    /api/v1/api-keys/{id}/addons         - Get API key add-ons
GET    /api/v1/api-keys/{id}/usage-stats    - Get usage statistics
GET    /api/v1/api-keys/{id}/request-logs   - Get request logs
GET    /api/v1/api-keys/{id}/complete-info  - Get complete API key info
```

### **Angular Integration Benefits:**
- **Rich Dashboard** - Complete API key usage overview
- **Add-on Management** - Purchase and manage add-on packages
- **Usage Analytics** - Charts and graphs of API usage
- **Request Monitoring** - Real-time request logging and analysis

---

This integration plan will transform your API key system into a **comprehensive, enterprise-grade solution** with full add-on support, usage analytics, and request monitoring! 🚀
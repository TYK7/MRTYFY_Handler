# 🚀 Quick Testing Guide - API Key Functionality

## 📋 **Prerequisites**

1. **Application Running**: Ensure your Spring Boot app is running on `http://localhost:8080`
2. **Postman Installed**: Import the provided collection
3. **Test User**: Have a registered user for authentication

---

## 🔧 **Setup Steps**

### **1. Import Postman Collection**
```bash
# File location:
./postman/JWT_Authenticator_Complete_Collection.json

# Import into Postman:
1. Open Postman
2. Click "Import" 
3. Select the JSON file
4. Collection will be imported with all variables
```

### **2. Configure Base URL**
```
Collection Variables:
- baseUrl: http://localhost:8080/myapp
- jwt_token: (will be auto-filled)
- api_key: (will be auto-filled)
- user_id: (will be auto-filled)
- api_key_id: (will be auto-filled)
```

---

## 🧪 **Testing Workflow**

### **Step 1: Authentication**
```bash
# 1. Register User (if needed)
POST /auth/register
{
  "username": "testuser",
  "email": "test@example.com", 
  "password": "password123",
  "firstName": "Test",
  "lastName": "User"
}

# 2. Login to get JWT token
POST /auth/login
{
  "username": "testuser",
  "password": "password123"
}
# ✅ JWT token will be automatically saved to collection variables
```

### **Step 2: Create API Keys**
```bash
# 1. Create Standard API Key
POST /api/v1/api-keys
Headers: Authorization: Bearer {{jwt_token}}
Body: {
  "name": "My Standard API Key",
  "registeredDomain": "mywebsite.com",
  "prefix": "sk-",
  "rateLimitTier": "BASIC",
  "scopes": ["READ_USERS", "READ_BRANDS"]
}
# ✅ API key will be automatically saved to collection variables

# 2. Create Testing Key (bypasses domain validation)
POST /api/v1/api-keys
Body: {
  "name": "Development Test Key",
  "registeredDomain": "localhost",
  "prefix": "test-",
  "scopes": ["DOMAINLESS_ACCESS", "READ_USERS", "READ_BRANDS"]
}

# 3. Create Server-to-Server Key (bypasses domain validation)
POST /api/v1/api-keys
Body: {
  "name": "Backend Service Key",
  "registeredDomain": "api.internal.com",
  "prefix": "srv-",
  "scopes": ["SERVER_ACCESS", "BACKEND_API", "BUSINESS_READ"]
}
```

### **Step 3: Test API Usage**
```bash
# 1. Test External API (with domain validation)
GET /api/external/users
Headers: 
- x-api-key: {{api_key}}
- Origin: https://mywebsite.com

# 2. Test Secure Forward (with advanced security)
POST /api/secure/forward
Headers: 
- x-api-key: {{api_key}}
- Origin: https://mywebsite.com  # Optional (has fallback)
Body: {"url": "https://httpbin.org/json"}

# 3. Test Internal Forward (JWT or API Key)
POST /forward
Headers: 
- Authorization: Bearer {{jwt_token}}  # OR
- x-api-key: {{api_key}}              # OR both
Body: {"url": "https://httpbin.org/json"}
```

---

## ✅ **Expected Results**

### **🟢 Should Work (Success Cases):**

1. **Standard API Key with Correct Domain**
   ```bash
   GET /api/external/users
   Headers: x-api-key: sk-..., Origin: https://mywebsite.com
   # ✅ 200 OK - Domain matches registered domain
   ```

2. **API Key without Domain Headers (IP Fallback)**
   ```bash
   POST /api/secure/forward
   Headers: x-api-key: sk-...
   # ✅ 200 OK - IP fallback validation
   ```

3. **Server-to-Server Key (Auto Bypass)**
   ```bash
   POST /api/secure/forward
   Headers: x-api-key: srv-...
   # ✅ 200 OK - Server-to-server auto-detection
   ```

4. **Testing Key (Domain Bypass)**
   ```bash
   POST /api/secure/forward
   Headers: x-api-key: test-...
   # ✅ 200 OK - DOMAINLESS_ACCESS scope bypass
   ```

### **🔴 Should Fail (Error Cases):**

1. **Wrong Domain**
   ```bash
   GET /api/external/users
   Headers: x-api-key: sk-..., Origin: https://wrong-domain.com
   # ❌ 403 Forbidden - Domain validation failed
   ```

2. **Invalid API Key**
   ```bash
   POST /api/secure/forward
   Headers: x-api-key: invalid-key
   # ❌ 401 Unauthorized - Invalid API key
   ```

3. **Insufficient Scope**
   ```bash
   POST /api/external/admin-operation
   Headers: x-api-key: sk-... (without ADMIN_ACCESS scope)
   # ❌ 403 Forbidden - Insufficient permissions
   ```

4. **Rate Limit Exceeded**
   ```bash
   # Make many requests quickly
   # ❌ 429 Too Many Requests - Rate limit exceeded
   ```

---

## 🔍 **Testing Scenarios**

### **Scenario 1: Angular App Integration**
```typescript
// Test from browser console or Angular app
fetch('http://localhost:8080/myapp/api/secure/forward', {
  method: 'POST',
  headers: {
    'x-api-key': 'your-api-key',
    'Origin': window.location.origin,  // Automatically set
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({url: 'https://httpbin.org/json'})
})
.then(response => response.json())
.then(data => console.log('Success:', data))
.catch(error => console.error('Error:', error));
```

### **Scenario 2: cURL Testing**
```bash
# Test without domain headers (should work with IP fallback)
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://httpbin.org/json"}'

# Test with domain headers
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: your-api-key" \
  -H "Origin: https://mywebsite.com" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://httpbin.org/json"}'
```

### **Scenario 3: Mobile App Testing**
```bash
# Mobile apps typically don't send Origin headers
# Should work with IP fallback validation
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: your-api-key" \
  -H "User-Agent: MyMobileApp/1.0" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://httpbin.org/json"}'
```

---

## 📊 **Monitoring & Debugging**

### **Check Logs**
```bash
# Look for these log messages:
- "API key authentication successful"
- "Domain validation passed"
- "IP fallback validation successful"
- "Server-to-server bypass applied"
- "Rate limit check passed"
```

### **Response Headers**
```bash
# Successful responses include:
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Tier: BASIC
X-RateLimit-Reset: 1640995200
```

### **Error Response Format**
```json
{
  "error": "Domain validation failed",
  "status": 403,
  "timestamp": "2024-01-15T10:30:00Z",
  "errorCode": "DOMAIN_MISMATCH",
  "requestDomain": "wrong-domain.com",
  "matchedDomain": "mywebsite.com"
}
```

---

## 🎯 **Key Testing Points**

### **✅ Must Test:**
1. **API Key Creation** - All types (standard, business, server-to-server, admin, testing)
2. **Domain Validation** - Correct domain, wrong domain, missing domain
3. **IP Fallback** - Requests without Origin/Referer headers
4. **Scope Validation** - Correct scopes, insufficient scopes
5. **Rate Limiting** - Normal usage, rate limit exceeded
6. **Server-to-Server** - Auto-detection via naming and scopes
7. **Error Handling** - Invalid keys, expired keys, inactive keys

### **✅ Angular Integration Points:**
1. **JWT Authentication** - Login and token management
2. **API Key Storage** - Secure storage of API keys
3. **Domain Headers** - Automatic Origin header setting
4. **Error Handling** - Proper error message display
5. **Rate Limit Handling** - Retry logic and user feedback

---

## 🚀 **Ready for Production**

Once all tests pass:

1. **✅ API Key Creation** works with all field combinations
2. **✅ Domain Validation** works with fallback strategies  
3. **✅ Scope Authorization** works correctly
4. **✅ Rate Limiting** enforces limits properly
5. **✅ Error Handling** provides clear messages
6. **✅ Angular Integration** works seamlessly

**Your API key system is production-ready!** 🎉

---

**Quick Start**: Import Postman collection → Login → Create API Key → Test endpoints → Integrate with Angular!
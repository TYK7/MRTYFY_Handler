# API Endpoints Reference

## Base URL
```
http://localhost:8080/api/v1
```

## Authentication Endpoints

### Login
```http
POST /auth/login
Content-Type: application/json

{
  "username": "string",
  "password": "string"
}
```

**Response (200):**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "userId": "user123",
  "expiresIn": 3600,
  "tokenType": "Bearer"
}
```

---

## API Key Management Endpoints

### 1. Create API Key (Standard)
```http
POST /api-keys?environment=production
Authorization: Bearer {jwt_token}
Content-Type: application/json

{
  "name": "My API Key",
  "description": "Description",
  "registeredDomain": "api.example.com",
  "allowedIps": ["192.168.1.100"],
  "allowedDomains": ["backup.example.com"],
  "rateLimitTier": "PRO_TIER",
  "scopes": ["READ_BASIC", "DOMAIN_HEALTH"],
  "expiresAt": "2024-12-31T23:59:59Z"
}
```

### 2. Create Enhanced API Key (Rivo)
```http
POST /api-keys/rivo-create-api?environment=production
Authorization: Bearer {jwt_token}
Content-Type: application/json

{
  "name": "Enhanced API Key",
  "description": "Enhanced features",
  "registeredDomain": "business.example.com",
  "allowedIps": ["203.0.113.10"],
  "allowedDomains": ["staging.business.example.com"],
  "rateLimitTier": "BUSINESS_TIER",
  "scopes": ["READ_ADVANCED", "WRITE_BASIC", "AI_SUMMARIES"]
}
```

### 3. Get All API Keys
```http
GET /api-keys?page=0&size=10&sort=createdAt,desc
Authorization: Bearer {jwt_token}
```

### 4. Get API Key by ID
```http
GET /api-keys/{keyId}
Authorization: Bearer {jwt_token}
```

### 5. Update API Key
```http
PUT /api-keys/{keyId}
Authorization: Bearer {jwt_token}
Content-Type: application/json

{
  "name": "Updated Name",
  "description": "Updated description",
  "isActive": true,
  "allowedIps": ["192.168.1.200"],
  "expiresAt": "2024-12-31T23:59:59Z"
}
```

### 6. Revoke API Key
```http
PATCH /api-keys/{keyId}/revoke
Authorization: Bearer {jwt_token}
```

### 7. Delete API Key
```http
DELETE /api-keys/{keyId}
Authorization: Bearer {jwt_token}
```

### 8. Get Plan Usage
```http
GET /api-keys/plan-usage
Authorization: Bearer {jwt_token}
```

**Response:**
```json
{
  "success": true,
  "plan": "PRO",
  "planDisplayName": "Pro Plan",
  "currentApiKeys": 2,
  "maxApiKeys": 3,
  "remainingApiKeys": 1,
  "currentDomains": 2,
  "maxDomains": 3,
  "remainingDomains": 1,
  "canCreateApiKey": true,
  "canClaimDomain": true,
  "monthlyApiCalls": 1000,
  "price": "$25/month",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

---

## Secure Endpoints

### RivoFetch
```http
POST /secure/rivofetch
x-api-key: sk-your-api-key
Origin: https://api.example.com
Content-Type: application/json

{
  "url": "https://jsonplaceholder.typicode.com/posts/1"
}
```

**Success Response (200):**
```json
{
  "success": true,
  "data": {
    "userId": 1,
    "id": 1,
    "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
    "body": "quia et suscipit..."
  },
  "metadata": {
    "requestId": "req_123456789",
    "timestamp": "2024-01-15T10:30:00Z",
    "responseTime": 245,
    "targetUrl": "https://jsonplaceholder.typicode.com/posts/1",
    "statusCode": 200
  },
  "usage": {
    "remainingCalls": 95,
    "resetTime": "2024-01-16T00:00:00Z"
  }
}
```

---

## Error Responses

### Standard Error Format
```json
{
  "success": false,
  "error": "Detailed error message",
  "errorCode": "ERROR_CODE",
  "timestamp": "2024-01-15T10:30:00Z",
  "requestId": "req_123456789",
  "details": {
    "field": "registeredDomain",
    "value": "invalid-domain",
    "suggestions": ["api.example.com", "app.example.com"]
  }
}
```

### Plan Limit Error
```json
{
  "success": false,
  "error": "API key limit exceeded for FREE plan. You have 1/1 API keys.",
  "errorCode": "API_KEY_LIMIT_EXCEEDED",
  "currentPlan": "FREE",
  "upgradeMessage": "Upgrade to PRO plan to create up to 3 API keys",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### Domain Conflict Error
```json
{
  "success": false,
  "error": "Domain 'api.example.com' is already registered by another API key",
  "errorCode": "DOMAIN_ALREADY_EXISTS",
  "domain": "api.example.com",
  "suggestions": [
    "app.example.com",
    "v1.example.com",
    "service.example.com"
  ],
  "timestamp": "2024-01-15T10:30:00Z"
}
```

---

## Rate Limit Headers

All API responses include rate limiting information:

```http
X-RateLimit-Limit: 50
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1642291200
X-RateLimit-Window: 86400
Retry-After: 3600
```

---

## HTTP Status Codes

| Code | Description | Common Scenarios |
|------|-------------|------------------|
| 200 | OK | Successful GET, PUT requests |
| 201 | Created | Successful API key creation |
| 204 | No Content | Successful DELETE, PATCH requests |
| 400 | Bad Request | Invalid request format, validation errors |
| 401 | Unauthorized | Missing/invalid JWT token or API key |
| 403 | Forbidden | Plan limits exceeded, insufficient permissions |
| 409 | Conflict | Domain already exists |
| 429 | Too Many Requests | Rate limit exceeded |
| 500 | Internal Server Error | Server-side errors |

---

## Request/Response Examples

### Complete API Key Creation Flow

**1. Login to get JWT token:**
```bash
curl -X POST "http://localhost:8080/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "password123"
  }'
```

**2. Create API key:**
```bash
curl -X POST "http://localhost:8080/api/v1/api-keys" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." \
  -d '{
    "name": "Production API Key",
    "description": "Main API key for production website",
    "registeredDomain": "api.mywebsite.com",
    "allowedIps": ["192.168.1.100"],
    "scopes": ["READ_BASIC", "DOMAIN_HEALTH", "READ_BRANDS"]
  }'
```

**3. Use API key for secure request:**
```bash
curl -X POST "http://localhost:8080/api/v1/secure/rivofetch" \
  -H "Content-Type: application/json" \
  -H "x-api-key: sk-1234567890abcdef..." \
  -H "Origin: https://api.mywebsite.com" \
  -d '{
    "url": "https://jsonplaceholder.typicode.com/posts/1"
  }'
```

### Development Environment Setup

**Create development API key:**
```bash
curl -X POST "http://localhost:8080/api/v1/api-keys?environment=development" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {jwt_token}" \
  -d '{
    "name": "Development API Key",
    "description": "For local development and testing",
    "registeredDomain": "localhost:3000",
    "allowedDomains": ["127.0.0.1:3000", "dev.localhost"],
    "scopes": ["READ_BASIC", "DOMAIN_HEALTH"]
  }'
```

**Test with localhost:**
```bash
curl -X POST "http://localhost:8080/api/v1/secure/rivofetch" \
  -H "Content-Type: application/json" \
  -H "x-api-key: sk-dev-key..." \
  -H "Origin: http://localhost:3000" \
  -d '{
    "url": "https://httpbin.org/json"
  }'
```

---

This reference provides all the essential endpoint information needed for integration with the JWT Authenticator API Key system.
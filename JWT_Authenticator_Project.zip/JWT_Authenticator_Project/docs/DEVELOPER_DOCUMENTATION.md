# JWT Authenticator API - Documentation Hub

> **🚀 Professional Brand Extraction & API Key Management Platform**

[![API Version](https://img.shields.io/badge/API%20Version-v1-blue)](https://api.yourcompany.com/v1)
[![Documentation](https://img.shields.io/badge/Documentation-Complete-green)](https://docs.yourcompany.com)
[![Support](https://img.shields.io/badge/Support-24%2F7-orange)](mailto:support@yourcompany.com)

---

## 📚 Documentation Suite

### **🎯 Choose Your Path**

| Document | Best For | Time to Complete |
|----------|----------|------------------|
| **[🚀 Quick Start Guide](./QUICK_START_INTEGRATION_GUIDE.md)** | Developers who want to integrate immediately | 10 minutes |
| **[📚 Complete API Reference](./API_REFERENCE.md)** | Detailed API specifications and examples | 30 minutes |
| **[📖 Enhanced Developer Guide](./ENHANCED_DEVELOPER_DOCUMENTATION.md)** | Comprehensive implementation guide | 60 minutes |
| **[📋 This Overview](./DEVELOPER_DOCUMENTATION.md)** | Understanding the platform and planning | 15 minutes |

---

## 🌟 What is JWT Authenticator API?

JWT Authenticator API is an **enterprise-grade platform** that provides:

### **🔑 Secure API Key Management**
- Domain-based validation and access control
- Multi-environment support (dev/staging/prod)
- IP whitelisting and advanced security features
- Plan-based access control with usage analytics

### **🎨 Advanced Brand Extraction (RivoFetch)**
- **Logos & Visual Assets**: Extract logos, icons, banners, symbols
- **Color Palettes**: Identify brand colors with hex codes and names
- **Typography**: Detect fonts and font stacks used
- **Company Information**: Business details, industry, social links
- **Performance Metrics**: Extraction time and success rates

### **📊 Professional Features**
- Real-time usage analytics and monitoring
- Rate limiting with intelligent headers
- Comprehensive error handling with suggestions
- Multi-tier plans (FREE, PRO, BUSINESS, ENTERPRISE)

---

## 🚀 Quick Start (5 Minutes)

### **1. Get Your API Key**
```bash
# Login and create API key
curl -X POST "https://api.yourcompany.com/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"username": "your-username", "password": "your-password"}'

# Use JWT token to create API key
curl -X POST "https://api.yourcompany.com/api/v1/api-keys" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{"name": "My API Key", "registeredDomain": "yourdomain.com"}'
```

### **2. Extract Brand Data**
```bash
# Extract comprehensive brand information
curl -X POST "https://api.yourcompany.com/api/v1/secure/rivofetch" \
  -H "x-api-key: sk-your-api-key" \
  -H "Origin: https://yourdomain.com" \
  -d '{"url": "https://github.com"}'
```

### **3. Integrate in Your App**
```javascript
// Simple JavaScript integration
const response = await fetch('/api/v1/secure/rivofetch', {
  method: 'POST',
  headers: {
    'x-api-key': 'sk-your-api-key',
    'Origin': 'https://yourdomain.com',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({ url: 'https://example.com' })
});

const brandData = await response.json();
console.log('Company:', brandData.Company?.Name);
console.log('Logo:', brandData.Logo?.Logo);
```

**👉 [Complete Quick Start Guide →](./QUICK_START_INTEGRATION_GUIDE.md)**

---

## 🎯 Use Cases & Business Value

### **🎨 Design & Creative Agencies**
```javascript
// Extract client brand assets automatically
const brandAssets = await extractBrand('https://client-website.com');
const designSystem = {
  logo: brandAssets.Logo.Logo,
  colors: brandAssets.Colors.map(c => c.hex),
  fonts: brandAssets.Fonts.map(f => f.name),
  // Use in design tools, presentations, proposals
};
```

### **📊 Market Research & Analytics**
```javascript
// Analyze competitor branding at scale
const competitors = ['competitor1.com', 'competitor2.com'];
const brandAnalysis = await Promise.all(
  competitors.map(url => extractBrand(url))
);
// Generate competitive analysis reports
```

### **🤝 Sales & CRM Integration**
```javascript
// Enrich prospect data automatically
const prospectData = await extractBrand(prospect.website);
const enrichedLead = {
  ...prospect,
  companyLogo: prospectData.Logo?.Logo,
  industry: prospectData.Company?.Industry,
  companySize: prospectData.Company?.Employees,
  socialLinks: prospectData.Company?.SocialLinks
};
```

### **💼 Enterprise Applications**
```javascript
// Brand monitoring and compliance
const brandData = await extractBrand('https://partner-website.com');
const complianceCheck = {
  logoUsage: validateLogoUsage(brandData.Logo),
  colorCompliance: checkBrandColors(brandData.Colors),
  brandConsistency: analyzeBrandConsistency(brandData)
};
```

---

## 📋 Table of Contents (Legacy Reference)

### **Core Features**
1. [API Key Management](#api-key-management)
2. [Brand Extraction (RivoFetch)](#brand-extraction-rivofetch)
3. [Authentication & Security](#authentication--security)
4. [Domain Management](#domain-management)

### **Advanced Topics**
5. [Plan-Based Access Control](#plan-based-access-control)
6. [Rate Limiting & Performance](#rate-limiting--performance)
7. [Error Handling](#error-handling)
8. [Monitoring & Analytics](#monitoring--analytics)

### **Implementation**
9. [SDK Examples](#sdk-examples)
10. [Best Practices](#best-practices)
11. [Production Deployment](#production-deployment)
12. [Troubleshooting](#troubleshooting)

---

## Quick Start Guide

### 1. Authentication
First, obtain a JWT token by logging in:

```bash
curl -X POST "http://localhost:8080/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "your-username",
    "password": "your-password"
  }'
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "userId": "user123",
  "expiresIn": 3600
}
```

### 2. Create Your First API Key
```bash
curl -X POST "http://localhost:8080/api/v1/api-keys" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "name": "My First API Key",
    "description": "API key for my website",
    "registeredDomain": "api.mywebsite.com"
  }'
```

**Response:**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "My First API Key",
  "keyValue": "sk-1234567890abcdef...",
  "registeredDomain": "api.mywebsite.com",
  "mainDomain": "mywebsite.com",
  "environment": "production",
  "scopes": "READ_BASIC,DOMAIN_HEALTH,READ_BRANDS",
  "rateLimitTier": "FREE_TIER",
  "isActive": true,
  "createdAt": "2024-01-15T10:30:00Z"
}
```

### 3. Use Your API Key
```bash
curl -X POST "http://localhost:8080/api/v1/secure/rivofetch" \
  -H "Content-Type: application/json" \
  -H "x-api-key: sk-1234567890abcdef..." \
  -H "Origin: https://api.mywebsite.com" \
  -d '{
    "url": "https://jsonplaceholder.typicode.com/posts/1"
  }'
```

---

## API Key Management

### Create API Key (Standard)

**Endpoint:** `POST /api/v1/api-keys`

**Headers:**
- `Authorization: Bearer {jwt_token}`
- `Content-Type: application/json`

**Parameters:**
- `environment` (query, optional): `production` | `development` | `staging` (default: `production`)

**Request Body:**
```json
{
  "name": "string (required, max 255 chars)",
  "description": "string (optional, max 1000 chars)",
  "registeredDomain": "string (required, valid domain format)",
  "allowedIps": ["string"] (optional),
  "allowedDomains": ["string"] (optional),
  "rateLimitTier": "string (optional)",
  "scopes": ["string"] (optional),
  "expiresAt": "ISO 8601 datetime (optional)"
}
```

**Example Request:**
```json
{
  "name": "Production API Key",
  "description": "Main API key for production website",
  "registeredDomain": "api.example.com",
  "allowedIps": ["192.168.1.100", "10.0.0.50"],
  "allowedDomains": ["backup.example.com"],
  "rateLimitTier": "PRO_TIER",
  "scopes": ["READ_BASIC", "READ_ADVANCED", "DOMAIN_HEALTH"]
}
```

**Success Response (201):**
```json
{
  "id": "uuid",
  "name": "Production API Key",
  "description": "Main API key for production website",
  "keyValue": "sk-abcd1234...",
  "registeredDomain": "api.example.com",
  "mainDomain": "example.com",
  "subdomainPattern": "*.example.com",
  "environment": "production",
  "allowedDomains": "backup.example.com",
  "allowedIps": "192.168.1.100,10.0.0.50",
  "scopes": "READ_BASIC,READ_ADVANCED,DOMAIN_HEALTH",
  "rateLimitTier": "PRO_TIER",
  "isActive": true,
  "expiresAt": null,
  "createdAt": "2024-01-15T10:30:00Z"
}
```

### Create Enhanced API Key (Rivo)

**Endpoint:** `POST /api/v1/api-keys/rivo-create-api`

This endpoint provides the same functionality as the standard creation endpoint but with enhanced features and validation. Both endpoints use identical validation logic and return the same response format.

### Get All API Keys

**Endpoint:** `GET /api/v1/api-keys`

**Headers:**
- `Authorization: Bearer {jwt_token}`

**Query Parameters:**
- `page` (optional): Page number (default: 0)
- `size` (optional): Page size (default: 20, max: 100)
- `sort` (optional): Sort criteria (e.g., `createdAt,desc`)

**Response:**
```json
{
  "content": [
    {
      "id": "uuid",
      "name": "API Key Name",
      "description": "Description",
      "registeredDomain": "api.example.com",
      "environment": "production",
      "scopes": "READ_BASIC,DOMAIN_HEALTH",
      "rateLimitTier": "FREE_TIER",
      "isActive": true,
      "createdAt": "2024-01-15T10:30:00Z",
      "lastUsed": "2024-01-15T15:45:00Z"
    }
  ],
  "totalElements": 5,
  "totalPages": 1,
  "size": 20,
  "number": 0
}
```

### Get API Key by ID

**Endpoint:** `GET /api/v1/api-keys/{keyId}`

**Headers:**
- `Authorization: Bearer {jwt_token}`

**Response:** Same as creation response (without `keyValue`)

### Update API Key

**Endpoint:** `PUT /api/v1/api-keys/{keyId}`

**Headers:**
- `Authorization: Bearer {jwt_token}`
- `Content-Type: application/json`

**Request Body:**
```json
{
  "name": "Updated Name",
  "description": "Updated description",
  "isActive": true,
  "allowedIps": ["192.168.1.200"],
  "expiresAt": "2024-12-31T23:59:59Z"
}
```

### Revoke API Key

**Endpoint:** `PATCH /api/v1/api-keys/{keyId}/revoke`

**Headers:**
- `Authorization: Bearer {jwt_token}`

**Response:** `204 No Content`

### Delete API Key

**Endpoint:** `DELETE /api/v1/api-keys/{keyId}`

**Headers:**
- `Authorization: Bearer {jwt_token}`

**Response:** `204 No Content`

### Get Plan Usage

**Endpoint:** `GET /api/v1/api-keys/plan-usage`

**Headers:**
- `Authorization: Bearer {jwt_token}`

**Response:**
```json
{
  "success": true,
  "plan": "PRO",
  "planDisplayName": "Pro Plan",
  "currentApiKeys": 2,
  "maxApiKeys": 3,
  "remainingApiKeys": 1,
  "currentDomains": 2,
  "maxDomains": 3,
  "remainingDomains": 1,
  "canCreateApiKey": true,
  "canClaimDomain": true,
  "monthlyApiCalls": 1000,
  "price": "$25/month",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

---

## Secure Endpoints

### RivoFetch Endpoint

**Endpoint:** `POST /api/v1/secure/rivofetch`

**Headers:**
- `x-api-key: {your_api_key}` (required)
- `Origin: {your_domain}` (required for domain validation)
- `Content-Type: application/json`

**Request Body:**
```json
{
  "url": "https://api.example.com/data"
}
```

**Success Response (200):**
```json
{
  "success": true,
  "data": {
    // Response from the target URL
  },
  "metadata": {
    "requestId": "req_123456789",
    "timestamp": "2024-01-15T10:30:00Z",
    "responseTime": 245,
    "targetUrl": "https://api.example.com/data",
    "statusCode": 200
  },
  "usage": {
    "remainingCalls": 95,
    "resetTime": "2024-01-16T00:00:00Z"
  }
}
```

**Error Response (401):**
```json
{
  "success": false,
  "error": "Invalid API key",
  "errorCode": "INVALID_API_KEY",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

---

## Authentication & Authorization

### API Key Authentication Methods

1. **Header Authentication (Recommended):**
   ```bash
   curl -H "x-api-key: sk-your-api-key" ...
   ```

2. **Bearer Token Authentication:**
   ```bash
   curl -H "Authorization: Bearer sk-your-api-key" ...
   ```

3. **Query Parameter (Not Recommended):**
   ```bash
   curl "https://api.example.com/endpoint?api_key=sk-your-api-key"
   ```

### Domain Validation

API keys are validated against the request's origin domain:

- **Origin Header:** `Origin: https://api.example.com`
- **Referer Header:** `Referer: https://api.example.com/page`

**Supported Domain Formats:**
- Standard domains: `api.example.com`
- Subdomains: `*.example.com` (if configured)
- Localhost: `localhost:3000`, `127.0.0.1:8080`
- IP addresses: `192.168.1.100:3000`

---

## Plan-Based Access Control

### Plan Comparison

| Feature | FREE | PRO | BUSINESS |
|---------|------|-----|----------|
| API Keys | 1 | 3 | 10 |
| Domains | 1 | 3 | 10 |
| Monthly Calls | 100 | 1,000 | Unlimited |
| Rate Limit | 50/day | 200/day | 1,000/day |
| Basic Scopes | ✅ | ✅ | ✅ |
| Advanced Scopes | ❌ | ✅ | ✅ |
| Write Permissions | ❌ | ❌ | ✅ |
| AI Features | ❌ | ❌ | ✅ |
| Analytics | ❌ | Read Only | Full Access |

### Scope Permissions

**Basic Scopes (All Plans):**
- `READ_BASIC`: Basic read access to public data
- `DOMAIN_HEALTH`: Access domain health monitoring
- `READ_BRANDS`: Read brand information

**Advanced Scopes (PRO+):**
- `READ_ADVANCED`: Advanced read access to detailed data
- `DOMAIN_INSIGHTS`: Access domain analytics and insights
- `READ_CATEGORIES`: Read category hierarchy
- `ANALYTICS_READ`: Read analytics data

**Business Scopes (BUSINESS only):**
- `WRITE_BASIC`: Basic write access to user data
- `WRITE_BRANDS`: Create and update brand information
- `AI_SUMMARIES`: Access AI-generated summaries
- `ANALYTICS_WRITE`: Write analytics data

---

## Domain Management

### Domain Processing

When you register a domain, the system automatically:

1. **Normalizes** the domain (lowercase, trim)
2. **Extracts** the main domain (`api.example.com` → `example.com`)
3. **Generates** subdomain patterns (`*.example.com`)
4. **Validates** format and availability

### Domain Validation Rules

**Valid Formats:**
- `api.example.com`
- `subdomain.example.co.uk`
- `localhost:3000`
- `192.168.1.100:8080`

**Invalid Formats:**
- `http://example.com` (no protocol)
- `example` (no TLD)
- `example.` (trailing dot)

### Development Domains

For development and testing:

```json
{
  "registeredDomain": "localhost:3000",
  "allowedDomains": ["127.0.0.1:3000", "dev.localhost"],
  "environment": "development"
}
```

---

## Error Handling

### Common Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `MISSING_API_KEY` | 401 | API key not provided |
| `INVALID_API_KEY` | 401 | API key not found or invalid |
| `API_KEY_INACTIVE` | 401 | API key is deactivated |
| `API_KEY_EXPIRED` | 401 | API key has expired |
| `DOMAIN_VALIDATION_FAILED` | 400 | Invalid domain format |
| `DOMAIN_ALREADY_EXISTS` | 409 | Domain already registered |
| `API_KEY_LIMIT_EXCEEDED` | 403 | Plan API key limit reached |
| `DOMAIN_LIMIT_EXCEEDED` | 403 | Plan domain limit reached |
| `MONTHLY_QUOTA_EXCEEDED` | 403 | Monthly API call limit reached |
| `RATE_LIMIT_EXCEEDED` | 429 | Rate limit exceeded |
| `INSUFFICIENT_PERMISSIONS` | 403 | Missing required scopes |

### Error Response Format

```json
{
  "success": false,
  "error": "Detailed error message",
  "errorCode": "ERROR_CODE",
  "timestamp": "2024-01-15T10:30:00Z",
  "requestId": "req_123456789",
  "details": {
    "field": "registeredDomain",
    "value": "invalid-domain",
    "suggestions": ["api.example.com", "app.example.com"]
  }
}
```

### Plan Limit Error Example

```json
{
  "success": false,
  "error": "API key limit exceeded for FREE plan. You have 1/1 API keys.",
  "errorCode": "API_KEY_LIMIT_EXCEEDED",
  "currentPlan": "FREE",
  "upgradeMessage": "Upgrade to PRO plan to create up to 3 API keys",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

---

## Rate Limiting

### Rate Limit Headers

All responses include rate limit information:

```
X-RateLimit-Limit: 50
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1642291200
X-RateLimit-Window: 86400
```

### Rate Limit Tiers

| Tier | Requests/Day | Window | Plans |
|------|--------------|--------|-------|
| FREE_TIER | 50 | 24 hours | FREE |
| PRO_TIER | 200 | 24 hours | PRO |
| BUSINESS_TIER | 1,000 | 24 hours | BUSINESS |

### Handling Rate Limits

```javascript
// Check rate limit headers
const remaining = response.headers['x-ratelimit-remaining'];
const resetTime = response.headers['x-ratelimit-reset'];

if (remaining < 10) {
  console.warn('Approaching rate limit');
}

// Handle 429 response
if (response.status === 429) {
  const retryAfter = response.headers['retry-after'];
  setTimeout(() => {
    // Retry request
  }, retryAfter * 1000);
}
```

---

## SDK Examples

### JavaScript/Node.js

```javascript
class JWTAuthenticatorClient {
  constructor(apiKey, baseUrl = 'http://localhost:8080') {
    this.apiKey = apiKey;
    this.baseUrl = baseUrl;
  }

  async rivofetch(url, options = {}) {
    const response = await fetch(`${this.baseUrl}/api/v1/secure/rivofetch`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': this.apiKey,
        'Origin': window.location.origin,
        ...options.headers
      },
      body: JSON.stringify({ url })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`API Error: ${error.error} (${error.errorCode})`);
    }

    return response.json();
  }
}

// Usage
const client = new JWTAuthenticatorClient('sk-your-api-key');

try {
  const result = await client.rivofetch('https://api.github.com/users/octocat');
  console.log(result.data);
} catch (error) {
  console.error('Error:', error.message);
}
```

### Python

```python
import requests
import json

class JWTAuthenticatorClient:
    def __init__(self, api_key, base_url='http://localhost:8080'):
        self.api_key = api_key
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            'x-api-key': api_key,
            'Content-Type': 'application/json'
        })

    def rivofetch(self, url, origin=None):
        headers = {}
        if origin:
            headers['Origin'] = origin
            
        response = self.session.post(
            f'{self.base_url}/api/v1/secure/rivofetch',
            json={'url': url},
            headers=headers
        )
        
        if not response.ok:
            error_data = response.json()
            raise Exception(f"API Error: {error_data['error']} ({error_data['errorCode']})")
            
        return response.json()

# Usage
client = JWTAuthenticatorClient('sk-your-api-key')

try:
    result = client.rivofetch(
        'https://api.github.com/users/octocat',
        origin='https://api.mywebsite.com'
    )
    print(result['data'])
except Exception as e:
    print(f'Error: {e}')
```

### cURL Examples

**Basic Request:**
```bash
curl -X POST "http://localhost:8080/api/v1/secure/rivofetch" \
  -H "Content-Type: application/json" \
  -H "x-api-key: sk-your-api-key" \
  -H "Origin: https://api.mywebsite.com" \
  -d '{"url": "https://jsonplaceholder.typicode.com/posts/1"}'
```

**With Error Handling:**
```bash
#!/bin/bash
API_KEY="sk-your-api-key"
ORIGIN="https://api.mywebsite.com"
TARGET_URL="https://api.github.com/users/octocat"

response=$(curl -s -w "%{http_code}" -X POST \
  "http://localhost:8080/api/v1/secure/rivofetch" \
  -H "Content-Type: application/json" \
  -H "x-api-key: $API_KEY" \
  -H "Origin: $ORIGIN" \
  -d "{\"url\": \"$TARGET_URL\"}")

http_code="${response: -3}"
body="${response%???}"

if [ "$http_code" -eq 200 ]; then
  echo "Success: $body"
else
  echo "Error ($http_code): $body"
fi
```

---

## Best Practices

### Security

1. **Store API Keys Securely:**
   - Use environment variables
   - Never commit keys to version control
   - Rotate keys regularly

2. **Domain Validation:**
   - Always set proper Origin headers
   - Use HTTPS in production
   - Validate domains on your end

3. **Error Handling:**
   - Implement proper error handling
   - Log errors for debugging
   - Don't expose sensitive information

### Performance

1. **Rate Limiting:**
   - Monitor rate limit headers
   - Implement exponential backoff
   - Cache responses when possible

2. **Connection Management:**
   - Reuse HTTP connections
   - Set appropriate timeouts
   - Handle network failures gracefully

### Development

1. **Environment Management:**
   - Use different API keys for dev/staging/prod
   - Set appropriate environment parameters
   - Test with localhost domains

2. **Monitoring:**
   - Track API usage and quotas
   - Monitor error rates
   - Set up alerts for limits

### Example Environment Configuration

```bash
# .env file
JWT_AUTH_API_KEY_DEV=sk-dev-key-123...
JWT_AUTH_API_KEY_STAGING=sk-staging-key-456...
JWT_AUTH_API_KEY_PROD=sk-prod-key-789...
JWT_AUTH_BASE_URL=http://localhost:8080
JWT_AUTH_ORIGIN=https://api.mywebsite.com
```

```javascript
// config.js
const config = {
  apiKey: process.env.NODE_ENV === 'production' 
    ? process.env.JWT_AUTH_API_KEY_PROD
    : process.env.JWT_AUTH_API_KEY_DEV,
  baseUrl: process.env.JWT_AUTH_BASE_URL,
  origin: process.env.JWT_AUTH_ORIGIN
};
```

---

## Troubleshooting

### Common Issues

1. **"Invalid API key" Error:**
   - Verify the API key is correct
   - Check if the key is active
   - Ensure the key hasn't expired

2. **"Domain validation failed" Error:**
   - Check Origin header is set correctly
   - Verify domain is registered for the API key
   - Ensure domain format is valid

3. **"Rate limit exceeded" Error:**
   - Check rate limit headers
   - Implement proper backoff strategy
   - Consider upgrading your plan

4. **"Plan limit exceeded" Error:**
   - Check current usage with `/plan-usage` endpoint
   - Upgrade to a higher plan
   - Remove unused API keys

### Debug Mode

Enable debug logging by setting the `DEBUG` environment variable:

```bash
DEBUG=jwt-auth:* node your-app.js
```

This will provide detailed logging of API requests and responses.

---

This documentation provides comprehensive guidance for integrating with the JWT Authenticator API Key system. For additional support, please refer to the API specification or contact the development team.
# Testing Guide: Secure API Access with Domain Validation

## 🧪 **Testing Overview**

This guide provides comprehensive testing scenarios for the secure API access system with domain-based validation. All tests support various domain types including `.com`, `.org`, `.io`, `.in`, `.co`, etc.

## 🚀 **Prerequisites**

1. **Application Running**: Start the application on `http://localhost:8080`
2. **JWT Token**: Obtain a valid JWT token for management endpoints
3. **Test Domains**: Use domains like `xamply.com`, `xamplyfy.co`, `xamplyfy.in` for testing

## 📋 **Test Scenarios**

### **Scenario 1: Create API Key with Domain**

#### **Test 1.1: Valid Domain Creation (.com)**

```bash
curl -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test API Key COM",
    "description": "Testing .com domain",
    "registeredDomain": "xamply.com",
    "rateLimitTier": "STANDARD"
  }'
```

**Expected Response (201):**
```json
{
  "id": "uuid-here",
  "name": "Test API Key COM",
  "keyValue": "sk-generated-key-here"
}
```

#### **Test 1.2: Valid Domain Creation (.co)**

```bash
curl -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test API Key CO",
    "description": "Testing .co domain",
    "registeredDomain": "xamplyfy.co",
    "rateLimitTier": "BASIC"
  }'
```

#### **Test 1.3: Valid Domain Creation (.in)**

```bash
curl -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test API Key IN",
    "description": "Testing .in domain",
    "registeredDomain": "xamplyfy.in",
    "rateLimitTier": "PREMIUM"
  }'
```

#### **Test 1.4: Valid Domain Creation (.io)**

```bash
curl -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test API Key IO",
    "description": "Testing .io domain",
    "registeredDomain": "api.startup.io",
    "rateLimitTier": "ENTERPRISE"
  }'
```

#### **Test 1.5: Invalid Domain Format**

```bash
curl -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Invalid Domain Test",
    "registeredDomain": "invalid-domain",
    "rateLimitTier": "BASIC"
  }'
```

**Expected Response (400):**
```json
{
  "error": "Invalid domain format. Supported formats: xamply.com, xamplyfy.co, xamplyfy.in, etc.",
  "errorCode": "INVALID_DOMAIN_FORMAT",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

#### **Test 1.6: Duplicate Domain**

```bash
# First, create an API key with xamply.com
# Then try to create another with the same domain
curl -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Duplicate Domain Test",
    "registeredDomain": "xamply.com",
    "rateLimitTier": "BASIC"
  }'
```

**Expected Response (400):**
```json
{
  "error": "Domain already registered to another API key: xamply.com",
  "errorCode": "DOMAIN_ALREADY_EXISTS",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### **Scenario 2: Domain Validation Testing**

#### **Test 2.1: Valid Domain Access (.com)**

```bash
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: YOUR_API_KEY_FOR_XAMPLY_COM" \
  -H "Origin: https://xamply.com" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://httpbin.org/json"
  }'
```

**Expected Response (200):** Successful forward with response data

#### **Test 2.2: Valid Domain Access (.co)**

```bash
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: YOUR_API_KEY_FOR_XAMPLYFY_CO" \
  -H "Origin: https://xamplyfy.co" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://httpbin.org/json"
  }'
```

#### **Test 2.3: Valid Domain Access (.in)**

```bash
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: YOUR_API_KEY_FOR_XAMPLYFY_IN" \
  -H "Origin: https://xamplyfy.in" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://httpbin.org/json"
  }'
```

#### **Test 2.4: Domain Mismatch**

```bash
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: YOUR_API_KEY_FOR_XAMPLY_COM" \
  -H "Origin: https://unauthorized.com" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://httpbin.org/json"
  }'
```

**Expected Response (403):**
```json
{
  "error": "Domain 'unauthorized.com' not allowed. Registered: 'xamply.com', Additional: []",
  "status": 403,
  "errorCode": "DOMAIN_NOT_ALLOWED",
  "timestamp": "2024-01-15T10:30:00Z",
  "requestDomain": "unauthorized.com",
  "expectedDomain": "xamply.com",
  "suggestions": [
    "Ensure your request includes Origin or Referer header",
    "Verify your domain is registered for this API key",
    "Check that your domain format is correct"
  ]
}
```

#### **Test 2.5: Missing Domain Header**

```bash
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://httpbin.org/json"
  }'
```

**Expected Response (403):**
```json
{
  "error": "Could not determine request domain. Ensure Origin, Referer, or Host header is set.",
  "status": 403,
  "errorCode": "MISSING_DOMAIN_HEADER",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

#### **Test 2.6: WWW Prefix Normalization**

```bash
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: YOUR_API_KEY_FOR_XAMPLY_COM" \
  -H "Origin: https://www.xamply.com" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://httpbin.org/json"
  }'
```

**Expected Response (200):** Should work (www.xamply.com normalized to xamply.com)

### **Scenario 3: Header Priority Testing**

#### **Test 3.1: Origin Header Priority**

```bash
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: YOUR_API_KEY_FOR_XAMPLY_COM" \
  -H "Origin: https://xamply.com" \
  -H "Referer: https://other.com/page" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://httpbin.org/json"
  }'
```

**Expected:** Should use Origin header (xamply.com) and succeed

#### **Test 3.2: Referer Header Fallback**

```bash
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: YOUR_API_KEY_FOR_XAMPLY_COM" \
  -H "Referer: https://xamply.com/dashboard" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://httpbin.org/json"
  }'
```

**Expected:** Should extract xamply.com from Referer and succeed

#### **Test 3.3: Host Header Fallback**

```bash
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: YOUR_API_KEY_FOR_XAMPLY_COM" \
  -H "Host: xamply.com" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://httpbin.org/json"
  }'
```

**Expected:** Should extract xamply.com from Host and succeed

### **Scenario 4: API Key Management Testing**

#### **Test 4.1: Check Domain Availability**

```bash
curl -X GET "http://localhost:8080/myapp/api/v1/api-keys/domain/check?domain=available.com" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

**Expected Response (200):**
```json
{
  "domain": "available.com",
  "available": true,
  "message": "Domain is available",
  "suggestions": []
}
```

#### **Test 4.2: Check Taken Domain**

```bash
curl -X GET "http://localhost:8080/myapp/api/v1/api-keys/domain/check?domain=xamply.com" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

**Expected Response (200):**
```json
{
  "domain": "xamply.com",
  "available": false,
  "message": "Domain already registered to another API key",
  "suggestions": [
    "xamply.org",
    "xamply.io",
    "xamply.co",
    "xamply.in",
    "xamply.net"
  ]
}
```

#### **Test 4.3: Get Domain Suggestions**

```bash
curl -X GET "http://localhost:8080/myapp/api/v1/api-keys/domain/suggestions?baseDomain=mycompany" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

**Expected Response (200):**
```json
{
  "baseDomain": "mycompany",
  "suggestions": [
    "mycompany.com",
    "mycompany.org",
    "mycompany.io",
    "mycompany.co",
    "mycompany.in"
  ]
}
```

#### **Test 4.4: Update API Key Domain**

```bash
curl -X PUT "http://localhost:8080/myapp/api/v1/api-keys/{keyId}/domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "domain": "newdomain.com"
  }'
```

#### **Test 4.5: Get API Keys with Domains**

```bash
curl -X GET "http://localhost:8080/myapp/api/v1/api-keys/with-domains" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

**Expected Response (200):** Array of API keys with domain information

### **Scenario 5: Rate Limiting Testing**

#### **Test 5.1: Rate Limit Headers**

```bash
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: YOUR_API_KEY" \
  -H "Origin: https://xamply.com" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://httpbin.org/json"
  }' \
  -v
```

**Expected Headers:**
```
X-RateLimit-Limit: 5000
X-RateLimit-Remaining: 4999
X-RateLimit-Tier: STANDARD
X-RateLimit-Total-Remaining: 5999
```

#### **Test 5.2: Rate Limit Exceeded**

```bash
# Make multiple rapid requests to exceed rate limit
for i in {1..100}; do
  curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
    -H "x-api-key: YOUR_BASIC_TIER_API_KEY" \
    -H "Origin: https://xamply.com" \
    -H "Content-Type: application/json" \
    -d '{"url": "https://httpbin.org/json"}' &
done
wait
```

**Expected Response (429):**
```json
{
  "error": "Rate limit exceeded. Try again later.",
  "status": 429,
  "errorCode": "RATE_LIMIT_EXCEEDED",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### **Scenario 6: Health Check Testing**

#### **Test 6.1: Valid Health Check**

```bash
curl -X GET "http://localhost:8080/myapp/api/secure/health" \
  -H "x-api-key: YOUR_API_KEY" \
  -H "Origin: https://xamply.com"
```

**Expected Response (200):**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-15T10:30:00Z",
  "apiKeyId": "uuid-here",
  "userId": "user-id-here",
  "requestDomain": "xamply.com",
  "matchedDomain": "xamply.com",
  "validationType": "PRIMARY_MATCH"
}
```

#### **Test 6.2: Health Check with Domain Mismatch**

```bash
curl -X GET "http://localhost:8080/myapp/api/secure/health" \
  -H "x-api-key: YOUR_API_KEY" \
  -H "Origin: https://unauthorized.com"
```

**Expected Response (403):** Domain validation error

## 🔧 **Automated Testing Script**

### **Bash Script for Comprehensive Testing**

```bash
#!/bin/bash

# Configuration
BASE_URL="http://localhost:8080/myapp"
JWT_TOKEN="YOUR_JWT_TOKEN_HERE"

echo "🧪 Starting Secure API Testing..."

# Test 1: Create API keys with different domains
echo "📝 Test 1: Creating API keys with various domains..."

create_api_key() {
  local name=$1
  local domain=$2
  local tier=$3
  
  curl -s -X POST "$BASE_URL/api/v1/api-keys/with-domain" \
    -H "Authorization: Bearer $JWT_TOKEN" \
    -H "Content-Type: application/json" \
    -d "{
      \"name\": \"$name\",
      \"registeredDomain\": \"$domain\",
      \"rateLimitTier\": \"$tier\"
    }" | jq -r '.keyValue'
}

# Create test API keys
API_KEY_COM=$(create_api_key "Test COM" "xamply.com" "STANDARD")
API_KEY_CO=$(create_api_key "Test CO" "xamplyfy.co" "BASIC")
API_KEY_IN=$(create_api_key "Test IN" "xamplyfy.in" "PREMIUM")
API_KEY_IO=$(create_api_key "Test IO" "api.startup.io" "ENTERPRISE")

echo "✅ Created API keys for different domains"

# Test 2: Domain validation
echo "🔒 Test 2: Testing domain validation..."

test_domain_access() {
  local api_key=$1
  local origin=$2
  local expected_status=$3
  
  status=$(curl -s -o /dev/null -w "%{http_code}" \
    -X POST "$BASE_URL/api/secure/forward" \
    -H "x-api-key: $api_key" \
    -H "Origin: $origin" \
    -H "Content-Type: application/json" \
    -d '{"url": "https://httpbin.org/json"}')
  
  if [ "$status" -eq "$expected_status" ]; then
    echo "✅ $origin with expected status $expected_status"
  else
    echo "❌ $origin expected $expected_status, got $status"
  fi
}

# Test valid domains
test_domain_access "$API_KEY_COM" "https://xamply.com" 200
test_domain_access "$API_KEY_CO" "https://xamplyfy.co" 200
test_domain_access "$API_KEY_IN" "https://xamplyfy.in" 200
test_domain_access "$API_KEY_IO" "https://api.startup.io" 200

# Test invalid domains
test_domain_access "$API_KEY_COM" "https://unauthorized.com" 403
test_domain_access "$API_KEY_CO" "https://wrong.domain" 403

# Test WWW normalization
test_domain_access "$API_KEY_COM" "https://www.xamply.com" 200

echo "🎉 All tests completed!"
```

## 📊 **Performance Testing**

### **Load Testing with Apache Bench**

```bash
# Test concurrent requests
ab -n 1000 -c 10 \
  -H "x-api-key: YOUR_API_KEY" \
  -H "Origin: https://xamply.com" \
  -H "Content-Type: application/json" \
  -p post_data.json \
  http://localhost:8080/myapp/api/secure/forward
```

### **Stress Testing Different Domains**

```bash
# Test .com domain
ab -n 500 -c 5 -H "x-api-key: $API_KEY_COM" -H "Origin: https://xamply.com" ...

# Test .co domain  
ab -n 500 -c 5 -H "x-api-key: $API_KEY_CO" -H "Origin: https://xamplyfy.co" ...

# Test .in domain
ab -n 500 -c 5 -H "x-api-key: $API_KEY_IN" -H "Origin: https://xamplyfy.in" ...
```

## 🐛 **Troubleshooting**

### **Common Issues**

1. **Domain Not Recognized**: Check domain format and TLD support
2. **WWW Issues**: System automatically normalizes www.domain.com to domain.com
3. **Case Sensitivity**: All domains are normalized to lowercase
4. **Missing Headers**: Ensure Origin, Referer, or Host header is present
5. **Rate Limiting**: Check rate limit headers and tier limits

### **Debug Commands**

```bash
# Check domain normalization
curl -X GET "$BASE_URL/api/v1/api-keys/domain/check?domain=WWW.XAMPLY.COM" \
  -H "Authorization: Bearer $JWT_TOKEN"

# Test health endpoint for debugging
curl -X GET "$BASE_URL/api/secure/health" \
  -H "x-api-key: YOUR_API_KEY" \
  -H "Origin: https://xamply.com" \
  -v
```

---

**Last Updated**: January 2024  
**Version**: 1.0.0
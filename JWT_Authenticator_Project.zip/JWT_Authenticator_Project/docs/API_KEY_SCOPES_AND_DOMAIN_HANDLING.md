# 🔐 API Key Scopes & Missing Domain Header Handling

## 📋 **Complete Scope System Overview**

This document explains how API key scopes work and how they integrate with the automatic handling of missing domain headers.

---

## 🎯 **Available API Key Scopes**

### **📖 Read Permissions**
```
READ_USERS        - Read user information and profiles
READ_BRANDS       - Read brand information and assets  
READ_CATEGORIES   - Read category hierarchy and information
READ_API_KEYS     - Read own API key information
```

### **✏️ Write Permissions**
```
WRITE_USERS       - Create and update user information
WRITE_BRANDS      - Create and update brand information
WRITE_CATEGORIES  - Create and update categories
```

### **🗑️ Delete Permissions**
```
DELETE_USERS      - Delete user accounts
DELETE_BRANDS     - Delete brands and assets
DELETE_CATEGORIES - Delete categories
```

### **🔑 API Key Management**
```
MANAGE_API_KEYS   - Full API key management capabilities
REVOKE_API_KEYS   - Revoke and deactivate API keys
```

### **👑 Admin Permissions**
```
ADMIN_ACCESS      - Access administrative functions
SYSTEM_MONITOR    - Monitor system health and metrics
```

### **⭐ Special Permissions**
```
FULL_ACCESS       - Complete system access (super admin equivalent)
```

### **💼 Business API Permissions**
```
BUSINESS_READ     - Read business-related data via API
BUSINESS_WRITE    - Write business-related data via API
```

### **🔗 Server-to-Server Permissions** *(NEW)*
```
SERVER_ACCESS     - Server-to-server communication access
BACKEND_API       - Backend service API access
SERVICE_ACCESS    - Microservice communication access
INTERNAL_API      - Internal API access (bypasses domain validation)
```

### **🌐 Domain Bypass Permissions** *(NEW)*
```
DOMAINLESS_ACCESS - Explicit permission to bypass domain validation
```

---

## 🔄 **How Scopes Enable Missing Domain Header Handling**

### **Strategy 1: Server-to-Server Auto-Detection**

**Scopes that trigger server-to-server bypass:**
```java
// These scopes automatically bypass domain validation
"FULL_ACCESS"      // Complete system access
"ADMIN_ACCESS"     // Admin access  
"SYSTEM_MONITOR"   // System monitoring
"MANAGE_API_KEYS"  // API key management
"BUSINESS_READ"    // Business API (often server-to-server)
"BUSINESS_WRITE"   // Business API (often server-to-server)
"SERVER_ACCESS"    // Explicit server-to-server ⭐ NEW
"BACKEND_API"      // Backend service API ⭐ NEW
"SERVICE_ACCESS"   // Microservice communication ⭐ NEW
"INTERNAL_API"     // Internal API access ⭐ NEW
```

**Example API Key Creation:**
```bash
curl -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Backend Service Key",
    "registeredDomain": "api.company.com",
    "scopes": ["SERVER_ACCESS", "BACKEND_API", "BUSINESS_READ"],
    "rateLimitTier": "ENTERPRISE"
  }'
```

**Result**: This API key will **automatically bypass domain validation** and work without Origin/Referer headers.

### **Strategy 2: Special Scope Bypass**

**Scopes that allow domain-less access:**
```java
// These scopes explicitly bypass domain validation
"FULL_ACCESS"       // Complete system access
"ADMIN_ACCESS"      // Admin access
"SYSTEM_MONITOR"    // System monitoring
"DOMAINLESS_ACCESS" // Explicit domain bypass ⭐ NEW
```

**Example API Key Creation:**
```bash
curl -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Admin System Key",
    "registeredDomain": "admin.company.com",
    "scopes": ["FULL_ACCESS"],
    "rateLimitTier": "UNLIMITED"
  }'
```

**Result**: This API key will **bypass all domain validation** regardless of headers.

---

## 🧪 **Testing Different Scope Combinations**

### **Test 1: Server-to-Server API Key**
```bash
# Create server-to-server API key
API_KEY=$(curl -s -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Production Backend",
    "registeredDomain": "api.company.com",
    "scopes": ["SERVER_ACCESS", "BUSINESS_READ", "BUSINESS_WRITE"],
    "rateLimitTier": "ENTERPRISE"
  }' | jq -r '.keyValue')

# Test without domain headers (should work)
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://external-api.com/data"}'

# ✅ SUCCESS: Server-to-server scope bypass
```

### **Test 2: Admin Access API Key**
```bash
# Create admin API key
ADMIN_KEY=$(curl -s -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "System Administrator",
    "registeredDomain": "admin.company.com",
    "scopes": ["ADMIN_ACCESS", "SYSTEM_MONITOR"],
    "rateLimitTier": "UNLIMITED"
  }' | jq -r '.keyValue')

# Test without domain headers (should work)
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: $ADMIN_KEY" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://monitoring-api.com/metrics"}'

# ✅ SUCCESS: Admin scope bypass
```

### **Test 3: Regular API Key (No Special Scopes)**
```bash
# Create regular API key
REGULAR_KEY=$(curl -s -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Website API Key",
    "registeredDomain": "website.company.com",
    "scopes": ["READ_USERS", "READ_BRANDS"],
    "allowedIps": ["203.0.113.45", "192.168.1.0/24"],
    "rateLimitTier": "STANDARD"
  }' | jq -r '.keyValue')

# Test without domain headers (should work via IP fallback)
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: $REGULAR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://external-api.com/data"}'

# ✅ SUCCESS: IP fallback validation (if IP is in allowed list)
# ❌ BLOCKED: If IP is not in allowed list
```

### **Test 4: Explicit Domain Bypass**
```bash
# Create API key with explicit domain bypass
BYPASS_KEY=$(curl -s -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Testing API Key",
    "registeredDomain": "test.company.com",
    "scopes": ["DOMAINLESS_ACCESS", "READ_USERS"],
    "rateLimitTier": "STANDARD"
  }' | jq -r '.keyValue')

# Test without domain headers (should work)
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: $BYPASS_KEY" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://test-api.com/data"}'

# ✅ SUCCESS: Explicit domain bypass scope
```

---

## 📊 **Scope-Based Fallback Decision Matrix**

| **Scope** | **Server-to-Server Bypass** | **Special Scope Bypass** | **Requires IP Fallback** |
|-----------|------------------------------|---------------------------|---------------------------|
| `FULL_ACCESS` | ✅ Yes | ✅ Yes | ❌ No |
| `ADMIN_ACCESS` | ✅ Yes | ✅ Yes | ❌ No |
| `SERVER_ACCESS` | ✅ Yes | ❌ No | ❌ No |
| `BACKEND_API` | ✅ Yes | ❌ No | ❌ No |
| `SERVICE_ACCESS` | ✅ Yes | ❌ No | ❌ No |
| `INTERNAL_API` | ✅ Yes | ❌ No | ❌ No |
| `SYSTEM_MONITOR` | ✅ Yes | ✅ Yes | ❌ No |
| `DOMAINLESS_ACCESS` | ❌ No | ✅ Yes | ❌ No |
| `BUSINESS_READ` | ✅ Yes | ❌ No | ❌ No |
| `BUSINESS_WRITE` | ✅ Yes | ❌ No | ❌ No |
| `MANAGE_API_KEYS` | ✅ Yes | ❌ No | ❌ No |
| `READ_USERS` | ❌ No | ❌ No | ✅ Yes |
| `WRITE_USERS` | ❌ No | ❌ No | ✅ Yes |
| `READ_BRANDS` | ❌ No | ❌ No | ✅ Yes |

---

## 🔍 **Validation Flow with Scopes**

```
Request without domain headers
           ↓
    Check API key scopes
           ↓
┌─────────────────────────────────────┐
│  Has Special Bypass Scopes?        │
│  - FULL_ACCESS                      │
│  - ADMIN_ACCESS                     │
│  - SYSTEM_MONITOR                   │
│  - DOMAINLESS_ACCESS                │
│                                     │
│  ✅ YES → Allow immediately         │
└─────────────────────────────────────┘
           ↓ NO
┌─────────────────────────────────────┐
│  Has Server-to-Server Scopes?      │
│  - SERVER_ACCESS                    │
│  - BACKEND_API                      │
│  - SERVICE_ACCESS                   │
│  - INTERNAL_API                     │
│  - BUSINESS_READ/WRITE              │
│  - MANAGE_API_KEYS                  │
│                                     │
│  ✅ YES → Allow (server-to-server)  │
└─────────────────────────────────────┘
           ↓ NO
┌─────────────────────────────────────┐
│  Check IP Fallback                  │
│  - Extract client IP automatically  │
│  - Validate against allowed IPs     │
│                                     │
│  ✅ IP allowed → Allow              │
│  ❌ IP not allowed → Block          │
└─────────────────────────────────────┘
```

---

## 🎯 **Recommended Scope Combinations**

### **For Server-to-Server Communication:**
```json
{
  "scopes": ["SERVER_ACCESS", "BACKEND_API", "BUSINESS_READ"]
}
```
**Result**: Automatic domain bypass + business API access

### **For Admin/System Tools:**
```json
{
  "scopes": ["ADMIN_ACCESS", "SYSTEM_MONITOR", "MANAGE_API_KEYS"]
}
```
**Result**: Complete domain bypass + admin capabilities

### **For Testing/Development:**
```json
{
  "scopes": ["DOMAINLESS_ACCESS", "READ_USERS", "READ_BRANDS"]
}
```
**Result**: Domain bypass for testing + limited read access

### **For Regular Applications:**
```json
{
  "scopes": ["READ_USERS", "WRITE_BRANDS"],
  "allowedIps": ["203.0.113.45", "192.168.1.0/24"]
}
```
**Result**: Normal domain validation + IP fallback

### **For Full System Access:**
```json
{
  "scopes": ["FULL_ACCESS"]
}
```
**Result**: Bypasses all validation + complete access

---

## 🚀 **Integration Examples**

### **Java Spring Boot Service:**
```java
@Service
public class ExternalApiService {
    
    @Value("${app.server-api-key}")
    private String serverApiKey; // Has SERVER_ACCESS scope
    
    public ResponseEntity<String> callExternalApi(String url) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("x-api-key", serverApiKey);
        headers.set("Content-Type", "application/json");
        // No Origin header needed - SERVER_ACCESS scope bypasses domain validation
        
        HttpEntity<Map<String, String>> entity = new HttpEntity<>(
            Map.of("url", url), headers
        );
        
        return restTemplate.postForEntity(
            "http://localhost:8080/myapp/api/secure/forward",
            entity,
            String.class
        );
        // ✅ Success: SERVER_ACCESS scope bypass
    }
}
```

### **Node.js Microservice:**
```javascript
const axios = require('axios');

// API key with BACKEND_API scope
const backendApiKey = process.env.BACKEND_API_KEY;

async function callForwardApi(targetUrl) {
    try {
        const response = await axios.post(
            'http://localhost:8080/myapp/api/secure/forward',
            { url: targetUrl },
            {
                headers: {
                    'x-api-key': backendApiKey,
                    'Content-Type': 'application/json'
                    // No Origin header needed - BACKEND_API scope bypasses domain validation
                }
            }
        );
        
        return response.data;
        // ✅ Success: BACKEND_API scope bypass
    } catch (error) {
        console.error('API call failed:', error.message);
        throw error;
    }
}
```

### **Python Admin Script:**
```python
import requests
import os

# API key with ADMIN_ACCESS scope
admin_api_key = os.getenv('ADMIN_API_KEY')

def monitor_system():
    response = requests.post(
        'http://localhost:8080/myapp/api/secure/forward',
        headers={
            'x-api-key': admin_api_key,
            'Content-Type': 'application/json'
            # No Origin header needed - ADMIN_ACCESS scope bypasses domain validation
        },
        json={'url': 'https://monitoring-api.com/health'}
    )
    
    if response.status_code == 200:
        return response.json()
        # ✅ Success: ADMIN_ACCESS scope bypass
    else:
        raise Exception(f'API call failed: {response.status_code}')
```

---

## 📋 **Summary: Scopes & Domain Handling**

### **✅ Scopes that Bypass Domain Validation:**

**Complete Bypass (Special Scopes):**
- `FULL_ACCESS` - Complete system access
- `ADMIN_ACCESS` - Administrative access
- `SYSTEM_MONITOR` - System monitoring
- `DOMAINLESS_ACCESS` - Explicit domain bypass

**Server-to-Server Bypass:**
- `SERVER_ACCESS` - Server communication
- `BACKEND_API` - Backend services
- `SERVICE_ACCESS` - Microservices
- `INTERNAL_API` - Internal APIs
- `BUSINESS_READ/WRITE` - Business APIs
- `MANAGE_API_KEYS` - API management

### **✅ Scopes that Require IP Fallback:**
- All other scopes (`READ_USERS`, `WRITE_BRANDS`, etc.)
- Must have `allowedIps` configured for missing domain handling

### **✅ Result:**
**No more `MISSING_DOMAIN_HEADER` errors when scopes are configured correctly!**

The system automatically detects scope-based permissions and applies the appropriate fallback strategy without any user intervention.

---

**Last Updated**: January 2024  
**Version**: 2.0.0# 🔐 API Key Scopes & Missing Domain Header Handling

## 📋 **Complete Scope System Overview**

This document explains how API key scopes work and how they integrate with the automatic handling of missing domain headers.

---

## 🎯 **Available API Key Scopes**

### **📖 Read Permissions**
```
READ_USERS        - Read user information and profiles
READ_BRANDS       - Read brand information and assets  
READ_CATEGORIES   - Read category hierarchy and information
READ_API_KEYS     - Read own API key information
```

### **✏️ Write Permissions**
```
WRITE_USERS       - Create and update user information
WRITE_BRANDS      - Create and update brand information
WRITE_CATEGORIES  - Create and update categories
```

### **🗑️ Delete Permissions**
```
DELETE_USERS      - Delete user accounts
DELETE_BRANDS     - Delete brands and assets
DELETE_CATEGORIES - Delete categories
```

### **🔑 API Key Management**
```
MANAGE_API_KEYS   - Full API key management capabilities
REVOKE_API_KEYS   - Revoke and deactivate API keys
```

### **👑 Admin Permissions**
```
ADMIN_ACCESS      - Access administrative functions
SYSTEM_MONITOR    - Monitor system health and metrics
```

### **⭐ Special Permissions**
```
FULL_ACCESS       - Complete system access (super admin equivalent)
```

### **💼 Business API Permissions**
```
BUSINESS_READ     - Read business-related data via API
BUSINESS_WRITE    - Write business-related data via API
```

### **🔗 Server-to-Server Permissions** *(NEW)*
```
SERVER_ACCESS     - Server-to-server communication access
BACKEND_API       - Backend service API access
SERVICE_ACCESS    - Microservice communication access
INTERNAL_API      - Internal API access (bypasses domain validation)
```

### **🌐 Domain Bypass Permissions** *(NEW)*
```
DOMAINLESS_ACCESS - Explicit permission to bypass domain validation
```

---

## 🔄 **How Scopes Enable Missing Domain Header Handling**

### **Strategy 1: Server-to-Server Auto-Detection**

**Scopes that trigger server-to-server bypass:**
```java
// These scopes automatically bypass domain validation
"FULL_ACCESS"      // Complete system access
"ADMIN_ACCESS"     // Admin access  
"SYSTEM_MONITOR"   // System monitoring
"MANAGE_API_KEYS"  // API key management
"BUSINESS_READ"    // Business API (often server-to-server)
"BUSINESS_WRITE"   // Business API (often server-to-server)
"SERVER_ACCESS"    // Explicit server-to-server ⭐ NEW
"BACKEND_API"      // Backend service API ⭐ NEW
"SERVICE_ACCESS"   // Microservice communication ⭐ NEW
"INTERNAL_API"     // Internal API access ⭐ NEW
```

**Example API Key Creation:**
```bash
curl -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Backend Service Key",
    "registeredDomain": "api.company.com",
    "scopes": ["SERVER_ACCESS", "BACKEND_API", "BUSINESS_READ"],
    "rateLimitTier": "ENTERPRISE"
  }'
```

**Result**: This API key will **automatically bypass domain validation** and work without Origin/Referer headers.

### **Strategy 2: Special Scope Bypass**

**Scopes that allow domain-less access:**
```java
// These scopes explicitly bypass domain validation
"FULL_ACCESS"       // Complete system access
"ADMIN_ACCESS"      // Admin access
"SYSTEM_MONITOR"    // System monitoring
"DOMAINLESS_ACCESS" // Explicit domain bypass ⭐ NEW
```

**Example API Key Creation:**
```bash
curl -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Admin System Key",
    "registeredDomain": "admin.company.com",
    "scopes": ["FULL_ACCESS"],
    "rateLimitTier": "UNLIMITED"
  }'
```

**Result**: This API key will **bypass all domain validation** regardless of headers.

---

## 🧪 **Testing Different Scope Combinations**

### **Test 1: Server-to-Server API Key**
```bash
# Create server-to-server API key
API_KEY=$(curl -s -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Production Backend",
    "registeredDomain": "api.company.com",
    "scopes": ["SERVER_ACCESS", "BUSINESS_READ", "BUSINESS_WRITE"],
    "rateLimitTier": "ENTERPRISE"
  }' | jq -r '.keyValue')

# Test without domain headers (should work)
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://external-api.com/data"}'

# ✅ SUCCESS: Server-to-server scope bypass
```

### **Test 2: Admin Access API Key**
```bash
# Create admin API key
ADMIN_KEY=$(curl -s -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "System Administrator",
    "registeredDomain": "admin.company.com",
    "scopes": ["ADMIN_ACCESS", "SYSTEM_MONITOR"],
    "rateLimitTier": "UNLIMITED"
  }' | jq -r '.keyValue')

# Test without domain headers (should work)
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: $ADMIN_KEY" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://monitoring-api.com/metrics"}'

# ✅ SUCCESS: Admin scope bypass
```

### **Test 3: Regular API Key (No Special Scopes)**
```bash
# Create regular API key
REGULAR_KEY=$(curl -s -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Website API Key",
    "registeredDomain": "website.company.com",
    "scopes": ["READ_USERS", "READ_BRANDS"],
    "allowedIps": ["203.0.113.45", "192.168.1.0/24"],
    "rateLimitTier": "STANDARD"
  }' | jq -r '.keyValue')

# Test without domain headers (should work via IP fallback)
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: $REGULAR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://external-api.com/data"}'

# ✅ SUCCESS: IP fallback validation (if IP is in allowed list)
# ❌ BLOCKED: If IP is not in allowed list
```

### **Test 4: Explicit Domain Bypass**
```bash
# Create API key with explicit domain bypass
BYPASS_KEY=$(curl -s -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Testing API Key",
    "registeredDomain": "test.company.com",
    "scopes": ["DOMAINLESS_ACCESS", "READ_USERS"],
    "rateLimitTier": "STANDARD"
  }' | jq -r '.keyValue')

# Test without domain headers (should work)
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: $BYPASS_KEY" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://test-api.com/data"}'

# ✅ SUCCESS: Explicit domain bypass scope
```

---

## 📊 **Scope-Based Fallback Decision Matrix**

| **Scope** | **Server-to-Server Bypass** | **Special Scope Bypass** | **Requires IP Fallback** |
|-----------|------------------------------|---------------------------|---------------------------|
| `FULL_ACCESS` | ✅ Yes | ✅ Yes | ❌ No |
| `ADMIN_ACCESS` | ✅ Yes | ✅ Yes | ❌ No |
| `SERVER_ACCESS` | ✅ Yes | ❌ No | ❌ No |
| `BACKEND_API` | ✅ Yes | ❌ No | ❌ No |
| `SERVICE_ACCESS` | ✅ Yes | ❌ No | ❌ No |
| `INTERNAL_API` | ✅ Yes | ❌ No | ❌ No |
| `SYSTEM_MONITOR` | ✅ Yes | ✅ Yes | ❌ No |
| `DOMAINLESS_ACCESS` | ❌ No | ✅ Yes | ❌ No |
| `BUSINESS_READ` | ✅ Yes | ❌ No | ❌ No |
| `BUSINESS_WRITE` | ✅ Yes | ❌ No | ❌ No |
| `MANAGE_API_KEYS` | ✅ Yes | ❌ No | ❌ No |
| `READ_USERS` | ❌ No | ❌ No | ✅ Yes |
| `WRITE_USERS` | ❌ No | ❌ No | ✅ Yes |
| `READ_BRANDS` | ❌ No | ❌ No | ✅ Yes |

---

## 🔍 **Validation Flow with Scopes**

```
Request without domain headers
           ↓
    Check API key scopes
           ↓
┌─────────────────────────────────────┐
│  Has Special Bypass Scopes?        │
│  - FULL_ACCESS                      │
│  - ADMIN_ACCESS                     │
│  - SYSTEM_MONITOR                   │
│  - DOMAINLESS_ACCESS                │
│                                     │
│  ✅ YES → Allow immediately         │
└─────────────────────────────────────┘
           ↓ NO
┌─────────────────────────────────────┐
│  Has Server-to-Server Scopes?      │
│  - SERVER_ACCESS                    │
│  - BACKEND_API                      │
│  - SERVICE_ACCESS                   │
│  - INTERNAL_API                     │
│  - BUSINESS_READ/WRITE              │
│  - MANAGE_API_KEYS                  │
│                                     │
│  ✅ YES → Allow (server-to-server)  │
└─────────────────────────────────────┘
           ↓ NO
┌─────────────────────────────────────┐
│  Check IP Fallback                  │
│  - Extract client IP automatically  │
│  - Validate against allowed IPs     │
│                                     │
│  ✅ IP allowed → Allow              │
│  ❌ IP not allowed → Block          │
└─────────────────────────────────────┘
```

---

## 🎯 **Recommended Scope Combinations**

### **For Server-to-Server Communication:**
```json
{
  "scopes": ["SERVER_ACCESS", "BACKEND_API", "BUSINESS_READ"]
}
```
**Result**: Automatic domain bypass + business API access

### **For Admin/System Tools:**
```json
{
  "scopes": ["ADMIN_ACCESS", "SYSTEM_MONITOR", "MANAGE_API_KEYS"]
}
```
**Result**: Complete domain bypass + admin capabilities

### **For Testing/Development:**
```json
{
  "scopes": ["DOMAINLESS_ACCESS", "READ_USERS", "READ_BRANDS"]
}
```
**Result**: Domain bypass for testing + limited read access

### **For Regular Applications:**
```json
{
  "scopes": ["READ_USERS", "WRITE_BRANDS"],
  "allowedIps": ["203.0.113.45", "192.168.1.0/24"]
}
```
**Result**: Normal domain validation + IP fallback

### **For Full System Access:**
```json
{
  "scopes": ["FULL_ACCESS"]
}
```
**Result**: Bypasses all validation + complete access

---

## 🚀 **Integration Examples**

### **Java Spring Boot Service:**
```java
@Service
public class ExternalApiService {
    
    @Value("${app.server-api-key}")
    private String serverApiKey; // Has SERVER_ACCESS scope
    
    public ResponseEntity<String> callExternalApi(String url) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("x-api-key", serverApiKey);
        headers.set("Content-Type", "application/json");
        // No Origin header needed - SERVER_ACCESS scope bypasses domain validation
        
        HttpEntity<Map<String, String>> entity = new HttpEntity<>(
            Map.of("url", url), headers
        );
        
        return restTemplate.postForEntity(
            "http://localhost:8080/myapp/api/secure/forward",
            entity,
            String.class
        );
        // ✅ Success: SERVER_ACCESS scope bypass
    }
}
```

### **Node.js Microservice:**
```javascript
const axios = require('axios');

// API key with BACKEND_API scope
const backendApiKey = process.env.BACKEND_API_KEY;

async function callForwardApi(targetUrl) {
    try {
        const response = await axios.post(
            'http://localhost:8080/myapp/api/secure/forward',
            { url: targetUrl },
            {
                headers: {
                    'x-api-key': backendApiKey,
                    'Content-Type': 'application/json'
                    // No Origin header needed - BACKEND_API scope bypasses domain validation
                }
            }
        );
        
        return response.data;
        // ✅ Success: BACKEND_API scope bypass
    } catch (error) {
        console.error('API call failed:', error.message);
        throw error;
    }
}
```

### **Python Admin Script:**
```python
import requests
import os

# API key with ADMIN_ACCESS scope
admin_api_key = os.getenv('ADMIN_API_KEY')

def monitor_system():
    response = requests.post(
        'http://localhost:8080/myapp/api/secure/forward',
        headers={
            'x-api-key': admin_api_key,
            'Content-Type': 'application/json'
            # No Origin header needed - ADMIN_ACCESS scope bypasses domain validation
        },
        json={'url': 'https://monitoring-api.com/health'}
    )
    
    if response.status_code == 200:
        return response.json()
        # ✅ Success: ADMIN_ACCESS scope bypass
    else:
        raise Exception(f'API call failed: {response.status_code}')
```

---

## 📋 **Summary: Scopes & Domain Handling**

### **✅ Scopes that Bypass Domain Validation:**

**Complete Bypass (Special Scopes):**
- `FULL_ACCESS` - Complete system access
- `ADMIN_ACCESS` - Administrative access
- `SYSTEM_MONITOR` - System monitoring
- `DOMAINLESS_ACCESS` - Explicit domain bypass

**Server-to-Server Bypass:**
- `SERVER_ACCESS` - Server communication
- `BACKEND_API` - Backend services
- `SERVICE_ACCESS` - Microservices
- `INTERNAL_API` - Internal APIs
- `BUSINESS_READ/WRITE` - Business APIs
- `MANAGE_API_KEYS` - API management

### **✅ Scopes that Require IP Fallback:**
- All other scopes (`READ_USERS`, `WRITE_BRANDS`, etc.)
- Must have `allowedIps` configured for missing domain handling

### **✅ Result:**
**No more `MISSING_DOMAIN_HEADER` errors when scopes are configured correctly!**

The system automatically detects scope-based permissions and applies the appropriate fallback strategy without any user intervention.

---

**Last Updated**: January 2024  
**Version**: 2.0.0
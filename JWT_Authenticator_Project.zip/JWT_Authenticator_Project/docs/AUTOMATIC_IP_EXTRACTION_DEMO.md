# 🔍 Automatic IP Address Extraction - No User Input Required

## ✅ **How It Works (Completely Automatic)**

The system automatically extracts the client IP address from HTTP request headers **WITHOUT requiring any user input**. Users don't need to provide IP addresses - the system gets them automatically.

## 🌐 **Automatic IP Header Detection**

The system checks these headers in priority order:

### **Priority 1: X-Forwarded-For** (Most Common)
```bash
# When user makes request through proxy/load balancer
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: sk-your-key" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://httpbin.org/json"}'

# System automatically detects:
# X-Forwarded-For: 203.0.113.45, 198.51.100.1, 192.0.2.1
# Extracts: 203.0.113.45 (original client IP)
```

### **Priority 2: X-Real-IP** (Nginx)
```bash
# Nginx proxy automatically adds this header
# X-Real-IP: 203.0.113.45
# System extracts: 203.0.113.45
```

### **Priority 3: X-Client-IP** (Apache)
```bash
# Apache proxy automatically adds this header
# X-Client-IP: 203.0.113.45
# System extracts: 203.0.113.45
```

### **Priority 4: CF-Connecting-IP** (Cloudflare)
```bash
# Cloudflare automatically adds this header
# CF-Connecting-IP: 203.0.113.45
# System extracts: 203.0.113.45
```

### **Priority 5: RemoteAddr** (Direct Connection)
```bash
# Direct connection without proxy
# request.getRemoteAddr() = 203.0.113.45
# System extracts: 203.0.113.45
```

## 🧪 **Real-World Test Scenarios**

### **Scenario 1: Direct API Call (No Domain Headers)**

```bash
# User makes this simple call (NO IP provided by user)
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: sk-your-key-with-ip-restrictions" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://external-api.com/data"}'

# System automatically:
# 1. Detects no Origin/Referer headers
# 2. Extracts IP from request: 127.0.0.1 (or actual client IP)
# 3. Validates against API key's allowed IPs
# 4. ✅ Success if IP is in allowed list
# 5. ❌ Blocked if IP is not in allowed list
```

### **Scenario 2: Behind Load Balancer**

```bash
# User makes request through AWS ALB/ELB
curl -X POST "https://api.company.com/secure/forward" \
  -H "x-api-key: sk-production-key" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://external-service.com/api"}'

# Load balancer automatically adds headers:
# X-Forwarded-For: 203.0.113.45, 10.0.1.100
# X-Real-IP: 203.0.113.45

# System automatically:
# 1. Detects X-Forwarded-For header
# 2. Extracts first IP: 203.0.113.45 (original client)
# 3. Validates against allowed IPs
# 4. ✅ Success if 203.0.113.45 is allowed
```

### **Scenario 3: Behind Cloudflare CDN**

```bash
# User makes request through Cloudflare
curl -X POST "https://api.company.com/secure/forward" \
  -H "x-api-key: sk-cdn-key" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://backend-api.com/data"}'

# Cloudflare automatically adds:
# CF-Connecting-IP: 203.0.113.45
# X-Forwarded-For: 203.0.113.45

# System automatically:
# 1. Detects CF-Connecting-IP header
# 2. Extracts IP: 203.0.113.45
# 3. Validates against allowed IPs
# 4. ✅ Success if IP is allowed
```

### **Scenario 4: Mobile App**

```javascript
// React Native app makes request
fetch('https://api.company.com/secure/forward', {
  method: 'POST',
  headers: {
    'x-api-key': 'sk-mobile-key',
    'Content-Type': 'application/json'
    // NO IP provided by developer
  },
  body: JSON.stringify({url: 'https://data-api.com/mobile'})
});

// System automatically:
// 1. Detects mobile carrier IP from headers
// 2. Extracts IP: 198.51.100.123 (mobile carrier IP)
// 3. Validates against allowed mobile IP ranges
// 4. ✅ Success if mobile IP range is allowed
```

## 🔧 **API Key Configuration for IP Fallback**

### **Step 1: Create API Key with IP Restrictions**

```bash
# Create API key with allowed IPs (user provides these during setup)
curl -X POST "http://localhost:8080/myapp/api/v1/api-keys/with-domain" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Server API Key",
    "description": "For server-to-server communication",
    "registeredDomain": "api.company.com",
    "allowedIps": [
      "203.0.113.45",           // Specific server IP
      "192.168.1.0/24",         // Office network
      "10.0.0.0/8",             // Internal network
      "198.51.100.0/24"         // Mobile carrier range
    ],
    "rateLimitTier": "ENTERPRISE"
  }'
```

### **Step 2: Use API Key (IP Extracted Automatically)**

```bash
# Server makes request (NO IP provided in request)
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: sk-generated-server-key" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://external-api.com/data"}'

# System automatically:
# 1. No domain headers found
# 2. Extracts server IP: 203.0.113.45
# 3. Checks against allowed IPs: [203.0.113.45, 192.168.1.0/24, ...]
# 4. ✅ Match found: 203.0.113.45 is in allowed list
# 5. Request succeeds with IP fallback validation
```

## 📊 **Automatic IP Extraction Log Examples**

### **Success Case:**
```
2024-01-15 10:30:00 INFO  - No domain headers found for API key: abc123 - Attempting IP fallback validation
2024-01-15 10:30:00 INFO  - Checking IP header 'X-Forwarded-For': '203.0.113.45, 10.0.1.100'
2024-01-15 10:30:00 INFO  - Client IP extracted from 'X-Forwarded-For' header (first in chain): 203.0.113.45
2024-01-15 10:30:00 INFO  - Validating automatically extracted IP '203.0.113.45' against allowed IPs: [203.0.113.45, 192.168.1.0/24]
2024-01-15 10:30:00 INFO  - ✅ IP match found: 203.0.113.45 matches allowed IP 203.0.113.45
2024-01-15 10:30:00 INFO  - ✅ IP fallback validation successful for API key: abc123 - IP: 203.0.113.45
2024-01-15 10:30:00 INFO  - API key validation successful via IP fallback for POST /api/secure/forward - IP: '203.0.113.45', Time: 15ms
```

### **Blocked Case:**
```
2024-01-15 10:30:00 INFO  - No domain headers found for API key: abc123 - Attempting IP fallback validation
2024-01-15 10:30:00 INFO  - Client IP from direct connection (RemoteAddr): 198.51.100.999
2024-01-15 10:30:00 INFO  - Validating automatically extracted IP '198.51.100.999' against allowed IPs: [203.0.113.45, 192.168.1.0/24]
2024-01-15 10:30:00 WARN  - ❌ IP validation failed: 198.51.100.999 not in allowed IPs [203.0.113.45, 192.168.1.0/24]
2024-01-15 10:30:00 WARN  - ❌ IP fallback validation failed for API key: abc123 - IP: 198.51.100.999 not in allowed list
```

## 🎯 **Response Examples**

### **Success with IP Fallback:**
```json
{
  "data": "forwarded response from external API",
  "headers": {
    "X-RateLimit-Limit": "5000",
    "X-RateLimit-Remaining": "4999",
    "X-Validation-Type": "IP_FALLBACK",
    "X-Client-IP": "203.0.113.45"
  }
}
```

### **Blocked - IP Not Allowed:**
```json
{
  "error": "Access denied. No domain headers found and IP address 198.51.100.999 is not in allowed list. Either include Origin/Referer header or add IP to allowed list.",
  "status": 403,
  "errorCode": "IP_NOT_ALLOWED_NO_DOMAIN",
  "timestamp": "2024-01-15T10:30:00Z",
  "clientIp": "198.51.100.999",
  "allowedIps": ["203.0.113.45", "192.168.1.0/24"],
  "suggestions": [
    "Add your IP address to the API key's allowed IP list",
    "Include Origin or Referer header in your request",
    "Contact administrator to update IP restrictions"
  ]
}
```

## 🔒 **Security Benefits**

### **✅ Automatic Security:**
1. **No User Input Required**: IP extracted from standard HTTP headers
2. **Proxy-Aware**: Handles load balancers, CDNs, proxies correctly
3. **CIDR Support**: Supports IP ranges (192.168.1.0/24)
4. **Priority-Based**: Uses most reliable IP source available
5. **Fallback Chain**: Multiple header sources for reliability

### **✅ Supported Network Scenarios:**
- **Direct Connection**: `request.getRemoteAddr()`
- **Load Balancer**: `X-Forwarded-For`, `X-Real-IP`
- **CDN (Cloudflare)**: `CF-Connecting-IP`
- **Proxy (Apache)**: `X-Client-IP`
- **Cluster**: `X-Cluster-Client-IP`

## 🧪 **Testing Different Network Setups**

### **Test 1: Direct Connection**
```bash
# From server with IP 203.0.113.45
curl -X POST "http://localhost:8080/myapp/api/secure/forward" \
  -H "x-api-key: sk-server-key" \
  -d '{"url": "https://api.example.com"}'
# System extracts: 203.0.113.45 from RemoteAddr
```

### **Test 2: Behind Nginx Proxy**
```bash
# Nginx adds X-Real-IP header automatically
curl -X POST "https://api.company.com/secure/forward" \
  -H "x-api-key: sk-proxy-key" \
  -d '{"url": "https://api.example.com"}'
# System extracts: client IP from X-Real-IP header
```

### **Test 3: Behind AWS Load Balancer**
```bash
# ALB adds X-Forwarded-For automatically
curl -X POST "https://api.company.com/secure/forward" \
  -H "x-api-key: sk-aws-key" \
  -d '{"url": "https://api.example.com"}'
# System extracts: original client IP from X-Forwarded-For
```

## 📋 **Summary**

### **✅ Completely Automatic:**
- **No user input required** for IP address
- **No special headers** needed from user
- **No configuration** required in request
- **Works with all network setups** (direct, proxy, CDN, load balancer)

### **✅ How It Works:**
1. **User makes API call** with just `x-api-key` header
2. **System automatically detects** no domain headers
3. **System automatically extracts** IP from request headers
4. **System automatically validates** IP against allowed list
5. **Request succeeds or fails** based on IP validation

### **✅ User Experience:**
- **Simple API calls** - just include API key
- **No network knowledge required** - system handles all IP detection
- **Works everywhere** - mobile, server, browser, proxy environments
- **Secure by default** - only allowed IPs can access

**Result**: Users get seamless API access without domain headers, while maintaining security through automatic IP validation.

---

**Last Updated**: January 2024  
**Version**: 2.0.0
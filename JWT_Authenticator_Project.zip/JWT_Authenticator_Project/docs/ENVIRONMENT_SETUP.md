# Environment Setup Guide

## Prerequisites

- Java 17 or higher
- Maven 3.6+
- PostgreSQL 12+
- Redis (optional, for rate limiting)
- Git

## Database Setup

### 1. PostgreSQL Installation

**Windows:**
```bash
# Download and install PostgreSQL from https://www.postgresql.org/download/windows/
# Or use Chocolatey
choco install postgresql
```

**macOS:**
```bash
brew install postgresql
brew services start postgresql
```

**Linux (Ubuntu):**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

### 2. Database Configuration

**Create database and user:**
```sql
-- Connect as postgres user
sudo -u postgres psql

-- Create database
CREATE DATABASE jwt_authenticator;

-- Create user
CREATE USER jwt_user WITH PASSWORD 'your_password';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE jwt_authenticator TO jwt_user;

-- Exit
\q
```

### 3. Database Schema

The application will automatically create tables on startup using JPA/Hibernate. Key tables include:

- `users` - User accounts and plans
- `api_keys` - API key storage and metadata
- `monthly_usage` - Monthly API call tracking
- `request_logs` - Request logging (optional)

## Application Configuration

### 1. Environment Variables

Create a `.env` file in the project root:

```bash
# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=jwt_authenticator
DB_USERNAME=jwt_user
DB_PASSWORD=your_password

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-here-make-it-long-and-random
JWT_EXPIRATION=86400

# Redis Configuration (optional)
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=

# Application Configuration
SERVER_PORT=8080
CORS_ALLOWED_ORIGINS=http://localhost:3000,https://yourdomain.com

# Logging
LOG_LEVEL=INFO
LOG_FILE=logs/application.log

# Rate Limiting
RATE_LIMIT_ENABLED=true
RATE_LIMIT_REDIS_ENABLED=false

# Development Settings
SPRING_PROFILES_ACTIVE=development
```

### 2. Application Properties

**application.yml:**
```yaml
spring:
  application:
    name: jwt-authenticator
  
  datasource:
    url: jdbc:postgresql://${DB_HOST:localhost}:${DB_PORT:5432}/${DB_NAME:jwt_authenticator}
    username: ${DB_USERNAME:jwt_user}
    password: ${DB_PASSWORD:password}
    driver-class-name: org.postgresql.Driver
    
  jpa:
    hibernate:
      ddl-auto: update
    show-sql: false
    properties:
      hibernate:
        dialect: org.hibernate.dialect.PostgreSQLDialect
        format_sql: true
    
  redis:
    host: ${REDIS_HOST:localhost}
    port: ${REDIS_PORT:6379}
    password: ${REDIS_PASSWORD:}
    timeout: 2000ms
    
server:
  port: ${SERVER_PORT:8080}
  servlet:
    context-path: /api/v1

jwt:
  secret: ${JWT_SECRET:default-secret-change-in-production}
  expiration: ${JWT_EXPIRATION:86400}

cors:
  allowed-origins: ${CORS_ALLOWED_ORIGINS:http://localhost:3000}

logging:
  level:
    com.example.jwtauthenticator: ${LOG_LEVEL:INFO}
    org.springframework.security: DEBUG
  file:
    name: ${LOG_FILE:logs/application.log}

management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics
  endpoint:
    health:
      show-details: always
```

**application-development.yml:**
```yaml
spring:
  jpa:
    show-sql: true
    hibernate:
      ddl-auto: create-drop
      
logging:
  level:
    com.example.jwtauthenticator: DEBUG
    org.springframework.web: DEBUG
    
cors:
  allowed-origins: http://localhost:3000,http://127.0.0.1:3000,http://localhost:8080
```

**application-production.yml:**
```yaml
spring:
  jpa:
    show-sql: false
    hibernate:
      ddl-auto: validate
      
logging:
  level:
    com.example.jwtauthenticator: WARN
    root: ERROR
    
server:
  error:
    include-stacktrace: never
```

## Build and Run

### 1. Clone Repository
```bash
git clone <repository-url>
cd JWT_Authenticator_Project
```

### 2. Build Application
```bash
# Clean and compile
mvn clean compile

# Run tests
mvn test

# Package application
mvn package -DskipTests
```

### 3. Run Application

**Development Mode:**
```bash
# Using Maven
mvn spring-boot:run -Dspring-boot.run.profiles=development

# Using Java
java -jar target/brandsnap-api-1.0.0.jar --spring.profiles.active=development
```

**Production Mode:**
```bash
java -jar target/brandsnap-api-1.0.0.jar --spring.profiles.active=production
```

### 4. Docker Setup (Optional)

**Dockerfile:**
```dockerfile
FROM openjdk:17-jdk-slim

WORKDIR /app

COPY target/brandsnap-api-1.0.0.jar app.jar

EXPOSE 8080

ENTRYPOINT ["java", "-jar", "app.jar"]
```

**docker-compose.yml:**
```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "8080:8080"
    environment:
      - SPRING_PROFILES_ACTIVE=production
      - DB_HOST=postgres
      - REDIS_HOST=redis
    depends_on:
      - postgres
      - redis
    networks:
      - jwt-auth-network

  postgres:
    image: postgres:13
    environment:
      POSTGRES_DB: jwt_authenticator
      POSTGRES_USER: jwt_user
      POSTGRES_PASSWORD: your_password
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
    networks:
      - jwt-auth-network

  redis:
    image: redis:6-alpine
    ports:
      - "6379:6379"
    networks:
      - jwt-auth-network

volumes:
  postgres_data:

networks:
  jwt-auth-network:
    driver: bridge
```

**Run with Docker:**
```bash
# Build and start
docker-compose up --build

# Run in background
docker-compose up -d

# View logs
docker-compose logs -f app

# Stop
docker-compose down
```

## Initial Data Setup

### 1. Create Test User

**SQL Script (create_test_user.sql):**
```sql
-- Insert test user
INSERT INTO users (id, username, email, password, plan, created_at, updated_at) 
VALUES (
  'testuser01',
  'testuser',
  'test@example.com',
  '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',  -- password: password123
  'FREE',
  NOW(),
  NOW()
);
```

**Run the script:**
```bash
psql -h localhost -U jwt_user -d jwt_authenticator -f create_test_user.sql
```

### 2. API Testing Script

**test_setup.sh:**
```bash
#!/bin/bash

BASE_URL="http://localhost:8080/api/v1"

echo "Testing JWT Authenticator API..."

# 1. Login
echo "1. Logging in..."
LOGIN_RESPONSE=$(curl -s -X POST "$BASE_URL/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "password123"
  }')

JWT_TOKEN=$(echo $LOGIN_RESPONSE | jq -r '.token')

if [ "$JWT_TOKEN" = "null" ]; then
  echo "❌ Login failed"
  echo $LOGIN_RESPONSE
  exit 1
fi

echo "✅ Login successful"

# 2. Create API Key
echo "2. Creating API key..."
API_KEY_RESPONSE=$(curl -s -X POST "$BASE_URL/api-keys" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -d '{
    "name": "Test API Key",
    "description": "Test API key for setup verification",
    "registeredDomain": "localhost:3000"
  }')

API_KEY=$(echo $API_KEY_RESPONSE | jq -r '.keyValue')

if [ "$API_KEY" = "null" ]; then
  echo "❌ API key creation failed"
  echo $API_KEY_RESPONSE
  exit 1
fi

echo "✅ API key created: $API_KEY"

# 3. Test Secure Endpoint
echo "3. Testing secure endpoint..."
SECURE_RESPONSE=$(curl -s -X POST "$BASE_URL/secure/rivofetch" \
  -H "Content-Type: application/json" \
  -H "x-api-key: $API_KEY" \
  -H "Origin: http://localhost:3000" \
  -d '{
    "url": "https://jsonplaceholder.typicode.com/posts/1"
  }')

SUCCESS=$(echo $SECURE_RESPONSE | jq -r '.success')

if [ "$SUCCESS" = "true" ]; then
  echo "✅ Secure endpoint test successful"
else
  echo "❌ Secure endpoint test failed"
  echo $SECURE_RESPONSE
  exit 1
fi

echo "🎉 All tests passed! Setup is complete."
echo "JWT Token: $JWT_TOKEN"
echo "API Key: $API_KEY"
```

**Make executable and run:**
```bash
chmod +x test_setup.sh
./test_setup.sh
```

## Development Tools

### 1. IDE Configuration

**IntelliJ IDEA:**
- Install Spring Boot plugin
- Configure run configuration with active profile: `development`
- Set environment variables in run configuration

**VS Code:**
- Install Java Extension Pack
- Install Spring Boot Extension Pack
- Configure launch.json:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "java",
      "name": "JWT Authenticator",
      "request": "launch",
      "mainClass": "com.example.jwtauthenticator.JwtAuthenticatorApplication",
      "projectName": "brandsnap-api",
      "env": {
        "SPRING_PROFILES_ACTIVE": "development"
      }
    }
  ]
}
```

### 2. Database Tools

**pgAdmin (GUI):**
```bash
# Install pgAdmin
# Windows: Download from https://www.pgadmin.org/download/pgadmin-4-windows/
# macOS: brew install --cask pgadmin4
# Linux: sudo apt install pgadmin4
```

**Command Line:**
```bash
# Connect to database
psql -h localhost -U jwt_user -d jwt_authenticator

# Useful commands
\dt          # List tables
\d api_keys  # Describe api_keys table
\q           # Quit
```

### 3. API Testing Tools

**Postman:**
- Import the provided collection
- Set up environment variables
- Configure authentication

**HTTPie:**
```bash
# Install HTTPie
pip install httpie

# Test login
http POST localhost:8080/api/v1/auth/login username=testuser password=password123

# Test API key creation
http POST localhost:8080/api/v1/api-keys \
  Authorization:"Bearer $JWT_TOKEN" \
  name="Test Key" \
  registeredDomain="localhost:3000"
```

## Monitoring and Logging

### 1. Application Logs

**Log Configuration:**
```yaml
logging:
  level:
    com.example.jwtauthenticator: INFO
    org.springframework.security: DEBUG
  pattern:
    console: "%d{yyyy-MM-dd HH:mm:ss} - %msg%n"
    file: "%d{yyyy-MM-dd HH:mm:ss} [%thread] %-5level %logger{36} - %msg%n"
  file:
    name: logs/application.log
    max-size: 10MB
    max-history: 30
```

### 2. Health Checks

**Endpoints:**
- Health: `GET /actuator/health`
- Info: `GET /actuator/info`
- Metrics: `GET /actuator/metrics`

**Custom Health Check:**
```bash
curl http://localhost:8080/actuator/health
```

**Response:**
```json
{
  "status": "UP",
  "components": {
    "db": {
      "status": "UP",
      "details": {
        "database": "PostgreSQL",
        "validationQuery": "isValid()"
      }
    },
    "redis": {
      "status": "UP",
      "details": {
        "version": "6.2.6"
      }
    }
  }
}
```

## Troubleshooting

### Common Issues

**1. Database Connection Failed:**
```bash
# Check PostgreSQL is running
sudo systemctl status postgresql

# Check connection
psql -h localhost -U jwt_user -d jwt_authenticator -c "SELECT 1;"

# Check firewall
sudo ufw status
```

**2. Port Already in Use:**
```bash
# Find process using port 8080
lsof -i :8080

# Kill process
kill -9 <PID>

# Or change port in application.yml
server:
  port: 8081
```

**3. JWT Token Issues:**
```bash
# Check JWT secret is set
echo $JWT_SECRET

# Verify token format
echo "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." | base64 -d
```

**4. API Key Validation Errors:**
```bash
# Check API key format
echo "sk-1234567890abcdef..." | wc -c  # Should be > 20 characters

# Verify domain in Origin header
curl -v -H "Origin: http://localhost:3000" ...
```

### Debug Mode

**Enable debug logging:**
```yaml
logging:
  level:
    com.example.jwtauthenticator: DEBUG
    org.springframework.security: DEBUG
    org.springframework.web: DEBUG
```

**Or via environment:**
```bash
export LOGGING_LEVEL_COM_EXAMPLE_JWTAUTHENTICATOR=DEBUG
java -jar app.jar
```

This setup guide provides everything needed to get the JWT Authenticator API Key system running in development and production environments.